﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_TDS
{
    public class Invoice
    {

        public string InvoiceNumber { get; set; }
        public string TVoucherNumber { get; set; }
        public string TTDSCode { get; set; }
        public string TDateofTaxDeduction { get; set; }
        public double TAmountofpaymentcredit { get; set; }
        public double TTotalTDS { get; set; }
        public string TRate { get; set; }
        public string PanNumber { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorCdAYQtrId { get; set; }
        public string PanNumberInExcel { get; set; }
    }
}
