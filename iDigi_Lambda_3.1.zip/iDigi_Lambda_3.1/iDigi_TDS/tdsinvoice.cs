﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_TDS
{
    class TdsInvoice
    {
        public string VendorRegisteredCd { get; set; }
        public string AYQtr { get; set; }
        public string TDSId_UniqueId { get; set; }
        public string AssessmentYear { get; set; }
        public string Quarter { get; set; }
        public string PanNumber { get; set; }
        public string PanNumberInExcel { get; set; }
        public string TDSCertificateUploaded { get; set; }
        public string TDSCertificateName { get; set; }
        public string SummaryInvoiceExcelUploaded { get; set; }
        public string SummaryInvoiceExcelName { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public List<TDSDetailsHistory> History { get; set; }
        public string IsMailSent { get; set; }



    }
    public class TDSDetailsHistory
    {
        public string DocName { get; set; }
        public string DocUploadedDt { get; set; }
        public string DocUploadedBy { get; set; }

    }
}
