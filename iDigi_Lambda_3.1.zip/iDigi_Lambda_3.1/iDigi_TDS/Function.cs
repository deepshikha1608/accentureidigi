
using System;
using System.Threading.Tasks;
using Amazon.Lambda.Model;
using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.Lambda;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.S3.Model;
using iDigi_TDS;
using CsvHelper;
using System.Linq;
using System.Collections.Generic;
using Amazon.DynamoDBv2;
using System.Diagnostics;
using Newtonsoft.Json;
using Amazon.DynamoDBv2.Model;
using Ionic.Zip;
using System.IO;
using iTextSharp.text.pdf;
using System.Collections;
using System.Text;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_TDS
{
    public class Function
    {


        IAmazonS3 S3Client { get; set; }
        IAmazonDynamoDB DbClient { get; set; }
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            S3Client = new AmazonS3Client();
            DbClient = new AmazonDynamoDBClient();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
            
           
        }
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public static TimeZoneInfo INDIAN_ZONE
        {

            get
            {
                if (System.Environment.GetEnvironmentVariable("DebugEnvironMent") == "true")
                { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                }
                //return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            }
        }

        

        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            Amazon.Lambda.Model.InvokeRequest invokeRequest = new InvokeRequest();
            invokeRequest.FunctionName = "";
            invokeRequest.InvocationType = InvocationType.Event;
            DateTime datetime = new DateTime();
            string invoiceTable = string.Empty;
            string TDStable = string.Empty;
            string vendorMasterTable = string.Empty;
            string TDSAssessmentYr_VendorRegisteredCd_Index = string.Empty;

            DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);

            string tdsPrivatecsvFolder = CommonConstants.Private_Folder + "/" + CommonConstants.tds_FilePath + "/" + CommonConstants.tdsPrivatecsvFolder;
            string tdsCsvDumpFolder = CommonConstants.Public_Folder + "/" + CommonConstants.tds_FilePath + "/" + CommonConstants.tds_summaryexcel;
            string tdsZipDumpFolder = CommonConstants.Public_Folder + "/" + CommonConstants.tds_FilePath + "/" + CommonConstants.tds_ZipFile;
            string tdsZipCertificatesFolder = CommonConstants.Private_Folder + "/" + CommonConstants.tds_FilePath + "/" + CommonConstants.tds_Certificates;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                invoiceTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                TDStable = CommonConstants.AirId + "_" + CommonConstants.TDSTable;
            }
            else
            {
                invoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                TDStable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.TDSTable;               
            }
            try
            {

                IDigiDynamoDb db = new IDigiDynamoDb();
                string bucketName = evnt.Records[0].S3.Bucket.Name;
                string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')));
                #region summaryexcel
                if (fileName.ToLowerInvariant().Contains("summaryexcel"))
                {
                     fileName = fileName.Replace(tdsCsvDumpFolder + "/", "");
                    string fileUploaderName = (fileName.Split('_'))[0];
                    string QuarterSelected = (fileName.Split('_'))[1];
                    string Assesmentyear = (fileName.Split('_'))[2];
                    var CSVFileData = await GetFileFromS3(bucketName, tdsCsvDumpFolder, fileName, context);
                    var scanFilterTDSTable = new ScanFilter();
                    scanFilterTDSTable.AddCondition("VendorCdAYQtrId", ScanOperator.Contains, Assesmentyear + '_' + QuarterSelected);
                    ScanOperationConfig scanOperationConfigTDSTable = new ScanOperationConfig()
                    {
                        Filter = scanFilterTDSTable,
                        //Select = SelectValues.SpecificAttributes,
                        //AttributesToGet = new List<string> { "VendorRegisteredCd", "Assesmentyear", "QuarterSelected" }
                    };
                    Table table = Table.LoadTable(DbClient, invoiceTable);
                    Search search = table.Scan(scanOperationConfigTDSTable);
                    List<Document> listOfDocument = new List<Document>();
                    do
                    {
                        List<Document> documentList = await search.GetNextSetAsync();
                        foreach (var document in documentList)
                        {
                            listOfDocument.Add(document);
                        }
                    } while (!search.IsDone);
                    Console.WriteLine($"Data: Total items in invoice table {listOfDocument.Count}");

                    if (listOfDocument.Count > 0)
                    {

                        //result = result.Where(x => x.Assesmentyear == Assesmentyear && x.QuarterSelected == QuarterSelected).ToList();
                        //context.Logger.Log($"count of data from TDSinvoiceSummary : {result.Count}");
                        DeleteTheData(listOfDocument, table, context);

                    }
                    else
                    {
                        context.Logger.Log($"No data fetched from TDSinvoiceSummary ");
                    }
                    context.Logger.Log($"fetching data from vendormastertable");
                    var filter = new ScanFilter();
                    filter.AddCondition("PAN", ScanOperator.IsNotNull);
                    var mastertable = await db.ScanAsync<VendorMasterEntities>(filter, vendorMasterTable, context);

                    if (mastertable != null)
                    {
                        context.Logger.Log($"count from vendormaster : {mastertable.Count}");
                    }
                    else
                    {
                        context.Logger.Log($"No data fetched from vendormaster ");
                    }
                    using (var csvReadData = new System.IO.StreamReader(CSVFileData.ResponseStream))
                    {
                        context.Logger.Log($"Proccess :Now StreamReader is reading the data from the csv file");
                        var csv = new CsvReader(csvReadData);
                        csv.Configuration.HasHeaderRecord = false;
                        VendorMasterEntities vendordetail = new VendorMasterEntities();
                        List<TdsInvoice> tdslist = new List<TdsInvoice>();
                        while (csv.Read())
                        {

                            string iscorrect = string.Empty;
                            string rowType = csv.GetField<string>(0);
                            if (!string.IsNullOrWhiteSpace(rowType))
                            {
                                if (rowType == "T-Voucher No")
                                {
                                }
                                else
                                {
                                    try
                                    {
                                        TdsInvoice tdsinvoice = new TdsInvoice();
                                        Invoice invoice = new Invoice();
                                        invoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        invoice.ModifiedBy = CommonConstants.rtpTeam;
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                        {
                                            invoice.TVoucherNumber = csv.GetField<string>(0);
                                        }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                                        {
                                            invoice.TTDSCode = csv.GetField<string>(1);
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                                        {
                                            
                                            invoice.VendorRegisteredCd = csv.GetField<string>(2);
                                           // var vendorData = mastertable.Where(X => X.ParentVendorId == invoice.VendorRegisteredCd && X.VendorUserId.);
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                        {
                                            invoice.TDateofTaxDeduction = csv.GetField<string>(3);
                                            var splitedDate = invoice.TDateofTaxDeduction.Split('/');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[0].Length == 1)
                                                {
                                                    splitedDate[0] = "0" + splitedDate[0];
                                                }
                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }
                                                //when date is of format mm/dd/yyyy
                                                //invoice.InvoiceDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                                //when date is of format dd/mm/yyyy uat testing lgi have this dd/mm/yyyy format
                                                // invoice.InvoiceDt = splitedDate2[1] + "/" + splitedDate2[0] + "/" + splitedDate2[2];
                                                invoice.TDateofTaxDeduction = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                                // if (DateTime.TryParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                                //  {
                                                //  invoice.InvoiceDt = DateTime.ParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                                // }
                                            }
                                            context.Logger.Log($"Invoice Date :{invoice.TDateofTaxDeduction}");
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                        {
                                            double b;
                                            if (double.TryParse(csv.GetField<string>(4), out b))
                                            {
                                                invoice.TAmountofpaymentcredit = double.Parse(csv.GetField<string>(4));
                                            }

                                        }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                        {
                                            double b;
                                            if (double.TryParse(csv.GetField<string>(5), out b))
                                            {
                                                invoice.TTotalTDS = double.Parse(csv.GetField<string>(5));
                                            }

                                        }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                                        {
                                            invoice.TRate = csv.GetField<string>(6);
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(7)))
                                        {
                                            invoice.InvoiceNumber = csv.GetField<string>(7);
                                        }
                                        else
                                        {
                                            iscorrect = "N";
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(8)))
                                        {
                                            invoice.PanNumberInExcel = csv.GetField<string>(8);

                                            var vendorData = mastertable.Where(X => X.PAN == invoice.PanNumberInExcel && X.ParentVendorId == invoice.VendorRegisteredCd);
                                            if (vendorData != null && vendorData.Count() > 0)
                                            {
                                                foreach (var z in vendorData)
                                                {
                                                    invoice.PanNumber = z.PAN;
                                                }
                                            }
                                            else
                                            {

                                                context.Logger.Log($"Pan Number is not matching for { invoice.InvoiceNumber}");

                                            }
                                        }
                                        else
                                        {
                                            iscorrect = "N";
                                            context.Logger.Log($"Pan Number is not available for { invoice.InvoiceNumber}");
                                        }


                                        if (iscorrect != "N")
                                        {
                                            invoice.VendorCdAYQtrId = invoice.VendorRegisteredCd + '_' + Assesmentyear + '_' + QuarterSelected;
                                            await db.InsertAsync<Invoice>(invoice, invoiceTable, context);
                                            if (tdslist.Count(x => x.PanNumberInExcel == invoice.PanNumberInExcel && x.VendorRegisteredCd == invoice.VendorRegisteredCd) == 0)
                                            {
                                                TdsInvoice obj = new TdsInvoice();
                                                obj.PanNumberInExcel = invoice.PanNumberInExcel;
                                                obj.PanNumber = invoice.PanNumber;
                                                obj.VendorRegisteredCd = invoice.VendorRegisteredCd;
                                                obj.SummaryInvoiceExcelUploaded = "Y";
                                                obj.SummaryInvoiceExcelName = fileName;
                                                obj.AYQtr = Assesmentyear + '_' + QuarterSelected;
                                                obj.Quarter = QuarterSelected;
                                                obj.AssessmentYear = Assesmentyear;
                                                obj.ModifiedBy = fileUploaderName;
                                                obj.IsMailSent = "N";
                                                obj.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                                tdslist.Add(obj);
                                            }

                                            //var tdsddata = tdsdetail.Where(tds => tds.PanNumber == invoice.PanNumber && tds.VendorRegisteredCd == invoice.VendorRegisteredCd);

                                            //if (tdsddata != null && tdsddata.Count() > 0)
                                            //{
                                            //    foreach (var z in tdsddata)
                                            //    {
                                            //        tdsinvoice.PanNumber = z.PanNumber;
                                            //        tdsinvoice.VendorRegisteredCd = z.VendorRegisteredCd;
                                            //        tdsinvoice.SummaryInvoiceExcelUploaded = "Y";
                                            //        tdsinvoice.SummaryInvoiceExcelName = fileName;
                                            //       

                                            //        Console.WriteLine($"Updated the data for TDS Table {JsonConvert.SerializeObject(tdsinvoice)}");
                                            //    }
                                            //}
                                            //else
                                            //{
                                            //    tdsinvoice.PanNumber = invoice.PanNumber;
                                            //    tdsinvoice.VendorRegisteredCd = invoice.VendorRegisteredCd;
                                            //    tdsinvoice.TDSCertificateUploaded = "N";
                                            //    tdsinvoice.SummaryInvoiceExcelUploaded = "Y";
                                            //    tdsinvoice.SummaryInvoiceExcelName = fileName;
                                            //    await db.InsertAsync<tdsinvoice>(tdsinvoice, TDStable, context);
                                            //}
                                            context.Logger.Log($"Data inserted successfully {invoice.InvoiceNumber}");
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        context.Logger.Log($"Exception while inserting the data inside the HD  {e.Message}");
                                        context.Logger.Log($"Innner exception :{e.InnerException}");
                                        context.Logger.Log($"Stack trace :{e.StackTrace}");
                                    }

                                }
                            }
                        }

                        foreach (var tds in tdslist)
                        {
                            await db.UpdateItemAsync<TdsInvoice>(tds, TDStable, context);
                            //QueryRequest queryRequest = new QueryRequest()
                            //{
                            //    TableName = TDStable,
                            //    IndexName = TDSAssessmentYr_VendorRegisteredCd_Index,
                            //    KeyConditionExpression = "AssessmentYear = :AssessmentYear AND VendorRegisteredCd = :VendorCode",
                            //    FilterExpression = "PanNumber = :PanNumber",
                            //    ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                            //{
                            //    { ":VendorCode",new AttributeValue {S= tds.VendorRegisteredCd  } },
                            //    { ":AssessmentYear",new AttributeValue {S= Assesmentyear } },
                            //    {":PanNumber", new AttributeValue {S =tds.PanNumber } },
                            //}
                            //};
                            //var result = await IDigiDynamoDb.QueryThetable<tdsinvoice>(queryRequest);
                            //if (result != null)
                            //{
                            //   result[0].SummaryInvoiceExcelUploaded = "Y";
                            //   result[0].SummaryInvoiceExcelName = tds.SummaryInvoiceExcelName;
                            //   result[0].ModifiedBy = tds.ModifiedBy;
                            //   result[0].ModifiedDttm = tds.ModifiedDttm;

                            //    await db.UpdateItemAsync<tdsinvoice>(result[0], TDStable, context);
                            //}
                            //else
                            //{
                            //    tds.TDSCertificateUploaded = "N";

                            //    await db.InsertAsync<tdsinvoice>(tds, TDStable, context);
                            //}
                        }
                        if (!string.IsNullOrEmpty(fileName))
                        {
                           // string renamedFile = RenameFile(fileName); .// no need to rename as the file from api is already added with time stamp
                            await CopyFileFromOneFolderToOther(bucketName, bucketName, tdsCsvDumpFolder, tdsPrivatecsvFolder, fileName, fileName, context);
                            await DeleteFile(bucketName, tdsCsvDumpFolder, fileName, context);
                        }
                    }
                    return;
                }
                #endregion
                #region tds zip file
                else
                {
                    var filter = new ScanFilter();
                    filter.AddCondition("PAN", ScanOperator.IsNotNull);
                    var vendorMasterData = await db.ScanAsync<VendorMasterEntities>(filter, vendorMasterTable, context);


                    fileName = fileName.Replace(tdsZipDumpFolder + "/", "");

                    var zipFileNameSplitted=fileName.Split("_");
                    var fileUploaderName = zipFileNameSplitted[0];
                    var quarterInZipFile = zipFileNameSplitted[1];
                    var assessmentYearInZipFile = zipFileNameSplitted[2];

                    var zipFileData = await GetFileFromS3(bucketName, tdsZipDumpFolder, fileName, context);
                    DirectoryInfo directoryInfoBeforeunZipping = new DirectoryInfo("/tmp");
                    var fileBeforeUnzipping=directoryInfoBeforeunZipping.EnumerateFiles();
                    foreach (var file in fileBeforeUnzipping)
                    {
                        file.Delete();
                    }

                    Stopwatch sw1 = new Stopwatch();
                    using (Stream responseStream = zipFileData.ResponseStream)
                        //un zipping part requires
                    using (MemoryStream memStream = new MemoryStream())
                    {
                        sw1.Start();
                        responseStream.CopyTo(memStream);
                        memStream.Seek(0, SeekOrigin.Begin);
                        ZipFile zip = ZipFile.Read(memStream);
                        zip.ExtractAll("/tmp", ExtractExistingFileAction.DoNotOverwrite);
                        Console.WriteLine($"Time Taken to extract all the file{sw1.Elapsed}");
                        sw1.Stop();
                        
                    }
                    DirectoryInfo directoryInfo = new DirectoryInfo("/tmp");
                    var fileNames=directoryInfo.EnumerateFiles();

                    Stopwatch sw = new Stopwatch();
                    Stopwatch sw2 = new Stopwatch();
                    sw2.Start();

                    List<string> fileNameWhoseVendorDataNotInDb = new List<string>();
                    List<string> panNumberWhooseDataNotVendorData = new List<string>();
                    foreach (var file in fileNames)
                    {
                        sw.Start();
                        Console.WriteLine($"{file.FullName}");
                        if (file.Name.Contains("_"))
                        {
                            var fileNameToBeStoredInDb = RenameFile(file.Name);
                            var splittedName = file.Name.Split("_");
                            var panNumberTemp = splittedName[0];
                            var quarter = splittedName[1];
                            var assessmentYear = splittedName[2].Replace(".pdf", "");

                            var vendorData = vendorMasterData.Where(vendordata => !string.IsNullOrEmpty(vendordata.PAN) && vendordata.PAN.ToLowerInvariant() == panNumberTemp.ToLowerInvariant() && !string.IsNullOrEmpty(vendordata.ParentVendorId));
                            if (vendorData != null && vendorData.Count() > 0)
                            {
                                TdsData tdsData = new TdsData();
                                if (vendorData.Count() >1)
                                {
                                   var genericModuleVendor= vendorData.Where(i=>  !string.IsNullOrEmpty(i.VendorCd) && i.VendorCd.ToLowerInvariant() == "grn vendor");
                                    if (genericModuleVendor != null && genericModuleVendor.Count() > 0)
                                    {
                                        tdsData.VendorRegisteredCd = genericModuleVendor.FirstOrDefault().ParentVendorId;
                                    }
                                    else
                                    {
                                        tdsData.VendorRegisteredCd = vendorData.FirstOrDefault().ParentVendorId;
                                    }
                                }
                                else
                                {
                                    tdsData.VendorRegisteredCd = vendorData.FirstOrDefault().ParentVendorId;
                                }
                                tdsData.AYQtr = assessmentYear + "_" + quarter;
                                tdsData.AssessmentYear = assessmentYear;
                                tdsData.Quarter = quarter;
                                tdsData.PanNumber = panNumberTemp;
                                tdsData.TDSCertificateName = fileNameToBeStoredInDb;
                                tdsData.TDSCertificateUploaded = "Y";
                                tdsData.CreatedBy = fileUploaderName;
                                tdsData.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                tdsData.ModifiedBy = fileUploaderName;
                                tdsData.IsMailSent = "N";
                                tdsData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                                var passwordString = panNumberTemp.Substring(0, 8) + "$$1234";
                                byte[] password = Encoding.ASCII.GetBytes(passwordString);
                                using (var fileData = File.OpenRead(file.FullName))
                                {
                                    PdfReader readPDFInv = new PdfReader(fileData, password);
                                    context.Logger.Log($" Digitally sign check :  {file.FullName}");
                                    AcroFields fieldsInv = readPDFInv.AcroFields;
                                    ArrayList namesInv = fieldsInv.GetSignatureNames(); //.GetSignatureNames();
                                    if (namesInv.Count > 0)
                                    {
                                        await db.UpdateItemAsync<TdsData>(tdsData, TDStable, context);
                                        PutObjectRequest putObjectRequest = new PutObjectRequest()
                                        {
                                            InputStream = fileData,
                                            BucketName = bucketName + "/" + tdsZipCertificatesFolder,
                                            Key = fileNameToBeStoredInDb
                                        };
                                        var response = await S3Client.PutObjectAsync(putObjectRequest);

                                        Console.WriteLine($"Time taken for reading the file digital signaturechecking and uploading to s3 {sw.Elapsed}");
                                        sw.Restart();
                                    }
                                    else
                                    {
                                        Console.WriteLine($"File is not digitally signed {file.Name}");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine($"File name {file.Name}- Pan number {panNumberTemp} does not has vendor related data in the db");
                                fileNameWhoseVendorDataNotInDb.Add(file.Name);
                                panNumberWhooseDataNotVendorData.Add(panNumberTemp);
                            }
                        }
                        else
                        {
                            Console.WriteLine($"File name has format problem {file.Name}");
                        }
                           
                    }
                    Console.WriteLine($"Total time taken for file reading and sign check and upload for all the files{sw2.Elapsed}");
                    Console.WriteLine($"File whoose data not in db count {fileNameWhoseVendorDataNotInDb.Count}");
                    Console.WriteLine($"Pan whoose data not in db count {panNumberWhooseDataNotVendorData.Count}");

                    Console.WriteLine($"File name list {JsonConvert.SerializeObject(fileNameWhoseVendorDataNotInDb)}");
                    Console.WriteLine($"File name list {JsonConvert.SerializeObject(panNumberWhooseDataNotVendorData)}");

                    sw2.Stop();
                    Console.WriteLine($"End ");

                }
                return;
                #endregion
            }
            catch (Exception e)
            {
                //context.Logger.LogLine($"Error getting object {s3Event.Object.Key} from bucket {s3Event.Bucket.Name}. Make sure they exist and your bucket is in the same region as this function.");
                //context.Logger.LogLine(e.Message);
                //context.Logger.LogLine(e.StackTrace);
                //throw;
                context.Logger.Log($"Exception in main block :{e.Message}");
                context.Logger.Log($"Innner exception :{e.InnerException}");
                context.Logger.Log($"Stack trace :{e.StackTrace}");
                context.Logger.Log($"{e.Source}");
                context.Logger.Log($"{e.HResult}");
            }
        }
        private async Task<GetObjectResponse> GetFileFromS3(string bucketName, string folderName, string fileName, ILambdaContext context)
        {
            GetObjectResponse getObjectResponse = null;
            if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderName) && !string.IsNullOrEmpty(fileName))
            {
                var getObjectRequest = new GetObjectRequest
                {
                    BucketName = bucketName + "/" + folderName,
                    Key = fileName
                };

                getObjectResponse = await
                    S3Client.GetObjectAsync(getObjectRequest);
            }
            else
            {
                context.Logger.Log($"Log: File path mentioned does not exists :{bucketName}/{folderName}/{fileName}");
            }

            return getObjectResponse;


        }       
        private async void DeleteTheData(List<Document> listOfDocument ,Table table, ILambdaContext context)
        {
            try
            {
                context.Logger.Log("Process: Now inside delete method");
                //ScanFilter scanFilter = new ScanFilter();
                //ScanOperationConfig scanConfig = new ScanOperationConfig()
                //{
                //    AttributesToGet = new List<string> { "SupplierID", "POLineItem" },
                //    Filter = scanFilter,
                //    Select = SelectValues.SpecificAttributes
                //};
                //Table table = Table.LoadTable(DbClient, tableName);
                //Search search = table.Scan(scanConfig);
                //List<Invoice> List = new List<Invoice>();
                //List<Document> listOfDocument = new List<Document>();
                //do
                //{
                //    List<Document> documentList = await search.GetNextSetAsync();
                //    foreach (var document in documentList)
                //    {
                //        listOfDocument.Add(document);
                //        //potransactionList.Add(IDigiDynamoDocumentConverter.ToObject<POTransaction>(document));
                //    }
                //} while (!search.IsDone);
                //Console.WriteLine($"Data: Total items in Potransaction table {listOfDocument.Count}");

                int tenThousandsCount = 0;
                Stopwatch sw1 = new Stopwatch();
                sw1.Start();
                int documentsToDelete = 0;
                DocumentBatchWrite documentBatchWrite = table.CreateBatchWrite();

                foreach (var document in listOfDocument)
                {

                    documentBatchWrite.AddItemToDelete(document);
                    documentsToDelete = documentsToDelete + 1;
                    if (documentsToDelete == 25)
                    {
                        await documentBatchWrite.ExecuteAsync();
                        documentBatchWrite = table.CreateBatchWrite();
                        documentsToDelete = 0;
                    }
                    //await table.DeleteItemAsync(document);
                    tenThousandsCount = tenThousandsCount + 1;
                    if (tenThousandsCount == 10000)
                    {
                        Console.WriteLine($"Data: Time taken for deleting 10000 records  {sw1.ElapsedMilliseconds / 1000} seconds");
                        sw1.Restart();
                        tenThousandsCount = 0;
                    }
                }
                if (documentsToDelete != 0)
                {
                    await documentBatchWrite.ExecuteAsync();
                    documentBatchWrite = table.CreateBatchWrite();
                    documentsToDelete = 0;
                }
                Console.WriteLine($"Data: Time taken for deleting {tenThousandsCount} records  {sw1.ElapsedMilliseconds / 1000} seconds");
              
            }
            catch (Exception e)
            {
                context.Logger.Log($"{e.Message}");
            
            }
            
        }
        private async Task CopyFileFromOneFolderToOther(string sourceBucket, string destinationBucket, string sourceFolder, string destinationFolder, string srcfileName, string destFileName, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(srcfileName) && !string.IsNullOrEmpty(destFileName))
            {
                var copyObjectRequest = new CopyObjectRequest()
                {
                    SourceBucket = sourceBucket + "/" + sourceFolder,
                    DestinationBucket = destinationBucket + "/" + destinationFolder,
                    SourceKey = srcfileName,
                    DestinationKey = destFileName
                };
                context.Logger.Log($"Process :before copying the file : {srcfileName} from :{sourceBucket + "/" + sourceFolder} to {destinationBucket + "/" + destinationFolder}");
                await S3Client.CopyObjectAsync(copyObjectRequest);
                context.Logger.Log($"Log :Copied successfully");
            }
            else
            {
                context.Logger.Log($"Error :One of the passed parameter is empty");
            }
        }
        private async Task DeleteFile(string bucket, string folder, string file, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(file) && !string.IsNullOrEmpty(bucket) && !string.IsNullOrEmpty(folder))
            {
                var deleteObjectRequest = new DeleteObjectRequest()
                {
                    BucketName = bucket + "/" + folder,
                    Key = file
                };
                context.Logger.Log($"Now deleting the file name :{file} from folder {bucket}/{folder}");
                var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);

            }
        }
        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
    }
}

