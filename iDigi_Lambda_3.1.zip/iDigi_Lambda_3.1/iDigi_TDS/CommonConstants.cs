﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_TDS
{
    class CommonConstants
    {
        public const string AirId = "7433";
        public const string VendorMasterTable = "VendorMaster";
        public const string VendorMaster_FileFolder = "Vendor";

        public const string Public_Folder = "public";
        public const string Private_Folder = "private";
        public const string tds_FilePath = "tds";
        public const string tds_summaryexcel = "summaryexcel";
        public const string tds_ZipFile = "tdszipfile";
        public const string tds_Certificates = "tdscertificates";
        public const string tdsPrivatecsvFolder = "csv";
        public const string tdsPrivateInvoiceFolder = "invoice";
        public const string rtpTeam = "RTP";



        public const string InvoiceTable = "TDSInvoiceSummary";
        public const string TDSTable = "TDSDetails";
       
    }
}
