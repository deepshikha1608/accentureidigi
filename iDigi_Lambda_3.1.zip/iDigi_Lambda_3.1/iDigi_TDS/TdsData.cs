﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_TDS
{
    public class TdsData
    {
        public string VendorRegisteredCd { get; set; }
        public string AYQtr { get; set; }
        public string AssessmentYear { get; set; }
        public string Quarter { get; set; }
        public string PanNumber { get; set; }
        public string TDSCertificateUploaded { get; set; }
        public string TDSCertificateName { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string IsMailSent { get; set; }
    }
}
