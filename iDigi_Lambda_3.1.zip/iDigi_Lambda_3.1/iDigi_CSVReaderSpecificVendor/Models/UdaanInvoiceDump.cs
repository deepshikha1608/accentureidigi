﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReaderSpecificVendor.Models
{
    public class UdaanInvoiceDump
    {
        public UdaanInvoiceDump()
        {
            InvoiceLineItemsDump = new List<InvoiceLineItemDump>();
            ErrorList = new List<VendorInvoiceErrorDetails>();
        }
        public int InvoiceId { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string InvoiceDt { get; set; }
        public string DFMURN { get; set; }
        public string PoNbr { get; set; }
        public string CompanyCd { get; set; }
        public string WBSE { get; set; }
        public string EmpNo { get; set; }
        public string PaxName { get; set; }
        public string Country { get; set; }
        public string TicketNumber { get; set; }
        public string RTPApproved { get; set; }
        public string LGIGenerated { get; set; }
        public string PMApproved { get; set; }
        public string ServiceTax { get; set; }
        public string BusinessUnit { get; set; }
        public string ReimbursementCharges { get; set; }
        public string EmployeeName { get; set; }
        public string InvAmt { get; set; }
        public string Service { get; set; }
        public string InvSubmissionDt { get; set; }
        public string ServiceCharges { get; set; }
        public string ImplantName { get; set; }
        public string RTPRemarks { get; set; }
        public string VendorRemarks { get; set; }
        public string RowType { get; set; }
        public string TaxAmt { get; set; }
        public string TPCd { get; set; }
        public string FreightAmt { get; set; }
        public string GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string DCInd { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public string Base1Amt { get; set; }
        public string Base2Amt { get; set; }
        public string Base3Amt { get; set; }
        public string Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string VendorGSTNumber { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string RTPTeam { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        //public string RTPAction { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string InvoiceDate { get; set; }
        public List<InvoiceLineItemDump> InvoiceLineItemsDump { get; set; }
        public InvoiceLineItemDump InvoiceLineItemDump { get; set; }
        public List<VendorInvoiceErrorDetails> ErrorList { get; set; }
        public string IsError { get; set; } //Y N
        public string ApprovedAmt { get; set; }
        public string AmountRecdDate1 { get; set; }
        public string AmountRecdDate2 { get; set; }

        public string IsBatchValidated { get; set; }
        public string IsGSTError { get; set; }

    }
}
