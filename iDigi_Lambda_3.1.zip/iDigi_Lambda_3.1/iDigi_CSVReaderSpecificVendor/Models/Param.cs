﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReaderSpecificVendor.Models
{
    public class Param
    {
        public string ModuleNm { get; set; }
        public int StartPos { get; set; }
        public int LastPos { get; set; }
        public int EndPos { get; set; }
    }
}
