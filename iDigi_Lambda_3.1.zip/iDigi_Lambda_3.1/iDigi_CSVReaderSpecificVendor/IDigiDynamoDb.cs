﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace iDigi_CSVReaderSpecificVendor
{
    public class IDigiDynamoDb
    {
        IAmazonDynamoDB dbClient { get; set; }

        public IDigiDynamoDb()
        {
            dbClient = new AmazonDynamoDBClient();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InsertAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            var document = IDigiDynamoDocumentConverter.ToDocument(tObject, true, false);
            await table.PutItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task UpdateItemAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Document document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.UpdateItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="scanFilterCondition"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<List<T>> ScanAsync<T>(ScanFilter scanFilterCondition, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            do
            {
                List<Document> documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }

        public async Task<Document> GetItem(string tableName, Primitive hashKey, Primitive rangeKey)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            return await table.GetItemAsync(hashKey, rangeKey);

        }
        public async Task<Document> GetItem(string tableName, Primitive hashKey)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            return await table.GetItemAsync(hashKey);

        }
        public async Task<List<T>> FilterScanSpecificAttribute<T>(ScanOperationConfig scanFilterCondition, string tableName)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            List<Document> documentList = new List<Document>();
            do
            {
                documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }

        /// <summary>
        /// QueryThetableForCount
        /// </summary>
        /// <param name="queryRequest"></param>
        /// <returns></returns>
        public async Task<long> QueryThetableForCount<T>(QueryRequest queryRequest)
        {
            long count = 0;
            QueryResponse response = null;
            do
            {
                response = await dbClient.QueryAsync(queryRequest);
                count = count + response.Count;
                if (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0)
                {
                    queryRequest.ExclusiveStartKey = response.LastEvaluatedKey;
                }
            }
            while (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0);
            return count;

        }
        public async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanOperationConfig);
            List<T> resultList = new List<T>();
            int count = 0;
            do
            {
                //Console.WriteLine($"Data :Scan operation :iteration number{count}");
                count = count + 1;
                List<Document> docList = await search.GetNextSetAsync();
                foreach (var document in docList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
                //Console.WriteLine($"Data :Document count in iteration number :{count} is {docList.Count}");
            }
            while (!search.IsDone);
            Console.WriteLine($"Data :Total number of iteration  :{count}");
            Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
            return resultList;
        }

    }
}
