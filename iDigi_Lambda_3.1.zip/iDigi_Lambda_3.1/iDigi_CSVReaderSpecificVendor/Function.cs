using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using iDigi_CSVReaderSpecificVendor.Models;
using Amazon.Lambda.Model;
using System.IO;
using Amazon.Lambda;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2;
using CsvHelper;
using Newtonsoft.Json;
using System.Reflection;
using System.Text;
using System.Globalization;
using Amazon.DynamoDBv2.Model;
using Amazon.S3.Model;
using Amazon.S3;
using MoreLinq;
 using  CwtDataInsertion= iDigi_CWTDataInsertionAndValidation;
// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CSVReaderSpecificVendor
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonDynamoDB DbClient { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        IDigiDynamoDb db = new IDigiDynamoDb();
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }

        public static string CSRDestinationBucket
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("CSRDestinationBucket");
            }
        }
        public static string DebugEnvironMent
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("DebugEnvironMent");
            }

        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                if (DebugEnvironMent.ToLowerInvariant() == "true")
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); // windows os
                }
                else
                { return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); } // amazon linux os 
                
            }
        }
        

        public Function()
        {
            DbClient = new AmazonDynamoDBClient();
            LambdaClient = new AmazonLambdaClient();
        }

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(MasterClass masterClass, ILambdaContext context)
        {
            context.Logger.Log($"{masterClass.GetType().ToString()}");
            string fileColsDbColsMappingTable = string.Empty;
            string udaanModuleCd = CommonConstants.UdaanTeam;
            string cwtModuleCd = CommonConstants.CWTTeam;
            string csrModuleCd = CommonConstants.CSRTeam;
            string isActiveTrue = CommonConstants.IsActiveTRUE;
            string udaanTable = string.Empty;
            string cwtTable = string.Empty;
            string csrTable = string.Empty;
            string paramTable = string.Empty;
            string invoiceBatchTable = string.Empty;
            string csrDestinationBucket = string.Empty;
            string gstMasterTable = string.Empty;
            string invoiceErrorDetailsTable = string.Empty;
            string cwtPrivateBucket = string.Empty;
            string cwtPublicFolderPath = string.Empty;
            string cwtPrivateCSVFolderPath = string.Empty;
            string cwtPrivateInvalidFilespath = string.Empty;
            string cwtPublicBucket = string.Empty;

            List<CWTInvoice> duplicatesValues = new List<CWTInvoice>();
            Amazon.Lambda.Model.InvokeRequest invokeRequest = new Amazon.Lambda.Model.InvokeRequest();
            IDigiDynamoDb db = new IDigiDynamoDb();
            IDigiS3 s3 = new IDigiS3();
            invokeRequest.InvocationType = InvocationType.Event;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CommonConstants.FileColsDbColsMappingTable;
                udaanTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                cwtTable = CommonConstants.AirId + "_" + CommonConstants.CWTInvoiceTable;
                invoiceBatchTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceBatchTable;
                csrTable = CommonConstants.AirId + "_" + CommonConstants.CSRInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CommonConstants.ParamTable;
                gstMasterTable = CommonConstants.AirId + "_" + CommonConstants.GSTMasterTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTProdPrivateBucketName;
                cwtPublicFolderPath = CommonConstants.CWTvendor_FilePath;
                cwtPrivateCSVFolderPath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTCsvFilePath;
                cwtPrivateInvalidFilespath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvalidFile_FolderPath;

            }
            else
            {
                fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.FileColsDbColsMappingTable;
                udaanTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;

                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                csrTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CSRInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ParamTable;
                gstMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GSTMasterTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTStagePrivateBucketName;
                cwtPublicFolderPath = CommonConstants.CWTvendor_FilePath;
                cwtPrivateCSVFolderPath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTCsvFilePath;
                cwtPrivateInvalidFilespath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvalidFile_FolderPath;
                if (CloudEnvironment.ToLowerInvariant() == "stage")
                {
                    cwtTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoiceStageTable;
                }
                else if (CloudEnvironment.ToLowerInvariant() == "dev")
                {
                    cwtTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoiceTable;
                    cwtPublicFolderPath = CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath;
                    cwtPrivateCSVFolderPath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTCsvFilePath;
                    cwtPrivateInvalidFilespath = CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvalidFile_FolderPath;
                    cwtPublicBucket = CommonConstants.CWTDevBucketName;
                }

            }

            string udaanPublicFolderPath = CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath;
            string udaanPrivateLGICSVFolderPath = CommonConstants.Private_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/" + CommonConstants.UdaanLGICSVFilePath;
            string udaanPrivateInvalidFilesPath = CommonConstants.Private_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/" + CommonConstants.Invalidfiles;

          
            string CsrPublicFolderPath = CommonConstants.CSRInvoice_FilePath;
            string CsrcsvPrivateFolderPath = CommonConstants.Private_Folder + "/" + CommonConstants.CSRInvoice_FilePath + "/" + CommonConstants.CSRCsvFilePath;
            string csrInvalidFilePath = CommonConstants.Private_Folder + "/" + CommonConstants.CSRInvoice_FilePath + "/" + CommonConstants.CSRInvalidFilesPath;
            string csrINVPrivatefolderpath = CommonConstants.Private_Folder + "/" + CommonConstants.CSRvendor_FilePath + "/" + CommonConstants.CSRInvoiceFilePath;
            string csrTRPrivatefolderpath = CommonConstants.Private_Folder + "/" + CommonConstants.CSRvendor_FilePath + "/" + CommonConstants.CSRTRFilePath;
            string CSR_InvoiceNumber_VendorCd_index = CommonConstants.AirId + "_" + CloudEnvironment + CommonConstants.CSRInvoiceNumberVendorCd_index;

            context.Logger.Log($"Initialised all the constants and table names required");
            if (masterClass != null)
            {
                #region udaan

                try
                {
                    //if (masterClass.Vendor == CommonConstants.UdaanTeam || masterClass.Vendor == CommonConstants.FCMTeam)
                        if (masterClass.Vendor == "VISA")
                        {
                        int max = 0;
                        int visaNextVendorCd = 1;
                        var scanResult = await ScanAndFetchLatestPartitionIdentityValue<UdaanInvoice>(udaanTable, "VendorCd", context);

                        Console.WriteLine($"Total items returned from table {scanResult.Count } first item {JsonConvert.SerializeObject(scanResult.FirstOrDefault())}");

                        List<string> duplicateInvoiceNumbers = new List<string>();

                        var document = await db.GetItem(paramTable, "VISA");
                        var visaParameters = IDigiDynamoDocumentConverter.ToObject<Param>(document);


                        if (visaParameters.LastPos < 1000)
                        {
                            visaNextVendorCd = visaParameters.LastPos;
                           
                        }
                        else if (visaParameters.LastPos >= 1000)
                        {
                            visaNextVendorCd = 0;
                        }

                        if (!string.IsNullOrEmpty(masterClass.UdaanLgiCSVName) && !string.IsNullOrEmpty(masterClass.BucketName))
                        {
                            var udaanLgiCSVData = await s3.GetFileFromS3(masterClass.BucketName, udaanPublicFolderPath, masterClass.UdaanLgiCSVName, context);
                            Dictionary<string, bool> invoiceNumberDictionary = new Dictionary<string, bool>();
                            if (udaanLgiCSVData != null)
                            {

                                var csvStream = new StreamReader(udaanLgiCSVData.ResponseStream);
                                var csv1 = new CsvReader(csvStream);
                                csv1.Configuration.HasHeaderRecord = false;     //no header in udaan lgi csv file    
                                while (csv1.Read())
                                {
                                    if (!string.IsNullOrWhiteSpace(csv1.GetField<string>(0)))
                                    {
                                        if (csv1.GetField<string>(0).ToLowerInvariant() == "hd")
                                        {
                                            if (!string.IsNullOrEmpty(csv1.GetField<string>(3)))
                                            {
                                                if (!invoiceNumberDictionary.ContainsKey(csv1.GetField<string>(3)))
                                                {
                                                    invoiceNumberDictionary.Add(csv1.GetField<string>(3), false);
                                                }
                                            }
                                        }
                                    }
                                }
                                context.Logger.Log($"Data :unique invoice number dictionary - {JsonConvert.SerializeObject(invoiceNumberDictionary)}");
                                var fileColsDBColsMappinglistHDRows = await ReadFileColsDBMappingTable(fileColsDbColsMappingTable, udaanModuleCd, CommonConstants.HDHeaderType, isActiveTrue);
                                var fileColsDBColsMappinglistDTRows = await ReadFileColsDBMappingTable(fileColsDbColsMappingTable, udaanModuleCd, CommonConstants.DTHeaderType, isActiveTrue);
                                //int invoiceIdGenarated = max + 1;
                                var udaanLgiCSVDataCopy = await s3.GetFileFromS3(masterClass.BucketName, udaanPublicFolderPath, masterClass.UdaanLgiCSVName, context);
                                using (var stream = new StreamReader(udaanLgiCSVDataCopy.ResponseStream))
                                {
                                    var csv = new CsvReader(stream);
                                    csv.Configuration.HasHeaderRecord = false;     //no header in udaan lgi csv file                   
                                    UdaanInvoice udaanInvoice = new UdaanInvoice();
                                    MasterClass masterClassObj = null;
                                    int dtCount = 0;

                                    while (csv.Read())
                                    {
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                        {
                                            if (csv.GetField<string>(0).ToLowerInvariant() == "hd")
                                            {
                                                if (dtCount > 0)
                                                {
                                                    bool a;
                                                    context.Logger.Log($" Invoice number {udaanInvoice.VendorInvoiceNumber}");
                                                    if (invoiceNumberDictionary.TryGetValue(udaanInvoice.VendorInvoiceNumber, out a))
                                                    {
                                                        Console.WriteLine(JsonConvert.SerializeObject($"{invoiceNumberDictionary[udaanInvoice.VendorInvoiceNumber]}"));
                                                        if (!invoiceNumberDictionary[udaanInvoice.VendorInvoiceNumber])
                                                        {
                                                            if(udaanInvoice.VendorRegisteredCd.Length == 10)
                                                            {

                                                                udaanInvoice.VendorRegisteredCd = udaanInvoice.VendorRegisteredCd.TrimStart('0'); // removing leading 0 from the vendorregistered cd as some time it conatin 0 some time it wont
                                                            }
                                                            if (!IsThisVisaDuplicateInvoice(scanResult, udaanInvoice.VendorInvoiceNumber, udaanInvoice.VendorRegisteredCd))
                                                            {
                                                                Console.WriteLine(
                                                                    $"{udaanInvoice.InvoiceLineItems.Count}");
                                                                masterClassObj = new MasterClass();
                                                                masterClassObj.BucketName = masterClass.BucketName;
                                                                masterClassObj.Vendor = masterClass.Vendor;
                                                                masterClassObj.InvoiceBatchDttm =
                                                                    masterClass.InvoiceBatchDttm;
                                                                masterClassObj.UdaanInvoice = udaanInvoice;
                                                                if (udaanInvoice.VendorRegisteredCd == "100252385")
                                                                {
                                                                    if (visaNextVendorCd <= 999)
                                                                    {
                                                                        visaNextVendorCd = visaNextVendorCd + 1;
                                                                    }
                                                                    else
                                                                    {
                                                                        visaNextVendorCd = 1;
                                                                    }

                                                                    masterClassObj.UdaanInvoice.VendorCd =
                                                                        "UDN100252385" + "-" +
                                                                        visaNextVendorCd.ToString();
                                                                }
                                                                else if (udaanInvoice.VendorRegisteredCd == "100407668")
                                                                {
                                                                    if (visaNextVendorCd <= 999)
                                                                    {
                                                                        visaNextVendorCd = visaNextVendorCd + 1;
                                                                    }
                                                                    else
                                                                    {
                                                                        visaNextVendorCd = 1;
                                                                    }

                                                                    masterClassObj.UdaanInvoice.VendorCd =
                                                                        "FCM100407668" + "-" +
                                                                        visaNextVendorCd.ToString();
                                                                }
                                                                else
                                                                {
                                                                    if (visaNextVendorCd <= 999)
                                                                    {
                                                                        visaNextVendorCd = visaNextVendorCd + 1;
                                                                    }
                                                                    else
                                                                    {
                                                                        visaNextVendorCd = 1;
                                                                    }

                                                                    masterClassObj.UdaanInvoice.VendorCd =
                                                                        udaanInvoice.VendorRegisteredCd + '-' + visaNextVendorCd.ToString();
                                                                }

                                                                masterClassObj.IsLastUdaanChildLambdaInvoking = false;
                                                                invokeRequest.Payload =
                                                                    JsonConvert.SerializeObject(masterClassObj);
                                                                invokeRequest.FunctionName =
                                                                    "7433_iDigi_UdaanDataInsertionAndValidation";
                                                                invoiceNumberDictionary[
                                                                    udaanInvoice.VendorInvoiceNumber] = true;
                                                                var childLambdaResponse =
                                                                    LambdaClient.InvokeAsync(invokeRequest);

                                                                LogChildLambdaResponse(childLambdaResponse, context);

                                                            }
                                                            else
                                                            {
                                                                duplicateInvoiceNumbers.Add(udaanInvoice.VendorInvoiceNumber);
                                                                Console.WriteLine($"Data -error: Duplicate- Invoice number {udaanInvoice.VendorInvoiceNumber}");
                                                            }
                                                        }
                                                        else
                                                        {
                                                            duplicateInvoiceNumbers.Add(udaanInvoice.VendorInvoiceNumber);
                                                            context.Logger.Log($"Data -error: Duplicate- Invoice number {udaanInvoice.VendorInvoiceNumber}");
                                                        }
                                                    }

                                                    udaanInvoice = new UdaanInvoice();
                                                    dtCount = 0;
                                                }
                                                udaanInvoice = (UdaanInvoice)ReadCSVDataBasedOnIndexRequired(csv, udaanInvoice, fileColsDBColsMappinglistHDRows, context);
                                                if (!string.IsNullOrEmpty(udaanInvoice.InvoiceDt))
                                                {
                                                    if (udaanInvoice.InvoiceDt.Contains("/"))
                                                    {
                                                        var splitedDate = udaanInvoice.InvoiceDt.Split('/');
                                                        if (splitedDate.Length == 3)
                                                        {
                                                            if (splitedDate[0].Length == 1)
                                                            {
                                                                splitedDate[0] = "0" + splitedDate[0];
                                                            }
                                                            if (splitedDate[1].Length == 1)
                                                            {
                                                                splitedDate[1] = "0" + splitedDate[1];
                                                            }
                                                            //date format is coming as dd/mm/yyyy in udaan convert to mm/dd/yyyy
                                                            udaanInvoice.InvoiceDt = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];
                                                        }

                                                        udaanInvoice.SearchInvoiceDt = splitedDate[2] + "/" + splitedDate[1] + "/" + splitedDate[0];
                                                    }
                                                }
                                               
                                            }
                                            else if (csv.GetField<string>(0).ToLowerInvariant() == "dt")
                                            {

                                                InvoiceLineItem lineItemobj = new InvoiceLineItem();
                                                var data = (InvoiceLineItem)ReadCSVDataBasedOnIndexRequired(csv, lineItemobj, fileColsDBColsMappinglistDTRows, context);
                                                dtCount++;
                                                data.InvoiceDTId = dtCount;
                                                udaanInvoice.InvoiceLineItems.Add(data);
                                            }

                                        }

                                    }
                                    if (dtCount > 0)
                                    {
                                        bool a;
                                        context.Logger.Log($" Invoice number{udaanInvoice.VendorInvoiceNumber}  {JsonConvert.SerializeObject(invoiceNumberDictionary.TryGetValue(udaanInvoice.VendorInvoiceNumber, out a))}");
                                        if (invoiceNumberDictionary.TryGetValue(udaanInvoice.VendorInvoiceNumber, out a))
                                        {
                                            Console.WriteLine(JsonConvert.SerializeObject($"{invoiceNumberDictionary[udaanInvoice.VendorInvoiceNumber]}"));
                                            if (!invoiceNumberDictionary[udaanInvoice.VendorInvoiceNumber])
                                            {
                                                if (udaanInvoice.VendorRegisteredCd.Length == 10)
                                                {
                                                    udaanInvoice.VendorRegisteredCd = udaanInvoice.VendorRegisteredCd.TrimStart('0'); // removing leading 0 from the vendorregistered cd as some time it conatin 0 some time it wont
                                                }
                                                if (!IsThisVisaDuplicateInvoice(scanResult, udaanInvoice.VendorInvoiceNumber, udaanInvoice.VendorRegisteredCd))
                                                {
                                                    Console.WriteLine($"{udaanInvoice.InvoiceLineItems.Count}");
                                                    masterClassObj = new MasterClass();
                                                    masterClassObj.BucketName = masterClass.BucketName;
                                                    masterClassObj.Vendor = masterClass.Vendor;
                                                    masterClassObj.InvoiceBatchDttm = masterClass.InvoiceBatchDttm;
                                                    masterClassObj.UdaanInvoice = udaanInvoice;
                                                    masterClassObj.IsLastUdaanChildLambdaInvoking = true;
                                                    if (udaanInvoice.VendorRegisteredCd == "100252385")
                                                    {
                                                        if (visaNextVendorCd <= 999)
                                                        {
                                                            visaNextVendorCd = visaNextVendorCd + 1;
                                                        }
                                                        else
                                                        {
                                                            visaNextVendorCd = 1;
                                                        }

                                                        masterClassObj.UdaanInvoice.VendorCd =
                                                            "UDN100252385" + "-" + visaNextVendorCd.ToString();
                                                    }
                                                    else if (udaanInvoice.VendorRegisteredCd == "100407668")
                                                    {
                                                        if (visaNextVendorCd <= 999)
                                                        {
                                                            visaNextVendorCd = visaNextVendorCd + 1;
                                                        }
                                                        else
                                                        {
                                                            visaNextVendorCd = 1;
                                                        }

                                                        masterClassObj.UdaanInvoice.VendorCd =
                                                            "FCM100407668" + "-" + visaNextVendorCd.ToString();
                                                    }
                                                    else 
                                                    {
                                                        if (visaNextVendorCd <= 999)
                                                        {
                                                            visaNextVendorCd = visaNextVendorCd + 1;
                                                        }
                                                        else
                                                        {
                                                            visaNextVendorCd = 1;
                                                        }

                                                        masterClassObj.UdaanInvoice.VendorCd =
                                                            udaanInvoice.VendorRegisteredCd + '-' + visaNextVendorCd.ToString();
                                                    }



                                                    invokeRequest.Payload = JsonConvert.SerializeObject(masterClassObj);
                                                    invokeRequest.FunctionName =
                                                        "7433_iDigi_UdaanDataInsertionAndValidation";
                                                    var childLambdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                                                    LogChildLambdaResponse(childLambdaResponse, context);
                                                    invoiceNumberDictionary[udaanInvoice.VendorInvoiceNumber] = true;
                                                }
                                                else
                                                {
                                                    context.Logger.Log($"Data -error: Duplicate- Invoice number {udaanInvoice.VendorInvoiceNumber}");
                                                    duplicateInvoiceNumbers.Add(udaanInvoice.VendorInvoiceNumber);
                                                }
                                            }
                                            else
                                            {
                                                context.Logger.Log($"Data -error: Duplicate- Invoice number {udaanInvoice.VendorInvoiceNumber}");
                                                duplicateInvoiceNumbers.Add(udaanInvoice.VendorInvoiceNumber);

                                            }
                                        }
                                        context.Logger.Log($"Data :unique invoice number dictionary -{JsonConvert.SerializeObject(invoiceNumberDictionary)}");
                                        udaanInvoice = new UdaanInvoice();
                                        dtCount = 0;
                                    }

                                    #region default execution range
                                    #region Duplicate files cut paste
                                    InvoiceBatch invoiceBatch = await GetInvoiceBatch(invoiceBatchTable, CommonConstants.UdaanTeam, masterClass.InvoiceBatchDttm);
                                    if (duplicateInvoiceNumbers != null &&
                                        duplicateInvoiceNumbers.Count > 0 && invoiceBatch.ValidFileList != null && invoiceBatch.ValidFileList.Count > 0)
                                    {
                                        foreach (var dupliCateInvoice in duplicateInvoiceNumbers)
                                        {
                                            var fileNames = invoiceBatch.ValidFileList.Where(file =>
                                                  file.Contains("_" + dupliCateInvoice + "_"));

                                            foreach (var file in fileNames)
                                            {
                                                string ranamedfileName = RenameFile(file);
                                                await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, masterClass.BucketName, udaanPublicFolderPath, udaanPrivateInvalidFilesPath, file, ranamedfileName, context);
                                                await s3.DeleteFile(masterClass.BucketName, udaanPublicFolderPath, file, context);
                                            }
                                        }


                                    }
                                    #endregion Duplicate files cut paste
                                    #region invalid files Cut paste
                                    //foreach (var file in invoiceBatch.InValidFileList)
                                    //{
                                    //    string ranamedfileName = RenameFile(file);
                                    //    await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, masterClass.BucketName, udaanPublicFolderPath, udaanPrivateInvalidFilesPath, file, ranamedfileName, context);
                                    //    await s3.DeleteFile(masterClass.BucketName, udaanPublicFolderPath, file, context);
                                    //}
                                    #endregion
                                    #endregion
                                }
                                var udaanParamvalue = new Param();
                                udaanParamvalue.EndPos = 1000;
                                udaanParamvalue.StartPos = 1;
                                udaanParamvalue.LastPos = visaNextVendorCd;
                                udaanParamvalue.ModuleNm = "VISA";
                                context.Logger.Log($" Max val at the end: udaan: {max}");
                                await db.UpdateItemAsync<Param>(udaanParamvalue, paramTable, context);

                                //var fcmParamvalue = new Param();
                                //fcmParamvalue.EndPos = 1000;
                                //fcmParamvalue.StartPos = 1;
                                //fcmParamvalue.LastPos = fcmNextVendorCd;
                                //fcmParamvalue.ModuleNm = "FCM";
                                //context.Logger.Log($" Max val at the end fcm: {max}");
                                //await db.UpdateItemAsync<Param>(fcmParamvalue, paramTable, context);
                            }
                            if (!string.IsNullOrEmpty(masterClass.UdaanLgiCSVName))
                            {
                                string renamedFileName = RenameFile(masterClass.UdaanLgiCSVName);
                                await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, masterClass.BucketName, udaanPublicFolderPath, udaanPrivateLGICSVFolderPath, masterClass.UdaanLgiCSVName, renamedFileName, context);
                                await s3.DeleteFile(masterClass.BucketName, udaanPublicFolderPath, masterClass.UdaanLgiCSVName, context);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    context.Logger.Log($" Exception logged : {JsonConvert.SerializeObject(ex)}");
                }
                #endregion
                #region cwt
                if (masterClass.Vendor.ToLowerInvariant() == CommonConstants.CWTTeam.ToLowerInvariant())
                {
                    context.Logger.Log($"Inside cwt module");
                    int max = 0;
                    var scanResult = await ScanAndFetchLatestPartitionIdentityValue<CWTInvoice>(cwtTable, "CWTInvoiceId", context);
                    if (scanResult != null && scanResult.Count > 0)
                    {
                        max = scanResult.Max(x => x.CWTInvoiceId);
                    }

                    
                    int cwtNextVendorCd = 1;

                    var paramTabeData = await db.GetItem(paramTable, "CWT");
                    var cwtParameters = IDigiDynamoDocumentConverter.ToObject<Param>(paramTabeData);

                    if (cwtParameters.LastPos < 1000)
                    {
                        cwtNextVendorCd = cwtParameters.LastPos;

                    }
                    else if (cwtParameters.LastPos >= 1000)
                    {
                        cwtNextVendorCd = 0;
                    }
                    ScanOperationConfig config = new ScanOperationConfig();
                    config.Select = SelectValues.SpecificAttributes;
                    config.AttributesToGet = new List<string>() { "BusinessPlace", "GSTID", "GSTIN", "Plant", "Type" };
                    List<GSTMaster> gstMasterList = await db.FilterScanSpecificAttribute<GSTMaster>(config, gstMasterTable);
                    context.Logger.Log($"Data : Gst master item count{gstMasterList.Count}");

                    var document = await db.GetItem(invoiceBatchTable, masterClass.Vendor, masterClass.InvoiceBatchDttm);

                    List<CWTInvoice> duplicateInvoicesInDB = new List<CWTInvoice>();
                    List<string> creditNotesWithoutPriorBookingInvoice = new List<string>();

                    var invoiceBatch = IDigiDynamoDocumentConverter.ToObject<InvoiceBatch>(document);

                    int invoiceIdGenarated = max + 1;
                    if (!string.IsNullOrEmpty(masterClass.CwtCSVFileName) && !string.IsNullOrEmpty(masterClass.BucketName))
                    {
                        var cwtCSVData = await s3.GetFileFromS3(masterClass.BucketName, cwtPublicFolderPath, masterClass.CwtCSVFileName, context);
                        List<CWTInvoice> cwtInvcoicesListInCsv = new List<CWTInvoice>();
                        if (cwtCSVData != null)
                        {
                            var fileColsDBColsMappinglist = await ReadFileColsDBMappingTable(fileColsDbColsMappingTable, cwtModuleCd, CommonConstants.HRHeaderType, isActiveTrue);
                            using (var stream = new StreamReader(cwtCSVData.ResponseStream))
                            {
                                var csv = new CsvReader(stream);
                                csv.Configuration.HasHeaderRecord = true;     //cwt csv file has header                   
                                CWTInvoice cwtInvoice = null;
                                csv.Configuration.Delimiter = "|";
                               
                                while (csv.Read())
                                {
                                    //context.Logger.Log($"Log: Row count :{csv.Row}");
                                    cwtInvoice = new CWTInvoice();
                                    cwtInvoice = ReadCSVDataBasedOnIndexRequired<CWTInvoice>(csv, cwtInvoice, fileColsDBColsMappinglist, context);
                                    if (cwtInvoice != null && !string.IsNullOrEmpty(cwtInvoice.InvoiceDt))
                                    {

                                        if (!string.IsNullOrEmpty(cwtInvoice.InvoiceDt))
                                        {
                                            string convertedDate = ConvertDateTimeCWT(cwtInvoice.InvoiceDt);

                                            if (!string.IsNullOrEmpty(convertedDate))
                                            {
                                                cwtInvoice.InvoiceDt = convertedDate;
                                                cwtInvoice.SearchInvoiceDt = ConvertDateTimeCWTISOFormat(convertedDate);
                                            }
                                        }
                                        if (!string.IsNullOrEmpty(cwtInvoice.IssuanceDt))
                                        {
                                            string convertedDate = ConvertDateTimeCWT(cwtInvoice.IssuanceDt);
                                            if (!string.IsNullOrEmpty(convertedDate))
                                            {
                                                cwtInvoice.IssuanceDt = convertedDate;
                                                cwtInvoice.SearchIssuanceDt = ConvertDateTimeCWTISOFormat(convertedDate);
                                            }
                                        }

                                        if (!string.IsNullOrEmpty(cwtInvoice.TravelDt))
                                        {
                                            string convertedDate = ConvertDateTimeCWT(cwtInvoice.TravelDt);
                                            if (!string.IsNullOrEmpty(convertedDate))
                                            {
                                                cwtInvoice.TravelDt = convertedDate;
                                                cwtInvoice.SearchTravelDt = ConvertDateTimeCWTISOFormat(convertedDate);
                                            }

                                        }
                                        if (!string.IsNullOrEmpty(cwtInvoice.ReturnDt))
                                        {
                                            string convertedDate = ConvertDateTimeCWT(cwtInvoice.ReturnDt);
                                            if (!string.IsNullOrEmpty(convertedDate))
                                            {
                                                cwtInvoice.ReturnDt = convertedDate;
                                                cwtInvoice.SearchReturnDt = ConvertDateTimeCWTISOFormat(convertedDate);
                                            }
                                        }
                                        cwtInvcoicesListInCsv.Add(cwtInvoice);

                                    }
                                }

                            }
                        }

                        var distinctValues = cwtInvcoicesListInCsv.DistinctBy(x => x.VendorInvoiceCRNo);
                         duplicatesValues = cwtInvcoicesListInCsv.Except(distinctValues).ToList();

                        //var bookingInv = from fileName in distinctValues
                        //                 join files in invoiceBatch.CwtValidInvoiceTicketSupFiles on fileName.VendorInvoiceCRNo equals files.Split('_')[0]
                        //                 where files.ToLowerInvariant().Contains("inv") || files.ToLowerInvariant().Contains("tkt")
                        //                 select files;

                        //var cancelationInv = from fileName in distinctValues
                        //                     join files in invoiceBatch.CwtValidCrOiSupFiles on fileName.VendorInvoiceCRNo equals files.Split('_')[0]
                        //                     where files.ToLowerInvariant().Contains("crn") || files.ToLowerInvariant().Contains("oi")
                        //                     select files;

                        //if (duplicatesValues != null && duplicatesValues.Count() > 0)
                        //{
                        //    Console.WriteLine($"Duplicate entries in csv is there {JsonConvert.SerializeObject(duplicatesValues)}");
                        //    foreach (var duplicate in duplicatesValues)
                        //    {
                        //        duplicateInvoices.Add(duplicate.VendorInvoiceCRNo);
                        //    }
                        //}
                        if (distinctValues == null && distinctValues.Count() == 0)
                        {
                            Console.WriteLine($"No data is there in the csv to update ");
                            if (!string.IsNullOrEmpty(masterClass.CwtCSVFileName))
                            {
                                string renamedFileName = RenameFile(masterClass.CwtCSVFileName);
                                await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, cwtPrivateBucket, cwtPublicFolderPath, cwtPrivateCSVFolderPath, masterClass.CwtCSVFileName, renamedFileName, context);
                                await s3.DeleteFile(masterClass.BucketName, cwtPublicFolderPath, masterClass.CwtCSVFileName, context);
                            }
                            return;
                        }
                        MasterClass masterClassObj = null;
                        var orderdData = distinctValues.OrderBy(i => i.BookingCancelInd).ToList(); //need to have booking invoices in the begining so we can match them with the cancellation invoices
                        Console.WriteLine($"Sorted data {JsonConvert.SerializeObject(orderdData)}");
                        foreach (var cwtDataInCsv in orderdData)
                        {
                            masterClassObj = new MasterClass();
                            var CWTInvoiceDuplicateCheck = IsAEERejectedOrNewOrDuplicteInvoice(cwtDataInCsv.VendorInvoiceCRNo, scanResult);
                            Console.WriteLine($"{JsonConvert.SerializeObject(CWTInvoiceDuplicateCheck)}");
                            if (CWTInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate == "duplicate") // need not to insert the duplicate invoices unless they are rejected
                            {
                                context.Logger.Log($"Duplicate:-Invoice number -{cwtDataInCsv.VendorInvoiceCRNo}");
                                duplicateInvoicesInDB.Add(cwtDataInCsv);
                                continue; //do not insert continue to next set of data
                                          //await MoveInvalidInvTktFiles(s3, masterclass, attachedInvoiceFileName, renamedInvoiceFileName, attchedTicketFileName, renamedTicketFileName, context);
                            }
                            else 
                            {

                                #region no need for original booking invoice presence
                                //if (cwtDataInCsv.BookingCancelInd.ToLowerInvariant() == "cancel")
                                //{
                                //    float netPayDifference = 0;
                                //    if (!string.IsNullOrEmpty(cwtDataInCsv.InvoiceNo))
                                //    {
                                //        var matchedBookingInvoice = CheckForBookingInvNumberAndNetAmtDifference(scanResult, cwtDataInCsv.InvoiceNo, context);
                                //        if (matchedBookingInvoice != null && !string.IsNullOrEmpty(matchedBookingInvoice.VendorInvoiceCRNo))
                                //        {
                                //            if (!string.IsNullOrEmpty(cwtDataInCsv.NetPayAmt.ToString()))
                                //            {
                                //                if (!string.IsNullOrEmpty(matchedBookingInvoice.NetPayAmt.ToString())) // cancel data
                                //                {
                                //                    netPayDifference = matchedBookingInvoice.NetPayAmt + cwtDataInCsv.NetPayAmt;
                                //                }
                                //            }
                                //            else
                                //            {
                                //                if (!string.IsNullOrEmpty(matchedBookingInvoice.NetPayAmt.ToString())) //booking data
                                //                {
                                //                    netPayDifference = matchedBookingInvoice.NetPayAmt;
                                //                }
                                //            }
                                //            cwtDataInCsv.NetPayDifference = netPayDifference;
                                //        }
                                //        else
                                //        {
                                //            Console.WriteLine($"Data:error- booking invoice not found for cancel invoice {cwtDataInCsv.VendorInvoiceCRNo}");
                                //            creditNotesWithoutPriorBookingInvoice.Add(cwtDataInCsv.VendorInvoiceCRNo);
                                //            continue; //if not found move to next line for reading
                                //        }
                                //    }
                                //    else
                                //    {
                                //        Console.WriteLine($"Data:error- original invoice booking invoice number is not mentioned in table {cwtDataInCsv.VendorInvoiceCRNo}");
                                //        creditNotesWithoutPriorBookingInvoice.Add(cwtDataInCsv.VendorInvoiceCRNo);
                                //        continue; //if not found move to next line for reading
                                //    }
                                //}
                                #endregion

                                masterClassObj.BucketName = masterClass.BucketName;
                                masterClassObj.Vendor = masterClass.Vendor;
                                masterClassObj.InvoiceBatchDttm = masterClass.InvoiceBatchDttm;
                                masterClassObj.CWTInvoice = cwtDataInCsv;
                                /*every time invoice id is incremented and passed to next insertion to avoid the scanning each time and 
                                 to avoid insertion of the same invoid id as lambdas will be running parallelly/concurrently
                                 */

                                string vendorCdGenarated = "CWT" + "-" + 1;
                                if (CWTInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate == "new") 
                                {
                                    if (cwtNextVendorCd <= 999)
                                    {
                                        cwtNextVendorCd = cwtNextVendorCd + 1;
                                        vendorCdGenarated = "CWT" + "-" + cwtNextVendorCd;

                                    }
                                    else
                                    {
                                        cwtNextVendorCd = 1;
                                        vendorCdGenarated="CWT" + "-" + 1;
                                    }
                                }
                                else  // if invoice is RTP rejected then we have to overwrite the existing data (allowing them to upload the data)
                                {
                                    masterClassObj.CWTInvoice.Remarks = !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.Remarks)? CWTInvoiceDuplicateCheck.CWTInvoice.Remarks:null;
                                    masterClassObj.CWTInvoice.RTPRemarks= !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.RTPRemarks) ? CWTInvoiceDuplicateCheck.CWTInvoice.RTPRemarks : null;

                                    masterClassObj.CWTInvoice.CreatedDttm= !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.CreatedDttm) ? CWTInvoiceDuplicateCheck.CWTInvoice.CreatedDttm : null;
                                    masterClassObj.CWTInvoice.SearchCreatedDttm = !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.SearchCreatedDttm) ? CWTInvoiceDuplicateCheck.CWTInvoice.SearchCreatedDttm : null;

                                    masterClassObj.CWTInvoice.SearchResubmissionDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd"); ;

                                    masterClassObj.CWTInvoice.SearchInvoiceSubmittedDt = !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.SearchInvoiceSubmittedDt) ? CWTInvoiceDuplicateCheck.CWTInvoice.SearchInvoiceSubmittedDt : null;
                                    masterClassObj.CWTInvoice.InvoiceSubmittedDt = !string.IsNullOrEmpty(CWTInvoiceDuplicateCheck.CWTInvoice.InvoiceSubmittedDt) ? CWTInvoiceDuplicateCheck.CWTInvoice.InvoiceSubmittedDt : null;

                                    vendorCdGenarated = CWTInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate;
                                    
                                }
                                
                                masterClassObj.CWTInvoice.VendorCd = vendorCdGenarated;
                                masterClassObj.CWTInvoice.CWTInvoiceId = invoiceIdGenarated;
                                invoiceIdGenarated = invoiceIdGenarated + 1;  //incremeting the invoice id. ( which is needed in the api side)
                                masterClassObj.GSTMasterList = gstMasterList;
                                masterClassObj.InvoiceBatchItem = invoiceBatch;
                                if (DebugEnvironMent.ToLowerInvariant() == "true")
                                {
                                    var masterClassJsonString=JsonConvert.SerializeObject(masterClassObj);
                                    var masterClassObject=JsonConvert.DeserializeObject<CwtDataInsertion.Model.MasterClass>(masterClassJsonString);
                                    CwtDataInsertion.Function cwtDataInsertionFUnction = new CwtDataInsertion.Function();
                                   await cwtDataInsertionFUnction.FunctionHandler(masterClassObject,context);
                                }
                                else
                                {
                                    invokeRequest.Payload = JsonConvert.SerializeObject(masterClassObj);
                                    Console.WriteLine($"Master class {invokeRequest.Payload}");
                                    invokeRequest.FunctionName = "7433_iDigi_CWTDataInsertionAndValidation";
                                    var childLambdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                                    LogChildLambdaResponse(childLambdaResponse, context);
                                }                             
                                //if (masterClassObj.CWTInvoice.BookingCancelInd.ToLowerInvariant() == "booking")
                                //{
                                //    scanResult.Add(masterClassObj.CWTInvoice); // so we can match them with the cancellation invoices if booking data came in the same csv 
                                //}                                
                                //cwtInvoice = new CWTInvoice();
                            }
                        }
                        var cwtParamvalue = new Param();
                        cwtParamvalue.EndPos = 1000;
                        cwtParamvalue.StartPos = 1;
                        cwtParamvalue.LastPos = cwtNextVendorCd;
                        cwtParamvalue.ModuleNm = "CWT";
                        context.Logger.Log($" Max val at the end CWT: {cwtNextVendorCd}");
                        await db.UpdateItemAsync<Param>(cwtParamvalue, paramTable, context);

                        if (!string.IsNullOrEmpty(masterClass.CwtCSVFileName))
                        {
                            string renamedFileName = RenameFile(masterClass.CwtCSVFileName);
                            await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, cwtPrivateBucket, cwtPublicFolderPath, cwtPrivateCSVFolderPath, masterClass.CwtCSVFileName, renamedFileName, context);
                            await s3.DeleteFile(masterClass.BucketName, cwtPublicFolderPath, masterClass.CwtCSVFileName, context);
                        }
                    }
                    InvoiceErrorDetails invoiceErrorDetails = new InvoiceErrorDetails();
                    List<ErrorDetails> errorDetailsList = null;                    
                    foreach (var duplicate in duplicatesValues)
                        {
                            ErrorDetails errorDetail = new ErrorDetails();
                            errorDetailsList = new List<ErrorDetails>();
                            errorDetail.Error = $"Data for {duplicate.VendorInvoiceCRNo} is a present 2 times(Duplicate) in csv.only single invoice will be accepted into idigi on the successful passing of validations";
                            errorDetail.IsValidError = "true";
                            errorDetail.VendorType = "AEE";
                            errorDetailsList.Add(errorDetail);
                            invoiceErrorDetails.ErrorsList = errorDetailsList;
                            invoiceErrorDetails.InvoiceDt = !string.IsNullOrEmpty(duplicate.SearchInvoiceDt) ? duplicate.SearchInvoiceDt :null ;
                            invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                            invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                            invoiceErrorDetails.VendorInvoiceNbr = duplicate.VendorInvoiceCRNo;
                            invoiceErrorDetails.VendorModuleCd = "CWTADG";
                            Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                            await db.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                            Console.WriteLine($"Process: Inserted error details to table");
                        }                                   
                    foreach (var duplicate in duplicateInvoicesInDB)
                        {
                            ErrorDetails errorDetail = new ErrorDetails();
                            errorDetailsList = new List<ErrorDetails>();
                            errorDetail.Error = $"{duplicate.VendorInvoiceCRNo} is a duplicate invoice. This invoice is already present in idigi";
                            errorDetail.IsValidError = "true";
                            errorDetail.VendorType = "AEE";
                            errorDetailsList.Add(errorDetail);
                            invoiceErrorDetails.ErrorsList = errorDetailsList;
                            invoiceErrorDetails.InvoiceDt = !string.IsNullOrEmpty(duplicate.SearchInvoiceDt) ? duplicate.SearchInvoiceDt : null;
                            invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                            invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                            invoiceErrorDetails.VendorInvoiceNbr = duplicate.VendorInvoiceCRNo;
                            invoiceErrorDetails.VendorModuleCd = "CWTADG";
                            Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                            await db.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                            Console.WriteLine($"Process: Inserted error details to table");
                          


                        }

                    #region no need for moving the creditNotesWithoutPriorBookingInvoice 
                    //if (creditNotesWithoutPriorBookingInvoice != null && creditNotesWithoutPriorBookingInvoice.Count > 0)
                    //{
                    //    foreach (var invoiceNumber in creditNotesWithoutPriorBookingInvoice)
                    //    {
                    //        ErrorDetails errorDetail = new ErrorDetails();
                    //        errorDetailsList = new List<ErrorDetails>();
                    //        errorDetail.Error = $"{invoiceNumber} does not contain corresponding prior booking invoice in iDigi system.";
                    //        errorDetail.IsValidError = "true";
                    //        errorDetail.VendorType = "AEE";
                    //        errorDetailsList.Add(errorDetail);
                    //        invoiceErrorDetails.ErrorsList = errorDetailsList;
                    //        invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                    //        invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                    //        invoiceErrorDetails.VendorInvoiceNbr = invoiceNumber;
                    //        invoiceErrorDetails.VendorModuleCd = "CWTADG";
                    //        Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                    //        await db.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                    //        Console.WriteLine($"Process: Inserted error details to table");

                    //        var crFile = invoiceBatch.CwtValidCrOiSupFiles.Find(file => file.Contains(invoiceNumber) && file.ToLowerInvariant().Contains("_crn.pdf"));
                    //        if (!string.IsNullOrEmpty(crFile))
                    //        {
                    //            string renamedFileName = RenameFile(crFile);
                    //            await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, cwtPrivateBucket, cwtPublicFolderPath, cwtPrivateInvalidFilespath, crFile, renamedFileName, context);
                    //            await s3.DeleteFile(masterClass.BucketName, cwtPublicFolderPath, crFile, context);
                    //        }
                    //        var oiFile = invoiceBatch.CwtValidCrOiSupFiles.Find(file => file.Contains(invoiceNumber) && file.ToLowerInvariant().Contains("_oi.pdf"));
                    //        if (!string.IsNullOrEmpty(oiFile))
                    //        {
                    //            string renamedFileName = RenameFile(crFile);
                    //            await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, cwtPrivateBucket, cwtPublicFolderPath, cwtPrivateInvalidFilespath, oiFile, renamedFileName, context);
                    //            await s3.DeleteFile(masterClass.BucketName, cwtPublicFolderPath, oiFile, context);
                    //        }
                    //    }
                    //}
                    #endregion
                }
                #endregion
                #region CSR
                try
                {
                    if (masterClass.Vendor.ToLowerInvariant() == CommonConstants.CSRTeam.ToLowerInvariant())
                    {
                        context.Logger.Log($"Inside csr module");
                        int max = 0;
                        string CsrInvIdGenerated = "CSR100285915-";
                        Param LastValTbl = null;

                        context.Logger.Log($" Read Param table :{paramTable}");
                        var document = await db.GetItem(paramTable, "CSR");
                        LastValTbl = IDigiDynamoDocumentConverter.ToObject<Param>(document);
                        if (LastValTbl.LastPos < 1000)
                        {
                            max = LastValTbl.LastPos;
                        }
                        else if (LastValTbl.LastPos >= 1000)
                        {
                            max = 0;
                        }

                        context.Logger.Log($" max no saved : {max}");
                        var csrInvoicelist = await CSRInvoiceList(db, csrTable, context);
                        context.Logger.Log($" CSR CSV file name in source path : {masterClass.CsrCSVFileName}");

                        var csrInvoiceTicketFileList = await s3.ListAllTheFilesInFolder(masterClass.BucketName, CsrPublicFolderPath, context);
                        List<string> duplicateFileList = new List<string>();

                        if (!string.IsNullOrEmpty(masterClass.CsrCSVFileName) && !string.IsNullOrEmpty(masterClass.BucketName))
                        {
                            Dictionary<string, bool> invoiceNumberDictionary = new Dictionary<string, bool>();
                            var CsrCSVData = await s3.GetFileFromS3(masterClass.BucketName, CsrPublicFolderPath, masterClass.CsrCSVFileName, context);
                            if (CsrCSVData != null)
                            {
                                context.Logger.Log($" max no saved : {max}");
                                var csvStream = new StreamReader(CsrCSVData.ResponseStream);
                                var csv1 = new CsvReader(csvStream);
                                csv1.Configuration.HasHeaderRecord = true;
                                context.Logger.Log($" Check for duplicate in Csv file ");
                                while (csv1.Read())
                                {
                                    if (!string.IsNullOrEmpty(csv1.GetField<string>(21)))
                                    {
                                        if (!invoiceNumberDictionary.ContainsKey(csv1.GetField<string>(21)))
                                        {
                                            string invoiceNumber = csv1.GetField<string>(21);
                                            invoiceNumberDictionary.Add(invoiceNumber, false);
                                        }
                                    }
                                }
                                var fileColsDBColsMappinglist = ReturnFilesCollumnDbCollumnForCSr();
                                context.Logger.Log($"Log: Row count :{JsonConvert.SerializeObject(fileColsDBColsMappinglist)}");
                                var CsrCSVDataCopy = await s3.GetFileFromS3(masterClass.BucketName, CsrPublicFolderPath, masterClass.CsrCSVFileName, context);
                                using (var stream = new StreamReader(CsrCSVDataCopy.ResponseStream))
                                {
                                    var csv = new CsvReader(stream);
                                    csv.Configuration.HasHeaderRecord = true;
                                    MasterClass masterClassObj = null;
                                    CSRInvoice csrDataObj = null;
                                    Param LastValUpdate = null;
                                    while (csv.Read())
                                    {
                                        //context.Logger.Log($"Log: Row count :{csv.Row}");
                                        csrDataObj = new CSRInvoice();
                                        csrDataObj = ReadCSVDataBasedOnIndexRequired<CSRInvoice>(csv, csrDataObj, fileColsDBColsMappinglist, context);
                                        if (csrDataObj != null && !string.IsNullOrEmpty(csrDataObj.InvoiceDt))
                                        {
                                            bool a;
                                            context.Logger.Log($" invoice number {csrDataObj.InvoiceNumber}");
                                            if (invoiceNumberDictionary.TryGetValue(csrDataObj.InvoiceNumber, out a))
                                            {
                                                Console.WriteLine(JsonConvert.SerializeObject($"{invoiceNumberDictionary[csrDataObj.InvoiceNumber]}"));
                                                if (!invoiceNumberDictionary[csrDataObj.InvoiceNumber])
                                                {
                                                    if (IsThisCSRADuplicateInvoice(csrDataObj.InvoiceNumber, csrInvoicelist))
                                                    {
                                                        context.Logger.Log($"Data -error: Duplicate- Invoice number {csrDataObj.InvoiceNumber}");
                                                        var tempFileList = csrInvoiceTicketFileList.Where(file => file.Contains("_" + csrDataObj.InvoiceNumber + "."));
                                                        if (tempFileList != null && tempFileList.Count() > 0)
                                                        {
                                                            duplicateFileList.AddRange(tempFileList);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        context.Logger.Log($" invoice number {csrDataObj.InvoiceNumber}");
                                                        masterClassObj = new MasterClass();
                                                        masterClassObj.BucketName = masterClass.BucketName;
                                                        masterClassObj.Vendor = masterClass.Vendor;
                                                        masterClassObj.InvoiceBatchDttm = masterClass.InvoiceBatchDttm;

                                                        context.Logger.Log($" IsDublicate : {masterClassObj.IsDublicate}");
                                                        masterClassObj.CSRInvoice = csrDataObj;
                                                        context.Logger.Log($" Un changed Inv Dt : {csrDataObj.InvoiceDt}");
                                                        //DateTime dt = Convert.ToDateTime(csrDataObj.InvoiceDt);
                                                        masterClassObj.CSRInvoice.InvoiceDt = ConvertDateTimeCSR(csrDataObj.InvoiceDt); //dt.ToString("mm/dd/yyyy")
                                                        context.Logger.Log($" changed Inv Dt : {masterClassObj.CSRInvoice.InvoiceDt}");

                                                        if (max <= 999)
                                                        {
                                                            max = max + 1;
                                                        }
                                                        else
                                                        {
                                                            max = 1;
                                                        }
                                                        masterClassObj.CSRInvoice.VendorCd = CsrInvIdGenerated + max.ToString();

                                                        context.Logger.Log($" max no saved : {max}");
                                                        invokeRequest.Payload = JsonConvert.SerializeObject(masterClassObj);
                                                        invokeRequest.FunctionName = "7433_iDigi_CSRDataValidationAndInsertion";
                                                        var childLambdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                                                        LogChildLambdaResponse(childLambdaResponse, context);
                                                        invoiceNumberDictionary[csrDataObj.InvoiceNumber] = true;
                                                    }

                                                }
                                                else
                                                {
                                                    context.Logger.Log($"Data -error: Duplicate- Invoice number {csrDataObj.InvoiceNumber}");
                                                    var tempFileList = csrInvoiceTicketFileList.Where(file => file.Contains("_" + csrDataObj.InvoiceNumber + "."));
                                                    if (tempFileList != null && tempFileList.Count() > 0)
                                                    {
                                                        duplicateFileList.AddRange(tempFileList);
                                                    }
                                                }
                                            }
                                            csrDataObj = new CSRInvoice();

                                        }
                                    }
                                    LastValUpdate = new Param();
                                    LastValUpdate.EndPos = 1000;
                                    LastValUpdate.StartPos = 1;
                                    LastValUpdate.LastPos = max;
                                    LastValUpdate.ModuleNm = "CSR";
                                    context.Logger.Log($" max val at the end : {max}");
                                    await db.UpdateItemAsync<Param>(LastValUpdate, paramTable, context);
                                }
                            }
                            if (!string.IsNullOrEmpty(masterClass.CsrCSVFileName))
                            {
                                string renamedFileName = RenameFile(masterClass.CsrCSVFileName);
                                await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, CSRDestinationBucket, CsrPublicFolderPath, CsrcsvPrivateFolderPath, masterClass.CsrCSVFileName, renamedFileName, context);
                                await s3.DeleteFile(masterClass.BucketName, CsrPublicFolderPath, masterClass.CsrCSVFileName, context);
                            }
                            if (duplicateFileList != null && duplicateFileList.Count > 0)
                            {

                                foreach (var fileName in duplicateFileList)
                                {
                                    string renamedFileName = RenameFile(fileName);
                                    await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, CSRDestinationBucket, CsrPublicFolderPath, csrInvalidFilePath, fileName, renamedFileName, context);
                                    await s3.DeleteFile(masterClass.BucketName, CsrPublicFolderPath, fileName, context);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    context.Logger.Log($" Exception logged : {JsonConvert.SerializeObject(ex)}");
                }
                #endregion
            }
        }

        private List<string> ReturnCRandOIInvoiceNumber(string invoiceNumber, InvoiceBatch invoiceBatch)
        {
            List<string> invalidFiles = new List<string>();

            var crFile = invoiceBatch.CwtValidCrOiSupFiles.Find(file => file.Contains(invoiceNumber) && file.ToLowerInvariant().Contains("_crn.pdf"));
            if (!string.IsNullOrEmpty(crFile))
            {
                invalidFiles.Add(crFile);
            }
            var oiFile = invoiceBatch.CwtValidCrOiSupFiles.Find(file => file.Contains(invoiceNumber) && file.ToLowerInvariant().Contains("_oi.pdf"));
            if (!string.IsNullOrEmpty(oiFile))
            {
                invalidFiles.Add(oiFile);
            }
            return null;
        }

        private CWTInvoice CheckForBookingInvNumberAndNetAmtDifference(List<CWTInvoice> cwtInvoicesList, string invoiceNo, ILambdaContext context)
        {
            var cwtInvoice = cwtInvoicesList.Find(i => i.VendorInvoiceCRNo == invoiceNo && i.BookingCancelInd.ToLowerInvariant() == "booking");
            return cwtInvoice;
        }

        private bool IsThisVisaDuplicateInvoice(List<UdaanInvoice> listUdaanInvoices, string invoiceNumber, string vendorRegisteredCode)
        {
            //Console.WriteLine($"Duplicate check{invoiceNumber}/{vendorRegisteredCode}");

            if (vendorRegisteredCode.Length == 10)
            {
                vendorRegisteredCode = vendorRegisteredCode.TrimStart('0'); // removing leading 0 from the vendorregistered cd as some time it conatin 0 some time it wont
            }
            /////////////////////////////////////////////////////////                                    abc==abc  && 123=0123
            var duplicateInvoice = listUdaanInvoices.Where(invoice => invoice.VendorInvoiceNumber == invoiceNumber && invoice.VendorRegisteredCd == vendorRegisteredCode);

            if (duplicateInvoice != null && duplicateInvoice.Count() > 0)
            {
                Console.WriteLine($" Duplicate found for {invoiceNumber}, vendorregisteredcd {vendorRegisteredCode} ,{JsonConvert.SerializeObject(duplicateInvoice)}");
                return true;
            }
            else
            {
                return false;
            }

        }

        private List<FileColsDBColsMapping> ReturnFilesCollumnDbCollumnForCSr()
        {

            List<FileColsDBColsMapping> filesCollumnDbCollummapping = new List<FileColsDBColsMapping>();

            FileColsDBColsMapping filCollumnDbcolMapping0 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping1 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping2 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping3 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping4 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping5 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping6 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping7 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping8 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping9 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping10 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping11 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping12 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping13 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping14 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping15 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping16 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping17 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping18 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping19 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping20 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping21 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping22 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping23 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping24 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping25 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping26 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping27 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping28 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping29 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping30 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping31 = new FileColsDBColsMapping();
            FileColsDBColsMapping filCollumnDbcolMapping32 = new FileColsDBColsMapping();

            filCollumnDbcolMapping0.IndexOfCollInCsvfile = 0;
            filCollumnDbcolMapping1.IndexOfCollInCsvfile = 1;
            filCollumnDbcolMapping2.IndexOfCollInCsvfile = 2;
            filCollumnDbcolMapping3.IndexOfCollInCsvfile = 3;
            filCollumnDbcolMapping4.IndexOfCollInCsvfile = 4;
            filCollumnDbcolMapping5.IndexOfCollInCsvfile = 5;
            filCollumnDbcolMapping6.IndexOfCollInCsvfile = 6;
            filCollumnDbcolMapping7.IndexOfCollInCsvfile = 7;
            filCollumnDbcolMapping8.IndexOfCollInCsvfile = 8;
            filCollumnDbcolMapping9.IndexOfCollInCsvfile = 9;
            filCollumnDbcolMapping10.IndexOfCollInCsvfile = 10;
            filCollumnDbcolMapping11.IndexOfCollInCsvfile = 11;
            filCollumnDbcolMapping12.IndexOfCollInCsvfile = 12;
            filCollumnDbcolMapping13.IndexOfCollInCsvfile = 13;
            filCollumnDbcolMapping14.IndexOfCollInCsvfile = 14;
            filCollumnDbcolMapping15.IndexOfCollInCsvfile = 15;
            filCollumnDbcolMapping16.IndexOfCollInCsvfile = 16;
            filCollumnDbcolMapping17.IndexOfCollInCsvfile = 17;
            filCollumnDbcolMapping18.IndexOfCollInCsvfile = 18;
            filCollumnDbcolMapping19.IndexOfCollInCsvfile = 19;
            filCollumnDbcolMapping20.IndexOfCollInCsvfile = 20;
            filCollumnDbcolMapping21.IndexOfCollInCsvfile = 21;
            filCollumnDbcolMapping22.IndexOfCollInCsvfile = 22;
            filCollumnDbcolMapping23.IndexOfCollInCsvfile = 23;
            filCollumnDbcolMapping24.IndexOfCollInCsvfile = 24;
            filCollumnDbcolMapping25.IndexOfCollInCsvfile = 25;
            filCollumnDbcolMapping26.IndexOfCollInCsvfile = 26;
            filCollumnDbcolMapping27.IndexOfCollInCsvfile = 27;
            filCollumnDbcolMapping28.IndexOfCollInCsvfile = 28;
            filCollumnDbcolMapping29.IndexOfCollInCsvfile = 29;
            filCollumnDbcolMapping30.IndexOfCollInCsvfile = 30;
            filCollumnDbcolMapping31.IndexOfCollInCsvfile = 31;
            filCollumnDbcolMapping32.IndexOfCollInCsvfile = 32;

            filCollumnDbcolMapping0.ReqFieldNm = "TRNumber";
            filCollumnDbcolMapping1.ReqFieldNm = "BookingID";
            filCollumnDbcolMapping2.ReqFieldNm = "BookingDt";
            filCollumnDbcolMapping3.ReqFieldNm = "EmpNm";
            filCollumnDbcolMapping4.ReqFieldNm = "EmpNumber";
            filCollumnDbcolMapping5.ReqFieldNm = "EmpPhone";
            filCollumnDbcolMapping6.ReqFieldNm = "WBSECd";
            filCollumnDbcolMapping7.ReqFieldNm = "EmpEmail";
            filCollumnDbcolMapping8.ReqFieldNm = "DestFacility";
            filCollumnDbcolMapping9.ReqFieldNm = "DestState";
            filCollumnDbcolMapping10.ReqFieldNm = "TravelCity";
            filCollumnDbcolMapping11.ReqFieldNm = "StateCd";
            filCollumnDbcolMapping12.ReqFieldNm = "BillingAddressAcc";
            filCollumnDbcolMapping13.ReqFieldNm = "CheckInDt";
            filCollumnDbcolMapping14.ReqFieldNm = "CheckOutDt";
            filCollumnDbcolMapping15.ReqFieldNm = "PropertyNm";
            filCollumnDbcolMapping16.ReqFieldNm = "PropertyEmail";
            filCollumnDbcolMapping17.ReqFieldNm = "PropertyPhone";

            //filCollumnDbcolMapping18.ReqFieldNm = "CorporateGST";
            //filCollumnDbcolMapping19.ReqFieldNm = "PropertyGST";

            filCollumnDbcolMapping18.ReqFieldNm = "PropertyGST";
            filCollumnDbcolMapping19.ReqFieldNm = "CorporateGST";

            filCollumnDbcolMapping20.ReqFieldNm = "BillingAddressCSR";
            filCollumnDbcolMapping21.ReqFieldNm = "InvoiceNumber";
            filCollumnDbcolMapping22.ReqFieldNm = "InvoiceDt";
            filCollumnDbcolMapping23.ReqFieldNm = "BankRefNumber";
            filCollumnDbcolMapping24.ReqFieldNm = "HSNSSE";
            filCollumnDbcolMapping25.ReqFieldNm = "TaxableAmt";
            filCollumnDbcolMapping26.ReqFieldNm = "SingleSGSTTax";
            filCollumnDbcolMapping27.ReqFieldNm = "SingleSGSTAmt";
            filCollumnDbcolMapping28.ReqFieldNm = "SingleCGSTTax";
            filCollumnDbcolMapping29.ReqFieldNm = "SingleCGSTAmt";
            filCollumnDbcolMapping30.ReqFieldNm = "SingleIGSTTax";
            filCollumnDbcolMapping31.ReqFieldNm = "SingleIGSTAmt";
            filCollumnDbcolMapping32.ReqFieldNm = "TotalAmt";

            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping0);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping1);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping2);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping3);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping4);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping5);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping6);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping7);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping8);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping9);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping10);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping11);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping12);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping13);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping14);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping15);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping16);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping17);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping18);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping19);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping20);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping21);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping22);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping23);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping24);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping25);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping26);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping27);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping28);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping29);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping30);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping31);
            filesCollumnDbCollummapping.Add(filCollumnDbcolMapping32);



            return filesCollumnDbCollummapping;


        }
        private async Task<List<FileColsDBColsMapping>> ReadFileColsDBMappingTable(string tableName, string moduleCd, string headerType, string isActive)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            ScanFilter sfc = new ScanFilter();
            sfc.AddCondition("VendorModuleCd", ScanOperator.Equal, moduleCd);
            sfc.AddCondition("HeaderColType", ScanOperator.Equal, headerType);
            sfc.AddCondition("IsActive", ScanOperator.Equal, isActive);
            Search search = table.Scan(sfc);
            List<FileColsDBColsMapping> fileColsDBColsMappinglist = new List<FileColsDBColsMapping>();
            do
            {
                List<Document> docList = new List<Document>();
                docList = await search.GetNextSetAsync();
                foreach (var doc in docList)
                {
                    fileColsDBColsMappinglist.Add(IDigiDynamoDocumentConverter.ToObject<FileColsDBColsMapping>(doc));
                }
            }
            while (!search.IsDone);

            return fileColsDBColsMappinglist;
        }
        private T ReadCSVDataBasedOnIndexRequired<T>(CsvReader csv, T tObject, List<FileColsDBColsMapping> fileColsDBColsMappinglist, ILambdaContext context)
        {
            try
            {

                foreach (var fileColsDBColsMap in fileColsDBColsMappinglist)
                {
                    string requiredFieldname = fileColsDBColsMap.ReqFieldNm;
                    int indexInCsv = fileColsDBColsMap.IndexOfCollInCsvfile;
                    PropertyInfo propertyInfo = tObject.GetType().GetProperty(requiredFieldname);
                    if (propertyInfo != null)
                    {

                        var propType = propertyInfo.PropertyType;

                        if (propType == typeof(string))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                propertyInfo.SetValue(tObject, csv.GetField<string>(indexInCsv));
                            }
                        }
                        if (propType == typeof(int) || propType == typeof(int?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                int a;
                                if (int.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, int.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        if (propType == typeof(double) || propType == typeof(double?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                double a;
                                if (double.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, double.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        if (propType == typeof(float) || propType == typeof(float?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                float a;
                                if (float.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, float.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        //context.Logger.Log($"index {indexInCsv}  Property {requiredFieldname}");
                        //context.Logger.Log($"{csv.GetField<string>(indexInCsv)}");
                    }
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"Error : Exception message {e.Message}");
                context.Logger.Log($"Error : Inner exception {e.InnerException}");
                context.Logger.Log($"Error : Stack trace {e.StackTrace}");
            }
            return tObject;
        }
        private void LogChildLambdaResponse(dynamic childLmbdaResponse, ILambdaContext context)
        {
            context.Logger.Log($"Log: Running Child lambda instace id :{childLmbdaResponse.Id}");
            context.Logger.Log($"Log: Is Child lambda Instace :{childLmbdaResponse.Id} cancelled :{childLmbdaResponse.IsCanceled}");
            context.Logger.Log($"Log: Is child lambda instance faulted :{childLmbdaResponse.IsFaulted} ");
            context.Logger.Log($"Log: Result  :{childLmbdaResponse.Result} ");
            context.Logger.Log($"Log: Status  :{childLmbdaResponse.Status} ");
        }
        private async Task<List<T>> ScanAndFetchLatestPartitionIdentityValue<T>(string tableName, Primitive key, ILambdaContext context)
        {
            List<T> tObjectList = new List<T>();
            try
            {
                ScanFilter filter = new ScanFilter();
                Table table = Table.LoadTable(DbClient, tableName);
                Search search = table.Scan(filter);
                do
                {
                    List<Document> listObj = await search.GetNextSetAsync();
                    foreach (var obj in listObj)
                    {
                        tObjectList.Add(IDigiDynamoDocumentConverter.ToObject<T>(obj));
                    }
                }
                while (!search.IsDone);
            }
            catch (Exception e)
            {
                context.Logger.Log($"Error : {e.Message}");
            }
            return tObjectList;
        }
        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
        private string ConvertDateTimeCWT(string date)
        {
            string convertedDate = string.Empty;
            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is  mm/dd/yyyy in cwt
                    convertedDate = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                }
            }
            return convertedDate;
        }
        private string ConvertDateTimeCWTISOFormat(string date)
        {
            string convertedDate = string.Empty;
            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is  mm/dd/yyyy in cwt to yyyy/mm/dd
                    convertedDate = splitedDate[2] + "/" + splitedDate[0] + "/" + splitedDate[1];
                }
            }
            return convertedDate;
        }
        private string ConvertDateTimeCSR(string date)
        {
            string convertedDate = string.Empty;
            #region DD-MMM-YY
            //int monthInMM = 0;
            //string monthStrInMM = string.Empty;
            //var DateStr = date.Split('-');
            //if (DateStr[0].Length == 1)
            //{
            //    DateStr[0] = "0" + DateStr[0];
            //}
            //if (DateStr[1].Length == 3)
            //{
            //    //DateStr[1] = !string.IsNullOrEmpty(DateStr[1])?
            //    //    (DateStr[1].ToLower() == "jan"? ) : "00";
            //    monthInMM = DateTime.ParseExact(DateStr[1], "MMM", CultureInfo.CurrentCulture).Month;
            //    if (monthInMM.ToString().Length == 1)
            //    {
            //        monthStrInMM = "0" + monthInMM.ToString();
            //    }
            //    else
            //    {
            //        monthStrInMM = monthInMM.ToString();
            //    }

            //}

            ////date format is yyyy-mm-dd
            //convertedDate =  CultureInfo.CurrentCulture.Calendar.ToFourDigitYear(Convert.ToInt32(DateStr[2])).ToString() + "-" + monthStrInMM + "-" + DateStr[0] ;
            #endregion

            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is yyyy-mm-dd in csr
                    convertedDate = splitedDate[2] + "-" + splitedDate[0] + "-" + splitedDate[1];
                }
            }

            return convertedDate;
        }
        private async Task<InvoiceBatch> GetInvoiceBatch(string tableName, string vendorName, string invoiceBatchDatetm)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            return IDigiDynamoDocumentConverter.ToObject<InvoiceBatch>(await table.GetItemAsync(vendorName, invoiceBatchDatetm));
        }
        private bool IsThisADuplicateInvoice(string invoiceNumber, List<CWTInvoice> listOfInvoices)
        {
            if (listOfInvoices != null)
            {
                var invoiceCount = listOfInvoices.Where(invoice => invoice.VendorInvoiceCRNo == invoiceNumber);
                if (invoiceCount != null && invoiceCount.Count() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }
        private bool IsThisCSRADuplicateInvoice(string invoiceNumber, List<CSRInvoice> listOfInvoices)
        {
            if (listOfInvoices != null)
            {
                var invoiceCount = listOfInvoices.Where(invoice => invoice.InvoiceNumber == invoiceNumber);
                if (invoiceCount != null && invoiceCount.Count() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }
        private async Task<List<CSRInvoice>> CSRInvoiceList(IDigiDynamoDb db, string tableName, ILambdaContext context)
        {
            List<CSRInvoice> listOfObjects = new List<CSRInvoice>();
            ScanOperationConfig scanConfig = new ScanOperationConfig();
            scanConfig.Filter.AddCondition("InvoiceNumber", ScanOperator.IsNotNull);
            listOfObjects = await db.FilterScanSpecificAttribute<CSRInvoice>(scanConfig, tableName);
            return listOfObjects;
        }

        private CWTInvoiceDuplicateCheck IsAEERejectedOrNewOrDuplicteInvoice(string invoiceNumber, List<CWTInvoice> listOfInvoices)
        {
            string vendorCd = "new";
            CWTInvoiceDuplicateCheck cwtInvoiceDuplicateCheck = new CWTInvoiceDuplicateCheck();
            cwtInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate = "new";
            if (listOfInvoices != null)
            {
                var invoiceCount = listOfInvoices.Where(invoice => invoice.VendorInvoiceCRNo == invoiceNumber);
                if (invoiceCount != null && invoiceCount.Count() > 0)
                {
                    //if (invoiceCount.First().AEEAction.ToLowerInvariant() == "rejected")
                    //{
                    //     vendorCd = invoiceCount.First().VendorCd;
                    //}
                    //else if (invoiceCount.First().AEEAction.ToLowerInvariant() != "rejected")
                    //{
                    //     vendorCd = "duplicate";
                    //}

                    // when the rtp rejects the invoice then the resubmission of the data is allowed
                    if (invoiceCount.First().RTPAction.ToLowerInvariant() == "rejected")
                    {
                        //vendorCd = invoiceCount.First().VendorCd;
                        cwtInvoiceDuplicateCheck.CWTInvoice = invoiceCount.First();
                        
                        cwtInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate = invoiceCount.First().VendorCd;
                    }
                    else if (invoiceCount.First().RTPAction.ToLowerInvariant() != "rejected")
                    {
                        //vendorCd = "duplicate";
                        //cwtInvoiceDuplicateCheck.CWTInvoice = invoiceCount.First();
                        cwtInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate = "duplicate";


                    }
                    return cwtInvoiceDuplicateCheck;
                }
                else
                {
                    cwtInvoiceDuplicateCheck.isRejectedOrNewOrDuplicate = "new";
                    return cwtInvoiceDuplicateCheck;
                }
            }
            else
                return cwtInvoiceDuplicateCheck;
        }

    }
}
