﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_Iqn
{
    //[DynamoDBTable("7433_Dev_Invoices")]
    public class Invoice
    {
        public Invoice()
        {
            InvoiceLineItems = new List<InvoiceLineItem>();
            InvoiceHistoryLogs = new List<InvoiceHistory>();
        }
        //public int Id { get; set; }
        //[DynamoDBHashKey]
        //public int InvoiceID { get; set; }
        //public int? InvoiceDataId { get; set; }
        public int? CurrentInvoiceBatchId { get; set; }
        public string InternalInvoiceRefNbr { get; set; }
        public string VendorModuleCd { get; set; }
        //[DynamoDBRangeKey]
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string VendorGSTNumber { get; set; }
        public string InvoiceStatusCd { get; set; }
        public int CurrentLGIBatchFileToSAPId { get; set; }
        public string UserRoleBasedInd { get; set; }
        public string AssignedRoleCd { get; set; }
        public string AssignedUserLoginCd { get; set; }
        public string AssignedInternalUserId { get; set; }
        public string TPCd { get; set; }
        public string DCInd { get; set; }
        public string InvoiceDt { get; set; }
        public string SearchInvoiceDt { get; set; }
        public double? TaxAmt { get; set; }
        public double? FreightAmt { get; set; }
        public double? GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string PaymentStatus { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string SearchInvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public double? Base1Amt { get; set; }
        public double? Base2Amt { get; set; }
        public double? Base3Amt { get; set; }
        public double? Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string UpdateDttm { get; set; }
        public string SearchUpdateDttm { get; set; }
        public string UpdateUserId { get; set; }
        public string CreateDttm { get; set; }
        public string SearchCreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string LGIDownloaded { get; set; }
        public string SAPDocNo { get; set; }
        public string DFMURN { get; set; }
        public string AutomationTemplateDownloaded { get; set; }
        public string RTPTeam { get; set; }
        public string RowType { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string Description { get; set; }
        public double? TaxParameter1Amt { get; set; }
        public double? TaxParameter2Amt { get; set; }
        public double? LineAmt { get; set; }
        public string ChargedEntity { get; set; }
        public double? Quantity { get; set; }
        public string PoNbr { get; set; }
        public double? PoLineNbr { get; set; }
        public string Plant { get; set; }
        public string MaterialGroup { get; set; }
        public double? UnitPrice { get; set; }
        public string InvoicePdf { get; set; }
        //public int InvoiceDTId { get; set; }
        public string PageTitle { get; set; }
        public string HoldReason { get; set; }
        public string Remarks { get; set; }
        public string RTPRemarks { get; set; }
        public string CompanyCd { get; set; }
        public byte IsOverrideProcessingBlock { get; set; }
        public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        public InvoiceLineItem InvoiceLineItem { get; set; }

        public string RTPActionOnLGI { get; set; }
        public string RTPActionOnPDF { get; set; }

        public string  ModifiedDttm { get; set; }
        public string  SearchModifiedDttm { get; set; }
        public string  ModifiedBy { get; set; }

        public string InvoiceSubmissionDt { get; set; }
        public string SearchInvoiceSubmissionDt { get; set; }
        public string GSTR2AStatus { get; set; }
        public string IsExempted { get; set; }
        public string SGST { get; set; }

        public string CGST { get; set; }
        public string IGST { get; set; }

        public string SKU { get; set; }
        public double? TaxableValue { get; set; }

        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }

    }
}
