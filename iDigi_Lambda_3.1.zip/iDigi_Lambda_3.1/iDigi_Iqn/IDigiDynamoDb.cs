﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_Iqn
{
    public class IDigiDynamoDb
    {
        IAmazonDynamoDB DynamoDbClient { get; set; }
        //AWSDynamoTableConfig config = new AWSDynamoTableConfig("7433_Dev_", typeof(string), "Id", 5, 5);

        public IDigiDynamoDb()
        {
            DynamoDbClient = new AmazonDynamoDBClient();

            //use as needed
            //DynamoDBContext context = new DynamoDBContext(DynamoDbClient);           
        }
        public async Task InsertAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(DynamoDbClient, tableName);
            var document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.PutItemAsync(document);
        }
        public async Task InsertLambdaLogDetails(object obj, string tableName)
        {
            Table table = Table.LoadTable(DynamoDbClient, tableName);
            Document document = IDigiDynamoDocumentConverter.ToDocument(obj);
            await table.PutItemAsync(document);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj">Object with only attributes need update has to be intialised otherwise all other atribute
        /// values will be over written, primary keys are mondatary 
        /// </param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public async Task UpdateLambdaLogDetails(object obj, string tableName)
        {
            Table table = Table.LoadTable(DynamoDbClient, tableName);
            Document document = IDigiDynamoDocumentConverter.ToDocument(obj);

            await table.UpdateItemAsync(document);
        }
        public async Task<List<T>> ScanAsync<T>(ScanFilter scanFilterCondition, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(DynamoDbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            do
            {
                List<Document> documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }
    }
}
