﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_Iqn
{
    public class GSTMasterEntities
    {
        /// <summary>
        /// GSTMasterEntities
        /// </summary>
        public GSTMasterEntities()
        {

        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Entity Framework proxies requrie it.")]

        public GSTMasterEntities(int id)
        {
            Id = id;
        }
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// BusinessPlace
        /// </summary>
        public string BusinessPlace { get; set; }
        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// CompanyCode
        /// </summary>
        public string CompanyCode { get; set; }
        /// <summary>
        /// Country
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// CreatedBy
        /// </summary>
        public string CreatedBy { get; set; }
        /// <summary>
        /// CreatedDttm
        /// </summary>
        public string CreatedDttm { get; set; }
        /// <summary>
        /// FacilityName
        /// </summary>
        public string FacilityName { get; set; }
        /// <summary>
        /// FaxNumber
        /// </summary>
        public string FaxNumber { get; set; }
        /// <summary>
        /// GSTID
        /// </summary>
        public int GSTID { get; set; }
        /// <summary>
        /// GSTIN
        /// </summary>
        public string GSTIN { get; set; }
        /// <summary>
        /// IsActive
        /// </summary>
        public string IsActive { get; set; }
        /// <summary>
        /// LegalEntity
        /// </summary>
        public string LegalEntity { get; set; }
        /// <summary>
        /// Name1
        /// </summary>
        public string Name1 { get; set; }
        /// <summary>
        /// Name2
        /// </summary>
        public string Name2 { get; set; }
        /// <summary>
        /// NotUsed
        /// </summary>
        public string NotUsed { get; set; }
        /// <summary>
        /// PaymasterEntity
        /// </summary>
        public string PaymasterEntity { get; set; }
        /// <summary>
        /// Plant
        /// </summary>
        public string Plant { get; set; }
        /// <summary>
        /// PoBox
        /// </summary>
        public string PoBox { get; set; }
        /// <summary>
        /// PostCode
        /// </summary>
        public int PostCode { get; set; }
        /// <summary>
        /// Region
        /// </summary>
        public string Region { get; set; }
        /// <summary>
        /// Remarks
        /// </summary>
        public string Remarks { get; set; }
        /// <summary>
        /// Street
        /// </summary>
        public string Street { get; set; }
        /// <summary>
        /// TaxFillingGroup
        /// </summary>
        public string TaxFillingGroup { get; set; }
        /// <summary>
        /// TelNumber
        /// </summary>
        public string TelNumber { get; set; }
        /// <summary>
        /// Type
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// UpdatedBy
        /// </summary>
        public string UpdatedBy { get; set; }
        /// <summary>
        /// UpdatedDttm
        /// </summary>
        public string UpdatedDttm { get; set; }


    }
}
