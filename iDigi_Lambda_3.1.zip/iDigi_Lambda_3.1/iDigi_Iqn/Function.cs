using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Util;
using Amazon.S3.Model;
using CsvHelper;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Model;
using System.Globalization;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_Iqn
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                //return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
               
                 return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); // amazon linux os 

            }
        
        }
        
       
        //DateTime indianTime = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE);
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            S3Client = new AmazonS3Client();
            LambdaClient = new AmazonLambdaClient();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
        }

        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            InvokeRequest invokeRequest = new InvokeRequest();
            invokeRequest.FunctionName = "";
            invokeRequest.InvocationType = InvocationType.Event;
            DateTime datetime = new DateTime();
            string invoiceTable = string.Empty;
            string historyTable = string.Empty;
            string vendorMasterTable = string.Empty;
            string GSTMasterTable = string.Empty;
            string iqnPrivateLgiCsvFolder = CommonConstants.Private_Folder + "/" + CommonConstants.IqnVendor_FilePath + "/" + CommonConstants.IqnPrivateLgicsvFolder;
            string iqnLgiCsvDumpFolder = CommonConstants.Public_Folder + "/" + CommonConstants.IqnVendor_FilePath;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                invoiceTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceTable;
                historyTable = CommonConstants.AirId + "_" + CommonConstants.HistoryTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                GSTMasterTable = CommonConstants.AirId + "_" + CommonConstants.GSTMaster;
            }
            else
            {
                invoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceTable;
                historyTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.HistoryTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                GSTMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GSTMaster;
            }
            try
            {
                IDigiDynamoDb db = new IDigiDynamoDb();
                string bucketName = evnt.Records[0].S3.Bucket.Name;
                string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(iqnLgiCsvDumpFolder + "/", ""));
                var lgiCSVFileData = await GetFileFromS3(bucketName, iqnLgiCsvDumpFolder, fileName, context);

                ScanFilter filter = new ScanFilter();
                //filter.AddCondition("InvoiceID", ScanOperator.GreaterThan, 0);

                context.Logger.Log($"Data inserted successfully iqninvoicetable");
                var result = await db.ScanAsync<Invoice>(filter, invoiceTable, context);

                if (result != null)
                {
                    context.Logger.Log($"count from iqninvoices : {result.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from iqninvoices ");
                }

                context.Logger.Log($"fetching data from vendormastertable");
                var mastertable = await db.ScanAsync<VendorMasterEntities>(filter, vendorMasterTable, context);

                if (mastertable != null)
                {
                    context.Logger.Log($"count from vendormaster : {mastertable.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from vendormaster ");
                }
                context.Logger.Log($"fetching data from gstmastertable");
                var gstmasterresult = await db.ScanAsync<GSTMasterEntities>(filter, GSTMasterTable, context);
                if (gstmasterresult != null)
                {
                    context.Logger.Log($"count from Gstmaster : {gstmasterresult.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from gstmaster ");
                }
                using (var csvReadData = new System.IO.StreamReader(lgiCSVFileData.ResponseStream))
                {
                    context.Logger.Log($"Proccess :Now StreamReader is reading the data from the csv file");
                    var csv = new CsvReader(csvReadData);
                    csv.Configuration.HasHeaderRecord = false;
                    Invoice invoice = new Invoice();
                    VendorMasterEntities vendordetail = new VendorMasterEntities();
                    int dtCount = 0;
                    while (csv.Read())
                    {
                        string rowType = csv.GetField<string>(0);
                        if (!string.IsNullOrWhiteSpace(rowType))
                        {
                            if (rowType.ToUpper() == "HD")
                            {
                                #region HD 
                                //context.Logger.Log($"DT count while reading the HD data{dtCount}");
                                //  if (dtCount>0)
                                //{
                                try
                                {
                                    invoice = new Invoice();
                                    context.Logger.Log($"Line items(dt) count :{dtCount}");
                                    // if (invoice != null)
                                    //{
                                    context.Logger.Log($"Now inserting data into the dynamo db when we encountered the next HD");

                                    invoice.VendorModuleCd = "IQN";
                                    invoice.RTPActionOnLGI = "Y";
                                    invoice.AutomationTemplateDownloaded = "N";
                                    invoice.LGIDownloaded = "N";
                                    invoice.CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    invoice.UpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    invoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    invoice.InvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                                    invoice.SearchCreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                    invoice.SearchUpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                    invoice.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                    invoice.SearchInvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                    invoice.CreateUserId = CommonConstants.IqnTeam;
                                    invoice.UpdateUserId = CommonConstants.IqnTeam;
                                    invoice.InvoiceStatusCd = CommonConstants.StatusPDFAwaited;
                                    //invoice.InvoiceID = invoiceId;


                                    //invoiceId =invoiceId + 1;
                                    // invoice = new Invoice(); 
                                    //   dtCount = 0;
                                    //}


                                    // }                                                             
                                    //context.Logger.Log($" Instance type {invoice.GetType().Name}");

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                    {
                                        invoice.RowType = csv.GetField<string>(0);
                                        context.Logger.Log($"Row type {invoice.RowType}");
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                                    {
                                        string tempVendorCd = csv.GetField<string>(1);
                                        if (tempVendorCd.Count() == 9)
                                        {
                                            tempVendorCd = "0" + tempVendorCd;
                                            invoice.TPCd = tempVendorCd;//tp code and Vendor 
                                            invoice.VendorRegisteredCd = tempVendorCd;
                                            context.Logger.Log($" {invoice.TPCd}");
                                        }
                                        else if (tempVendorCd.Count() == 10)
                                        {
                                            invoice.TPCd = tempVendorCd;//tp code and Vendor 
                                            invoice.VendorRegisteredCd = tempVendorCd;
                                            context.Logger.Log($" {invoice.TPCd}");
                                        }
                                    }
                                    else
                                    {
                                        context.Logger.Log($"Tp code is missing");
                                    }

                                    invoice.IsExempted = CommonConstants.VendorCategory_NonExempted_STATUS;
                                    invoice.GSTR2AStatus = CommonConstants.GSTR2A_ReconPending_STATUS;
                                    context.Logger.Log($"enter code to check vendormaster");
                                    VendorMasterEntities vendorDet = CheckExemptedVendorCode(mastertable, invoice.VendorRegisteredCd, context);
                                    context.Logger.Log($"vendor obj  found");

                                    if (vendorDet.IsExempted == CommonConstants.VendorCategory_Exempted_STATUS)
                                    {
                                        invoice.GSTR2AStatus = CommonConstants.GSTR2A_ReconPending_STATUS;
                                        invoice.IsExempted = CommonConstants.VendorCategory_Exempted_STATUS;

                                    }

                                    if (vendorDet.IsExempted == CommonConstants.VendorCategory_NotApplicable_STATUS)
                                    {

                                        invoice.GSTR2AStatus = CommonConstants.GSTR2A_NotRequired_STATUS;
                                        invoice.IsExempted = CommonConstants.VendorCategory_NotApplicable_STATUS;

                                    }
                                    context.Logger.Log($" { invoice.IsExempted}");
                                    context.Logger.Log($" {invoice.GSTR2AStatus}");

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                                    { invoice.DCInd = csv.GetField<string>(2); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                    { invoice.VendorInvoiceNumber = csv.GetField<string>(3); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                    {
                                        invoice.InvoiceDt = csv.GetField<string>(4);
                                        var splitedDate = invoice.InvoiceDt.Split('/');
                                        if (splitedDate.Length == 3)
                                        {
                                            if (splitedDate[0].Length == 1)
                                            {
                                                splitedDate[0] = "0" + splitedDate[0];
                                            }
                                            if (splitedDate[1].Length == 1)
                                            {
                                                splitedDate[1] = "0" + splitedDate[1];
                                            }
                                            //when date is of format mm/dd/yyyy
                                            //invoice.InvoiceDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                            //when date is of format dd/mm/yyyy uat testing lgi have this dd/mm/yyyy format
                                            invoice.InvoiceDt = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];
                                            if (DateTime.TryParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                            {
                                                invoice.SearchInvoiceDt = DateTime.ParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                            }
                                        }
                                        context.Logger.Log($"Invoice Date :{invoice.InvoiceDt}");
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(5), out a))
                                        {
                                            invoice.TaxAmt = double.Parse(csv.GetField<string>(5));
                                        }
                                        //ask 
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                                    {
                                        double b;
                                        if (double.TryParse(csv.GetField<string>(6), out b))
                                        {
                                            invoice.FreightAmt = double.Parse(csv.GetField<string>(6));
                                        }

                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(7)))
                                    {
                                        double b;
                                        if (double.TryParse(csv.GetField<string>(7), out b))
                                        {
                                            invoice.GrossAmt = double.Parse(csv.GetField<string>(7));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(8)))
                                    { invoice.CurrencyCd = csv.GetField<string>(8); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(9)))
                                    { invoice.RequestorNm = csv.GetField<string>(9); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(10)))
                                    { invoice.InvoiceReferenceNbr = csv.GetField<string>(10); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(11)))
                                    { invoice.PaymentReferenceNbr = csv.GetField<string>(11); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(12)))
                                    { invoice.AlternativePayeeNm = csv.GetField<string>(12); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(13)))
                                    { invoice.PORReferenceNbr = csv.GetField<string>(13); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(14)))
                                    { invoice.IndexingNbr = csv.GetField<string>(14); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(15)))
                                    { invoice.ReserverdInd = csv.GetField<string>(15); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(16)))
                                    {
                                        //invoice.InvoiceReceiptDt = csv.GetField<string>(16);

                                        invoice.InvoiceReceiptDt = csv.GetField<string>(16);
                                        var splitedDate = invoice.InvoiceReceiptDt.Split('/');
                                        if (splitedDate.Length == 3)
                                        {
                                            if (splitedDate[0].Length == 1)
                                            {
                                                splitedDate[0] = "0" + splitedDate[0];
                                            }
                                            if (splitedDate[1].Length == 1)
                                            {
                                                splitedDate[1] = "0" + splitedDate[1];
                                            }

                                            //when date is of format mm/dd/yyyy 
                                            //invoice.InvoiceDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];

                                            //when date is of format dd/mm/yyyy uat testing lgi have this dd/mm/yyyy format
                                            invoice.InvoiceReceiptDt = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];
                                            if (DateTime.TryParseExact(invoice.InvoiceReceiptDt, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                            {
                                                invoice.SearchInvoiceReceiptDt = DateTime.ParseExact(invoice.InvoiceReceiptDt, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                            }
                                        }
                                        context.Logger.Log($"Invoice Reciept Date :{invoice.InvoiceReceiptDt}");

                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(17)))
                                    {
                                        invoice.BusinessPlaceNm = csv.GetField<string>(17);
                                    }
                                    context.Logger.Log($"Invoice BPNm :{invoice.BusinessPlaceNm}");
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(18)))
                                    { invoice.ReferenceKey1Str = csv.GetField<string>(18); }
                                    context.Logger.Log($"Invoice ref key :{invoice.ReferenceKey1Str}");
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(19)))
                                    { invoice.ReferenceKey2Str = csv.GetField<string>(19); }
                                    context.Logger.Log($"Invoice ref key 2 :{invoice.ReferenceKey2Str}");
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(20)))
                                    {
                                        invoice.ReferenceKey3Str = csv.GetField<string>(20);
                                    }
                                    context.Logger.Log($"Invoice ref key 3 :{invoice.ReferenceKey3Str}");
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(21)))
                                    {
                                        invoice.AssignmentNbr = csv.GetField<string>(21);
                                    }
                                    context.Logger.Log($"Invoice assnbr :{invoice.AssignmentNbr}");

                                    //Before production we are not expecting  these below collumns 

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(22)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(22), out a))
                                        {
                                            invoice.Base1Amt = double.Parse(csv.GetField<string>(22));
                                        }
                                    }

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(23)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(23), out a))
                                        {
                                            invoice.Base2Amt = double.Parse(csv.GetField<string>(23));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(24)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(24), out a))
                                        {
                                            invoice.Base3Amt = double.Parse(csv.GetField<string>(24));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(25)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(25), out a))
                                        {
                                            invoice.Base4Amt = double.Parse(csv.GetField<string>(25));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(26)))
                                    {
                                        invoice.GSTPartnerNm = csv.GetField<string>(26);
                                    }
                                    context.Logger.Log($" { invoice.GSTPartnerNm}");

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(27)))
                                    {
                                        invoice.POSStr = csv.GetField<string>(27);
                                    }
                                    context.Logger.Log($"Invoice POSStr :{invoice.POSStr}");
                                    string output = string.Empty;
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(28)))
                                    {
                                        invoice.SAPDocNo = csv.GetField<string>(28);
                                    }
                                    context.Logger.Log($"SAPDocNo :{invoice.SAPDocNo}");
                                    

                                    //if (csv.TryGetField(28, out output))
                                    //{
                                    //    if (!string.IsNullOrEmpty(csv.GetField<string>(28)))
                                    //    {
                                    //        invoice.SAPDocNo = csv.GetField<string>(28);

                                    //    }
                                    //}

                                    context.Logger.Log($"GrossAmt :{invoice.GrossAmt}");
                                    context.Logger.Log($"TaxAmt :{invoice.TaxAmt}");

                                    invoice.TaxableValue = invoice.GrossAmt - invoice.TaxAmt;
                                    context.Logger.Log($"TaxableValue :{invoice.TaxableValue}");
                                    if (invoice.TaxableValue != null)
                                    {
                                        invoice.TaxableValue = Math.Round((double)invoice.TaxableValue, 2);

                                    }
                                    Guid objsku = Guid.NewGuid();
                                    invoice.SKU = objsku.ToString();
                                    context.Logger.Log($"BusinessPlaceNm :{invoice.BusinessPlaceNm}");
                                    if (!string.IsNullOrWhiteSpace(invoice.BusinessPlaceNm))
                                    {
                                        GSTMasterEntities obj = getGstMasterDetail(gstmasterresult, invoice.BusinessPlaceNm);
                                        if (obj != null)
                                        {
                                            context.Logger.Log($"obj found ");

                                        }
                                        string type = obj.Type;
                                        string accenturegstn = obj.GSTIN;
                                        string partnerCode = invoice.GSTPartnerNm;

                                        //if (partnerCode.Count() == 9)
                                        //{
                                        //    partnerCode = "0" + partnerCode;
                                        //}

                                        VendorMasterEntities vendorData = CheckExemptedVendorCode(mastertable, partnerCode, context);
                                        string vendorgstnumber = "";
                                        if (vendorData != null)
                                        {
                                            context.Logger.Log($"vendordata found ");
                                            vendorgstnumber = vendorData.GSTNumber;
                                            invoice.VendorGSTNumber = vendorgstnumber;
                                            invoice.AccentureGSTPartnerNm = accenturegstn;
                                        }
                                        else
                                        {
                                            if (partnerCode.StartsWith("0"))
                                            {
                                                context.Logger.Log($"starts with 0");
                                                partnerCode = partnerCode.Substring(1, (partnerCode.Length - 1));

                                            }
                                            else
                                            {
                                                context.Logger.Log($"Appended 0");
                                                partnerCode = "0" + partnerCode;
                                            }
                                            vendorData = CheckExemptedVendorCode(mastertable, partnerCode, context);
                                            if (vendorData != null)
                                            {
                                                context.Logger.Log($"vendordata found in else");
                                                vendorgstnumber = vendorData.GSTNumber;
                                                invoice.VendorGSTNumber = vendorgstnumber;
                                                invoice.AccentureGSTPartnerNm = accenturegstn;
                                            }
                                        }




                                        context.Logger.Log($"VendorGSTNumber { invoice.VendorGSTNumber}");
                                        context.Logger.Log($"AccentureGSTPartnerNm { invoice.AccentureGSTPartnerNm}");
                                        context.Logger.Log($"type {type}");


                                        if (type != null && type != "")
                                        {
                                            if ((type.ToUpper() == CommonConstants.TAXTypeHO) || (type.ToUpper() == CommonConstants.TAXTypeSTPI) || (type.ToUpper() == CommonConstants.TAXTypeIDB) || (type.ToUpper().Contains(CommonConstants.TAXTypeneitherstpinorSEZ)))
                                            {
                                                if (vendorgstnumber != null && vendorgstnumber != "" && vendorgstnumber.Length >= 2 && accenturegstn != null && accenturegstn != "" && accenturegstn.Length > 2)
                                                {
                                                    if (vendorgstnumber.Substring(0, 2) == accenturegstn.Substring(0, 2))
                                                    {

                                                        invoice.TaxType = CommonConstants.TAXCGSTSGST;

                                                        if (invoice.TaxAmt == null)
                                                        {
                                                            invoice.TaxAmt = 0;
                                                        }
                                                        var amt = invoice.TaxAmt / 2;
                                                        invoice.CGST = amt + "";
                                                        invoice.SGST = amt + "";
                                                        invoice.IGST = 0 + "";
                                                    }
                                                    else
                                                    {
                                                        invoice.TaxType = CommonConstants.TAXIGST;
                                                        invoice.CGST = 0 + "";
                                                        invoice.SGST = 0 + "";
                                                        invoice.IGST = invoice.TaxAmt + "";
                                                    }


                                                }

                                            }
                                            if (type.ToUpper() == CommonConstants.TAXTypeSEZ)
                                            {
                                                if (invoice.TaxAmt == 0)
                                                {
                                                    invoice.TaxType = CommonConstants.TAXExempt;
                                                    invoice.CGST = 0 + "";
                                                    invoice.SGST = 0 + "";
                                                    invoice.IGST = 0 + "";
                                                }
                                                else
                                                {
                                                    invoice.TaxType = CommonConstants.TAXIGST;
                                                    invoice.CGST = 0 + "";
                                                    invoice.SGST = 0 + "";
                                                    invoice.IGST = invoice.TaxAmt + "";
                                                }

                                            }
                                        }
                                    }

                                    context.Logger.Log($"TAXType { invoice.TaxType}");
                                    context.Logger.Log($"CGST { invoice.CGST}");
                                    context.Logger.Log($"SGST { invoice.SGST}");
                                    context.Logger.Log($"IGST { invoice.IGST}");

                                    #endregion
                                    bool isDuplicate = await CheckDuplicateInvoiceNumberForVendorCode(db, invoiceTable, invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, context, result);
                                    if (!isDuplicate)
                                    {
                                        InvoiceHistory invoiceHistory = new InvoiceHistory();
                                        {
                                            invoiceHistory.SourceId = invoice.VendorRegisteredCd + "-" + invoice.VendorInvoiceNumber;
                                            invoiceHistory.ModifiedBy = CommonConstants.IqnTeam;
                                            invoiceHistory.StatusCd = CommonConstants.StatusPDFAwaited;
                                            invoiceHistory.StatusDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                                            if (DateTime.TryParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                            {
                                                invoiceHistory.SearchStatusDt = DateTime.ParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                                            }
                                        }
                                        await db.InsertAsync<Invoice>(invoice, invoiceTable, context);
                                        await db.InsertAsync<InvoiceHistory>(invoiceHistory, historyTable, context);
                                        context.Logger.Log($"Data inserted successfully {invoice.VendorRegisteredCd}, {invoice.VendorInvoiceNumber}");
                                    }
                                    else
                                    {
                                        Console.WriteLine($"Duplicate invoice found {invoice.VendorRegisteredCd},{invoice.VendorInvoiceNumber}");
                                    }
                                }
                                catch (Exception e)
                                {
                                    context.Logger.Log($"Exception while inserting the data inside the HD  {e.Message}");
                                    context.Logger.Log($"Innner exception :{e.InnerException}");
                                    context.Logger.Log($"Stack trace :{e.StackTrace}");
                                }
                            }
                            //else if (rowType.ToUpper() == "DT")
                            //{
                            //    dtCount = ++dtCount;
                            //    //context.Logger.Log($"now dt count is {dtCount}");
                            //    InvoiceLineItem lineItemobj = new InvoiceLineItem();
                            //    #region DT line Items
                            //    lineItemobj.InvoiceDTId = dtCount;
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                            //    {
                            //        lineItemobj.RowType = csv.GetField<string>(0);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                            //    {
                            //        lineItemobj.Description = csv.GetField<string>(1);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                            //    {
                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(2), out a))
                            //        {
                            //            lineItemobj.TaxParameter2Amt = double.Parse(csv.GetField<string>(2));
                            //        }
                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                            //    {
                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(3), out a))
                            //        {
                            //            lineItemobj.TaxParameter1Amt = double.Parse(csv.GetField<string>(3));
                            //        }


                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                            //    {

                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(4), out a))
                            //        {
                            //            lineItemobj.TaxAmt = double.Parse(csv.GetField<string>(4));
                            //        }

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                            //    {

                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(5), out a))
                            //        {
                            //            lineItemobj.LineAmt = double.Parse(csv.GetField<string>(5));
                            //        }
                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                            //    {
                            //        lineItemobj.ChargedEntity = csv.GetField<string>(6);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(7)))
                            //    {
                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(7), out a))
                            //        {
                            //            lineItemobj.Quantity = double.Parse(csv.GetField<string>(7));
                            //        }

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(8)))
                            //    {
                            //        lineItemobj.PoNbr = csv.GetField<string>(8);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(9)))
                            //    {
                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(9), out a))
                            //        {
                            //            lineItemobj.PoLineNbr = double.Parse(csv.GetField<string>(9));
                            //        }

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(10)))
                            //    {

                            //        lineItemobj.MaterialGroup = csv.GetField<string>(10);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(11)))
                            //    {
                            //        double a;
                            //        if (double.TryParse(csv.GetField<string>(11), out a))
                            //        {
                            //            lineItemobj.UnitPrice = double.Parse(csv.GetField<string>(11));
                            //        }

                            //    }

                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(12)))
                            //    {
                            //        lineItemobj.DCInd = csv.GetField<string>(12);
                            //    }

                            //    //needed for the production


                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(13)))
                            //    {
                            //        lineItemobj.ReserverdInd = csv.GetField<string>(13);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(14)))
                            //    {
                            //        lineItemobj.ReserverdInd = csv.GetField<string>(14);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(15)))
                            //    {
                            //        lineItemobj.HSNSAC = csv.GetField<string>(15);

                            //    }
                            //    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(16)))
                            //    {
                            //        lineItemobj.Plant = csv.GetField<string>(16);
                            //    }
                            //    if (lineItemobj!= null)
                            //    {
                            //        //context.Logger.Log($"LineItem Count {lineItemobj.Count()}");
                            //        invoice.InvoiceLineItems.Add(lineItemobj);
                            //    }


                            //    #endregion
                            //}
                        }
                    }
                    //if (dtCount > 0)
                    //{
                    //    context.Logger.Log($"InvoiceNumber {invoice.VendorInvoiceNumber}");
                    //    context.Logger.Log($"Lineitems(dt) count : {dtCount}");
                    //    if (invoice != null)
                    //    {
                    //        invoice.VendorModuleCd = "IQN";
                    //        invoice.RTPActionOnLGI = "Y";
                    //        invoice.AutomationTemplateDownloaded = "N";
                    //        invoice.LGIDownloaded = "N";
                    //        invoice.CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                    //        invoice.UpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                    //        invoice.ModifiedDttm= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                    //        invoice.CreateUserId = CommonConstants.IqnTeam;
                    //        invoice.UpdateUserId = CommonConstants.IqnTeam;
                    //        invoice.InvoiceStatusCd = CommonConstants.StatusPDFAwaited;
                    //        //invoice.InvoiceID = invoiceId;
                    //        bool isDuplicate = await CheckDuplicateInvoiceNumberForVendorCode(db, invoiceTable, invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, context,result);
                    //        //context.Logger.Log($"Data :Is dupliacte entry : {isDuplicate}");
                    //        //if (isDuplicate)
                    //        //{
                    //        //    InvoiceHistory invoiceHistory = new InvoiceHistory();
                    //        //    invoiceHistory.CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    //        //    invoiceHistory.InvoiceStatusCd = CommonConstants.StatusDuplicate;
                    //        //    invoiceHistory.CreateUserId = CommonConstants.IqnTeam;
                    //        //    invoice.InvoiceHistoryLogs.Add(invoiceHistory);
                    //        //    context.Logger.Log($"Concern :the invoice number : {invoice.VendorInvoiceNumber} for vendor code : {invoice.VendorRegisteredCd} is a duplicate entry");
                    //        //    invoice.InvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    //        //    invoice.InvoiceStatusCd = CommonConstants.StatusDuplicate;
                    //        //    await db.InsertAsync<Invoice>(invoice,invoiceTable,context);
                    //        //    context.Logger.Log($"Data saved successfully");
                    //        //}
                    //        if(!isDuplicate)
                    //        {
                    //            InvoiceHistory invoiceHistory = new InvoiceHistory();
                    //            {
                    //                invoiceHistory.SourceId = invoice.VendorRegisteredCd + "-" + invoice.VendorInvoiceNumber;
                    //                invoiceHistory.ModifiedBy = CommonConstants.IqnTeam;
                    //                invoiceHistory.StatusCd = CommonConstants.StatusPDFAwaited;
                    //                invoiceHistory.StatusDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    //                if (DateTime.TryParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                    //                {
                    //                    invoiceHistory.SearchStatusDt = DateTime.ParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                    //                }
                    //             }
                    //            invoice.InvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    //            invoice.SearchCreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                    //            invoice.SearchUpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                    //            invoice.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                    //            invoice.SearchInvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                    //            await db.InsertAsync<Invoice>(invoice, invoiceTable, context);
                    //            await db.InsertAsync<InvoiceHistory>(invoiceHistory, historyTable, context);
                    //            context.Logger.Log($"Data saved successfully");
                    //         }
                    //        //invoiceId = invoiceId + 1;
                    //        invoice = new Invoice();
                    //        dtCount = 0;
                    //    }

                    //}
                }
                if (!string.IsNullOrEmpty(fileName))
                {
                    string renamedFile = RenameFile(fileName);
                    await CopyFileFromOneFolderToOther(bucketName, bucketName, iqnLgiCsvDumpFolder, iqnPrivateLgiCsvFolder, fileName, renamedFile, context);
                    await DeleteFile(bucketName, iqnLgiCsvDumpFolder, fileName, context);
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"Exception in main block :{e.Message}");
                context.Logger.Log($"Innner exception :{e.InnerException}");
                context.Logger.Log($"Stack trace :{e.StackTrace}");
                context.Logger.Log($"{e.Source}");
                context.Logger.Log($"{e.HResult}");
                // throw;
            }
        }

        private async Task<GetObjectResponse> GetFileFromS3(string bucketName, string folderName, string fileName, ILambdaContext context)
        {
            GetObjectResponse getObjectResponse = null;
            if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderName) && !string.IsNullOrEmpty(fileName))
            {
                var getObjectRequest = new GetObjectRequest
                {
                    BucketName = bucketName + "/" + folderName,
                    Key = fileName
                };

                getObjectResponse = await
                    S3Client.GetObjectAsync(getObjectRequest);
            }
            else
            {
                context.Logger.Log($"Log: File path mentioned does not exists :{bucketName}/{folderName}/{fileName}");
            }

            return getObjectResponse;


        }
        private async Task<bool> CheckDuplicateInvoiceNumberForVendorCode(IDigiDynamoDb db, string tableName, string vendorCode, string invoiceNumber, ILambdaContext logger, List<Invoice> listOfInvoices)
        {

            if (listOfInvoices.Any(invoice => invoice.VendorInvoiceNumber == invoiceNumber && invoice.VendorRegisteredCd == vendorCode && invoice.VendorModuleCd == CommonConstants.IqnTeam))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private VendorMasterEntities CheckExemptedVendorCode(List<VendorMasterEntities> masterdata, string vendorcode, ILambdaContext context)
        {
            try
            {
                context.Logger.Log($"exemption check vendorcode {vendorcode}");


                var obj = new VendorMasterEntities();
                List<VendorMasterEntities> filteredVendorMasterDetails = new List<VendorMasterEntities>();
                filteredVendorMasterDetails = masterdata.Where(x => x.VendorCode == vendorcode).ToList();
                if (filteredVendorMasterDetails != null && filteredVendorMasterDetails.Count > 0)
                {
                    obj = filteredVendorMasterDetails[0];
                    return obj;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"exception in checkexemptedcode");

                context.Logger.Log($" {e.Message}");
                context.Logger.Log($" {e}");
                return null;

            }


        }



        private GSTMasterEntities getGstMasterDetail(List<GSTMasterEntities> masterdata, string businessPlace)
        {
            var obj = new GSTMasterEntities();
            List<GSTMasterEntities> filteredGSTMasterDetails = new List<GSTMasterEntities>();
            filteredGSTMasterDetails = masterdata.Where(x => x.BusinessPlace.ToUpper() == businessPlace.ToUpper()).ToList();
            if (filteredGSTMasterDetails != null && filteredGSTMasterDetails.Count > 0)
            {
                obj = filteredGSTMasterDetails[0];
                return obj;
            }
            else
            {
                return null;
            }

        }
        private async Task CopyFileFromOneFolderToOther(string sourceBucket, string destinationBucket, string sourceFolder, string destinationFolder, string srcfileName, string destFileName, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(srcfileName) && !string.IsNullOrEmpty(destFileName))
            {
                var copyObjectRequest = new CopyObjectRequest()
                {
                    SourceBucket = sourceBucket + "/" + sourceFolder,
                    DestinationBucket = destinationBucket + "/" + destinationFolder,
                    SourceKey = srcfileName,
                    DestinationKey = destFileName
                };
                context.Logger.Log($"Process :before copying the file : {srcfileName} from :{sourceBucket + "/" + sourceFolder} to {destinationBucket + "/" + destinationFolder}");
                await S3Client.CopyObjectAsync(copyObjectRequest);
                context.Logger.Log($"Log :Copied successfully");
            }
            else
            {
                context.Logger.Log($"Error :One of the passed parameter is empty");
            }
        }
        private async Task DeleteFile(string bucket, string folder, string file, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(file) && !string.IsNullOrEmpty(bucket) && !string.IsNullOrEmpty(folder))
            {
                var deleteObjectRequest = new DeleteObjectRequest()
                {
                    BucketName = bucket + "/" + folder,
                    Key = file
                };
                context.Logger.Log($"Now deleting the file name :{file} from folder {bucket}/{folder}");
                var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);

            }
        }

        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
        private void LogChildLambdaResponse(dynamic childLmbdaResponse, ILambdaContext context)
        {
            context.Logger.Log($"Log: Running Child lambda instace id :{childLmbdaResponse.Id}");
            context.Logger.Log($"Log: Is Child lambda Instace :{childLmbdaResponse.Id} cancelled :{childLmbdaResponse.IsCanceled}");
            context.Logger.Log($"Log: Is child lambda instance faulted :{childLmbdaResponse.IsFaulted} ");
            context.Logger.Log($"Log: Result  :{childLmbdaResponse.Result} ");
            context.Logger.Log($"Log: Status  :{childLmbdaResponse.Status} ");
        }
    }
}
