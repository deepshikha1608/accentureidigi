﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class InvSub
    {
        public string VendorModuleCd { get; set; }
        public string PoNbr { get; set; }
        public string WBSE { get; set; }
        public string EmpNo { get; set; }
        public string Country { get; set; }
        public string TicketNumber { get; set; }
        public double? ServiceTax { get; set; }
        public string BusinessUnit { get; set; }
        public double? ReimbursementCharges { get; set; }
        public string EmployeeName { get; set; }
        public double? InvAmt { get; set; }
        public string Service { get; set; }
        public string InvSubmissionDt { get; set; }
        public double? ServiceCharges { get; set; }
        public string ImplantName { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string InvoiceDate { get; set; }
        public string IsError { get; set; } //Y N
        public double? ApprovedAmt { get; set; }
        public string AmountRecdDate1 { get; set; }
        public string AmountRecdDate2 { get; set; }


    }
}
