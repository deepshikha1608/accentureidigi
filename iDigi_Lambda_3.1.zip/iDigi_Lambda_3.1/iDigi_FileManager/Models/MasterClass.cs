﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class MasterClass
    {
        public MasterClass()
        {
            UdaanInvoice = new UdaanInvoice();
            UdaanInvoiceDump = new UdaanInvoiceDump();
        }
        public string Vendor { get; set; }

        public string BucketName { get; set; }
        public string UdaanLgiCSVName { get; set; }
        public string InvoiceBatchDttm { get; set; }
        public UdaanInvoice UdaanInvoice { get; set; }

        public UdaanInvoiceDump UdaanInvoiceDump { get; set; }
        public bool IsLastUdaanChildLambdaInvoking { get; set; }
        public string CwtCSVFileName { get; set; }
        public string CsrCSVFileName { get; set; }
        public string IsDublicate { get; set; }
    }
}
