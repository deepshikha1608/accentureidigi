﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class InvoiceBatch
    {
        public string VendorGroupCd { get; set; }
        public string InvoiceBatchDttm { get; set; }
        public string VendorCd { get; set; }
        public string StatusCd { get; set; }
        public int TotalRecords { get; set; }
        public int TotalRecordsValid { get; set; }
        public int TotalRecordsFailed { get; set; }
        public int TotalRecordsRejected { get; set; }
        public int TotalFiles { get; set; }
        public int CopiedFiles { get; set; }
        public string FileTypeCd { get; set; }
        public List<string> ValidFileList { get; set; }
        public List<string> InValidFileList { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }

        public List<string> CwtValidInvoiceFiles { get; set; }
        public List<string> CwtInvoiceFiles { get; set; }
        public List<string> CwtTicketFiles { get; set; }
        public List<string> CwtSupportingFiles { get; set; }

        public List<string> CwtValidInvoiceTicketSupFiles { get; set; }

        public List<string> CwtValidCrOiSupFiles { get; set; }
    }
}
