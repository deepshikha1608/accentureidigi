﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
   public class CwtFiles
    {
        public List<string> ValidFilesWithInvTktAndSup { get; set; }
        public List<string> ValidFilesWithInvAndTktentry { get; set; }
    }
}
