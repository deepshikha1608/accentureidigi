﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class EtravelData
    {
        int FlightSubId { get; set; }
        string RequestNo { get; set; }
        int EmployeeId { get; set; }
        string EmployeeMailId { get; set; }
        string PurposeOfTravel { get; set; }
        string EmployeeRemarks { get; set; }
        string Wbse { get; set; }
        string CompanyCode { get; set; }
        string BillingAddress { get; set; }
        string BusinessUnit { get; set; }
        string Country { get; set; }
        string From { get; set; }
        string To { get; set; }
        string TDDepDate { get; set; }
        string TDArrTime { get; set; }
        string TDDepTime { get; set; }
        string RMSInit { get; set; }
        string FlightNo { get; set; }
        string TicketNo { get; set; }
        string MealPref { get; set; }
        string SeatPref { get; set; }
        string DepDate { get; set; }
        string DepTime { get; set; }
        string TDRemarks { get; set; }
        string RefundRemarks { get; set; }
        string CancelRemarks { get; set; }
        string ReqStatus { get; set; }

    }
}
