﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class InvoiceLineItem
    {
        public InvoiceLineItem()
        {
        }
        public string VendorInvoiceNumber { get; set; }
        public double? TaxAmt { get; set; }
        public string DCInd { get; set; }
        public int InvoiceDTId { get; set; }
        public int InvoiceDataId { get; set; }
        public double? TaxRate { get; set; }
        public double? TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string RowType { get; set; }
        public string TaxType { get; set; }
        public string Description { get; set; }
        public double? TaxParameter1Amt { get; set; }
        public double? TaxParameter2Amt { get; set; }
        public double? LineAmt { get; set; }
        public string ChargedEntity { get; set; }
        public double? Quantity { get; set; }
        public string PoNbr { get; set; }
        public double? PoLineNbr { get; set; }
        public string Plant { get; set; }
        public string MaterialGroup { get; set; }
        public double? UnitPrice { get; set; }
        public string CompanyCd { get; set; }
        public string ReserverdInd1 { get; set; }
        public string ReserverdInd2 { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string DFMURN { get; set; }
        public string LGIGenerated { get; set; }


    }
}
