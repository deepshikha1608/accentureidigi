﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_FileManager
{
    public class InvoiceSubmission
    {
        // UADANInvoiceExtId InvoiceBatchId  InvoiceId VendorGroupCd   VendorCd StatusCd    VendorInvoiceCRNo Date    InvoiceAmt ServiceChargeAmt    ServiceTaxAmt ReImbursementChargeAmt  Service Country PONumber EmployeeNm  TRNbr EmployeeNo  BusinessUnitNo WBSeNo  InvoiceSubmissionDt ImplantNm   ApprovedAmt AmountRecd1Dt   AmountRecd2Dt CreatedBy   CreatedDttm ModifiedBy  ModifiedDttm

        public int UDAANInvoiceExtId { get; set; }
        public int InvoiceBatchId { get; set; }
        public int InvoiceId { get; set; }

        public string VendorGroupCd { get; set; }

        public string VendorInvoiceNumber { get; set; }
        public string VendorCd { get; set; }
        public string StatusCd { get; set; }

        public string VendorInvoiceCRNo { get; set; }

        public string Date { get; set; }
        public double? InvoiceAmt { get; set; }
        public double? ServiceChargeAmt { get; set; }
        public double? ServiceTaxAmt { get; set; }
        public double? ReImbursementChargeAmt { get; set; }
        public string Service { get; set; }
        public string Country { get; set; }
        public string PONumber { get; set; }
        public string EmployeeNm { get; set; }
        public string TRNo { get; set; }

        public string EmployeeNo { get; set; }
        public string BusinessUnitNo { get; set; }
        public string WBSeNo { get; set; }
        public string InvoiceSubmissionDt { get; set; }  //
        public string ImplantNm { get; set; }
        public double? ApprovedAmt { get; set; }
        public string AmountRecd1Dt { get; set; }       //
        public string AmountRecd2Dt { get; set; }       //
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }

    }
}
