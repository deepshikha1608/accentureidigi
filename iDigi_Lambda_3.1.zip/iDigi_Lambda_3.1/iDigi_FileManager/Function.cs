using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Util;
using System.IO;
using CsvHelper;
using System.Reflection;
using iDigi_FileManager;
using Amazon.Lambda.Model;
using Newtonsoft.Json;
using Amazon.Lambda;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2;
using System.Text.RegularExpressions;
using iTextSharp.text.pdf;
using Amazon.S3.Model;
using System.Collections;
using iDigi_FileManager.Models;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_FileManager
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        public string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                if (DebugEnvironMent.ToLowerInvariant() == "true")
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); // windows os
                }
                else
                { return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); } // amazon linux os 

            }
        }
        public static string CSRDestinationBucket
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("CSRDestinationBucket");
            }
        }
        public static string DebugEnvironMent
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("DebugEnvironMent");
            }

        }
        AmazonDynamoDBClient client { get; set; }
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            LambdaClient = new AmazonLambdaClient();
            client = new AmazonDynamoDBClient();
            //S3Client = new AmazonS3Client();          
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
        }

        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            var s3Event = evnt.Records?[0].S3;
            string invoiceBatchTable = string.Empty;
            string udaanInvoiceTable = string.Empty;
            string paramTable = string.Empty;
            string invoiceErrorDetailsTable = string.Empty;
            string cwtPrivateBucket = string.Empty;
            string filePath = string.Empty;
            string vendorMasterTable = string.Empty;

            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                invoiceBatchTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceBatchTable;
                udaanInvoiceTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CommonConstants.ParamTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTProdPrivateBucketName;
                filePath = CommonConstants.CWTInvoice_FilePath;
                vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
            }
            else if (CloudEnvironment.ToLowerInvariant() == "dev")
            {
                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                udaanInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ParamTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTDevPrivateBucketName;
                filePath = CommonConstants.Public_Folder + "/" + CommonConstants.CWTInvoice_FilePath;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;

            }
            else
            {
                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                udaanInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ParamTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceErrorDetailsTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                cwtPrivateBucket = CommonConstants.CWTStagePrivateBucketName;
                filePath = CommonConstants.CWTInvoice_FilePath;
            }

            try
            {
                iDigiS3 s3 = new iDigiS3();
                iDigiDynamoDb dynamoDb = new iDigiDynamoDb();
                string bucketName = evnt.Records[0].S3.Bucket.Name;

                string CsrPublicFolderPath = CommonConstants.CSRInvoice_FilePath;
                string csrInvalidFilePath = CommonConstants.Private_Folder + "/" + CommonConstants.CSRInvoice_FilePath + "/" + CommonConstants.CSRInvalidFilesPath;
                #region start
                string objectKeyForFetchingVendorName = System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '));
                //assumed The folder structure to be public/vendoranme/filename.csv
                string[] objectKeySplited = objectKeyForFetchingVendorName.Split('/');
                string vendorName = string.Empty;
                //context.Logger.Log($"vendor name :{objectKeySplited[1]}");
                if (objectKeySplited[1].ToLowerInvariant() == "udaan")
                #region udaan and fcm
                {
                    ScanOperationConfig vendorMatserOperationConfig = new ScanOperationConfig();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorCd", ScanOperator.Equal, "UDN VENDOR");
                    vendorMatserOperationConfig.Select = SelectValues.SpecificAttributes;
                    vendorMatserOperationConfig.AttributesToGet = new List<string>() { "VendorCode", "VendorCd", "VendorUserId", "ParentVendorId" };
                    vendorMatserOperationConfig.Filter = scanFilter;
                    

                    var vendorMaster = await dynamoDb.ScanAsync<VendorMasterEntities>(vendorMatserOperationConfig, vendorMasterTable, context);

                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/", ""));
                    context.Logger.Log($"Data :Udaan Uploaded filename :-{fileName}");

                    var visaLgiFileSplitedLine = fileName.Split("_");
                    var vendorCode = visaLgiFileSplitedLine[0];
                    var dataSubmittingVendorData = vendorMaster.FirstOrDefault(vendor => vendor.ParentVendorId == vendorCode);
                    List<string> udaanFileNameList = null;
                    #region udaan and FCM lgi
                    if (dataSubmittingVendorData == null && string.IsNullOrEmpty(dataSubmittingVendorData.ParentVendorId))
                    {
                        Console.WriteLine($"Data related to this {vendorCode} is not there in the vendor master table");
                        return;
                    }

                    if (fileName.ToLowerInvariant().Contains("visa_lgi") || fileName.ToLowerInvariant().Contains("visa_lgi"))
                    {
                        string visaVendorName = string.Empty;
                        visaVendorName = dataSubmittingVendorData.VendorUserId;
                        udaanFileNameList = await s3.ListAllTheFilesSpecificToVisaVendorInFolder(bucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, vendorCode, context);


                        #region lgi read part
                        var udaanLgiFileData = await s3.GetFileFromS3(bucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, fileName, context);
                        List<string> udaanInvoiceNumberList = new List<string>();
                        if (udaanLgiFileData != null)
                        {
                            using (var fs = new StreamReader(udaanLgiFileData.ResponseStream))
                            {
                                var csv = new CsvReader(fs);
                                context.Logger.Log($"Process :Before starting to read the csv file");
                                //udaan files wont be having the headers in their csv files
                                csv.Configuration.HasHeaderRecord = false;
                                while (csv.Read())
                                {
                                    if (csv.GetField<string>(0).ToLowerInvariant() == "hd")
                                    {
                                        //udaan invoice number
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                        {
                                            string invoiceNumber = csv.GetField<string>(3);
                                            udaanInvoiceNumberList.Add(invoiceNumber);
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region matching files with invoice number and Maintaing invoice batch


                            if (udaanFileNameList != null && udaanInvoiceNumberList != null)
                            {
                                var invoiceNumberCorespondingFileNameList = udaanFileNameList.Where(file => udaanInvoiceNumberList.Any(invoiceNo => file.ToLowerInvariant().Contains("_" + invoiceNo.ToLowerInvariant() + "_")));
                                context.Logger.Log($"Invoice number list{JsonConvert.SerializeObject(udaanInvoiceNumberList)}");
                                context.Logger.Log($"Invoice coresponding file list {JsonConvert.SerializeObject(invoiceNumberCorespondingFileNameList)}");
                                var fileNameWithoutInvoiceEntryList = udaanFileNameList.Except(invoiceNumberCorespondingFileNameList);
                                InvoiceBatch invoiceBatch = new InvoiceBatch();

                                //invoiceBatch.VendorGroupCd = CommonConstants.UdaanTeam;
                                invoiceBatch.VendorGroupCd = "VISA";
                                invoiceBatch.InvoiceBatchDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm:ss");

                                invoiceBatch.TotalFiles = udaanFileNameList.Count;
                                invoiceBatch.CopiedFiles = invoiceNumberCorespondingFileNameList.Count();

                                invoiceBatch.TotalRecords = udaanFileNameList.Count;
                                //invoiceBatch.TotalRecordsFailed =;
                                invoiceBatch.TotalRecordsRejected = fileNameWithoutInvoiceEntryList.Count();
                                invoiceBatch.TotalRecordsValid = invoiceNumberCorespondingFileNameList.Count();

                                invoiceBatch.ValidFileList = invoiceNumberCorespondingFileNameList.ToList();
                                invoiceBatch.InValidFileList = fileNameWithoutInvoiceEntryList.ToList();

                                //invoiceBatch.CreatedBy = CommonConstants.UdaanTeam;
                                invoiceBatch.CreatedBy = visaVendorName;
                                invoiceBatch.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                                //invoiceBatch.ModifiedBy = CommonConstants.UdaanTeam;
                                invoiceBatch.ModifiedBy = visaVendorName;
                                invoiceBatch.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                await dynamoDb.InsertAsync<InvoiceBatch>(invoiceBatch, invoiceBatchTable, context);

                                MasterClass masterClass = new MasterClass();
                                masterClass.BucketName = bucketName;
                                //masterClass.Vendor = CommonConstants.UdaanTeam;

                                masterClass.Vendor = "VISA"; // need to change

                                masterClass.UdaanLgiCSVName = fileName;
                                masterClass.InvoiceBatchDttm = invoiceBatch.InvoiceBatchDttm;

                                Amazon.Lambda.Model.InvokeRequest invokeRequest = new Amazon.Lambda.Model.InvokeRequest();

                                invokeRequest.Payload = JsonConvert.SerializeObject(masterClass);

                                invokeRequest.FunctionName = "7433_iDigi_CSVReaderSpecificVendor";
                                invokeRequest.InvocationType = InvocationType.Event;
                                var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                                LogChildLambdaResponse(childLmbdaResponse, context);
                            }

                        }
                        #endregion
                    }
                    #endregion
                    #region udaan invoice submission                    
                    if (fileName.ToLowerInvariant().Contains("visa_invsub") || fileName.ToLowerInvariant().Contains("visa_invsub"))
                    {


                        #region Reading the invoice submission file
                        var invSubFileData = await s3.GetFileFromS3(bucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, fileName, context);

                        //ScanFilter scanFilter = new ScanFilter();

                        ScanOperationConfig scanopetionConfig = new ScanOperationConfig();
                        scanopetionConfig.Select = SelectValues.SpecificAttributes;
                        scanopetionConfig.AttributesToGet = new List<string> { "VendorCd,VendorInvoiceNumber" };


                        var udaanInvoiceData = await dynamoDb.ScanAsync<UdaanInvoice>(scanopetionConfig, udaanInvoiceTable, context);


                        if (invSubFileData != null)
                        {
                            using (var csvReadData = new System.IO.StreamReader(invSubFileData.ResponseStream))
                            {
                                context.Logger.Log($"Now StreamReader is reading the data from the invoice submission csv file");

                                var csv = new CsvReader(csvReadData);
                                csv.Configuration.HasHeaderRecord = true; //invoice submission file has header 
                                InvoiceSubmission udaanInvoiceSubmission = new InvoiceSubmission();
                                #region invoice submission read
                                while (csv.Read())
                                {
                                    udaanInvoiceSubmission.VendorGroupCd = "Udaan";
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                    {
                                        udaanInvoiceSubmission.VendorInvoiceNumber = csv.GetField<string>(0);
                                        // udaanInvoiceSubmission.VendorInvoiceCRNo= csv.GetField<string>(0);
                                        ////////////////////check/////////////////////////
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                                    {
                                        //udaanInvoiceSubmission.Date = csv.GetField<string>(1);                                        
                                        if (csv.GetField<string>(1).Contains("/"))
                                        {
                                            var splitedDate = csv.GetField<string>(1).Split('/');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[0].Length == 1)
                                                {
                                                    splitedDate[0] = "0" + splitedDate[0];
                                                }
                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }
                                                //date format is coming as dd/mm/yyyy convert to mm/dd/yyyy
                                                udaanInvoiceSubmission.Date = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];
                                            }
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(2), out a))
                                        {
                                            udaanInvoiceSubmission.InvoiceAmt = double.Parse(csv.GetField<string>(2));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(3), out a))
                                        {
                                            udaanInvoiceSubmission.ServiceChargeAmt = double.Parse(csv.GetField<string>(3));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(4), out a))
                                        {

                                            udaanInvoiceSubmission.ServiceTaxAmt = double.Parse(csv.GetField<string>(4));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(5), out a))
                                        {
                                            udaanInvoiceSubmission.ReImbursementChargeAmt = double.Parse(csv.GetField<string>(5));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                                    { udaanInvoiceSubmission.Service = csv.GetField<string>(6); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(7)))
                                    { udaanInvoiceSubmission.Country = csv.GetField<string>(7); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(8)))
                                    {
                                        //int a;
                                        //if (int.TryParse(csv.GetField<string>(8), out a))
                                        //{
                                        udaanInvoiceSubmission.PONumber = csv.GetField<string>(8);
                                        //}
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(9)))
                                    {
                                        udaanInvoiceSubmission.EmployeeNm = csv.GetField<string>(9);
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(10)))
                                    { udaanInvoiceSubmission.TRNo = csv.GetField<string>(10); }

                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(11)))
                                    { udaanInvoiceSubmission.EmployeeNo = csv.GetField<string>(11); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(12)))
                                    { udaanInvoiceSubmission.BusinessUnitNo = csv.GetField<string>(12); }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(13)))
                                    {
                                        udaanInvoiceSubmission.WBSeNo = csv.GetField<string>(13);
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(14)))
                                    {
                                        context.Logger.Log($"Invoice submission date {csv.GetField<string>(14)}");

                                        if (csv.GetField<string>(14).Contains("/"))
                                        {
                                            var splitedDate = csv.GetField<string>(14).Split('/');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[0].Length == 1)
                                                {
                                                    splitedDate[0] = "0" + splitedDate[0];
                                                }
                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }
                                                //date format is coming as dd/mm/yyyy convert to mm/dd/yyyy
                                                udaanInvoiceSubmission.InvoiceSubmissionDt = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];
                                            }
                                        }
                                        else if (csv.GetField<string>(14).Contains("-"))
                                        {
                                            var splitedDate = csv.GetField<string>(14).Split('-');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[2].Length == 1)
                                                {
                                                    splitedDate[2] = "0" + splitedDate[0];
                                                }
                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }
                                                //date format is coming as yyyy-MM-dd convert to mm/dd/yyyy
                                                udaanInvoiceSubmission.InvoiceSubmissionDt = splitedDate[1] + "/" + splitedDate[2] + "/" + splitedDate[0];
                                            }
                                        }
                                        else
                                        {
                                            udaanInvoiceSubmission.InvoiceSubmissionDt = null;
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(15)))
                                    {
                                        udaanInvoiceSubmission.ImplantNm = csv.GetField<string>(15);
                                    }
                                    context.Logger.Log($"Approved amt {csv.GetField<string>(16)}");
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(16)))
                                    {
                                        double a;
                                        if (double.TryParse(csv.GetField<string>(16), out a))
                                        {
                                            udaanInvoiceSubmission.ApprovedAmt = double.Parse(csv.GetField<string>(16));
                                        }
                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(17)))
                                    { udaanInvoiceSubmission.AmountRecd1Dt = csv.GetField<string>(17); }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(18)))
                                    { udaanInvoiceSubmission.AmountRecd2Dt = csv.GetField<string>(18); }

                                    context.Logger.Log($"{udaanInvoiceSubmission.GetType().ToString()}");
                                    if (udaanInvoiceSubmission != null && !string.IsNullOrEmpty(udaanInvoiceSubmission.VendorInvoiceNumber))
                                    {
                                        context.Logger.Log($"Now we trying to insert the data to invoicxe submission table");
                                        context.Logger.Log($"Process: Now updating the invoice data in the Udaan_Invoices table");
                                        await InsertInvoiceSubmissionDataIntoDb(udaanInvoiceSubmission, udaanInvoiceData, udaanInvoiceTable, context);
                                        udaanInvoiceSubmission = new InvoiceSubmission();
                                    }
                                }
                                #endregion                               
                            }

                        }
                        #endregion
                        if (!string.IsNullOrEmpty(fileName))
                        {
                            string destFilename = RenameFile(fileName);
                            await s3.CopyFileFromOneFolderToOther(bucketName, bucketName,
                                CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath,
                                CommonConstants.Private_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/" + CommonConstants.UdaanInvoiceSubmission,
                                fileName, destFilename, context
                                );
                            await s3.DeleteFile(bucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, fileName, context);
                        }
                    }
                    #endregion
                }
                #endregion

                #region cwt
                if (objectKeySplited[0].ToLowerInvariant() == "cwt" || objectKeySplited[1].ToLowerInvariant() == "cwt")
                {
                    Console.WriteLine($" CWT module");
                    List<string> cwtInvoiceListTemp = new List<string>();
                    List<string> cwtCreditNoteListTemp = new List<string>();

                    List<string> cwtInvoiceList = new List<string>();
                    List<string> cwtCreditNoteList = new List<string>();
                    List<string> cwtReissuance = new List<string>();
                    List<CWTInvoice> tempCwtInvoiceList = new List<CWTInvoice>();
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(filePath + "/", ""));
                    var fileData = await s3.GetFileFromS3(bucketName, filePath, fileName, context);
                    Dictionary<string, string> InvDetails = new Dictionary<string, string>();
                    if (fileData != null)
                    {
                        using (var csvReadData = new System.IO.StreamReader(fileData.ResponseStream))
                        {
                            var csv = new CsvReader(csvReadData);
                            context.Logger.Log($"Process :Before starting to read the csv file");
                            csv.Configuration.HasHeaderRecord = true;//cwt will have the header row
                            csv.Configuration.Delimiter = "|";
                            CWTInvoice tempCwtInvoice = null;
                            while (csv.Read())
                            {
                                tempCwtInvoice = new CWTInvoice();
                                if (!string.IsNullOrEmpty(csv.GetField<string>(6))) //   booking/cancel
                                {
                                    if (csv.GetField<string>(6).ToLowerInvariant().Trim() == "booking")
                                    {
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                        {
                                            string invoiceNumber = csv.GetField<string>(5);
                                            cwtInvoiceListTemp.Add(invoiceNumber);
                                            tempCwtInvoice.VendorInvoiceCRNo = invoiceNumber;
                                        }
                                        if (!string.IsNullOrEmpty(csv.GetField<string>(4)))
                                        {
                                            string invoiceDt = csv.GetField<string>(4);
                                            tempCwtInvoice.SearchInvoiceDt = ConvertDateTimeCWTISOFormat(invoiceDt);
                                        }
                                    }
                                    if (csv.GetField<string>(6).ToLowerInvariant().Trim() == "cancel")
                                    {
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                        {
                                            string invoiceNumber = csv.GetField<string>(5);

                                            cwtCreditNoteListTemp.Add(invoiceNumber);
                                            tempCwtInvoice.VendorInvoiceCRNo = invoiceNumber;

                                        }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                        {
                                            string invoiceDt = csv.GetField<string>(4);
                                            tempCwtInvoice.SearchInvoiceDt = ConvertDateTimeCWTISOFormat(invoiceDt);
                                        }
                                    }
                                }
                                if (tempCwtInvoice != null && tempCwtInvoice.VendorInvoiceCRNo != null)
                                {
                                    tempCwtInvoiceList.Add(tempCwtInvoice);
                                }


                            }
                        }
                        Console.WriteLine(JsonConvert.SerializeObject(tempCwtInvoiceList));
                    }
                    #region checking special chars and lenght of
                    foreach (var invoicenumber in cwtInvoiceListTemp)
                    {
                        Regex rgx = new Regex(@"^[a-zA-Z0-9]{8,16}$");
                        if (rgx.IsMatch(invoicenumber))
                        {
                            cwtInvoiceList.Add(invoicenumber);
                            //context.Logger.Log($"{invoicenumber} : Invoioce no is in proper format and added to the list");
                        }
                        else
                        {
                            context.Logger.Log($"Error: {invoicenumber} :Not matching alphanumeric 8-16 digit invoice number format");
                        }
                    }
                    foreach (var creditnote in cwtCreditNoteListTemp)
                    {
                        Regex rgx = new Regex(@"^[a-zA-Z0-9]{8,16}$");
                        if (rgx.IsMatch(creditnote))
                        {
                            cwtCreditNoteList.Add(creditnote);
                            //context.Logger.Log($"{creditnote} : credit note is in proper format and added to the list");
                        }
                        else
                        {
                            context.Logger.Log($"Error: {creditnote} :Not matching alphanumeric 8-16 digit credit note format");
                        }

                    }
                    #endregion
                    #region matching file and invoices
                    List<string> cwtFileNameList = await s3.ListAllTheFilesInFolder(bucketName, filePath, context);
                    List<string> ValidInvoiceTicketSupFiles = new List<string>();
                    List<string> ValidCrOiSupFiles = new List<string>();
                    List<string> uploadedInvoicesAgainstInvNo = new List<string>();
                    List<string> uploadedTktAgainstInvNo = new List<string>();
                    List<string> uploadedSupportingSAgainstInvNo = new List<string>();
                    List<string> InValidFilesList = new List<string>();
                    List<string> totalInvNoInCWTFileNameList = new List<string>();
                    string invNoInCWTFileNameList = string.Empty;
                    string invCount = string.Empty;
                    List<string> totalInv = new List<string>();
                    List<string> duplicateItemOfInvoice = new List<string>();
                    List<string> duplicateItemOfTicket = new List<string>();
                    List<string> totalTkt = new List<string>();
                    List<string> invoicesWhichDoesNotHavePdfFiles = new List<string>();
                    string tktCount = string.Empty;

                    List<string> listOfInvoicesinCsv = new List<string>();
                    listOfInvoicesinCsv.AddRange(cwtCreditNoteList);
                    listOfInvoicesinCsv.AddRange(cwtInvoiceList);


                    if (cwtFileNameList != null && cwtFileNameList.Count > 0)
                    {
                        //invoices whose entry there in the csv but there is no coresponding (any) pdf is present                        
                        invoicesWhichDoesNotHavePdfFiles = listOfInvoicesinCsv.Except(from invoiceEntryInCsv in listOfInvoicesinCsv
                                                                                      join cwtFileName in cwtFileNameList on invoiceEntryInCsv equals cwtFileName.Split('_')[0]
                                                                                      select invoiceEntryInCsv).ToList();


                        //the uploaded invoice file with matching invoice number in accrual sheet
                        uploadedInvoicesAgainstInvNo = cwtFileNameList.Where(file => cwtInvoiceList.Any(
                                                                               invoice => file.ToLowerInvariant().Contains(invoice.ToLowerInvariant())
                                                                               && file.ToLowerInvariant().Contains("_inv.pdf"))).ToList();
                        context.Logger.Log($"Data : The number of invoice files uploaded which has invoice no entry in accrual csv {uploadedInvoicesAgainstInvNo.Count} and they are{JsonConvert.SerializeObject(uploadedInvoicesAgainstInvNo)}");


                        //the uploaded ticket file with matching invoice number in accrual sheet
                        uploadedTktAgainstInvNo = cwtFileNameList.Where(file => cwtInvoiceList.Any(
                                                                           invoice => file.ToLowerInvariant().Contains(invoice.ToLowerInvariant())
                                                                           && file.ToLowerInvariant().Contains("_tkt.pdf"))).ToList();


                        //checking the 2 ticket associated with a invoice 
                        //var ticketApearingInSequense= uploadedTktAgainstInvNo.GroupBy(ticket => ticket.Substring(0, ticket.IndexOf("_") + 1))
                        //     .Where(invoiceNumberApearing => invoiceNumberApearing.Count() > 1).ToList();


                        context.Logger.Log($"Data :The number of ticket files uploaded which has invoice no entry in accrual csv {uploadedTktAgainstInvNo.Count} and they are {JsonConvert.SerializeObject(uploadedTktAgainstInvNo)}");

                        uploadedSupportingSAgainstInvNo = cwtFileNameList.Where(file => cwtInvoiceList.Any(
                                                                                   invoice => file.ToLowerInvariant().Contains(invoice.ToLowerInvariant())
                                                                                   && file.ToLowerInvariant().Contains("_sup"))).ToList();

                        context.Logger.Log($"Data :The number of supporting files uploaded which has invoice no entry in accrual csv {uploadedSupportingSAgainstInvNo.Count} and they are {JsonConvert.SerializeObject(uploadedSupportingSAgainstInvNo)}");

                        var allTheInvoicesWithCorespondingTicketFiles = uploadedInvoicesAgainstInvNo.Where(invoicefile => uploadedTktAgainstInvNo.Any
                                                                                                         (ticket => ticket.ToLowerInvariant().Contains(invoicefile.ToLowerInvariant().Substring(0, invoicefile.IndexOf('_') + 1)))).ToList();

                        context.Logger.Log($"Data :Number of invoice files with coresponding ticket uploaded which has invoice no entry in accrual csv {allTheInvoicesWithCorespondingTicketFiles.Count} and they are {JsonConvert.SerializeObject(allTheInvoicesWithCorespondingTicketFiles)}");

                        var allTheTicketWithCorespondingInvoiceFiles = uploadedTktAgainstInvNo.Where(ticket =>
                                                                       uploadedInvoicesAgainstInvNo.Any(invoice => invoice.ToLowerInvariant().Contains(ticket.ToLowerInvariant().Substring(0, ticket.IndexOf('_') + 1)))).ToList();
                        context.Logger.Log($"Data :Number of ticket files with coresponding invoice uploaded which has invoice no entry in accrual csv {allTheTicketWithCorespondingInvoiceFiles.Count} and they are {JsonConvert.SerializeObject(allTheTicketWithCorespondingInvoiceFiles)}");

                        var allMatchingIncoiceAndTicketFiles = allTheInvoicesWithCorespondingTicketFiles.Union(allTheTicketWithCorespondingInvoiceFiles).ToList();

                        context.Logger.Log($"Data :Total no files with both invoice & ticket uploaded which has invoice no entry in accrual csv {allMatchingIncoiceAndTicketFiles.Count} and they are {JsonConvert.SerializeObject(allMatchingIncoiceAndTicketFiles)}");

                        var allTheSupportingFilesWithCorespondingInvoiceAndTicketFile = uploadedSupportingSAgainstInvNo.Where(support => allMatchingIncoiceAndTicketFiles.Any
                        (invoice => support.ToLowerInvariant().Contains(invoice.ToLowerInvariant().Substring(0, invoice.IndexOf('_') + 1)))).ToList();

                        ValidInvoiceTicketSupFiles = allMatchingIncoiceAndTicketFiles.Union(allTheSupportingFilesWithCorespondingInvoiceAndTicketFile).ToList();

                        context.Logger.Log($"Data :Total no files with invoice,ticket and supporting uploaded which has invoice no entry in accrual csv {ValidInvoiceTicketSupFiles.Count} and they are {JsonConvert.SerializeObject(ValidInvoiceTicketSupFiles)}");
                        var uploadedCreditNotesAgainstCrNo = cwtFileNameList.Where(file => cwtCreditNoteList.Any(
                                                                               creditNote => file.ToLowerInvariant().Contains(creditNote.ToLowerInvariant())
                                                                               && file.ToLowerInvariant().Contains("_crn.pdf"))).ToList();

                        context.Logger.Log($"Data : The number of credit note files uploaded which has cr no entry in accrual csv {uploadedCreditNotesAgainstCrNo.Count} and they are{JsonConvert.SerializeObject(uploadedCreditNotesAgainstCrNo)}");

                        var uploadedOiAgainstCrNo = cwtFileNameList.Where(file => cwtCreditNoteList.Any(
                                                                            cr => file.ToLowerInvariant().Contains(cr.ToLowerInvariant())
                                                                            && file.ToLowerInvariant().Contains("_oi.pdf"))).ToList();

                        context.Logger.Log($"Data :The number of oi files uploaded which has cr no entry in accrual csv {uploadedOiAgainstCrNo.Count} and they are {JsonConvert.SerializeObject(uploadedOiAgainstCrNo)}");

                        var uploadedSupportingSAgainstCrNo = cwtFileNameList.Where(file => cwtCreditNoteList.Any(
                                                                                    cr => file.ToLowerInvariant().Contains(cr.ToLowerInvariant())
                                                                                    && file.ToLowerInvariant().Contains("_sup"))).ToList();

                        context.Logger.Log($"Data :The number of supporting files uploaded which has cr no entry in accrual csv {uploadedSupportingSAgainstInvNo.Count} and they are {JsonConvert.SerializeObject(uploadedSupportingSAgainstInvNo)}");

                        var allTheCrWithCorespondingOiFiles = uploadedCreditNotesAgainstCrNo.Where(crfile => uploadedOiAgainstCrNo.Any
                                                                                                         (oi => oi.ToLowerInvariant().Contains(crfile.ToLowerInvariant().Substring(0, crfile.IndexOf('_') + 1)))).ToList();

                        context.Logger.Log($"Data :Number of cr files with coresponding oi uploaded which has cr no entry in accrual csv {allTheCrWithCorespondingOiFiles.Count} and they are {JsonConvert.SerializeObject(allTheCrWithCorespondingOiFiles)}");

                        var allTheOiWithCorespondingCrFiles = uploadedOiAgainstCrNo.Where(oi =>
                                                                       uploadedCreditNotesAgainstCrNo.Any(cr => cr.ToLowerInvariant().Contains(oi.ToLowerInvariant().Substring(0, oi.IndexOf('_') + 1)))).ToList();
                        context.Logger.Log($"Data :Number of oi files with coresponding cr uploaded which has cr no entry in accrual csv {allTheOiWithCorespondingCrFiles.Count} and they are {JsonConvert.SerializeObject(allTheOiWithCorespondingCrFiles)}");

                        var allMatchingCrAndOiFiles = allTheCrWithCorespondingOiFiles.Union(allTheOiWithCorespondingCrFiles).ToList();

                        context.Logger.Log($"Data :Total no files with both cr & oi uploaded which has cr no entry in accrual csv {allMatchingCrAndOiFiles.Count} and they are {JsonConvert.SerializeObject(allMatchingCrAndOiFiles)}");

                        var allTheSupportingFilesWithCorespondingCrAndOiFile = uploadedSupportingSAgainstCrNo.Where(support => allMatchingCrAndOiFiles.Any
                        (cr => support.ToLowerInvariant().Contains(cr.ToLowerInvariant().Substring(0, cr.IndexOf('_') + 1)))).ToList();

                        ValidCrOiSupFiles = allMatchingCrAndOiFiles.Union(allTheSupportingFilesWithCorespondingCrAndOiFile).ToList();

                        context.Logger.Log($"Data :Total no files with cr,oi and supporting uploaded which has cr no entry in accrual csv {ValidCrOiSupFiles.Count} and they are {JsonConvert.SerializeObject(ValidCrOiSupFiles)}");

                        InValidFilesList = cwtFileNameList.Except(ValidCrOiSupFiles.Union(ValidInvoiceTicketSupFiles)).ToList();
                        context.Logger.Log($"Error :Invalid files list :{JsonConvert.SerializeObject(InValidFilesList)}");

                        //foreach (var invoice in cwtFileNameList)
                        //{
                        //   invNoInCWTFileNameList = invoice.ToLowerInvariant().Substring(0, invoice.IndexOf('_') );
                        //    totalInvNoInCWTFileNameList.Add(invNoInCWTFileNameList);
                        //   // var difference = totalList.Except(result, StringComparer.OrdinalIgnoreCase).ToList();

                        //}
                        //var csvNotPdf = totalList.Except(totalInvNoInCWTFileNameList, StringComparer.OrdinalIgnoreCase).ToList();
                        //if (csvNotPdf.Count > 0)
                        //{
                        //    context.Logger.Log($"Error :Invoice List present in CSV but its corresponding PDF :{JsonConvert.SerializeObject(csvNotPdf)}");
                        //}

                        //var pdfNotCsv = totalInvNoInCWTFileNameList.Except(totalList, StringComparer.OrdinalIgnoreCase).ToList();
                        //if (pdfNotCsv.Count > 0)
                        //{
                        //    context.Logger.Log($"Data :PDF present but its corresponding invoiceList in CSV  are not found :{JsonConvert.SerializeObject(pdfNotCsv)}");
                        //}

                        //          foreach (var invoice in uploadedInvoicesAgainstInvNo)
                        //          {
                        //             invCount = invoice.ToLowerInvariant().Substring(0, invoice.IndexOf('_'));
                        //              totalInv.Add(invCount);
                        //          var duplicateItems  = totalInv.GroupBy(x => x)
                        //.Where(g => g.Count() > 1)
                        //.Select(y => new { Element = y.Key, Counter = y.Count() })
                        //.ToList();
                        //              duplicateItemOfInvoice = duplicateItems.Select(c => c.ToString()).ToList();


                        //              // var difference = totalList.Except(result, StringComparer.OrdinalIgnoreCase).ToList();

                        //          }
                        //          foreach (var invoice in uploadedTktAgainstInvNo)
                        //          {
                        //              tktCount = invoice.ToLowerInvariant().Substring(0, invoice.IndexOf('_'));
                        //              totalTkt.Add(tktCount);
                        //              var duplicateItem = totalTkt.GroupBy(x => x)
                        //.Where(g => g.Count() > 1)
                        //.Select(y => new { Element = y.Key, Counter = y.Count() })
                        //.ToList();
                        //              duplicateItemOfTicket = duplicateItem.Select(c => c.ToString()).ToList();


                        //              // var difference = totalList.Except(result, StringComparer.OrdinalIgnoreCase).ToList();

                        //          }

                        //foreach (var inv in totalInv)
                        //{
                        //    foreach (var inve in totalInvNoInCWTFileNameList)
                        //    {

                        //        if(totalInv.Contains(inve)&& inve==inv && inve===inv.count)

                        //    }

                        //}

                        InvoiceBatch invoiceBatch = new InvoiceBatch();
                        invoiceBatch.VendorGroupCd = CommonConstants.Cwtteam;
                        invoiceBatch.InvoiceBatchDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm:ss");

                        invoiceBatch.TotalFiles = cwtFileNameList.Count;
                        //invoiceBatch.CopiedFiles = invoiceNumberCorespondingFileNameList.Count();
                        invoiceBatch.TotalRecords = cwtFileNameList.Count;
                        invoiceBatch.CwtValidInvoiceTicketSupFiles = ValidInvoiceTicketSupFiles;
                        invoiceBatch.CwtValidCrOiSupFiles = ValidCrOiSupFiles;
                        invoiceBatch.CwtInvoiceFiles = uploadedInvoicesAgainstInvNo;
                        invoiceBatch.CwtTicketFiles = uploadedTktAgainstInvNo;
                        invoiceBatch.CwtSupportingFiles = uploadedSupportingSAgainstInvNo;
                        //invoiceBatch.TotalRecordsRejected = fileNameWithoutInvoiceEntryList.Count();
                        //invoiceBatch.TotalRecordsValid = invoiceNumberCorespondingFileNameList.Count();
                        //invoiceBatch.ValidFileList = invoiceNumberCorespondingFileNameList.ToList();
                        //invoiceBatch.InValidFileList = fileNameWithoutInvoiceEntryList.ToList();                       
                        invoiceBatch.CreatedBy = CommonConstants.Cwtteam;
                        invoiceBatch.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                        invoiceBatch.ModifiedBy = CommonConstants.Cwtteam;
                        invoiceBatch.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                        await dynamoDb.InsertAsync<InvoiceBatch>(invoiceBatch, invoiceBatchTable, context);
                        MasterClass masterClass = new MasterClass();
                        masterClass.BucketName = bucketName;
                        masterClass.Vendor = CommonConstants.Cwtteam;
                        masterClass.CwtCSVFileName = fileName;
                        masterClass.InvoiceBatchDttm = invoiceBatch.InvoiceBatchDttm;

                        if (DebugEnvironMent.ToLowerInvariant() == "true")
                        {
                            iDigi_CSVReaderSpecificVendor.Function csvReaderSpecificVendor = new iDigi_CSVReaderSpecificVendor.Function();
                            var dataInJsonString = JsonConvert.SerializeObject(masterClass);
                            var mstserClassObject = JsonConvert.DeserializeObject<iDigi_CSVReaderSpecificVendor.Models.MasterClass>(dataInJsonString);
                            await csvReaderSpecificVendor.FunctionHandler(mstserClassObject, context);
                        }
                        else
                        {
                            Amazon.Lambda.Model.InvokeRequest invokeRequest = new Amazon.Lambda.Model.InvokeRequest();
                            invokeRequest.Payload = JsonConvert.SerializeObject(masterClass);
                            MasterClass deserializedMasterClass = JsonConvert.DeserializeObject<MasterClass>(invokeRequest.Payload);
                            invokeRequest.FunctionName = "7433_iDigi_CSVReaderSpecificVendor";
                            invokeRequest.InvocationType = InvocationType.Event;
                            var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                            LogChildLambdaResponse(childLmbdaResponse, context);
                        }

                        InvoiceErrorDetails invoiceErrorDetails = new InvoiceErrorDetails();
                        List<ErrorDetails> errorDetailsList = null;
                        CWTInvoice cwtInvoice = new CWTInvoice();

                        foreach (var file in InValidFilesList)
                        {
                            ErrorDetails errorDetail = new ErrorDetails();
                            errorDetailsList = new List<ErrorDetails>();
                            var invoiceNumber = file.Split('_')[0];
                            cwtInvoice.VendorInvoiceCRNo = invoiceNumber;
                            if (cwtInvoice.VendorInvoiceCRNo != null)
                            {
                                if (file.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && file.ToLowerInvariant().Contains("inv") && !file.ToLowerInvariant().Contains("tkt"))
                                {
                                    errorDetail.Error = $"{invoiceNumber} does not contain corresponding ticket file.";
                                }
                                if (file.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && file.ToLowerInvariant().Contains("tkt") && !file.ToLowerInvariant().Contains("inv"))
                                {
                                    errorDetail.Error = $"{invoiceNumber} does not contain corresponding invoice file.";
                                }
                                if (file.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && file.ToLowerInvariant().Contains("oi") && !file.ToLowerInvariant().Contains("crn"))
                                {
                                    errorDetail.Error = $"{invoiceNumber} does not contain corresponding credit note file.";
                                }
                                if (file.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && file.ToLowerInvariant().Contains("crn") && !file.ToLowerInvariant().Contains("oi"))
                                {
                                    errorDetail.Error = $"{invoiceNumber} does not contain corresponding Original invoice file.";
                                }
                            }
                            // errorDetail.Error = $"{invoiceNumber} does not contain corresponding invoice/ticket file.";
                            errorDetail.IsValidError = "true";
                            errorDetail.VendorType = "AEE";
                            errorDetailsList.Add(errorDetail);
                            string invDate = string.Empty;
                            if (tempCwtInvoiceList != null && tempCwtInvoiceList.Count > 0)
                            {
                                var invoiceMatching = tempCwtInvoiceList.Where(cwtInv => cwtInv.VendorInvoiceCRNo.Contains(invoiceNumber));
                                foreach (var inv in invoiceMatching)
                                {
                                    invDate = inv.SearchInvoiceDt;
                                }
                            }
                            invoiceErrorDetails.InvoiceDt = !string.IsNullOrEmpty(invDate) ? invDate : null;
                            invoiceErrorDetails.ErrorsList = errorDetailsList;
                            invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                            //invoiceErrorDetails.InvoiceDttm= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/mm/dd HH:mm:ss tt");
                            invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                            invoiceErrorDetails.VendorInvoiceNbr = invoiceNumber;
                            invoiceErrorDetails.VendorModuleCd = "CWTADG";
                            Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                            await dynamoDb.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                            Console.WriteLine($"Process: Inserted error details to table");
                            string tempFilename = RenameFile(file);
                            if (!string.IsNullOrEmpty(tempFilename))
                            {
                                await s3.CopyFileFromOneFolderToOther(bucketName, cwtPrivateBucket, CommonConstants.CWTInvoice_FilePath, CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvalidFile_FolderPath, file, tempFilename, context);
                                await s3.DeleteFile(bucketName, CommonConstants.CWTInvoice_FilePath, file, context);
                            }
                        }

                        foreach (var invoice in invoicesWhichDoesNotHavePdfFiles)
                        {
                            ErrorDetails errorDetail = new ErrorDetails();
                            errorDetailsList = new List<ErrorDetails>();
                            var invoiceNumber = invoice;
                            cwtInvoice.VendorInvoiceCRNo = invoiceNumber;
                            errorDetail.Error = $"{invoiceNumber} does not contain any pdf file.";
                            errorDetail.IsValidError = "true";
                            errorDetail.VendorType = "AEE";
                            errorDetailsList.Add(errorDetail);

                            // string invDate = (tempCwtInvoiceList != null && tempCwtInvoiceList.Count() > 0) ? ((tempCwtInvoiceList.Where(cwtInv => cwtInv.VendorInvoiceCRNo.Contains(invoiceNumber)).FirstOrDefault()).SearchInvoiceDt) : string.Empty;
                            string invDate = string.Empty;
                            if (tempCwtInvoiceList != null && tempCwtInvoiceList.Count > 0)
                            {
                                var invoiceMatching = tempCwtInvoiceList.Where(cwtInv => cwtInv.VendorInvoiceCRNo.Contains(invoiceNumber));
                                foreach (var inv in invoiceMatching)
                                {
                                    invDate = inv.SearchInvoiceDt;
                                }
                            }



                            invoiceErrorDetails.InvoiceDt = !string.IsNullOrEmpty(invDate) ? invDate : null;
                            invoiceErrorDetails.ErrorsList = errorDetailsList;
                            invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                            invoiceErrorDetails.InvoiceDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/mm/dd HH:mm:ss tt");
                            invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                            invoiceErrorDetails.VendorInvoiceNbr = invoiceNumber;
                            invoiceErrorDetails.VendorModuleCd = "CWTADG";
                            Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                            await dynamoDb.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                            Console.WriteLine($"Process: Inserted error details to table");
                        }
                    }
                    #endregion
                }
                #endregion

                #region CSR
                if (objectKeySplited[0].ToLowerInvariant() == "csr")
                {
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(CommonConstants.CSRInvoice_FilePath + "/", ""));
                    context.Logger.Log($"Data : Uploaded filename :-{fileName}");
                    var csrFileData = await s3.GetFileFromS3(bucketName, CommonConstants.CSRInvoice_FilePath, fileName, context);
                    List<string> csrInvoiceNumberList = new List<string>();

                    #region Get csr invoice list from .csv file
                    if (csrFileData != null)
                    {
                        using (var fs = new StreamReader(csrFileData.ResponseStream))
                        {
                            var csv = new CsvReader(fs);
                            context.Logger.Log($"Process :Before starting to read the csv file");
                            //CSR files wont be having the headers in their csv files
                            csv.Configuration.HasHeaderRecord = true;
                            while (csv.Read())
                            {
                                //if (csv.GetField<string>(21).ToLowerInvariant() == "hr")
                                //{
                                //CSR invoice number
                                if (!string.IsNullOrWhiteSpace(csv.GetField<string>(21)))
                                {
                                    string invoiceNumber = csv.GetField<string>(21);
                                    csrInvoiceNumberList.Add(invoiceNumber);
                                }
                                //}
                            }
                        }
                    }
                    #endregion

                    #region matching files with invoice number and Maintaing invoice batch
                    List<string> csrInvoiceNumberListfinal = new List<string>();
                    List<string> uploadedInvoicesAgainstInvNo = new List<string>();
                    List<string> uploadedTRAgainstInvNo = new List<string>();
                    List<string> csrValidpdfFileNameList = new List<string>();
                    List<string> csrFileNameList = await s3.ListAllTheFilesInFolder(bucketName, CommonConstants.CSRInvoice_FilePath, context);
                    csrInvoiceNumberListfinal = csrInvoiceNumberList.Distinct().ToList();
                    if (csrFileNameList != null && csrFileNameList.Count > 0 && csrInvoiceNumberList != null)
                    {
                        uploadedInvoicesAgainstInvNo = csrFileNameList.Where(file => csrInvoiceNumberList.Any(
                                                                               invoice => file.ToLowerInvariant().Contains(invoice.ToLowerInvariant())
                                                                               && file.ToLowerInvariant().Contains("_inv_"))).ToList();
                        context.Logger.Log($"Data : The number of invoice files uploaded which has invoice no entry in CSR csv {uploadedInvoicesAgainstInvNo.Count} and they are{JsonConvert.SerializeObject(uploadedInvoicesAgainstInvNo)}");

                        //the uploade TR file with matching invoice number in accrual sheet
                        uploadedTRAgainstInvNo = csrFileNameList.Where(file => csrInvoiceNumberList.Any(
                                                                           invoice => file.ToLowerInvariant().Contains(invoice.ToLowerInvariant())
                                                                           && file.ToLowerInvariant().Contains("_tr_"))).ToList();

                        context.Logger.Log($"Data :The number of TR files uploaded which has invoice no entry in CSR csv {uploadedTRAgainstInvNo.Count} and they are {JsonConvert.SerializeObject(uploadedTRAgainstInvNo)}");

                        var allTheInvoicesWithCorespondingTRFiles = uploadedInvoicesAgainstInvNo.Where(invoicefile => uploadedTRAgainstInvNo.Any
                                                                                                               (TR => TR.ToLowerInvariant().Contains(invoicefile.ToLowerInvariant().Substring(0, invoicefile.IndexOf('_') + 1)))).ToList();

                        context.Logger.Log($"Data :Number of invoice files with coresponding TR uploaded which has invoice no entry in CSR csv {allTheInvoicesWithCorespondingTRFiles.Count} and they are {JsonConvert.SerializeObject(allTheInvoicesWithCorespondingTRFiles)}");

                        var allTheTRWithCorespondingInvoiceFiles = uploadedTRAgainstInvNo.Where(TR =>
                                                                       uploadedInvoicesAgainstInvNo.Any(invoice => invoice.ToLowerInvariant().Contains(TR.ToLowerInvariant().Substring(0, TR.IndexOf('_') + 1)))).ToList();
                        context.Logger.Log($"Data :Number of TR files with coresponding invoice uploaded which has invoice no entry in CSR csv {allTheTRWithCorespondingInvoiceFiles.Count} and they are {JsonConvert.SerializeObject(allTheTRWithCorespondingInvoiceFiles)}");

                        var allMatchingIncoiceAndTRFiles = allTheInvoicesWithCorespondingTRFiles.Union(allTheTRWithCorespondingInvoiceFiles).ToList();

                        context.Logger.Log($"Data :Total no files with both invoice & TR uploaded which has invoice no entry in CSR csv {allMatchingIncoiceAndTRFiles.Count} and they are {JsonConvert.SerializeObject(allMatchingIncoiceAndTRFiles)}");

                        var fileNameWithoutInvoiceEntryList = csrFileNameList.Except(allMatchingIncoiceAndTRFiles);
                        context.Logger.Log($"Data :Total no files without both invoice or TR which has invoice no entry in CSR csv {fileNameWithoutInvoiceEntryList.ToList().Count} and they are {JsonConvert.SerializeObject(fileNameWithoutInvoiceEntryList)}");
                        csrValidpdfFileNameList = allMatchingIncoiceAndTRFiles.ToList();

                        context.Logger.Log($"Data :Total no files with both invoice & TR uploaded which has invoice no entry in CSR csv {fileNameWithoutInvoiceEntryList.ToList().Count} and they are {JsonConvert.SerializeObject(fileNameWithoutInvoiceEntryList.ToList())}");
                        InvoiceBatch invoiceBatch = new InvoiceBatch();
                        invoiceBatch.VendorGroupCd = CommonConstants.CSRTeam;
                        invoiceBatch.InvoiceBatchDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm:ss");

                        invoiceBatch.TotalFiles = csrFileNameList.Count;
                        invoiceBatch.CopiedFiles = allMatchingIncoiceAndTRFiles.Count();

                        invoiceBatch.TotalRecords = csrFileNameList.Count;
                        //invoiceBatch.TotalRecordsFailed =;
                        invoiceBatch.TotalRecordsRejected = fileNameWithoutInvoiceEntryList.Count();
                        invoiceBatch.TotalRecordsValid = allMatchingIncoiceAndTRFiles.Count();

                        invoiceBatch.ValidFileList = allMatchingIncoiceAndTRFiles.ToList();
                        invoiceBatch.InValidFileList = fileNameWithoutInvoiceEntryList.ToList();

                        invoiceBatch.CreatedBy = CommonConstants.CSRTeam;
                        invoiceBatch.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                        invoiceBatch.ModifiedBy = CommonConstants.CSRTeam;
                        invoiceBatch.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                        await dynamoDb.InsertAsync<InvoiceBatch>(invoiceBatch, invoiceBatchTable, context);

                        MasterClass masterClass = new MasterClass();
                        masterClass.BucketName = bucketName;
                        masterClass.Vendor = CommonConstants.CSRTeam;
                        masterClass.CsrCSVFileName = fileName;
                        masterClass.InvoiceBatchDttm = invoiceBatch.InvoiceBatchDttm;

                        Amazon.Lambda.Model.InvokeRequest invokeRequest = new Amazon.Lambda.Model.InvokeRequest();
                        invokeRequest.Payload = JsonConvert.SerializeObject(masterClass);
                        invokeRequest.FunctionName = "7433_iDigi_CSVReaderSpecificVendor";
                        invokeRequest.InvocationType = InvocationType.Event;
                        var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
                        LogChildLambdaResponse(childLmbdaResponse, context);

                        context.Logger.Log($"Valid file fromn S3 {JsonConvert.SerializeObject(invoiceBatch.ValidFileList)}");
                        Console.WriteLine(JsonConvert.SerializeObject(invoiceBatch.InValidFileList));
                        context.Logger.Log($"Invalid file fromn S3 {JsonConvert.SerializeObject(invoiceBatch.InValidFileList.Count)}");
                        context.Logger.Log($"Invalid file fromn S3 {JsonConvert.SerializeObject(invoiceBatch.InValidFileList)}");
                        foreach (var invalidfileName in invoiceBatch.InValidFileList)
                        {
                            string renamedFileName = RenameFile(invalidfileName);
                            await s3.CopyFileFromOneFolderToOther(masterClass.BucketName, CSRDestinationBucket, CsrPublicFolderPath, csrInvalidFilePath, invalidfileName, renamedFileName, context);
                            await s3.DeleteFile(masterClass.BucketName, CsrPublicFolderPath, invalidfileName, context);
                        }
                    }


                    #endregion
                }
                #endregion
                #endregion
            }
            catch (Exception e)
            {
                context.Logger.LogLine(e.Message);
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine(e.StackTrace);
                throw;
            }
        }
        private void LogChildLambdaResponse(dynamic childLmbdaResponse, ILambdaContext context)
        {
            context.Logger.Log($"Log: Running Child lambda instace id :{childLmbdaResponse.Id}");
            context.Logger.Log($"Log: Is Child lambda Instace :{childLmbdaResponse.Id} cancelled :{childLmbdaResponse.IsCanceled}");
            context.Logger.Log($"Log: Is child lambda instance faulted :{childLmbdaResponse.IsFaulted} ");
            context.Logger.Log($"Log: Result  :{childLmbdaResponse.Result} ");
            context.Logger.Log($"Log: Status  :{childLmbdaResponse.Status} ");
        }
        private async Task InsertInvoiceSubmissionDataIntoDb(InvoiceSubmission invoiceSubmission, List<UdaanInvoice> completeUdaanTabledata, string tableName, ILambdaContext logger)
        {
            logger.Logger.Log($" now trying to update the invoice submission details in udaan table ");
            await CheckUdaanInvoiceEntryInUdaanInvoiceTable(invoiceSubmission, completeUdaanTabledata, tableName, logger);

        }
        private async Task CheckUdaanInvoiceEntryInUdaanInvoiceTable(InvoiceSubmission invoiceSubmission, List<UdaanInvoice> completeUdaanTabledata, string tableName, ILambdaContext logger)
        {
            InvSub invSub = new InvSub();
            invSub.AmountRecdDate1 = invoiceSubmission.AmountRecd1Dt;
            invSub.AmountRecdDate2 = invoiceSubmission.AmountRecd2Dt;
            invSub.ApprovedAmt = invoiceSubmission.ApprovedAmt;
            invSub.BusinessUnit = invoiceSubmission.BusinessUnitNo;
            invSub.Country = invoiceSubmission.Country;
            invSub.EmployeeName = invoiceSubmission.EmployeeNm;
            invSub.EmpNo = invoiceSubmission.EmployeeNo;
            invSub.ImplantName = invoiceSubmission.ImplantNm;
            invSub.InvAmt = invoiceSubmission.InvoiceAmt;
            invSub.InvoiceDate = invoiceSubmission.Date;
            invSub.InvSubmissionDt = invoiceSubmission.InvoiceSubmissionDt;

            invSub.ModifiedBy = CommonConstants.UdaanTeam;
            invSub.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
            invSub.PoNbr = invoiceSubmission.PONumber;
            invSub.ReimbursementCharges = invoiceSubmission.ReImbursementChargeAmt;

            invSub.Service = invoiceSubmission.Service;
            invSub.ServiceCharges = invoiceSubmission.ServiceChargeAmt;
            invSub.ServiceTax = invoiceSubmission.ServiceTaxAmt;
            invSub.TicketNumber = invoiceSubmission.TRNo;
            invSub.WBSE = invoiceSubmission.WBSeNo;
            AmazonDynamoDBClient client = new AmazonDynamoDBClient();
            //ScanRequest scanRequest = new ScanRequest()
            //{
            //    TableName = tableName,
            //    FilterExpression = "VendorInvoiceNumber=:VendorInvoiceNumber",
            //    //AND VendorRegisteredCd=:VendorRegisteredCd",
            //    ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
            //        { ":VendorInvoiceNumber", new AttributeValue {S= invoiceSubmission.VendorInvoiceNumber } },
            //       // { ":VendorRegisteredCd", new AttributeValue {S= invoiceSubmission.VendorGroupCd} }
            //    },
            //};
            //var scanResponse = await client.ScanAsync(scanRequest);         
            //logger.Logger.Log($" rows count {scanResponse.Items.Count}");


            var invoiceNumbermatching = completeUdaanTabledata.Where(item => item.VendorInvoiceNumber == invoiceSubmission.VendorInvoiceNumber);

            if (invoiceNumbermatching.Count() > 0)
            {
                foreach (var item in invoiceNumbermatching)
                {
                    string VendorCd = item.VendorCd;
                    string VendorInvoiceNumber = item.VendorInvoiceNumber;



                    logger.Logger.Log($" VendorCd {VendorCd}");
                    logger.Logger.Log($" VendorInvoiceNumber {VendorInvoiceNumber}");
                    if (!string.IsNullOrEmpty(VendorCd) && !string.IsNullOrEmpty(VendorInvoiceNumber))
                    {
                        //invoiceSubmission.InvoiceId = int.Parse(invoiceId);

                        Table udaanInvoiceTable = Table.LoadTable(client, tableName);
                        Document invSubDocument = IDigiDynamoDocumentConverter.ToDocument(invSub);
                        logger.Logger.Log($"{invSubDocument.Count}");
                        logger.Logger.Log($"now updating the visa table");
                        await udaanInvoiceTable.UpdateItemAsync(invSubDocument, VendorCd, VendorInvoiceNumber);
                        logger.Logger.Log($"now updated the visa table with invoice submission details");
                    }
                }
            }

        }
        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }

        private string ConvertDateTimeCWTISOFormat(string date)
        {
            string convertedDate = string.Empty;
            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is  mm/dd/yyyy in cwt to yyyy/mm/dd
                    convertedDate = splitedDate[2] + "/" + splitedDate[0] + "/" + splitedDate[1];
                }
            }
            return convertedDate;
        }
    }
}
