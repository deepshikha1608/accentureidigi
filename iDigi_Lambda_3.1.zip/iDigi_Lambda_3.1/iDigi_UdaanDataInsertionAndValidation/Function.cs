using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using iDigi_UdaanDataInsertionAndValidation.Models;
using Amazon.DynamoDBv2.DocumentModel;
using System.Globalization;
using Newtonsoft.Json;
using Amazon.DynamoDBv2;
using System.Text.RegularExpressions;

using System.Text;
using Amazon.S3.Model;
using Amazon.S3;
using Amazon.DynamoDBv2.Model;
// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_UdaanDataInsertionAndValidation
{
    public class Function
    {
        
        IAmazonDynamoDB DbClient { get; set; }
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
            }
        }

        public Function()
        {
            DbClient = new AmazonDynamoDBClient();
        }
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(MasterClass masterclass, ILambdaContext context)
        {
            context.Logger.Log($"Process :Lambda invoked {masterclass.GetType().ToString()}");
            IDigiDynamoDb db = new IDigiDynamoDb();
            IDigiS3 s3 = new IDigiS3();
            string attachedFileName = string.Empty;
            string renamedAttcahedFile = string.Empty;

            string udaanInvoiceDumpTable = string.Empty;
            string gstMasterTable = string.Empty;
            string posMasterTable = string.Empty;
            string udaanInvoiceTable = string.Empty;
            string vendorInvoiceErrorDetailsTable = string.Empty;
            string visaInvoiceErrorDetailsTable = string.Empty;

            string invoiceBatchTable = string.Empty;
            string VisaVendorHistoryLogsTable = string.Empty;
            string VisaInvoiceTable = string.Empty;
            string vendorMasterTable = string.Empty;
            string ConfigValueMasterTable = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                udaanInvoiceDumpTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceDumpTable;
                gstMasterTable = CommonConstants.AirId + "_" + CommonConstants.GSTMasterTable;
                posMasterTable = CommonConstants.AirId + "_" + CommonConstants.POSMasterTable;

                udaanInvoiceTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                VisaInvoiceTable = CommonConstants.AirId + "_" + CommonConstants.VisaInvoiceTable;

                vendorInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.VendorInvoiceErrorDetailsTable;
                visaInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.VisaVendorErrorDetailsTable;
                VisaVendorHistoryLogsTable = CommonConstants.AirId + "_" + CommonConstants.VisaVendorHistoryLogsTable;
                invoiceBatchTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceBatchTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                ConfigValueMasterTable = CommonConstants.AirId + "_" + CommonConstants.Table_ConfigValueMaster;

            }
            else
            {
                udaanInvoiceDumpTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceDumpTable;
                gstMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GSTMasterTable;
                posMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.POSMasterTable;
                udaanInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                vendorInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorInvoiceErrorDetailsTable;

                VisaInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaInvoiceTable;
                visaInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaVendorErrorDetailsTable;
                VisaVendorHistoryLogsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaVendorHistoryLogsTable;
                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                ConfigValueMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.Table_ConfigValueMaster;
            }
            InvoiceBatch invoiceBatch = null;
            if (masterclass != null)
            {
                context.Logger.Log($"Vendor :{masterclass.Vendor}");
                var document = await db.GetItem(invoiceBatchTable, masterclass.Vendor, masterclass.InvoiceBatchDttm);
                context.Logger.Log($"Data :{invoiceBatchTable}{masterclass.Vendor}{masterclass.InvoiceBatchDttm}");
                invoiceBatch = IDigiDynamoDocumentConverter.ToObject<InvoiceBatch>(document);
                context.Logger.Log($"{JsonConvert.SerializeObject(invoiceBatch.ValidFileList)}");
                context.Logger.Log($"{JsonConvert.SerializeObject(invoiceBatch.InValidFileList)}");
            }
            var fcmvendorData = new VendorMaster();
            var udaanvendorData = new VendorMaster();

            ScanFilter scanFilterVendorMaster = new ScanFilter();
            scanFilterVendorMaster.AddCondition("VendorCd", ScanOperator.Equal, "UDN VENDOR");
            ScanOperationConfig scanOperationConfigVendorTable = new ScanOperationConfig()
            {
                Filter = scanFilterVendorMaster
            };            
            var vendorMasterData=await ScanAndFindTheInvoice<VendorMaster>(new VendorMaster(), vendorMasterTable, scanOperationConfigVendorTable);
            ScanFilter filter2 = new ScanFilter();
            filter2.AddCondition("GSTID", ScanOperator.GreaterThan, 0);
            List<GSTMaster> gstMasterList = await db.ScanAsync<GSTMaster>(filter2, gstMasterTable, context);
            context.Logger.Log($"Data : Gst master item count{gstMasterList.Count}");

            ScanFilter filter3 = new ScanFilter();
            filter3.AddCondition("POSID", ScanOperator.GreaterThan, 0);
            List<POSMaster> posMasterList = await db.ScanAsync<POSMaster>(filter3, posMasterTable, context);
            context.Logger.Log($"Data : Pos master item count{posMasterList.Count}");
            bool isThereHardStopingErrorInUdaanData = false;
            UdaanInvoice udaanInvoice = new UdaanInvoice();

            if (masterclass != null && masterclass.UdaanInvoice != null)
            {
                try
                {
                    context.Logger.Log($"Inside master class loop");
                    udaanInvoice = masterclass.UdaanInvoice;
                    udaanInvoice.IsBatchValidated = "N";
                    udaanInvoice.LGIGenerated = "N";
                    //udaanInvoice.CreatedBy = masterclass.Vendor;
                    udaanInvoice.IsGSTError = "N";
                    udaanInvoice.IsError = "N";
                    udaanInvoice.GSTID = 0;
                    udaanInvoice.RowType = "HD";
                    udaanInvoice.BusinessPlaceId = 0;
                    //udaanInvoice.ModifiedBy = masterclass.Vendor;
                    udaanInvoice.InvoiceStatusCd = "New Submission";
                    udaanInvoice.VendorModuleCd = CommonConstants.UdaanTeam;

                    if (udaanInvoice.Base1Amt != null && udaanInvoice.Base1Amt != double.NaN)
                    {
                        if (udaanInvoice.Base1Amt <= 0)
                        {
                            udaanInvoice.IsGSTError = "Y";
                            udaanInvoice.IsError = "Y";
                            Console.WriteLine($"GST error occured for baseamt validation");
                        }
                    }
                    else
                    {
                        udaanInvoice.IsGSTError = "Y";
                        udaanInvoice.IsError = "Y";
                        Console.WriteLine($"GST error occured for baseamt validation");
                    }
                    if (!string.IsNullOrEmpty(udaanInvoice.TaxRate))
                    {
                        if (!udaanInvoice.TaxRate.Contains("%") && udaanInvoice.TaxRate.ToLower() != "exempt")
                        {
                            udaanInvoice.TaxRate = udaanInvoice.TaxRate + "%";
                        }
                    }

                    //Simplified GST CR.Inserting IGST,CGST,SGST at the time of insertion of invoice.
                    if (udaanInvoice.TaxType == "IGST")
                    {
                        udaanInvoice.IGSTAmt = udaanInvoice.TaxAmt;
                        udaanInvoice.CGSTAmt = udaanInvoice.SGSTAmt = 0;
                    }
                    else if (udaanInvoice.TaxType == "CGST+SGST" && (udaanInvoice.TaxAmt != null && Convert.ToString(udaanInvoice.TaxAmt) != "undefined"))
                    {
                        udaanInvoice.CGSTAmt = udaanInvoice.SGSTAmt = udaanInvoice.TaxAmt / 2;
                        udaanInvoice.IGSTAmt = 0;
                    }
                    else if (udaanInvoice.TaxType != "IGST" && udaanInvoice.TaxType != "CGST+SGST")
                    {
                        udaanInvoice.IGSTAmt = udaanInvoice.CGSTAmt = udaanInvoice.SGSTAmt = 0;
                    }

                    if (invoiceBatch != null && invoiceBatch.ValidFileList != null && invoiceBatch.ValidFileList.Count > 0 && masterclass.UdaanInvoice.VendorInvoiceNumber != null)
                    {
                        context.Logger.Log($"Inside listing of the fileName");
                        string tempFileName = string.Empty;
                        foreach (var fileName in invoiceBatch.ValidFileList)
                        {
                            if (fileName.Contains(masterclass.UdaanInvoice.VendorInvoiceNumber))
                            {
                                tempFileName = fileName;
                                attachedFileName = tempFileName;
                                renamedAttcahedFile = RenameFile(attachedFileName);
                                context.Logger.Log($"Data :found file{attachedFileName} ranamed file {renamedAttcahedFile}");
                            }
                        }
                    }
                    context.Logger.Log($"Line item count {masterclass.UdaanInvoice.InvoiceLineItems.Count}");
                    context.Logger.LogLine(JsonConvert.SerializeObject(masterclass));
                    List<string> errorList = new List<string>();
                    #region LGI validations                    
                    if (!string.IsNullOrEmpty(masterclass.Vendor) && !string.IsNullOrEmpty(masterclass.InvoiceBatchDttm))
                    {
                       var visaVendorData= vendorMasterData.FirstOrDefault(vendor => vendor.VendorCode == udaanInvoice.VendorRegisteredCd);

                        udaanInvoice.IsExempted = !string.IsNullOrEmpty(visaVendorData.IsExempted) ? visaVendorData.IsExempted : "NonExempted";
                        if (udaanInvoice.IsExempted == "NotApplicable")
                            udaanInvoice.GSTR2AStatus = "GSTR2ANotRequired";
                        else
                            udaanInvoice.GSTR2AStatus = "GSTR2AReconPending";
                        if (masterclass.UdaanInvoice.VendorRegisteredCd.Length == 9)
                        {
                            udaanInvoice.TPCd = "0" + masterclass.UdaanInvoice.VendorRegisteredCd;
                        }
                        else
                        {
                            errorList.Add("The vendor code is not an visa vendor code");
                            isThereHardStopingErrorInUdaanData = true;
                        }

                        int VendorClassification = visaVendorData.VendorClassification;
                        if ((VendorClassification == 0 || VendorClassification == 1 || VendorClassification == 2) && string.IsNullOrEmpty(masterclass.UdaanInvoice.VendorGSTNumber))
                        {
                            udaanInvoice.IsGSTError = "Y";
                            udaanInvoice.IsError = "Y";
                            Console.WriteLine($"GST error occured for vendorclassification validation");
                        }
                        //UdaanInvoiceDump udaanInvoiceDump = masterclass.UdaanInvoiceDump;
                       
                        if (string.IsNullOrEmpty(masterclass.UdaanInvoice.DCInd))
                        {
                            errorList.Add(UdaanLgiErrorDetails.DCIndDTMndr);
                        }
                        else
                        {
                            if (masterclass.UdaanInvoice.DCInd.ToLower() == "d")
                            {
                                masterclass.UdaanInvoice.DCInd = "D";

                            }
                            else if (masterclass.UdaanInvoice.DCInd.ToLower() == "c")
                            {
                                masterclass.UdaanInvoice.DCInd = "C";
                            }
                            else
                            {
                                errorList.Add(UdaanLgiErrorDetails.DCIndDTDrC);
                            }
                        }


                        //30
                        if (string.IsNullOrEmpty(masterclass.UdaanInvoice.TaxAmt.ToString()))
                        {
                            errorList.Add(UdaanLgiErrorDetails.TaxAmtMndr);
                        }
                        else
                        {
                            double? a = 0;
                            foreach (var lineItem in masterclass.UdaanInvoice.InvoiceLineItems)
                            {


                                a = a + lineItem.TaxAmt;

                            }
                            //31
                            if (masterclass.UdaanInvoice.TaxAmt != a)
                            {
                                errorList.Add(UdaanLgiErrorDetails.TaxAmtSum);
                            }
                        }
                        //29
                        if (masterclass.UdaanInvoice.VendorInvoiceNumber.Length > 16)
                        {
                            errorList.Add(UdaanLgiErrorDetails.VendorInvoiceNumberLmt);
                        }
                        //32
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.FreightAmt.ToString()))
                        {
                            errorList.Add(UdaanLgiErrorDetails.FreightAmtBlnk);
                        }

                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.GrossAmt.ToString()))
                        {
                            double? a = 0;
                            foreach (var lineItem in masterclass.UdaanInvoice.InvoiceLineItems)
                            {
                                context.Logger.Log($"{a}");
                                a = a + lineItem.LineAmt + lineItem.TaxAmt;
                                context.Logger.Log($"{a}");
                            }
                            context.Logger.Log($"{masterclass.UdaanInvoice.GrossAmt}");
                            context.Logger.Log($"Calucalated {a}");
                            if (masterclass.UdaanInvoice.GrossAmt != a)
                            {
                                errorList.Add(UdaanLgiErrorDetails.GrossAmtEqToSmofLineTaxAmt);
                            }
                        }
                        //33
                        else
                        {
                            errorList.Add(UdaanLgiErrorDetails.GrossAmtMndr);
                        }
                        //34 & 35
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.CurrencyCd))
                        {
                            if (masterclass.UdaanInvoice.CurrencyCd.ToLower() == "inr")
                            {
                                masterclass.UdaanInvoice.CurrencyCd = "INR";
                            }
                            else
                            {
                                errorList.Add(UdaanLgiErrorDetails.CurrencyEqToInr);
                            }
                        }
                        else
                        {
                            errorList.Add(UdaanLgiErrorDetails.CurrencyMndr);
                        }
                        //36   -37 
                        if (string.IsNullOrEmpty(masterclass.UdaanInvoice.RequestorNm))
                        {
                            errorList.Add(UdaanLgiErrorDetails.RequestorNmMndr);
                        }
                        //38
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.InvoiceReferenceNbr))
                        {
                            errorList.Add(UdaanLgiErrorDetails.InvoiceRefeBlnk);
                        }
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.PaymentReferenceNbr))
                        {
                            errorList.Add(UdaanLgiErrorDetails.PaymentRefBlnk);
                        }
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.PORReferenceNbr))
                        {
                            errorList.Add(UdaanLgiErrorDetails.PORRefBlnk);
                        }
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.AlternativePayeeNm))
                        {
                            errorList.Add(UdaanLgiErrorDetails.AlternativePayeeBlnk);
                        }
                      
                        #region Line item validations

                        if (masterclass.UdaanInvoice.InvoiceLineItems == null &&
                            masterclass.UdaanInvoice.InvoiceLineItems.Count() == 0)
                        {
                            errorList.Add(UdaanLgiErrorDetails.LineItemDTMndr);
                        }

                        foreach (var linItem in masterclass.UdaanInvoice.InvoiceLineItems)
                        {
                            if (string.IsNullOrEmpty(linItem.TaxParameter1Amt.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.TaxParameter1DTMndr);
                            }
                            if (string.IsNullOrEmpty(linItem.TaxParameter2Amt.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.TaxParameter2DTMndr);
                            }
                            if (string.IsNullOrEmpty(linItem.TaxAmt.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.TaxAmtDTMndr);
                            }
                            if (string.IsNullOrEmpty(linItem.LineAmt.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.LineItemDTMndr);
                            }
                            if (string.IsNullOrEmpty(linItem.ChargedEntity))
                            {
                                errorList.Add(UdaanLgiErrorDetails.ChargedEntityDTMndr);
                            }
                            if (!string.IsNullOrEmpty(linItem.Quantity.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.QuantityDTBlnk);
                            }
                            if (!string.IsNullOrEmpty(linItem.PoNbr))
                            {
                                errorList.Add(UdaanLgiErrorDetails.PONobrBlnk);
                            }
                            if (!string.IsNullOrEmpty(linItem.PoLineNbr.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.POLineNumberDTBlnk);
                            }
                            if (string.IsNullOrEmpty(linItem.MaterialGroup))
                            {
                                errorList.Add(UdaanLgiErrorDetails.MaterialGroupDtBlnk);
                            }
                            if (!string.IsNullOrEmpty(linItem.UnitPrice.ToString()))
                            {
                                errorList.Add(UdaanLgiErrorDetails.UnitPriceBlnk);
                            }
                            if (string.IsNullOrEmpty(linItem.DCInd))
                            {
                                errorList.Add(UdaanLgiErrorDetails.DCIndDTMndr);
                            }
                            else
                            {
                                if (linItem.DCInd.ToLower() == "d")
                                {
                                    linItem.DCInd = "D";

                                }
                                else if (linItem.DCInd.ToLower() == "c")
                                {
                                    linItem.DCInd = "C";
                                }
                                else
                                {
                                    errorList.Add(UdaanLgiErrorDetails.DCIndDTDrC);
                                }
                            }
                            if (!string.IsNullOrEmpty(linItem.ReserverdInd1))
                            {
                                errorList.Add(UdaanLgiErrorDetails.ReservedDTBlnk);
                            }
                            if (!string.IsNullOrEmpty(linItem.ReserverdInd2))
                            {
                                errorList.Add(UdaanLgiErrorDetails.ReservedDTBlnk);
                            }

                        }
                        #endregion                       
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.InvoiceDt))
                        {
                            DateTime invoiceDate = DateTime.ParseExact(masterclass.UdaanInvoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                            DateTime junThirty = new DateTime(2017, 06, 30);
                            context.Logger.Log($"{invoiceDate} and {junThirty}");
                            int i = DateTime.Compare(invoiceDate, junThirty);
                            context.Logger.LogLine($"Data :Invoice date is  {i}");
                            if (i > 0)
                            {
                                GstValidations(masterclass, gstMasterList, posMasterList, udaanInvoice, ConfigValueMasterTable, visaVendorData, context);
                            }
                        }
                        if (!string.IsNullOrEmpty(masterclass.UdaanInvoice.AccentureGSTPartnerNm) && !string.IsNullOrEmpty(masterclass.UdaanInvoice.BusinessPlaceNm) && !string.IsNullOrEmpty(masterclass.UdaanInvoice.POSStr))
                        {
                            var listGSTMasterDetails = gstMasterList.Where(x => x.GSTIN == masterclass.UdaanInvoice.AccentureGSTPartnerNm && x.BusinessPlace == masterclass.UdaanInvoice.BusinessPlaceNm && x.Region == masterclass.UdaanInvoice.POSStr);
                            if (listGSTMasterDetails != null && listGSTMasterDetails.Count() > 0)
                            {
                                foreach (var gstDetail in listGSTMasterDetails)
                                {
                                    udaanInvoice.GSTID = gstDetail.GSTID;
                                    udaanInvoice.BusinessPlaceId = gstDetail.GSTID;
                                }
                            }
                            else
                            {
                                udaanInvoice.IsGSTError = "Y";
                                udaanInvoice.IsError = "Y";
                                Console.WriteLine($"GST error occured for AccentureGSTPartnerNm, BusinessPlaceNm and POSStr validation");
                            }

                        }
                        else
                        {
                            udaanInvoice.IsGSTError = "Y";
                            udaanInvoice.IsError = "Y";
                            Console.WriteLine($"GST error occured for AccentureGSTPartnerNm, BusinessPlaceNm and POSStr validation");
                        }

                        #endregion

                        context.Logger.Log($"Data :Udaan Line item count {udaanInvoice.InvoiceLineItems.Count}");
                        context.Logger.Log($"{JsonConvert.SerializeObject(udaanInvoice.InvoiceLineItems)}");
                        udaanInvoice.CreatedBy = visaVendorData.VendorUserId;
                        udaanInvoice.ModifiedBy = visaVendorData.VendorUserId;
                        udaanInvoice.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                        udaanInvoice.InvoiceSubmittedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                        udaanInvoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                        udaanInvoice.SearchCreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                        udaanInvoice.SearchInvoiceSubmittedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                        udaanInvoice.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");

                        Console.WriteLine($"visa object{JsonConvert.SerializeObject(udaanInvoice)}");

                        Console.WriteLine($"file name {attachedFileName}");

                        #region inserting data to db                    
                        if (!string.IsNullOrEmpty(attachedFileName))
                        {
                            udaanInvoice.AttachedFile = renamedAttcahedFile;

                            #region error List
                            if (errorList.Count > 0)
                            {
                                Console.WriteLine($"error list {JsonConvert.SerializeObject(errorList)}");

                                udaanInvoice.IsError = "Y";

                                foreach (var error in errorList)
                                {
                                    VendorInvoiceErrorDetails vendorInvoiceErrorDetails = new VendorInvoiceErrorDetails();

                                    //vendorInvoiceErrorDetails.InvoiceId = udaanInvoice.InvoiceId;

                                    vendorInvoiceErrorDetails.VendorInvoiceNbr = udaanInvoice.VendorCd + "-" + udaanInvoice.VendorInvoiceNumber;
                                    //vendorInvoiceErrorDetails.ErrorId = maxErrorId + 1;
                                    vendorInvoiceErrorDetails.IsValidError = "True";
                                    vendorInvoiceErrorDetails.ErrorDetails = error;
                                    //vendorInvoiceErrorDetails.VendorModuleCd = CommonConstants.UdaanTeam;

                                    vendorInvoiceErrorDetails.CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff");
                                    //vendorInvoiceErrorDetails.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");


                                    context.Logger.Log($"Process :Before inserting error into error table");
                                    await db.InsertAsync<VendorInvoiceErrorDetails>(vendorInvoiceErrorDetails, visaInvoiceErrorDetailsTable, context);
                                }
                            }
                            #endregion

                            context.Logger.Log($"Process :Before inserting udaanInvoice details");
                            context.Logger.Log($"Data :Invoice Id {udaanInvoice.InvoiceId}");
                            InvoiceHistory invoiceHistory = new InvoiceHistory();
                            invoiceHistory.CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                            invoiceHistory.SearchCreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                            invoiceHistory.AttachedFile = udaanInvoice.AttachedFile;
                            invoiceHistory.InvoiceStatusCd = "New Submission";
                            udaanInvoice.InvoiceHistoryLogs.Add(invoiceHistory);

                            InvoiceHistoryLogs invoiceHistoryLogs = new InvoiceHistoryLogs();
                            invoiceHistoryLogs.StatusDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                            invoiceHistoryLogs.SearchStatusDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                            invoiceHistoryLogs.ModifiedBy = visaVendorData.VendorUserId;
                            invoiceHistory.CreateUserId = visaVendorData.VendorUserId;

                            if (!string.IsNullOrEmpty(invoiceHistoryLogs.StatusDt))
                            {
                                DateTime datetime;
                                if (DateTime.TryParseExact(invoiceHistoryLogs.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                {
                                    invoiceHistoryLogs.SearchStatusDt = DateTime.ParseExact(invoiceHistoryLogs.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                }
                            }
                            invoiceHistoryLogs.VendorCd = udaanInvoice.VendorCd;
                            invoiceHistoryLogs.StatusCd = "New Submission";
                            invoiceHistoryLogs.SourceId = udaanInvoice.VendorRegisteredCd +'-' + udaanInvoice.VendorInvoiceNumber;  
                            udaanInvoice.SkuId = Guid.NewGuid().ToString();
                            await db.InsertAsync<UdaanInvoice>(udaanInvoice, VisaInvoiceTable, context);
                            await db.InsertAsync<InvoiceHistoryLogs>(invoiceHistoryLogs, VisaVendorHistoryLogsTable, context);
                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                           masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath,
                           CommonConstants.Private_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/" + CommonConstants.Invoice,
                           attachedFileName, renamedAttcahedFile, context);
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, attachedFileName, context);
                            //}                                                                                 
                        }
                        #endregion
                        context.Logger.Log($"Data :Is this last child lambda instance {masterclass.IsLastUdaanChildLambdaInvoking.ToString()}");
                        #region last udaan lambda instance
                        if (masterclass.IsLastUdaanChildLambdaInvoking)
                        {
                            context.Logger.Log($"CSV file name{masterclass.UdaanLgiCSVName}");
                            if (invoiceBatch.InValidFileList != null && invoiceBatch.InValidFileList.Count > 0)
                            {
                                foreach (var invalidFile in invoiceBatch.InValidFileList)
                                {
                                    string renamedInvalidFile = RenameFile(invalidFile);
                                    if (!string.IsNullOrEmpty(renamedInvalidFile))
                                    {
                                        await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                       masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath,
                                       CommonConstants.Private_Folder + "/" + CommonConstants.UdaanVendor_FilePath + "/" + CommonConstants.Invalidfiles,
                                       invalidFile, renamedInvalidFile, context);
                                        await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.UdaanVendor_FilePath, invalidFile, context);
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
                catch (Exception e)
                {
                    context.Logger.Log($"{e.Message}");
                    context.Logger.Log($"{e.InnerException}");
                    context.Logger.Log($"{e.StackTrace}");
                }
            }
        }
        private async void GstValidations(MasterClass masterClass, List<GSTMaster> gstMaster, List<POSMaster> posMaster, UdaanInvoice udaanInvoice,string ConfigValueMasterTable, VendorMaster visavendordata, ILambdaContext context)
        {
            context.Logger.LogLine($"Inside GST validation function");
            string plantType = string.Empty;
            // accenture gst number is a mandatory field
            if (!string.IsNullOrEmpty(masterClass.UdaanInvoice.AccentureGSTPartnerNm))
            {
                string accentureGSTEnetered = masterClass.UdaanInvoice.AccentureGSTPartnerNm;
                string vendorGST = masterClass.UdaanInvoice.VendorGSTNumber;
                string actualACcentureGSTNUmber = string.Empty;
                if (!string.IsNullOrEmpty(accentureGSTEnetered))
                {
                    var gstData = gstMaster.Where(r => r.GSTIN == accentureGSTEnetered);
                    if (gstData != null && gstData.Count() > 0)
                    {
                        foreach (var gst in gstData)
                        {
                            actualACcentureGSTNUmber = gst.GSTIN;
                            plantType = gst.Type;
                        }
                    }
                    else
                    {
                        udaanInvoice.IsGSTError = "Y";
                        udaanInvoice.IsError = "Y";
                        Console.WriteLine($"GST error occured for accentureGSTEnetered while fetching gst master data");
                    }
                }
            }
            else
            {
                udaanInvoice.IsGSTError = "Y";
                udaanInvoice.IsError = "Y";
                Console.WriteLine($"GST error occured for accentureGSTEnetered validation");
            }
            //If Vendor GST number is blank then tax type should be NIL, EXEMPT,REVERSE CHARGE
            if (string.IsNullOrEmpty(masterClass.UdaanInvoice.VendorGSTNumber))
            {
                if (!string.IsNullOrEmpty(masterClass.UdaanInvoice.TaxType))
                {
                    string taxType = masterClass.UdaanInvoice.TaxType.ToLower();
                    Console.WriteLine($"tax type {taxType}");
                    if (!(taxType == "zero" || taxType == "exempt" || taxType == "reverse charge"))
                    {
                        udaanInvoice.IsGSTError = "Y";
                        udaanInvoice.IsError = "Y";
                        Console.WriteLine($"GST error occured for If Vendor GST number is blank then tax type should be NIL, EXEMPT,REVERSE CHARGE validation");
                    }
                }
                else
                {
                    udaanInvoice.IsGSTError = "Y";
                    udaanInvoice.IsError = "Y";
                    Console.WriteLine($"GST error occured for If Vendor GST number is blank then tax type should be NIL, EXEMPT,REVERSE CHARGE validation");
                }
            }

            if (!string.IsNullOrEmpty(masterClass.UdaanInvoice.AccentureGSTPartnerNm) && !string.IsNullOrEmpty(masterClass.UdaanInvoice.VendorGSTNumber))
            {
                string firstTwoLetterAccentureGST = masterClass.UdaanInvoice.AccentureGSTPartnerNm.Substring(0, 2).ToLowerInvariant();
                string firstTwoLetterVendorGSt = masterClass.UdaanInvoice.VendorGSTNumber.Substring(0, 2).ToLowerInvariant();
                Console.WriteLine($"firstTwoLetterAccentureGST{firstTwoLetterAccentureGST}");
                Console.WriteLine($"firstTwoLetterVendorGSt{firstTwoLetterVendorGSt}");

                if (!string.IsNullOrEmpty(masterClass.UdaanInvoice.TaxType))
                {
                    //If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.";
                    //string taxType = masterClass.UdaanInvoice.TaxType.ToLower();
                    //If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.
                    string taxType = masterClass.UdaanInvoice.TaxType.ToLower();
                    if (taxType == "igst")
                    {   //if taxtype is igst then POS must not be blank hard stop 
                        if (string.IsNullOrEmpty(masterClass.UdaanInvoice.POSStr))
                        {
                            udaanInvoice.IsGSTError = "Y";
                            udaanInvoice.IsError = "Y";
                            Console.WriteLine($"GST error occured for if taxtype is igst then POS must not be blank hard stop  validation");
                        }
                    }
                    if (firstTwoLetterAccentureGST == firstTwoLetterVendorGSt)
                    {
                        if (!string.IsNullOrEmpty(plantType))
                        {
                            if (plantType.ToLower() == "sez")
                            {
                                if (!(taxType == "igst" || taxType == "zero" || taxType == "exempt"))
                                {
                                    udaanInvoice.IsGSTError = "Y";
                                    udaanInvoice.IsError = "Y";
                                    Console.WriteLine($"GST error occured for If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT");
                                }
                            }
                            else if (taxType.ToLowerInvariant() != "cgst+sgst")
                            {
                                udaanInvoice.IsGSTError = "Y";
                                udaanInvoice.IsError = "Y";
                                Console.WriteLine($"If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT");
                            }
                        }
                       
                    }
                }
            }
            context.Logger.LogLine($"Reason for Delay Submission validation ");
            var ISTdate = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
            var formattedsystemdate = Convert.ToDateTime(ISTdate);
            var invoicedate = masterClass.UdaanInvoice.InvoiceDt;
            var formattedinvoicedate = Convert.ToDateTime(invoicedate);
            var diff = (formattedsystemdate - formattedinvoicedate).Days;
            string DelayedReasonConfigKey = string.Empty;
            if (visavendordata.FreeText3 != "Foreign" || visavendordata.FreeText3 != "FOREIGN" || visavendordata.FreeText3 != "foreign" )
            DelayedReasonConfigKey = "Visa-LocalDelayReasonDays";
            else
            DelayedReasonConfigKey = "Visa-ForeignDelayReasonDays";
            string DelayedReasonConfigValue = string.Empty;
            string[] array = DelayedReasonConfigKey.Split('-');
            string configKey = array[1];
            string moduleNm = array[0];
            ScanFilter scanFilterCMaster = new ScanFilter();
            scanFilterCMaster.AddCondition("ConfigKey", ScanOperator.Equal, configKey);
            ScanOperationConfig scanOperationConfigValueTable = new ScanOperationConfig()
            {
                Filter = scanFilterCMaster
            };
            var ConfigMasterData = await ScanAndFindTheInvoice<ConfigValueEntities>(new ConfigValueEntities(), ConfigValueMasterTable, scanOperationConfigValueTable);
            var configData = ConfigMasterData.FirstOrDefault(x => x.ModuleNm == moduleNm);
            var DelayedReasonDays = configData.ConfigValue;
            context.Logger.LogLine($"Reason for Delay Submission date difference {diff}");
            context.Logger.LogLine($"Reason for Delay Submission {(masterClass.UdaanInvoice.ReasonforDelaySubmission)}");
            if (diff > Int32.Parse(DelayedReasonDays))
            {
                udaanInvoice.IsGSTError = "Y";
                udaanInvoice.IsError = "Y";
            }
            
            context.Logger.LogLine($"Reason for Delay Submission validation condition is executed ");
        }

        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }

        private async Task<bool> IsDuplicateInvoice(IDigiDynamoDb db, string tableName, string invoiceNumber, string vendorCode, ILambdaContext context)
        {
            ScanFilter filter = new ScanFilter();
            filter.AddCondition("VendorRegisteredCd", ScanOperator.Equal, vendorCode);
            filter.AddCondition("VendorInvoiceNumber", ScanOperator.Equal, invoiceNumber);
            var scanResult = await db.ScanAsync<UdaanInvoice>(filter, tableName, context);
            if (scanResult != null)
            {
                if (scanResult.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }
        private async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            Search search = table.Scan(scanOperationConfig);
            List<T> resultList = new List<T>();
            int count = 0;
            do
            {
                count = count + 1;
                List<Document> docList = await search.GetNextSetAsync();
                foreach (var document in docList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            }
            while (!search.IsDone);
            Console.WriteLine($"Data :Total number of iteration  :{count}");
            Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
            return resultList;
        }

      


    }
}
