﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{    
    public class ConfigValueEntities
    {
        public ConfigValueEntities()
        {

        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Entity Framework proxies requrie it.")]
        public ConfigValueEntities(int id)
        {
            Id = id;
        }
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        public string ConfigKey { get; set; }
        public string ModuleNm { get; set; }
        public string ConfigValue { get; set; }
        public string Description { get; set; }

    }
}