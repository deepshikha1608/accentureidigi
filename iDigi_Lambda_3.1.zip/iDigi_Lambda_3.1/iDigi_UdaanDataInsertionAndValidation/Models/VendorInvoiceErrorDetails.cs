﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    //public class VendorInvoiceErrorDetails
    //{
    //    public VendorInvoiceErrorDetails()
    //    {

    //    }

    //    public int ErrorId { get; set; }
    //    public string VendorModuleCd { get; set; }
    //    public string VendorInvoiceNbr { get; set; }
    //    public string ErrorDetails { get; set; }
    //    public string IsValidError { get; set; }
    //    public string CreatedDttm { get; set; }
    //    public string ModifiedDttm { get; set; }

    //    public int InvoiceId { get; set; }
    //}


    public class VendorInvoiceErrorDetails
    {
        public string VendorInvoiceNbr { get; set; }
        public string CreateDttm { get; set; }  //yyyy/MM/dd HH:mm:ss.fff
        public string ErrorDetails { get; set; }
        public string IsValidError { get; set; }

    }
}
