﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public class CommonConstants
    {
        public const string AirId = "7433";
        public const string UdaanVendorCode = "100252385";
        public const string FCMVendorCode = "100407668";

        public const string LambdaLogDetailsTable = "LambdaLogDetails";
        public const string FileColsDbColsMappingTable = "FileColsDBColsMapping";
        public const string PoTransactionTable = "POTransaction";
        public const string VendorMasterTable = "VendorMaster";
        public const string ApprovedExceptionInvoicesTable = "ApprovedExceptionInvoices";
        public const string InvoiceBatchTable = "InvoiceBatch";
        public const string UdaanInvoiceTable = "UdaanInvoiceDetails";

        public const string VisaInvoiceTable=  "VisaInvoiceDetails";
        public const string UdaanInvoiceDumpTable = "UdaanInvoiceDump";
        public const string GSTMasterTable = "GSTMaster";
        public const string POSMasterTable = "POSMaster";

        public const string VendorInvoiceErrorDetailsTable = "VendorInvoiceErrorDetails";

        public const string VisaVendorErrorDetailsTable = "VisaInvoiceErrorDetails";
        public const string VisaVendorHistoryLogsTable = "VisaInvoiceHistoryLogs";
        public const string Table_ConfigValueMaster = "ConfigValueMaster";

        public const string PO_FileFolder = "PO";
        public const string VendorMaster_FileFolder = "Vendor";
        public const string ApprovedException_FileFolder = "approvedexception";

        public const string Procurement_POTrasaction_FilePath = "private/procurement/PO";
        public const string Procurement_VendorMaster_FilePath = "private/procurement/Vendor";
        public const string Procurement_ApprovedException_FilePath = "private/procurement/approvedexception";

        public const string UdaanLGICSVFilePath = "lgi";
        public const string Invoice = "invoice";
        public const string Invalidfiles = "invalidfiles";

        public const string Public_Folder = "public";
        public const string Private_Folder = "private";
        public const string UdaanVendor_FilePath = "udaan";

        public const string POTrans_FileModuleCd = "POTRANS";
        public const string POTrans_CSVFile_HeaderColType = "HR";

        public const string HRHeaderType = "HR";
        public const string HDHeaderType = "HD";
        public const string DTHeaderType = "DT";

        public const string VendorMaster_FileModuleCd = "VNDRMAS";
        public const string VendorMaster_CSVFile_HeaderColType = "HR";

        public const string ApprovedException_FileModuleCd = "APVDEXPN";
        public const string ApprovedException_CSVFile_HeaderColType = "HR";

        public const string POtransactionMasterDataInserterLambdaForStageAndDev = "7433_iDIgi_RTPValidator";
        public const string POtransactionMasterDataInserterLambda = "7433_iDIgi_CSVDataInserter";

        public const string ProcurementTeam = "Procurement";
        public const string UdaanTeam = "UDNAG";

        public const string IsActiveTRUE = "TRUE";


        public const string Access_Key = "AccessKey";
        public const string Secret_Key = "SecretKey";

        public const string S3_Bucket_Name = "BucketName";
        public const string Vendor_Public_S3Folder = "S3PublicFolder";
        public const string Vendor_Private_S3Folder = "S3PrivateFolder";

        public const string Table_UdaanInvoiceDetails = "UdaanInvoiceDetails";

        //Table name added started
        public const string TableNameInitial = "TableNameInitial";

        public const string Udaan_CreditNote_PDF_Path = "/creditnoteinvoice";
        public const string Udaan_S3_Path = "/udaan";
        public const string Generic_S3_Path = "/generic";
        public const string IQN_S3_Path = "/iqn";
        /// <summary>
        /// S3 Bucket SubFolders
        /// </summary>

        public const string Invoice_PDF_Path = "/invoice";
        public const string Visa_PDF_Path = "/visa";
        public const string Support_PDF_Path = "/supportings";

        public const string S3_RejectedDumpFolder_Path = "/rejectedinvoices";
        /// <summary>
        /// Udaan PDF Sub File Name
        /// </summary>
        public const string Udaan_Invoice_SubFileName = "INV";
        public const string Udaan_Visa_SubFileName = "VIS";
        public const string Udaan_Support_SubFileName = "SUP";


        //CWT Table Details
        public const string Table_vendoreInvoiceErrorDetails = "VendorInvoiceErrorDetails";

        //Error Messages 
        public const string Invalid_Date = "Invoice Date is not matching.";
        public const string Not_DigitallySigned = "Invoice PDF is not Digitally Signed.";
        public const string Invalid_GrossAmt = "Gross Amount is not matching.";
        public const string Invalid_AccentureGSTID = "Accenture GST Number is not matching.";
        public const string Invalid_VendorGSTID = "Vendor GST Number is not matching.";
        public const string Invalid_LineAmount = "Line Amount is not matching.";
        public const string Invalid_BusinessPlace = "Business Place is not matching.";
        public const string Invalid_WBSID = "Charged Entity is not matching.";
        public const string PDF_Missing = "Invoice PDF does not exist in S3";
        public const string Invalid_VendorInvoiceNbr = "Vendor Invoice Number is not matching";


        //module code
        public const string Udaan_ModuleCd = "UDNAG";
        public const string LogDirectory = "LogDirectory";

        public const string Invoice_Rejected = "RTP Rejected";
        public const string RejectedBy_System = "Rejected by System";
        public const string Rejected_Remarks = "Rejected by system as invoice is not digitally signed.";
        public const string Rejected_PDFMissing = "Rejected by system as invoice Pdf does not exist";
        public const string Rejected_InvoiceNbrMismatch = "Rejected by system as Invoice Number is not matching";

        public const string Date_Mismatch = "Invoice Date does not match with current pdf format";
        public const string GrossAmt_Mismatch = "Gross Amount does not match with current pdf format";
        public const string AccentureGSTID_Mismatch = "Accenture GST ID is does not match with current pdf format";
        public const string HSNSAC_Mismatch = "HSN SAC does not match with current pdf format";
        public const string VisaFee_Mismatch = "Visa Fee(lineAmount) does not match with current pdf format";
        public const string BusinessPlace_Mismatch = "Business Place does not match with current pdf format";
        public const string WBSID_Mismatch = "WBS ID does not match with current pdf format";
        public const string VendorGSTID_Mismatch = "Vendor GST Number does not match with current pdf format";
        public const string VendorInvoiceNbr_Mismatch = "Vendor Invoice Number does not match with current pdf format";
    }
}
