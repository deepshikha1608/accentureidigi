﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public class InvoiceHistory
    {
        public InvoiceHistory()
        {

        }
        public int Id { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string CreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string DFMURN { get; set; }
        public string AttachedFile { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string SearchInvoiceReceiptDt { get; set; } //yyyy/MM/dd
        public string SearchCreateDttm { get; set; } ////yyyy/MM/dd HH:mm:ss.fff
    }

    public class InvoiceHistoryLogs
    {
        public InvoiceHistoryLogs()
        { }
        
        public int Id { get; set; }
        public string SourceId { get; set; }
        public string ModifiedBy { get; set; }
        public string StatusCd { get; set; }
        public string StatusDt { get; set; } //"mm/dd/yyyy HH:mm"
        public string VendorCd { get; set; }
        public string InvNo { get; set; }
        public string SearchStatusDt { get; set; } //"yyyy/MM/dd HH:mm"

    }
}
