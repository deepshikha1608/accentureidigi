﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public class POSMaster
    {
        public int Id { get; set; }
        public int POSID { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string IsActive { get; set; }

        public string State { get; set; }
        public string StateCode { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDttm { get; set; }
    }
}
