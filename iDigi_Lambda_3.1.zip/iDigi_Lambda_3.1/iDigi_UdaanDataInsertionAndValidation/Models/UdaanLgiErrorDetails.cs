﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public static class UdaanLgiErrorDetails
    {
        public const string IsValidErrorParameter = "True";
        public const string Udaan9DigitTpcode = "100252385";
        public const string Udaan10DigitTpcode = "0100252385";

        public const string FCM9DigitTPcode= "100407668";
        public const string FCM10DigitTpcode = "0100407668";


        public const string InvoicedateMndr = "Invoice date is not mentioned in the LGI file.";

        //8
        public const string InvoiceAmtMndr = "Invoice amount is not mentioned in the LGI file.";
        //12
        public const string ServiceTaxMndr = "Service tax is not mentioned in the LGI file.";
        //15
        public const string RowTypeMndr = "Row type is not mentioned in LGI file.";
        //16
        public const string TPCodeEqUdaan = "TP code is not equal to 100252385(UDAAN's vendor ID code)";
        //18
        public const string DCIndicatorMndr = "D/C indicator field has blank value.";
        //19
        public const string DCIndicatorDrC = "D/C indicator contains othere than D or C";
        //21
        public const string VendorInvoiceNumberLmt = "The vendor Invoice no contains more than 16 digits";
        //22
        public const string InvoiceDateFrmt = "The invoice date format is not in DD/MM/YYYY format";
        //23
        public const string TaxAmtMndr = "The Tax amount field has blank value.";
        //24
        public const string TaxAmtDecml = "The tax amount doesnot contain 2 digits after decimals";

        //25 No comma is tax amount
        public const string TaxAmtNoCm = "No comma is tax amount";
        //26
        public const string TaxAmtSum = "Tax amount in header is not equal to sum of all tax amounts for Rowtype DT";
        //27
        public const string FreightAmtBlnk = "Freight amount: should be left as blank. Even 0 should not be entered.";
        //28
        public const string GrossAmtMndr = "The gross amount field has blank value";
        //29
        public const string GrossAmtDecml = "The gross amount doesnot contain 2 digits after decimals";
        //31No comma is gross amount

        //32 Gross amount= Sum of all Line amount + tax amount in for DT row types

        public const string GrossAmtEqToSmofLineTaxAmt = "Gross amount is not equal to sum of line amount and tax amount in dt rows";
        //33
        public const string CurrencyMndr = "Currency field has blank value.";
        public const string CurrencyEqToInr = "Currency field should be INR always.";
        //34
        public const string RequestorNmMndr = "Requestor name field has blank value.";
        //35
        public const string RequestorNmValid = "The tool should validate that the Requester name is mentioned as per the country. Each requester is assigned a group of countries.";
        //36 a
        public const string InvoiceRefeBlnk = "Invoice reference field should be blank.";

        //36 c
        public const string PaymentRefBlnk = "Payment reference field should be blank.";
        //36 d
        public const string AlternativePayeeBlnk = "Alternative Payee field should be blank. ";
        //36 e
        public const string PORRefBlnk = "POR reference number field should be blank. ";
        //38
        public const string TaxParameter2DTMndr = "Tax parameter 2 should not be blank";
        //39
        public const string TaxParameter2DTDecml = "The tax parameter 2 should have 2 digits after decimals";
        //40
        public const string TaxParameter2DTNoCm = "No comma is tax parameter 2";
        //41
        public const string TaxParameter1DTMndr = "Tax parameter 1 should not be blank";
        //42
        public const string TaxAmtDTMndr = "The Tax amount field should not be blank.";
        //43
        public const string TaxAmtDTDecml = "The tax amount should have 2 digits after decimals";
        //44
        public const string TaxAmtDTNoCm = "No comma is tax amount";
        //45
        public const string LineItemDTMndr = "The line item should not be blank.";
        //46
        public const string LineItemDtDecml = "The line amount should have 2 digits after decimals";
        //48
        public const string LineItemDtNoCm = "No comma is line amount";
        //49
        public const string ChargedEntityDTMndr = "WBSE/Charged Entity should not be blank.";
        //50
        public const string QuantityDTBlnk = "Quantity should be blank. ";
        //51
        public const string PONobrBlnk = "PO Number should be blank. PO would be blank as going ahead it would be Non-PO";
        //52
        public const string POLineNumberDTBlnk = "PO line number should be blank.";
        //53
        public const string MaterialGroupDtBlnk = "Material group should not be blank.";
        //54
        public const string UnitPriceBlnk = "Unit price should be blank";
        //55
        public const string DCIndDTDrC = "D/C indicator can be either D or C";
        public const string DCIndDTMndr = "D/C indicator should not be blank.";
        //57
        public const string ReservedDTBlnk = "Reserved should be blank.";

        //---------------ending DT validation------------//

        //--------------extra HD colmns--------------//
        //58
        public const string IndexingDfm = "Indexing field should have the DFM URN number. It will be updated when the pdf get uploaded in DFM. UDAAN cannot populate this field.";
        //59
        public const string ReservedHDBlnk = "Reserved should be blank.";
        //60
        public const string InvoiceRecieptDateHD = "Invoice receipt date should be the date of upload into DFM.";
        //61
        public const string BusinessPlace = "Business place should correspond to the address of the employee as mentioned in the Etravel request";
        //62
        public const string ReferenceKey1Dfm = "Reference key 1 should be DFM URN.";

        //63
        public const string ReferenceKey2MMM = "Reference key 2 should be NL#_<<MMMYY of upload>>";
        //64
        public const string ReferenceKey3BP = "Reference key 3 should be <<Business Place>>_<<Description>>";

        public const string ReferenceKey3SplChar = "No special characters in Reference Key 3. &,(,), etc should be checked. Alt+0160 is a blank special charater, which should be removed.";
        public const string AssignmentMndr = "Assignment field should not be blank.";
        public const string AssignmentDfm = "Assignment field should be DFM URN.";
        //68
        public const string BaseAmount1Decml = "Base amount 1: either 0.00 or amount with 2 digits after decimal place.";
        //69
        public const string BaseAmount1AmtMaterialGrp = "Base Amount 1 = line amount for Material group 44";
        //70
        public const string BaseAmount2zero = "Base amount 2 = 0.00";
        //71
        public const string BaseAmount3Zero = "Base amount 3 = 0.00";
        //72
        public const string BaseAmount4Zero = "Base amount 4 = 0.00";
    }
}
