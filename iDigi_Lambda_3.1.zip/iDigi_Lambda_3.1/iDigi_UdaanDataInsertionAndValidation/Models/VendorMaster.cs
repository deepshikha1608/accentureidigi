﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public class VendorMaster
    {
        public VendorMaster()
        {

        }
       
        public VendorMaster(int id)
        {
            Id = id;
        }

        public int Id { get; set; }
        public string UserId { get; set; }
        public string IsActive { get; set; }
        public string VendorCd { get; set; }
        public string VendorNm { get; set; }
        public string VendorCode { get; set; }
        public string VendorCodeId { get; set; }   
        public string VendorUserId { get; set; }     
        public int VendorId { get; set; }
        public string CC { get; set; }
        public string VendorCategory { get; set; }
        public string ModifiedDttm { get; set; }       
        public string Status { get; set; }
        public string DelFlg { get; set; }       
        public string ADGObjectDetailId { get; set; }
        public int VendorGroupObjectDetailId { get; set; }      
        public string RedirectURL { get; set; }
        public string RoleObjectDetailId { get; set; }        
        public string IsAgreed { get; set; }
        public string IsExempted { get; set; }
        public string FreeText3 { get; set; }
        public int VendorClassification { get; set; }
    }
}
