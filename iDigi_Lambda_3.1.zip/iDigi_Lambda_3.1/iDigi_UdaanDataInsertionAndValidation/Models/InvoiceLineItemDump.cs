﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_UdaanDataInsertionAndValidation.Models
{
    public class InvoiceLineItemDump
    {
        public InvoiceLineItemDump()
        {
        }
        public string VendorInvoiceNumber { get; set; }
        public string TaxAmt { get; set; }
        public string DCInd { get; set; }
        public int InvoiceDTId { get; set; }
        public int InvoiceDataId { get; set; }
        public string TaxRate { get; set; }
        public string TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string RowType { get; set; }
        public string TaxType { get; set; }
        public string Description { get; set; }
        public string TaxParameter1Amt { get; set; }
        public string TaxParameter2Amt { get; set; }
        public string LineAmt { get; set; }
        public string ChargedEntity { get; set; }
        public string Quantity { get; set; }
        public string PoNbr { get; set; }
        public string PoLineNbr { get; set; }
        public string Plant { get; set; }
        public string MaterialGroup { get; set; }
        public string UnitPrice { get; set; }
        public string CompanyCd { get; set; }
        public string ReserverdInd1 { get; set; }
        public string ReserverdInd2 { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string DFMURN { get; set; }
        public string LGIGenerated { get; set; }

    }
}
