﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTDataInsertionAndValidation.Model
{
    public class CommonConstants
    {
        public const string AirId = "7433";

        public const string LambdaLogDetailsTable = "LambdaLogDetails";
        public const string FileColsDbColsMappingTable = "FileColsDBColsMapping";
        public const string PoTransactionTable = "POTransaction";
        public const string VendorMasterTable = "VendorMaster";
        public const string ApprovedExceptionInvoicesTable = "ApprovedExceptionInvoices";
        public const string InvoiceBatchTable = "InvoiceBatch";
        public const string UdaanInvoiceTable = "UdaanInvoiceDetails";
        public const string CWTInvoiceTable = "CWTInvoice";
        public const string CWTInvoiceStageTable = "CWTInvoiceNew";
        public const string InvoiceErrorDetailsTable = "ErrorDetails";

        public const string UdaanInvoiceDumpTable = "UdaanInvoiceDump";
        public const string GSTMasterTable = "GSTMaster";
        public const string POSMasterTable = "POSMaster";
        public const string VendorInvoiceErrorDetailsTable = "VendorInvoiceErrorDetails";

        public const string PO_FileFolder = "PO";
        public const string VendorMaster_FileFolder = "Vendor";
        public const string ApprovedException_FileFolder = "approvedexception";

        public const string Procurement_POTrasaction_FilePath = "private/procurement/PO";
        public const string Procurement_VendorMaster_FilePath = "private/procurement/Vendor";
        public const string Procurement_ApprovedException_FilePath = "private/procurement/approvedexception";

        public const string UdaanLGICSVFilePath = "lgi";
        public const string CWTCsvFilePath = "csv";
        public const string CWTInvoiceFilePath = "invoice";
        public const string CWTTicketFilePath = "ticket";
        public const string CWTSupportingsFilePath = "supportings";
        public const string CWTCreditNoteFilePath = "creditnote";
        public const string CWTOriginalInvoiceFilePath = "originalInvoice";
        public const string CWTInvalidFilesPath = "invalidfiles";


        public const string Public_Folder = "public";
        public const string Private_Folder = "private";
        public const string UdaanVendor_FilePath = "udaan";
        public const string CWTvendor_FilePath = "CWT";
        public const string CWTInvoice_Private_FilePath = "cwt";

        public const string POTrans_FileModuleCd = "POTRANS";
        public const string POTrans_CSVFile_HeaderColType = "HR";

        public const string HRHeaderType = "HR";
        public const string HDHeaderType = "HD";
        public const string DTHeaderType = "DT";

        public const string VendorMaster_FileModuleCd = "VNDRMAS";
        public const string VendorMaster_CSVFile_HeaderColType = "HR";

        public const string ApprovedException_FileModuleCd = "APVDEXPN";
        public const string ApprovedException_CSVFile_HeaderColType = "HR";

        public const string POtransactionMasterDataInserterLambdaForStageAndDev = "7433_iDIgi_RTPValidator";
        public const string POtransactionMasterDataInserterLambda = "7433_iDIgi_CSVDataInserter";

        public const string ProcurementTeam = "Procurement";
        public const string UdaanTeam = "UDNAG";
        public const string CWTTeam = "CWT";

        public const string IsActiveTRUE = "TRUE";
        public const string CWTProdPrivateBucketName = "7433-idigi-prod";
        public const string CWTStagePrivateBucketName = "7433";
        public const string CWTDevPrivateBucketName = "7433-idigi-dev";
    }
}
