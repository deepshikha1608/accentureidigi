﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTDataInsertionAndValidation.Model
{
    public class MasterClass
    {
        public MasterClass()
        {
           // UdaanInvoice = new UdaanInvoice();
            //UdaanInvoiceDump = new UdaanInvoiceDump();
            CWTInvoice = new CWTInvoice();
        }
        public string Vendor { get; set; }
        public string BucketName { get; set; }
        public string UdaanLgiCSVName { get; set; }
        public string InvoiceBatchDttm { get; set; }
        //public UdaanInvoice UdaanInvoice { get; set; }

       // public UdaanInvoiceDump UdaanInvoiceDump { get; set; }
        public bool IsLastUdaanChildLambdaInvoking { get; set; }
        public CWTInvoice CWTInvoice { get; set; }
        public string CwtCSVFileName { get; set; }
        public List<GSTMaster> GSTMasterList { get; set; }

        public InvoiceBatch InvoiceBatchItem { get; set; }
    }
}
