﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTDataInsertionAndValidation.Model
{
    public class VendorInvoiceErrorDetails
    {
        public VendorInvoiceErrorDetails()
        {

        }

        public int ErrorId { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorInvoiceNbr { get; set; }
        public string ErrorDetails { get; set; }
        public string IsValidError { get; set; }
    }
}
