﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTDataInsertionAndValidation.Model
{
    public class LambdaLogDetails
    {
        public string LambdaRequestId { get; set; }
        public string LambdaName { get; set; }
        public string LambdaLogGroupName { get; set; }
        public string LambdaLogStreamName { get; set; }
        public string ExceptionMsg { get; set; }
        public string InnerExceptionMsg { get; set; }
        public string StackTaceStr { get; set; }
        public string LambdaExeStartDttm { get; set; }
        public string LambdaExeEndDttm { get; set; }
        public string LambdaExeStartDttmIst { get; set; }
        public string LambdaExeEndDttmIst { get; set; }
        public string ModifiedDttm { get; set; }

    }
}
