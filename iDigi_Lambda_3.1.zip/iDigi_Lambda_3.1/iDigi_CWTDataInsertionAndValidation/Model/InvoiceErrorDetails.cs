﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTDataInsertionAndValidation.Model
{
    public class InvoiceErrorDetails
    {
        public InvoiceErrorDetails()
        {
            ErrorsList = new List<ErrorDetails>();
        }
        public string ErrorId { get; set; }
        public string VendorModuleCd { get; set; }
        public List<ErrorDetails> ErrorsList { get; set; }
        public ErrorDetails ErrorDetails { get; set; }
        public string VendorInvoiceNbr { get; set; }
        public string CreatedDttm { get; set; }
        public string InvoiceDt { get; set; }
        public string ValueInAcrualFile { get; set; }

        public string ValueInPDF { get; set; }
    }
    public class ErrorDetails
    {
        public string Error { get; set; }
        public string IsValidError { get; set; }
        public string VendorType { get; set; }
        public string ValueInAcrualFile { get; set; }

        public string ValueInPDF { get; set; }
    }
}
