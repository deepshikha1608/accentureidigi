using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using iDigi_CWTDataInsertionAndValidation.Model;
using Newtonsoft.Json;
using Amazon.DynamoDBv2.DocumentModel;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CWTDataInsertionAndValidation
{
    public class Function
    {

        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public static string DebugEnvironMent
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("DebugEnvironMent");
            }

        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                if (DebugEnvironMent.ToLowerInvariant() == "true")
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); // windows os
                }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");// amazon linux os 
                }

            }
        }
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(MasterClass masterclass, ILambdaContext context)
        {
            context.Logger.Log($"Process :Lambda invoked {masterclass.GetType().ToString()}");
            IDigiDynamoDb db = new IDigiDynamoDb();
            IDigiS3 s3 = new IDigiS3();

            string attachedInvoiceFileName = string.Empty;
            string renamedInvoiceFileName = string.Empty;
            string attchedTicketFileName = string.Empty;
            string renamedTicketFileName = string.Empty;

            string attachedCrFileName = string.Empty;
            string renamedCrFileName = string.Empty;
            string attachedOiFileName = string.Empty;
            string renamedOiFileName = string.Empty;

            List<string> supportingFiles = new List<string>();
            List<string> renamedsupportingFiles = new List<string>();

            string udaanInvoiceDumpTable = string.Empty;
            string gstMasterTable = string.Empty;
            string posMasterTable = string.Empty;
            string cwtInvoiceTable = string.Empty;
            string vendorInvoiceErrorDetailsTable = string.Empty;
            string invoiceBatchTable = string.Empty;
            string invoiceErrorDetailsTable = string.Empty;
            string cwtPrivateBucket = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                udaanInvoiceDumpTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceDumpTable;
                gstMasterTable = CommonConstants.AirId + "_" + CommonConstants.GSTMasterTable;
                posMasterTable = CommonConstants.AirId + "_" + CommonConstants.POSMasterTable;
                cwtInvoiceTable = CommonConstants.AirId + "_" + CommonConstants.CWTInvoiceTable;
                vendorInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.VendorInvoiceErrorDetailsTable;
                invoiceBatchTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceBatchTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTProdPrivateBucketName;

            }
            else
            {
                udaanInvoiceDumpTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceDumpTable;
                gstMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GSTMasterTable;
                posMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.POSMasterTable;

                vendorInvoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorInvoiceErrorDetailsTable;
                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                invoiceErrorDetailsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceErrorDetailsTable;
                cwtPrivateBucket = CommonConstants.CWTStagePrivateBucketName;

                if (CloudEnvironment.ToLowerInvariant() == "stage")
                {
                    cwtInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoiceStageTable;
                }
                else if (CloudEnvironment.ToLowerInvariant() == "dev")
                {
                    cwtInvoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoiceTable;
                    cwtPrivateBucket = CommonConstants.CWTDevPrivateBucketName;
                }
            }
            InvoiceBatch invoiceBatch = null;
            if (masterclass != null)
            {
                context.Logger.Log($"Vendor :{masterclass.Vendor}");
                context.Logger.Log($"{JsonConvert.SerializeObject(masterclass)}");
            }

            List<GSTMaster> gstMasterList = masterclass.GSTMasterList;

            CWTInvoice cwtInvoice = new CWTInvoice();

            if (masterclass != null && masterclass.CWTInvoice != null)
            {
                try
                {
                    context.Logger.Log($"Inside master class loop");
                    cwtInvoice = masterclass.CWTInvoice;
                    cwtInvoice.IsTrValidated = "N";

                    cwtInvoice.AEEAction = "Pending"; // check for Pending status
                    cwtInvoice.RTPAction = "Pending";
                    cwtInvoice.IsTRBusinessUnitUpdated = "N";
                   cwtInvoice.LGIGenerated = "N";
                    cwtInvoice.IsGSTError = "N";
                    cwtInvoice.IsBatchValidated = "N";
                    cwtInvoice.GSTID = 0;
                    cwtInvoice.BusinessPlaceId = 0;
                    cwtInvoice.CreatedBy = CommonConstants.CWTTeam;
                    cwtInvoice.ModifiedBy = CommonConstants.CWTTeam;
                    // rtp rejected resubmission snenario
                    cwtInvoice.Remarks = !string.IsNullOrEmpty(cwtInvoice.Remarks) ? cwtInvoice.Remarks : null;
                    cwtInvoice.RTPRemarks = !string.IsNullOrEmpty(cwtInvoice.RTPRemarks) ? cwtInvoice.RTPRemarks : null;

                    Console.WriteLine($"CreatedDttm{cwtInvoice.CreatedDttm}");
                    cwtInvoice.CreatedDttm = !string.IsNullOrEmpty(cwtInvoice.CreatedDttm) ? cwtInvoice.CreatedDttm : TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                    Console.WriteLine($"SearchCreatedDttm{cwtInvoice.SearchCreatedDttm}");
                    cwtInvoice.SearchCreatedDttm = !string.IsNullOrEmpty(cwtInvoice.SearchCreatedDttm) ? cwtInvoice.SearchCreatedDttm : TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff"); ;

                    Console.WriteLine($"SearchCreatedDttm{cwtInvoice.InvoiceSubmittedDt}");
                    Console.WriteLine($"SearchCreatedDttm{cwtInvoice.SearchInvoiceSubmittedDt}");
                    cwtInvoice.InvoiceSubmittedDt = !string.IsNullOrEmpty(cwtInvoice.InvoiceSubmittedDt) ? cwtInvoice.InvoiceSubmittedDt : TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    cwtInvoice.SearchInvoiceSubmittedDt = !string.IsNullOrEmpty(cwtInvoice.SearchInvoiceSubmittedDt) ? cwtInvoice.SearchInvoiceSubmittedDt : TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff"); ;
                    

                    cwtInvoice.SearchResubmissionDttm = !string.IsNullOrEmpty(cwtInvoice.SearchResubmissionDttm) ? cwtInvoice.SearchResubmissionDttm : null;

                    Console.WriteLine($"cwt resubmission date{cwtInvoice.SearchResubmissionDttm}");

                    //cwtInvoice.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                    //cwtInvoice.SearchCreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff");
                    //cwtInvoice.InvoiceSubmittedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                    // cwtInvoice.SearchInvoiceSubmittedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff");

                    cwtInvoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                    cwtInvoice.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm:ss.fff");

 
                    invoiceBatch = masterclass.InvoiceBatchItem;


                    InvoiceErrorDetails invoiceErrorDetails = new InvoiceErrorDetails();

                    // List<ErrorDetails> errorList = new List<ErrorDetails>(); 

                    if (string.IsNullOrEmpty(cwtInvoice.AccentureGSTNo) || string.IsNullOrEmpty(cwtInvoice.TaxType) || string.IsNullOrEmpty(cwtInvoice.TaxRate) || string.IsNullOrEmpty(cwtInvoice.BIZPlace))
                    {
                        Console.WriteLine($"gst error 1");
                        cwtInvoice.IsGSTError = "Y";
                        cwtInvoice.AEEAction = "Rejected by System";

                        ErrorDetails errorDetails = new ErrorDetails();
                        errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                        errorDetails.IsValidError = "true";
                        errorDetails.VendorType = "AEE";

                        invoiceErrorDetails.ErrorsList.Add(errorDetails);

                    }

                    string plantType = string.Empty;
                    if (!string.IsNullOrEmpty(cwtInvoice.AccentureGSTNo))
                    {
                        string accentureGSTEnetered = cwtInvoice.AccentureGSTNo;
                        string actualACcentureGSTNUmber = string.Empty;
                        if (!string.IsNullOrEmpty(accentureGSTEnetered))
                        {
                            var gstData = gstMasterList.Where(r => r.GSTIN == accentureGSTEnetered);
                            if (gstData != null && gstData.Count() > 0)
                            {
                                foreach (var data in gstData)
                                {
                                    actualACcentureGSTNUmber = data.GSTIN;
                                    plantType = data.Type;
                                }
                            }
                            else
                            {
                                Console.WriteLine($"gst error 2");
                                cwtInvoice.IsGSTError = "Y";
                                cwtInvoice.AEEAction = "Rejected by System";

                                ErrorDetails errorDetails = new ErrorDetails();
                                errorDetails.Error = "Business Place and Accenture GST number are not matching as per the Accenture master data.";
                                errorDetails.IsValidError = "true";
                                errorDetails.VendorType = "AEE";

                                invoiceErrorDetails.ErrorsList.Add(errorDetails);

                            }
                        }
                    }
                    context.Logger.Log($"Plant type{plantType}");
                    //If Vendor GST number is blank then tax type should be ZERO, EXEMPT,REVERSE CHARGE --Hard stop 
                    if (string.IsNullOrEmpty(cwtInvoice.VendorGSTNumber))
                    {
                        if (!string.IsNullOrEmpty(cwtInvoice.TaxType))
                        {
                            string taxType = cwtInvoice.TaxType.ToLower();
                            if (taxType != "zero" || taxType != "exempt" || taxType != "reverse charge")
                            {
                                Console.WriteLine($"gst error 3");
                                cwtInvoice.IsGSTError = "Y";
                                cwtInvoice.AEEAction = "Rejected by System";
                                ErrorDetails errorDetails = new ErrorDetails();
                                errorDetails.Error = "If Vendor GST number is blank then tax type should be NIL, EXEMPT,REVERSE CHARGE";
                                errorDetails.IsValidError = "true";
                                errorDetails.VendorType = "AEE";

                                invoiceErrorDetails.ErrorsList.Add(errorDetails);
                            }
                        }
                        else
                        {
                            Console.WriteLine($"gst error 4");
                            cwtInvoice.IsGSTError = "Y";
                            cwtInvoice.AEEAction = "Rejected by System";

                            ErrorDetails errorDetails = new ErrorDetails();
                            //errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                            errorDetails.Error = "If Vendor GST number is blank then tax type should be NIL, EXEMPT,REVERSE CHARGE";
                            errorDetails.IsValidError = "true";
                            errorDetails.VendorType = "AEE";

                            invoiceErrorDetails.ErrorsList.Add(errorDetails);

                        }
                    }


                    if (cwtInvoice.AccentureGSTNo != null && cwtInvoice.BIZPlace != null)
                    {
                        var gstData = gstMasterList.Where(X => X.BusinessPlace == cwtInvoice.BIZPlace && X.GSTIN == cwtInvoice.AccentureGSTNo);
                        if (gstData != null && gstData.Count() > 0)
                        {
                            foreach (var gst in gstData)
                            {
                                cwtInvoice.GSTID = gst.GSTID;
                                cwtInvoice.BusinessPlaceId = gst.GSTID;
                            }
                        }
                        else
                        {
                            Console.WriteLine($"gst error 5");
                            cwtInvoice.IsGSTError = "Y";
                            cwtInvoice.AEEAction = "Rejected by System";

                            ErrorDetails errorDetails = new ErrorDetails();
                            errorDetails.Error = "Business Place and Accenture GST number are not matching as per the Accenture master data.";
                            errorDetails.IsValidError = "true";
                            errorDetails.VendorType = "AEE";

                            invoiceErrorDetails.ErrorsList.Add(errorDetails);
                        }
                    }
                    else
                    {
                        Console.WriteLine($"gst error 6");
                        cwtInvoice.IsGSTError = "Y";
                        cwtInvoice.AEEAction = "Rejected by System";

                        ErrorDetails errorDetails = new ErrorDetails();
                        //errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                        errorDetails.Error = "Accenture GST and Business place are mandatory fields";
                        errorDetails.IsValidError = "true";
                        errorDetails.VendorType = "AEE";

                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                    }
                    if (string.IsNullOrEmpty(cwtInvoice.EmployeeNo))
                    {
                        Console.WriteLine($"gst error ");
                        cwtInvoice.IsGSTError = "Y";
                        cwtInvoice.AEEAction = "Rejected by System";

                        ErrorDetails errorDetails = new ErrorDetails();
                        errorDetails.Error = "Employee Number is blank";
                        errorDetails.IsValidError = "true";
                        errorDetails.VendorType = "AEE";

                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                    }
                    else if (cwtInvoice.EmployeeNo == "99999999")
                    {
                        Console.WriteLine($"gst error ");
                        cwtInvoice.IsGSTError = "Y";
                        cwtInvoice.AEEAction = "Rejected by System";

                        ErrorDetails errorDetails = new ErrorDetails();
                        errorDetails.Error = "Employee Number is equal to 99999999";
                        errorDetails.IsValidError = "true";
                        errorDetails.VendorType = "AEE";
                        errorDetails.ValueInAcrualFile = cwtInvoice.EmployeeNo;
                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                    }
                    if (string.IsNullOrEmpty(cwtInvoice.TAWBSeNo))
                    {
                        Console.WriteLine($"gst error ");
                        cwtInvoice.IsGSTError = "Y";
                        cwtInvoice.AEEAction = "Rejected by System";

                        ErrorDetails errorDetails = new ErrorDetails();
                        errorDetails.Error = "TA# is blank";
                        errorDetails.IsValidError = "true";
                        errorDetails.VendorType = "AEE";

                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                    }
                    if (!string.IsNullOrEmpty(cwtInvoice.AccentureGSTNo) && !string.IsNullOrEmpty(cwtInvoice.VendorGSTNumber))
                    {
                        string firstTwoLetterAccentureGST = cwtInvoice.AccentureGSTNo.Substring(0, 2).ToLowerInvariant();
                        string firstTwoLetterVendorGSt = cwtInvoice.VendorGSTNumber.Substring(0, 2).ToLowerInvariant();
                        Console.WriteLine($"firstTwoLetterAccentureGST{firstTwoLetterAccentureGST}");
                        Console.WriteLine($"firstTwoLetterVendorGSt{firstTwoLetterVendorGSt}");
                        if (!string.IsNullOrEmpty(cwtInvoice.TaxType))
                        {
                            Console.WriteLine($"cwtInvoice.TaxType {cwtInvoice.TaxType}");
                            string taxtype = cwtInvoice.TaxType.ToLowerInvariant();
                            Console.WriteLine($"taxtype {taxtype}");
                            if (firstTwoLetterAccentureGST == firstTwoLetterVendorGSt)
                            {
                                if (!string.IsNullOrEmpty(plantType))   //If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.
                                {
                                    Console.WriteLine($"plantType{plantType}");
                                    if (plantType.ToLower() == "sez")
                                    {
                                        if (taxtype.Equals("igst") || taxtype.Equals("zero") || taxtype.Equals("exempt") || taxtype.Equals("reverse charge"))
                                        {
                                            //expected
                                        }
                                        else
                                        {
                                            Console.WriteLine($"gst error 7");
                                            cwtInvoice.IsGSTError = "Y";
                                            cwtInvoice.AEEAction = "Rejected by System";

                                            ErrorDetails errorDetails = new ErrorDetails();
                                            errorDetails.Error = "If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.";
                                            errorDetails.IsValidError = "true";
                                            errorDetails.VendorType = "AEE";

                                            invoiceErrorDetails.ErrorsList.Add(errorDetails);

                                        }
                                    }                                  
                                    else if (taxtype.ToLowerInvariant() != "cgst+sgst")
                                    {
                                        Console.WriteLine($"gst error 7");
                                        cwtInvoice.IsGSTError = "Y";
                                        cwtInvoice.AEEAction = "Rejected by System";

                                        ErrorDetails errorDetails = new ErrorDetails();
                                        errorDetails.Error = "If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.";
                                        errorDetails.IsValidError = "true";
                                        errorDetails.VendorType = "AEE";

                                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                    }
                                }
                            }
                        }
                    }

                    //else if is not required as the accenture gst number null condition is handled in the above code

                    //else
                    //{
                    //    Console.WriteLine($"gst error 8");
                    //    cwtInvoice.IsGSTError = "Y";
                    //    cwtInvoice.AEEAction = "Rejected by System";

                    //    ErrorDetails errorDetails = new ErrorDetails();
                    //    //errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                    //    errorDetails.Error = "Accenture GST and Business place,Tax Rate are mandatory fields";
                    //    errorDetails.IsValidError = "true";
                    //    errorDetails.VendorType = "AEE";

                    //    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                    //}

                    #region booking
                    Console.WriteLine($"Now at booking area");
                    List<string> moreThanOneTicketFile = new List<string>();
                    if (cwtInvoice.BookingCancelInd.ToLowerInvariant() == "booking")
                    {
                        if (cwtInvoice.VendorInvoiceCRNo != null && invoiceBatch.CwtValidInvoiceTicketSupFiles != null && invoiceBatch.CwtValidInvoiceTicketSupFiles.Count > 0)
                        {
                            context.Logger.Log($"Log :Now matching invoice and ticket files");
                            int supportingFileCount = 0;
                            foreach (var fileName in invoiceBatch.CwtValidInvoiceTicketSupFiles)
                            {
                                if (fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && fileName.ToLowerInvariant().Contains("inv"))
                                {
                                    attachedInvoiceFileName = fileName;
                                    renamedInvoiceFileName = RenameFile(attachedInvoiceFileName);
                                    context.Logger.Log($"Data :found file{attachedInvoiceFileName} ranamed file {renamedInvoiceFileName}");
                                }
                                if (fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && fileName.ToLowerInvariant().Contains("sup"))
                                {
                                    string tempFile = fileName;
                                    supportingFiles.Add(fileName);
                                    string tempFile2 = RenameFile(tempFile);
                                    renamedsupportingFiles.Add(tempFile2);
                                    context.Logger.Log($"Data :found file{tempFile} ranamed file {tempFile2}");

                                    await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTSupportingsFilePath,
                                  fileName, tempFile2, context);
                                    await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, fileName, context);
                                }
                                if (fileName.ToLowerInvariant().Contains("tkt") && fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()))
                                {
                                   
                                    if (string.IsNullOrEmpty(renamedTicketFileName))
                                    {
                                        attchedTicketFileName = fileName;
                                        renamedTicketFileName = RenameFile(attchedTicketFileName); // single ticket file condition
                                        context.Logger.Log($"Data :found file{attchedTicketFileName} ranamed file {renamedTicketFileName}");
                                    }
                                    else if (!string.IsNullOrEmpty(renamedTicketFileName)) // more than 1 ticket file condition
                                    {
                                        supportingFileCount = supportingFileCount + 1;
                                        string tempFile = fileName;
                                        var ticketRenamed=tempFile.Replace("_tkt", "_SUP_" + supportingFileCount,StringComparison.InvariantCultureIgnoreCase);

                                        supportingFiles.Add(fileName);
                                        string tempFile2 = RenameFile(ticketRenamed);
                                        renamedsupportingFiles.Add(tempFile2);
                                        context.Logger.Log($"Data :found file{tempFile} ranamed file {tempFile2}");

                                        await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                      cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                      CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTSupportingsFilePath,
                                      fileName, tempFile2, context);
                                        await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, fileName, context);

                                        //moreThanOneTicketFile.Add(fileName);
                                        //ErrorDetails errorDetails = new ErrorDetails();
                                        //errorDetails.Error = $"{cwtInvoice.VendorInvoiceCRNo} Contains more than one ticket file {fileName} with it, additional ticket file is not accepted into the idigi system";
                                        //errorDetails.IsValidError = "true";
                                        //errorDetails.VendorType = "AEE";

                                        //invoiceErrorDetails.ErrorsList.Add(errorDetails);

                                    }
                                }
                               
                            }
                        }
                        if (!string.IsNullOrEmpty(renamedInvoiceFileName) && !string.IsNullOrEmpty(renamedTicketFileName))
                        {
                            cwtInvoice.InvoicePDF = renamedInvoiceFileName;
                            cwtInvoice.TicketPDF = renamedTicketFileName;
                            if (renamedsupportingFiles != null && renamedsupportingFiles.Count > 0)
                            {
                                cwtInvoice.SupportPDFFiles = renamedsupportingFiles;
                            }
                            context.Logger.Log($"Process :Before inserting cwtInvoice details");
                            context.Logger.Log($"Data :Invoice Id {cwtInvoice.CWTInvoiceId}");
                            await db.InsertAsync<CWTInvoice>(cwtInvoice, cwtInvoiceTable, context);
                            //invoice
                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvoiceFilePath,
                                  attachedInvoiceFileName, renamedInvoiceFileName, context);
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, attachedInvoiceFileName, context);
                            //ticket
                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTTicketFilePath,
                                  attchedTicketFileName, renamedTicketFileName, context);
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, attchedTicketFileName, context);

                        }
                    }
                    #endregion

                    #region cancel
                    if (cwtInvoice.BookingCancelInd.ToLowerInvariant() == "cancel")
                    {
                        if (cwtInvoice.VendorInvoiceCRNo != null && invoiceBatch.CwtValidCrOiSupFiles != null && invoiceBatch.CwtValidCrOiSupFiles.Count > 0)
                        {
                            context.Logger.Log($"Log :Now matching cr and oi files");
                            foreach (var fileName in invoiceBatch.CwtValidCrOiSupFiles)
                            {
                                if (fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && fileName.ToLowerInvariant().Contains("crn"))
                                {
                                    attachedCrFileName = fileName;
                                    renamedCrFileName = RenameFile(attachedCrFileName);
                                    context.Logger.Log($"Data :found file{attachedCrFileName} ranamed file {renamedCrFileName}");
                                }
                                if (fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && fileName.ToLowerInvariant().Contains("oi"))
                                {
                                    attachedOiFileName = fileName;
                                    renamedOiFileName = RenameFile(attachedOiFileName);
                                    context.Logger.Log($"Data :found file{attachedOiFileName} ranamed file {renamedOiFileName}");
                                }
                                if (fileName.ToLowerInvariant().Contains(cwtInvoice.VendorInvoiceCRNo.ToLowerInvariant()) && fileName.ToLowerInvariant().Contains("sup"))
                                {
                                    string tempFile = fileName;
                                    supportingFiles.Add(fileName);
                                    string tempFile2 = RenameFile(tempFile);
                                    renamedsupportingFiles.Add(tempFile2);
                                    context.Logger.Log($"Data :found file{tempFile} ranamed file {tempFile2}");

                                    await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTSupportingsFilePath,
                                  fileName, tempFile2, context);
                                    await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, fileName, context);
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(renamedCrFileName) && !string.IsNullOrEmpty(renamedOiFileName))
                        {
                            cwtInvoice.CreditNotePDF = renamedCrFileName;
                            cwtInvoice.OriginalInvoicePDF = renamedOiFileName;
                            if (renamedsupportingFiles != null && renamedsupportingFiles.Count > 0)
                            {
                                cwtInvoice.SupportPDFFiles = renamedsupportingFiles;
                            }
                            context.Logger.Log($"Process :Before inserting Invoice details");
                            context.Logger.Log($"Data :Invoice Id {cwtInvoice.CWTInvoiceId}");
                            //if (await IsDuplicateInvoice(db, cwtInvoiceTable, cwtInvoice.VendorInvoiceCRNo, context))
                            //{
                            //    context.Logger.Log($"Duplicate :- Invoice number is duplicate invoice :{cwtInvoice.VendorInvoiceCRNo}");
                            //    await MoveInvalidFies(s3, masterclass, attachedCrFileName, renamedCrFileName, attachedOiFileName, renamedOiFileName, context);
                            //}
                            //else
                            //{   
                            //default 


                            //float netPayDifference=0;                                
                            //if (!string.IsNullOrEmpty(cwtInvoice.InvoiceNo))
                            //{
                            //    var listOfInvoices =await CheckForBookingInvNumberAndNetAmtDifference(db,cwtInvoiceTable,cwtInvoice.InvoiceNo,context);
                            //    if (listOfInvoices != null && listOfInvoices.Count > 0)
                            //    {
                            //        foreach (var cwtInv in listOfInvoices)
                            //        {
                            //            if (cwtInv.BookingCancelInd.ToLower() == "booking")
                            //            {
                            //                if (!string.IsNullOrEmpty(cwtInvoice.NetPayAmt.ToString()))
                            //                {
                            //                    if (!string.IsNullOrEmpty(cwtInv.NetPayAmt.ToString())) // cancel data
                            //                    {

                            //                        netPayDifference = cwtInv.NetPayAmt + cwtInvoice.NetPayAmt;                                                         
                            //                    }                                                    
                            //                }
                            //                else
                            //                {
                            //                    if (!string.IsNullOrEmpty(cwtInv.NetPayAmt.ToString())) //bookin data
                            //                    {
                            //                        netPayDifference = cwtInv.NetPayAmt;
                            //                    }
                            //                }
                            //                cwtInvoice.NetPayDifference = netPayDifference;


                            await db.InsertAsync<CWTInvoice>(cwtInvoice, cwtInvoiceTable, context);

                            //credit note
                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTCreditNoteFilePath,
                                  attachedCrFileName, renamedCrFileName, context);
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, attachedCrFileName, context);
                            //original invoice
                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTOriginalInvoiceFilePath,
                                  attachedOiFileName, renamedOiFileName, context);
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, attachedOiFileName, context);
                            //}
                            //else
                            //{
                            //    context.Logger.Log($"Data :error- booking invoice not found for cancel invoice {cwtInvoice.VendorInvoiceCRNo}");
                            //    await MoveInvalidFies(s3,masterclass,attachedCrFileName,renamedCrFileName,attachedOiFileName,renamedOiFileName,context);

                            //}                                           
                            //}
                            //}
                            //else
                            //{
                            //    context.Logger.Log($"Data :error- booking invoice not found for cancelation invoice {cwtInvoice.VendorInvoiceCRNo}");
                            //    await MoveInvalidFies(s3, masterclass, attachedCrFileName, renamedCrFileName, attachedOiFileName, renamedOiFileName, context);
                            //}
                            // }                               
                            //}
                        }
                    }
                    #endregion

                    if (invoiceErrorDetails != null && invoiceErrorDetails.ErrorsList != null && invoiceErrorDetails.ErrorsList.Count > 0)
                    {
                        invoiceErrorDetails.ErrorId = Guid.NewGuid().ToString();
                        invoiceErrorDetails.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("M/d/yyyy HH:mm:ss tt"); // error table has different time format
                        invoiceErrorDetails.VendorInvoiceNbr = cwtInvoice.VendorInvoiceCRNo;
                        invoiceErrorDetails.VendorModuleCd = "CWTADG";
                        invoiceErrorDetails.InvoiceDt = !string.IsNullOrEmpty(cwtInvoice.SearchInvoiceDt) ? cwtInvoice.SearchInvoiceDt: null;

                        Console.WriteLine($"Process: Started inserting error details to table {invoiceErrorDetails.VendorInvoiceNbr }/{ invoiceErrorDetails.ErrorId}");
                        await db.InsertAsync<InvoiceErrorDetails>(invoiceErrorDetails, invoiceErrorDetailsTable, context);
                        Console.WriteLine($"Process: Inserted error details to table");
                    }

                    //if (moreThanOneTicketFile != null && moreThanOneTicketFile.Count > 0) //moving the additional ticket file to invalid folder
                    //{
                    //    foreach (var ticketFileName in moreThanOneTicketFile)
                    //    {
                    //        var renamedAdditionalTicketFile = RenameFile(ticketFileName);
                    //        await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                    //                  cwtPrivateBucket, CommonConstants.CWTvendor_FilePath,
                    //                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTInvoice_Private_FilePath + "/" + CommonConstants.CWTInvalidFilesPath,
                    //                  ticketFileName, renamedAdditionalTicketFile, context);
                    //        await s3.DeleteFile(masterclass.BucketName, CommonConstants.CWTvendor_FilePath, ticketFileName, context);
                    //    }
                    //}

                }
                catch (Exception e)
                {
                    context.Logger.Log($"{e.Message}");
                    context.Logger.Log($"{e.InnerException}");
                    context.Logger.Log($"{e.StackTrace}");
                }

            }
        }

        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }

        private async Task MoveInvalidFies(IDigiS3 s3, MasterClass masterclass, string attachedCrFileName, string renamedCrFileName, string attachedOiFileName, string renamedOiFileName, ILambdaContext context)
        {
            //credit note
            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                  masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath,
                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTvendor_FilePath + "/" + CommonConstants.CWTInvalidFilesPath,
                  attachedCrFileName, renamedCrFileName, context);
            await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath, attachedCrFileName, context);
            //original invoice
            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                  masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath,
                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTvendor_FilePath + "/" + CommonConstants.CWTInvalidFilesPath,
                  attachedOiFileName, renamedOiFileName, context);
            await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath, attachedOiFileName, context);
        }

        private async Task MoveInvalidInvTktFiles(IDigiS3 s3, MasterClass masterclass, string attachedInvoiceFileName, string renamedInvoiceFileName, string attchedTicketFileName, string renamedTicketFileName, ILambdaContext context)
        {
            //invoice
            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                  masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath,
                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTvendor_FilePath + "/" + CommonConstants.CWTInvalidFilesPath,
                  attachedInvoiceFileName, renamedInvoiceFileName, context);
            await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath, attachedInvoiceFileName, context);
            //ticket
            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName,
                  masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath,
                  CommonConstants.Private_Folder + "/" + CommonConstants.CWTvendor_FilePath + "/" + CommonConstants.CWTInvalidFilesPath,
                  attchedTicketFileName, renamedTicketFileName, context);
            await s3.DeleteFile(masterclass.BucketName, CommonConstants.Public_Folder + "/" + CommonConstants.CWTvendor_FilePath, attchedTicketFileName, context);
        }
    }
}
