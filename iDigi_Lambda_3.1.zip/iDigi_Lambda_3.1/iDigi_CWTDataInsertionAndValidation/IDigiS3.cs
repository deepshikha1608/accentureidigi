﻿using Amazon.S3.Model;
using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;

namespace iDigi_CWTDataInsertionAndValidation
{
    public class IDigiS3
    {
        IAmazonS3 S3Client { get; set; }
        public IDigiS3()
        {
            S3Client = new AmazonS3Client();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bucketName"></param>
        /// <param name="folderPath"></param>
        /// <param name="fileName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<GetObjectResponse> GetFileFromS3(string bucketName, string folderPath, string fileName, ILambdaContext context)
        {
            try
            {
                GetObjectResponse getObjectResponse = null;
                if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderPath) && !string.IsNullOrEmpty(fileName))
                {
                    var getObjectRequest = new GetObjectRequest
                    {
                        BucketName = bucketName + "/" + folderPath,
                        Key = fileName
                    };

                    getObjectResponse = await
                        S3Client.GetObjectAsync(getObjectRequest);
                }
                else
                {
                    if (string.IsNullOrEmpty(bucketName))
                    { context.Logger.Log($"ERROR: The passed bucket name is null or empty {bucketName}"); }
                    if (string.IsNullOrEmpty(folderPath))
                    { context.Logger.Log($"ERROR: The passed folder path is null or empty {folderPath}"); }
                    if (string.IsNullOrEmpty(fileName))
                    { context.Logger.Log($"ERROR: The passed file name is null or empty {fileName}"); }
                }

                return getObjectResponse;
            }
            catch (Exception e)
            {
                //string lambdaLogTableName = CommonConstants.AirId + "_" + Function.CloudEnvironment + "_" + CommonConstants.LambdaLogDetailsTable;
                //IDigiDynamoDb db = new IDigiDynamoDb();
                //await db.UpdateLambdaLogDetailsWithException(e, lambdaLogTableName, context);
                context.Logger.Log($"Error:Exception occured while trying to get the file, error message -{e.Message}");
                context.Logger.Log($"Error: Inner exception message -{e.InnerException}");
                context.Logger.Log($"Error: Stack trace -{e.StackTrace}");
                return null;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bucket">bucket name where the file resides</param>
        /// <param name="folder">complete folder path leaving bucketname ex: rootfolder/folder1/folder2</param>
        /// <param name="file">file name to be deleted</param>
        /// <param name="context">ILambdaContext object of current execution</param>
        /// <returns></returns>
        public async Task DeleteFile(string bucketName, string folderPath, string fileName, ILambdaContext context)
        {
            context.Logger.Log($"Proccess: Now process started to delete the file :{fileName} from path :{folderPath} in bucket :{bucketName}");

            if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderPath) && !string.IsNullOrEmpty(fileName))
            {
                var deleteObjectRequest = new DeleteObjectRequest()
                {
                    BucketName = bucketName + "/" + folderPath,
                    Key = fileName

                };
                context.Logger.Log($"now deleting the file, name :{fileName} from folder {bucketName}/{folderPath}");
                var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);
                //return deleteObjectResponse;
            }
            else
            {
                if (string.IsNullOrEmpty(bucketName))
                { context.Logger.Log($"ERROR: The passed bucket name is null or empty {bucketName}"); }
                if (string.IsNullOrEmpty(folderPath))
                { context.Logger.Log($"ERROR: The passed folder path is null or empty {folderPath}"); }
                if (string.IsNullOrEmpty(fileName))
                { context.Logger.Log($"ERROR: The passed file name is null or empty {fileName}"); }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bucketName"></param>
        /// <param name="folder"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<List<string>> ListAllTheFilesInFolder(string bucketName, string folder, ILambdaContext context)
        {
            ListObjectsRequest listObjectRequest = null;
            context.Logger.Log($"Proccess :now ilisting the files from bucket name :{bucketName} folder :{folder}");
            List<string> fileNameList = new List<string>();
            try
            {
                listObjectRequest = new ListObjectsRequest()
                {
                    BucketName = bucketName,
                    Prefix = folder + "/",
                };
                do
                {
                   

                    var listObjectResponse = await S3Client.ListObjectsAsync(listObjectRequest);
                    context.Logger.Log($"{listObjectResponse.S3Objects.Count}");
                    foreach (var s3file in listObjectResponse.S3Objects)
                    {
                        if (!s3file.Key.ToLowerInvariant().Contains(".csv"))
                        {
                            if (s3file.Key.Contains("."))
                            {
                                string tmpFileName = s3file.Key.Replace(folder + "/", "");
                                fileNameList.Add(tmpFileName);
                            }
                        }
                    };
                    if (listObjectResponse.IsTruncated == true)
                    {
                        listObjectRequest.Marker = listObjectResponse.NextMarker;
                    }
                    else
                    {
                        listObjectRequest = null;
                    }

                } while (listObjectRequest != null);
                return fileNameList;
            }
            catch (Exception e)
            {
                context.Logger.Log($"ERROR: Exception occured while listing the files from bucket name :{bucketName} folder : {folder} {e.Message}");
                context.Logger.Log($"ERROR: Inner exception {e.InnerException}");
                context.Logger.Log($"ERROR: Stack Trace {e.StackTrace}");
                return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceBucket"></param>
        /// <param name="destinationBucket"></param>
        /// <param name="sourceFolder"></param>
        /// <param name="destinationFolder"></param>
        /// <param name="fileName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task CopyFileFromOneFolderToOther(string sourceBucket, string destinationBucket, string sourceFolder, string destinationFolder, string srcFileName, string destFileName, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(srcFileName))
            {
                var copyObjectRequest = new CopyObjectRequest()
                {
                    SourceBucket = sourceBucket + "/" + sourceFolder,
                    DestinationBucket = destinationBucket + "/" + destinationFolder,
                    SourceKey = srcFileName,
                    DestinationKey = destFileName
                };
                context.Logger.Log($"Process :Before copying the file : {srcFileName} as {destFileName} from :{sourceBucket + "/" + sourceFolder} to {destinationBucket + "/" + destinationFolder}");
                await S3Client.CopyObjectAsync(copyObjectRequest);
                context.Logger.Log($"Copied successfully");
            }
        }

    }
}
