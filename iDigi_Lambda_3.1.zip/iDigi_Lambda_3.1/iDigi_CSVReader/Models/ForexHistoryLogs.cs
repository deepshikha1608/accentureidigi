﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models
{
    public class ForexHistoryLogs
    {
        public ForexHistoryLogs()
        {

        }
        public string SourceId { get; set; }
        public string ModifiedBy { get; set; }
        public string StatusCd { get; set; }
        public string StatusDt { get; set; }
        public string VendorCd { get; set; }
        public string InvNo { get; set; }
        public string SearchStatusDt { get; set; }
    }
}
