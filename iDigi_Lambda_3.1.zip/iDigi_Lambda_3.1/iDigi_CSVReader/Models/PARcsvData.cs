﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class PARcsvData
    {
        public PARcsvData()
        {

        }
        
        public string DFMURN { get; set; }
        public string VendorCode { get; set; }
        public string RejectionReason { get; set; }
        
        
    }
}
