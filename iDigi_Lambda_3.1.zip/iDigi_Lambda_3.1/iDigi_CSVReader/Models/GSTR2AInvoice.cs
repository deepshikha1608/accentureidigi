﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class GSTR2AInvoice
    {
        public string VendorRegisteredCd
        { get; set; }
        public string VendorInvoiceNumber
        { get; set; }
        public string VendorInvoiceNumberIn2A
        { get; set; }
        public string VendorNm
        { get; set; }
        public string DocType
        { get; set; }
        public string IssueCategory
        { get; set; }
        public string RTPRemarks
        { get; set; }
        public string VendorRemarks
        { get; set; }
        public string VendorGSTN
        { get; set; }
        public string VendorGSTNIn2A
        { get; set; }
        public string InvoiceDt
        { get; set; }
        public string InvoiceDtIn2A
        { get; set; }
        public double?
            BaseAmt
        { get; set; }
        public double?
            BaseAmtIn2A
        { get; set; }
        public double?
            IGSTAmt
        { get; set; }
        public double?
            IGSTAmtIn2A
        { get; set; }
        public double?
            CGSTAmt
        { get; set; }
        public double?
            CGSTAmtIn2A
        { get; set; }
        public double?
            SGSTAmt
        { get; set; }
        public double?
            SGSTAmtIn2A
        { get; set; }
        public double?
            InvoiceAmt
        { get; set; }
        public double?
            InvoiceAmtIn2A
        { get; set; }
        public string AccentureGSTN
        { get; set; }
        public string AccentureGSTNIn2A
        { get; set; }
        public string CreatedDttm
        { get; set; }
        public string ModifiedDttm
        { get; set; }
        public string CreatedBy
        { get; set; }
        public string ModifiedBy
        { get; set; }
        public string IsRTPDownloaded
        { get; set; }

        public string AmtCategory
        { get; set; }

        public double? BaseAmtForCompr
        { get; set; }
    }
}
