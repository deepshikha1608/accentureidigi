﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class CwtEtravelData
    {       
        public int RequestId { get; set; }
        public string RequestNo { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeMailId { get; set; }
        public string PurposeOfTravel { get; set; }
        public string EmployeeRemarks { get; set; }
        public string Wbse { get; set; }
        public string CompanyCode { get; set; }
        public string BillingAddress { get; set; }
        public string BusinessUnit { get; set; }
        public string Country { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string TDDepDate { get; set; }
        public string TDArrTime { get; set; }
        public string TDDepTime { get; set; }
        public string RMSInit { get; set; }
        public string FlightNo { get; set; }
        public string TicketNo { get; set; }
        public string MealPref { get; set; }
        public string SeatPref { get; set; }
        public string DepDate { get; set; }
        public string DepTime { get; set; }
        public string TDRemarks { get; set; }
        public string RefundRemarks { get; set; }
        public string CancelRemarks { get; set; }
        public string ReqStatus { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedDttm { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string IsTrCopyGenerated { get; set; }
        public string CareerLevel { get; set; }
        public string Gender { get; set; }
        public string Location { get; set; }
        public string Entity { get; set; }
        public string ContactNo { get; set; }
        public string Project { get; set; }
        public string TravelDesk { get; set; }
        public string Attachments { get; set; }
        public string ApproverName { get; set; }
        public string ApproverRemarks { get; set; }
        public string AdditionalTravelInformation { get; set; }
        public string RequestorName { get; set; }
        public string RequestedOn { get; set; }
        public string GSTTINOrBIZPlace { get; set; }
        public string TRCopyPDF { get; set; }
        public string TravellerName { get; set; }
    }
}

