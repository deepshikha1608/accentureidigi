﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class DataToDynamoDb
    {
        public List<POTransaction> POTransactionList { get; set; }

        public int InitialPOtransactionId { get; set; }
    }
}
