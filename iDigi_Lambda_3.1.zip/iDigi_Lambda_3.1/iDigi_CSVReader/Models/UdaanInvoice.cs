﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class UdaanInvoice
    {
        public UdaanInvoice()
        {
            InvoiceLineItems = new List<InvoiceLineItem>();
            ErrorList = new List<VendorInvoiceErrorDetails>();
            InvoiceHistoryLogs = new List<InvoiceHistory>();
        }
        public int Id { get; set; }
        public int InvoiceId { get; set; }
        public string VendorCd { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string InvoiceDt { get; set; }
        public string DFMURN { get; set; }
        public string PoNbr { get; set; }
        //public string CompanyCd { get; set; }
        public string WBSE { get; set; }
        //public string EmpNo { get; set; }
        //public string PaxName { get; set; }
        public string Country { get; set; }
        public string TicketNumber { get; set; }
        //public string RTPApproved { get; set; }
        public string LGIGenerated { get; set; }
        //public string PMApproved { get; set; }
        public double? ServiceTax { get; set; }
        public string BusinessUnit { get; set; }
        public double? ReimbursementCharges { get; set; }
        public string EmployeeName { get; set; }
        public double? InvAmt { get; set; }
        //public string Service { get; set; }
        public string InvSubmissionDt { get; set; }
        public double? ServiceCharges { get; set; }
        public string ImplantName { get; set; }
        public string RTPRemarks { get; set; }
        public string VendorRemarks { get; set; }
        //public string RowType { get; set; }
        public double? TaxAmt { get; set; }
        public string TPCd { get; set; }
        public double? FreightAmt { get; set; }
        public double? GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string DCInd { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public double? Base1Amt { get; set; }
        public double? Base2Amt { get; set; }
        public double? Base3Amt { get; set; }
        public double? Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string VendorGSTNumber { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string RTPTeam { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string InvoiceDate { get; set; }
        //public string IsError { get; set; }
        public string IsBatchValidated { get; set; }
        //public double? ApprovedAmt { get; set; }
        //public string AmountRecdDate1 { get; set; }
        //public string AmountRecdDate2 { get; set; }
        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public string IsGSTError { get; set; }
        public string VendorNm { get; set; }
        public string InvoiceSubmittedDt { get; set; }
        public string InvoiceApprovedDttm { get; set; }
        //public string RejectionReason { get; set; }
        //public string RejectionDate { get; set; }
        public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        public InvoiceLineItem InvoiceLineItem { get; set; }
        public List<VendorInvoiceErrorDetails> ErrorList { get; set; }
        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
        public string RejectedBy { get; set; }
        public string RejectedDt { get; set; }
        public string SearchCreatedDttm { get; set; }
        public string SearchModifiedDttm { get; set; }
        public string SearchInvoiceDt { get; set; }
        public string SearchInvSubmissionDt { get; set; }
        public string SearchInvoiceSubmittedDt { get; set; }
        public string SearchInvoiceReceiptDt { get; set; }
        public string SearchInvoiceDate { get; set; }
        public string SearchInvoiceApprovedDttm { get; set; }
        public string SearchRejectionDate { get; set; }
        public string LGIGeneratedBy { get; set; }
        public string LGIGeneratedDttm { get; set; }
        public string InvoiceStatus { get; set; }
        public string PaymentStatus { get; set; }
        public string WireId { get; set; }
        public string GSTR2AStatus { get; set; }
        public string PaymentDt { get; set; }
        public string ScheduledPaymentDt { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string VendorGSTNIn2A { get; set; }
        public string AccentureGSTNIn2A { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string BaseAmtIn2A { get; set; }
        public string GrossAmtIn2A { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string PaymentScheduledDt { get; set; }
        public string IsExempted { get; set; }
        public double? IGSTAmtIn2A { get; set; }
        public double? CGSTAmtIn2A { get; set; }
        public double? SGSTAmtIn2A { get; set; }
        public string InvoiceSubmissionDt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public double? IGSTAmt { get; set; }
      
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
       
        public string ReasonforMismatch { get; set; }
       
        public string SAPDocNo { get; set; }
    }

    public class VendorInvoiceErrorDetails
    {
        public VendorInvoiceErrorDetails()
        {

        }

        public int ErrorId { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorInvoiceNbr { get; set; }
        public string ErrorDetails { get; set; }
        public string IsValidError { get; set; }
    }

    public class UdaanEYData
    {
        public string InvoiceSubmissionDt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public double? IGSTAmt { get; set; }
        public string GSTR2AStatus { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? CGSTAmtIn2A { get; set; }
        public double? SGSTAmtIn2A { get; set; }
        public double? IGSTAmtIn2A { get; set; }
        public string ReasonforMismatch { get; set; }
        public string ModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public double? BaseAmtIn2A { get; set; }
        public string SAPDocNo { get; set; }
        public string VendorGSTNumber { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string VendorCd { get; set; }

    }
}
