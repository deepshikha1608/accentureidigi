﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models
{
    public class CSRInvoice
    {
        public int IdigiKey { get; set; }
        public string VendorCd { get; set; }
        public string InvoiceNumber { get; set; }
        public string InvoiceDt { get; set; }
        public string InvoiceStatus { get; set; }
        public string TRNumber { get; set; }
        public string BookingID { get; set; }
        public string BookingDt { get; set; }
        public string EmpNm { get; set; }
        public string EmpNumber { get; set; }
        public string EmpPhone { get; set; }
        public string EmpEmail { get; set; }
        public string WBSECd { get; set; }
        public string DestFacility { get; set; }
        public string DestState { get; set; }
        public string CheckInDt { get; set; }
        public string CheckOutDt { get; set; }
        public float TotalAmt { get; set; }
        public string PropertyNm { get; set; }
        public string PropertyEmail { get; set; }
        public string PropertyPhone { get; set; }
        public string CorporateGST { get; set; }
        public string PropertyGST { get; set; }
        public string CompanyNm { get; set; }
        public string BillingAddressAcc { get; set; }
        public string BankRefNumber { get; set; }
        public string HSNSSE { get; set; }
        public float SingleSGSTTax { get; set; }
        public float SingleSGSTAmt { get; set; }
        public float SingleCGSTTax { get; set; }
        public float SingleCGSTAmt { get; set; }
        public float SingleIGSTTax { get; set; }
        public float SingleIGSTAmt { get; set; }
        public float TotalGSTAmt { get; set; }
        public string InvoiceFileNm { get; set; }
        public string TRFileNm { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string DocNumber { get; set; }
        public string DocDate { get; set; }
        public string DocDatenew { get; set; }
        public string BillingAddressCSR { get; set; }
        public float TaxableAmt { get; set; }
        public string TravelCity { get; set; }
        public string creditTakenOn { get; set; }
        public string creditTakenOnnew { get; set; }
        public string StateCd { get; set; }
        public string PaymentDt { get; set; }
        public string PaymentDtnew { get; set; }

        public string employeeCostCenter { get; set; }
        public string employeeCompanyCode { get; set; }
        public string GlCode { get; set; }
        public string GlCodeDescription { get; set; }
        public string newWbse { get; set; }
        public string paymentDocumentNumber { get; set; }
        public string Status { get; set; }

        public string NDCInvoiceStatus { get; set; }

        public string WireId { get; set; }
  
    }

    public class CSREYData
    {
        public string VendorCd { get; set; }
        public string InvoiceNumber { get; set; }
        public string GSTR2AStatus { get; set; }
        public string ReasonforMismatch { get; set; }
        //public string ModifiedDttm { get; set; }
        //public string ModifiedBy { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? CGSTIn2A { get; set; }
        public double? SGSTIn2A { get; set; }
        public double? IGSTIn2A { get; set; }
        public double? BaseAmtIn2A { get; set; }
        public string SAPDocNo { get; set; }
    }
}
