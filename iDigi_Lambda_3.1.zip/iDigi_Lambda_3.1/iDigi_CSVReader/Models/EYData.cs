﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class EYData
    {
        public string module { get; set; }
        public string sapDocumentNumber { get; set; }
        public string invoiceNumber { get; set; }
        public string invoiceDate { get; set; }
        public string accentureGSTIN { get; set; }
        public string supplierGSTIN { get; set; }
        public string InvoiceNumber2A { get; set; }
        public string taxableValue { get; set; }
        public string SupplierGSTN2A { get; set; }
        public string cgstAmount { get; set; }
        public string sgstAmount { get; set; }
        public string igstAmount { get; set; }
        public string matchingStatus { get; set; }
        public string invoiceNumber2A { get; set; }
        public string invoiceDate2A { get; set; }
        public string accentureGSTIN2A { get; set; }
        public string supplierGSTIN2A { get; set; }
        public string taxableValue2A { get; set; }
        public string cgstAmount2A { get; set; }
        public string sgstAmount2A { get; set; }
        public string igstAmount2A { get; set; }
      
        public string reasonForMismatch { get; set; }

        //public string vendorCd { get; set; }
    }
}
