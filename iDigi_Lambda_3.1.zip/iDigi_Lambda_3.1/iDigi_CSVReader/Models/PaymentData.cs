﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class PaymentData
    {
       public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string PaymentDt { get; set; }
        public string ScheduledPaymentDt { get; set; }
        public string PaymentStatus { get; set; }
        public string WireId { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string VendorCd { get; set; }
        public string VendorInvoiceCRNo { get; set; }

    }
}
