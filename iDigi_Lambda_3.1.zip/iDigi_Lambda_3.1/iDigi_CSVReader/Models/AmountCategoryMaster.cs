using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
public class AmountCategoryMaster
{ 

public int SorttId { get; set; } 

public string CategoryNm { get; set; } 

public double? MinAmt { get; set; } 

public double? MaxAmt { get; set; } 

public string Description { get; set; } 

public string CreatedBy { get; set; } 

public string CreatedDttm { get; set; } 

public string ModifiedBy { get; set; } 

public string ModifiedDttm { get; set; } 

}
}