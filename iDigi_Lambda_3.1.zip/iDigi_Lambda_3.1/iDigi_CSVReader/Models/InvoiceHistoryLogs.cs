﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class InvoiceHistoryLogs
    {
        public InvoiceHistoryLogs()
        {

        }
        public int Id { get; set; }
        public string SourceId { get; set; }
        public string ModifiedBy { get; set; }
        public string StatusCd { get; set; }
        public string StatusDt { get; set; }
        public string VendorCd { get; set; }
        public string InvNo { get; set; }
        public string SearchStatusDt { get; set; }
    }
}
