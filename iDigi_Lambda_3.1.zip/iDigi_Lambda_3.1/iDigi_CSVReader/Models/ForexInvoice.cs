﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models
{
    public class ForexInvoice
    {
        public ForexInvoice()
        {

        }
        //public string SkuId { get; set; }
        //public string AttachedFile { get; set; }
        //public string VendorRegisteredCd { get; set; }
        //public string EmployeeID { get; set; }
        //public string EmployeeNm { get; set; }
        //public string Currency { get; set; }
        //public string IssuedOnCard { get; set; }
        //public string IssuedOnCash { get; set; }
        //public double TotalAmountInFCY { get; set; }
        //public string VendorInvoiceNumber { get; set; }
        //public string InvoiceDt { get; set; }
        //public string InvoiceSubmissionDt { get; set; }
        //public string Policy { get; set; }
        //public string Category { get; set; }
        //public string CompanyCd { get; set; }
        //public string BusinessPlace { get; set; }
        //public string POS { get; set; }
        //public string AccentureGSTIN { get; set; }
        //public string VendorGSTIN { get; set; }
        //public string DateOfExcelSubmission { get; set; }
        //public string RecoCode { get; set; }
        //public string ExchangeRate { get; set; }
        //public string ValueOfSupply { get; set; }
        //public string IsExempted { get; set; }
        //public double CGST { get; set; }
        //public double SGST { get; set; }
        //public double IGST { get; set; }
        //public double TotalAmountINR { get; set; }
        //public string GSTPartner { get; set; }
        //public string TypeOfTransaction { get; set; }
        //public string HSNSAC { get; set; }
        //public double TotalTax { get; set; }
        //public string ValueInExchangeRate { get; set; }
        //public string TaxType { get; set; }
        //public string DFMURN { get; set; }
        //public string TaxPercentage { get; set; }
        //public string IsBulkUploaded { get; set; }
        //public string LGIDownloaded { get; set; }
        //public string InvoiceStatusCd { get; set; }
        //public string VendorInvoiceNumberIn2A { get; set; }
        //public string InvoiceDtIn2A { get; set; }
        //public string AccentureGSTINIn2A { get; set; }
        //public string VendorGSTNumberIn2A { get; set; }
        //public double TaxableValueIn2A { get; set; }
        //public double CGSTIn2A { get; set; }
        //public double SGSTIn2A { get; set; }
        //public double IGSTIn2A { get; set; }
        //public string VendorRemarks { get; set; }
        //public string RTPRemarks { get; set; }
        //public string PaymentStatus { get; set; }
        //public string ReasonForMismatch { get; set; }
        //public string NDCInvoiceStatus { get; set; }
        //public string GSTR2AStatus { get; set; }
        //public string VendorGSTNumber { get; set; }
        //public string VendorNm { get; set; }
        //public string CreatedDttm { get; set; }
        //public string CreatedBy { get; set; }
        //public string ModifiedBy { get; set; }
        //public string ModifiedDttm { get; set; }
        //public string SAPDocNo { get; set; }
        //public string RTPTeam { get; set; }
        //public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        //public InvoiceHistory InvoiceHistory { get; set; }
        public string SKU { get; set; }
        public string AttachedFile { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeNm { get; set; }
        public string Currency { get; set; }
        public double IssuedOnCard { get; set; }
        public double IssuedOnCash { get; set; }
        public double TotalAmountInFCY { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string RequestorNm { get; set; }   //added Requestor Name
        public string Remarks { get; set; }    // added Remarks column
        public string VendorGSTNumberIn2A { get; set; } //added VendorGst Number In2A column 
        public string WireId { get; set; }  // added WIRE ID columnvendorInvoiceNumber
        public string PaymentDt { get; set; } // added Payment Date column
        public string InvoiceDt { get; set; }
        public string InvoiceSubmissionDt { get; set; }
        public string STPISEZ { get; set; }
        public string Policy { get; set; }
        public string Category { get; set; }
        public string CompanyCd { get; set; }
        public string BusinessPlace { get; set; }
        public string POS { get; set; }
        public string AccentureGSTIN { get; set; }
        public string VendorGSTIN { get; set; }
        public string DateOfExcelSubmission { get; set; }
        public string RecoCode { get; set; }
        public double ExchangeRate { get; set; }
        public double ValueOfSupply { get; set; }
        public string IsExempted { get; set; }
        public double CGSTAmount { get; set; }
        public double SGSTAmount { get; set; }
        public double IGSTAmount { get; set; }
        public double TotalAmountINR { get; set; }
        public string GSTPartner { get; set; }
        public string TypeOfTransaction { get; set; }
        public string HSNSAC { get; set; }
        public double TotalTax { get; set; }
        public string ValueInExchangeRate { get; set; }
        public string TaxType { get; set; }
        public string DFMURN { get; set; }
        public string TaxPercentage { get; set; }
        public string IsBulkUploaded { get; set; }
        public string LGIDownloaded { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string AccentureGSTNIn2A { get; set; }
        public string SupplierGSTNIn2A { get; set; }
        public double TaxableValueIn2A { get; set; }
        public double CGSTAmountIn2A { get; set; }
        public double SGSTAmountIn2A { get; set; }
        public double IGSTAmountIn2A { get; set; }
        public string VendorRemarks { get; set; }
        public string RTPRemarks { get; set; }
        public string PaymentStatus { get; set; }
        public string ReasonForMismatch { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string GSTR2AStatus { get; set; }
        //public string VendorGSTIN { get; set; }
        public string VendorNm { get; set; }
        public string RTPActionOnLGI { get; set; }
        public string SAPDocNo { get; set; }
        public string RTPTeam { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string LGIDownloadedBy { get; set; }
        public string LGIDownloadTime { get; set; }
        public string CreateUserId { get; set; }
        public string UpdateUserId { get; set; }
        public string UpdateDttm { get; set; }
        public string CreatedDttm { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public double? TaxAmt { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string AlternativePayeeNm { get; set; }
        public List<InvoiceLineItem> InvoiceLineItems { get; set; } // added the invoice line item list
        public InvoiceLineItem InvoiceLineItem { get; set; }
        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
        public string DtofGoodsDelivery { get; set; }
        public string VendorGSTNumber { get; set; }

    }
    public class ForexEYData
    {
        public string InvoiceSubmissionDt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public double? IGSTAmt { get; set; }
        public string GSTR2AStatus { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? CGSTAmountIn2A { get; set; }
        public double? SGSTAmountIn2A { get; set; }
        public double? IGSTAmountIn2A { get; set; }
        public string ReasonforMismatch { get; set; }
        public string ModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public double? BaseAmtIn2A { get; set; }
        public string SAPDocNo { get; set; }
        public string VendorGSTNumber { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }


    }
}
