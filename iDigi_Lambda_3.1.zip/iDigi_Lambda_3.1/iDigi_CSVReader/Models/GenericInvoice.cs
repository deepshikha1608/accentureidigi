﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class GenericInvoice
    {
        public GenericInvoice()
        {

        }
        
        public GenericInvoice(int id)
        {
            Id = id;
        }
        public int Id { get; set; }
        public string SkuId { get; set; }
        public int? CurrentInvoiceBatchId { get; set; }
        public string InternalInvoiceRefNbr { get; set; }
        public string VendorModuleCd { get; set; }
        public string InvoiceSubmissionDt { get; set; }
        public string SearchInvoiceSubmissionDt { get; set; }
        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string VendorGSTNumber { get; set; }
        public string InvoiceStatusCd { get; set; }
        public int CurrentLGIBatchFileToSAPId { get; set; }
        public string UserRoleBasedInd { get; set; }
        public string AssignedRoleCd { get; set; }
        public string AssignedUserLoginCd { get; set; }
        public string AssignedInternalUserId { get; set; }
        public string TPCd { get; set; }
        public string DCInd { get; set; }
        public string InvoiceDt { get; set; }
        public string SearchInvoiceDt { get; set; }
        
        public double? TaxAmt { get; set; }
        public double? FreightAmt { get; set; }
        public double? GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string SearchInvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public double? Base1Amt { get; set; }
        public double? Base2Amt { get; set; }
        public double? Base3Amt { get; set; }
        public double? Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string UpdateDttm { get; set; }
        public string UpdateUserId { get; set; }
        public string CreateDttm { get; set; }
        public string SearchCreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string LGIDownloaded { get; set; }
        public string DFMURN { get; set; }
        public string AutomationTemplateDownloaded { get; set; }
        public string RTPTeam { get; set; }
        public string RowType { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string InvoicePdf { get; set; }
        // public int InvoiceDTId { get; set; }
        public string PageTitle { get; set; }
        public string HoldReason { get; set; }
        public string Remarks { get; set; }
        public string RTPRemarks { get; set; }
        public string CompanyCd { get; set; }
        public string ExceptionReason { get; set; }
        public string IsBulkUploaded { get; set; }
        public string ModifiedDttm { get; set; }
        public string SearchModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string VendorNm { get; set; }
        //public string RejectionReason { get; set; }
        //public string RejectionDate { get; set; }
        public string BusinessGroup { get; set; }
        public string CurrentTeam { get; set; }
        public string LGIDownloadedBy { get; set; }
        public string LGIDownloadTime { get; set; }
        public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        public InvoiceLineItem InvoiceLineItem { get; set; }
        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
        public string LutExpDt { get; set; }
        public string SearchLutExpDt { get; set; }
        public string LutNo { get; set; }
        public string RTPRejectionRemarks { get; set; }
        public string BizRejectionRemarks { get; set; }
        public string EWayBillNo { get; set; }
        public string RejectedBy { get; set; }
        public string RejectedDt { get; set; }
        public string MaterialGroup { get; set; }
        public string IsHandDelivered { get; set; }
        public string GSTR2AStatus { get; set; }
        public string PaymentDt { get; set; }
        public string ScheduledPaymentDt { get; set; }
        public string PaymentStatus { get; set; }
        public string WireId { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string IsExempted { get; set; }
        public string ReasonforMismatch { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? IGSTAmtIn2A { get; set; }
        public double? CGSTAmtIn2A { get; set; }
        public double? SGSTAmtIn2A { get; set; }
        public double? IGSTAmt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public string SAPDocNo { get; set; }
        public byte IsOverrideProcessingBlock { get; set; }
        public string InvoiceStatus { get; set; }
        public string ReasonforDelaySubmission { get; set; }
        public string AccentureGST { get; set; }

        public string VendorGST { get; set; }

        public string VendorGSTPartner { get; set; }

        public string BaseTaxamount { get; set; }

        public string TaxAmount { get; set; }
        public string OtherReasonforDelaySubmission { get; set; }
        public double? TCSAmount { get; set; }


    }

    public class GenericEYData
    {

        public GenericEYData()
        {
            InvoiceHistoryLogs = new List<InvoiceHistory>();
        }

        public string InvoiceSubmissionDt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public double? IGSTAmt { get; set; }
        public string GSTR2AStatus { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? CGSTAmtIn2A { get; set; }
        public double? SGSTAmtIn2A { get; set; }
        public double? IGSTAmtIn2A { get; set; }
        public string ReasonforMismatch { get; set; }
        public string ModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public double? BaseAmtIn2A { get; set; }
        public string SAPDocNo { get; set; }
        public string VendorGSTNumber { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }

        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }

    }
}
