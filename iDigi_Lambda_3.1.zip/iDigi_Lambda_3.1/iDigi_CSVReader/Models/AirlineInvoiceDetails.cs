﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class AirlineInvoiceDetails
    {
        public string VendorCd { get; set; }
        public string InvoiceKey { get; set; }
        public string InvoiceNbr { get; set; }
        public string PNR { get; set; }
        public string TicketNbr { get; set; }
        public string AirlineNm { get; set; }
        public string InvoiceType { get; set; }
        public string InvoiceDt { get; set; }
        public string OrgInvNo { get; set; }
        public string OrgInvDt { get; set; }
        public string SupplierGSTN { get; set; }
        public string AccentureGSTN { get; set; }
        public string RegisteredAccentureNm { get; set; }
        public string POS { get; set; }
        public string SupplierNm { get; set; }
        public string SupplierBillingAddress { get; set; }
        public string HSNSACTaxableAmt { get; set; }
        public string HSNSACNonTaxableAmt { get; set; }
        public string PAXNm { get; set; }
        public string TravelFrom { get; set; }
        public string TravelTo { get; set; }
        public string Currency { get; set; }
        public double TaxableValue { get; set; }
        public double NonTaxableValue { get; set; }
        public double TotalValueWithoutTax { get; set; }
        public double CGSTRate { get; set; }
        public double CGSTAmt { get; set; }
        public double SGSTRate { get; set; }
        public double SGSTAmt { get; set; }
        public double IGSTRate { get; set; }
        public double IGSTAmt { get; set; }
        public double CessRate { get; set; }
        public double CessAmt { get; set; }
        public double TotalValueWithTax { get; set; }
        public string CreditTaken { get; set; }
        public string CreditDttm { get; set; }
        public string CWTMatchedFlag { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }

        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }

        public string MailReceiveDttm { get; set; }
        public string AirLineInvoiceFileName { get; set; }
        public string SourceOfInvoice { get; set; }
        public string PNROrTktNbr { get; set; }

    }
}
