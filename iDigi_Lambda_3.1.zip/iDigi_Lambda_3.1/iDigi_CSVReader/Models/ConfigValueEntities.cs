﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models
{
    public class ConfigValueEntities
    {
        public int Id { get; set; }
        public string ConfigKey { get; set; }
        public string ModuleNm { get; set; }
        public string ConfigValue { get; set; }
        public string Description { get; set; }
    }
}
