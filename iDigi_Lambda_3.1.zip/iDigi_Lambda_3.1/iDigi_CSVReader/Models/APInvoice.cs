﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class APInvoice
    {
        public APInvoice()
        {

        }
        public int Id { get; set; }
        public string SkuId { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string VendorGSTNumber { get; set; }
        public string AccentureGSTNumber { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string VendorModuleCd { get; set; }
        public string POSStr { get; set; }
        public string VendorNm { get; set; }
        public string Entity { get; set; }
        public string Email { get; set; }
        public string ProcessorNm { get; set; }
        public string VendorClassification { get; set; }
        public string DCInd { get; set; }
        public string IndexingNbr { get; set; }
        public string InvoiceDt { get; set; }
        //public string SearchInvoiceDt { get; set; }
        public double? TaxAmt { get; set; }
        public double? FreightAmt { get; set; }
        public double? GrossAmt { get; set; }
        public double? LineAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string PONumber { get; set; }
        public string PartnerCode { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string Reserved { get; set; }
        public string Reserved1 { get; set; }
        public string Reserved2 { get; set; }
        public string InvoiceType { get; set; }
        public double? InvoiceValue { get; set; }
        public string InvoiceReceivedDt { get; set; }
        //public string SearchInvoiceReceivedDt { get; set; }
        public string InvoiceReceiptDt { get; set; }
        //public string SearchInvoiceReceiptDt { get; set; }
        public string RequestorNm { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string PORReferenceNbr { get; set; }
        public string DateCleared { get; set; }
        //public string SearchDateCleared { get; set; }
        public string RejectionReason { get; set; }
        public string ReasonDelayedSubmission { get; set; }
        public string DeliveryChallanDt { get; set; }
        public string Plant { get; set; }
        public int BusinessPlaceId { get; set; }
        public string DaysTaken { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string TaxType { get; set; }
        public string HSNSAC { get; set; }
        public string EWayBill { get; set; }
        public string InvoiceSource { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string CompanyCd { get; set; }
        public string LGIDownloaded { get; set; }
        public double? Taxable { get; set; }
        public double? CGST { get; set; }
        public double? IGST { get; set; }
        public double? SGST { get; set; }
        public double? Cess { get; set; }
        public double? Base1Amt { get; set; }
        public double? Base2Amt { get; set; }
        public double? Base3Amt { get; set; }
        public double? Base4Amt { get; set; }
        public string DFMBarCode { get; set; }
        public string DateScanned { get; set; }
        //public string SearchDateScanned { get; set; }
        public string Status { get; set; }
        public string Remarks { get; set; }
        public string TPCd { get; set; }
        public string TaxRate { get; set; }
        public double? TaxParameter1Amt { get; set; }
        public double? TaxParameter2Amt { get; set; }
        public string ChargedEntity { get; set; }
        public double? PoLineNbr { get; set; }
        public string MaterialGroup { get; set; }
        public double? UnitPrice { get; set; }
        public string InvNumCreditNote { get; set; }
        public string InvDtCreditNote { get; set; }
        //public string SearchInvDtCreditNote { get; set; }
        public string AssignmentNbr { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string RTPRemarks { get; set; }
        public string RTPTeam { get; set; }
        public string IsHandDelivered { get; set; }
        public string IsResubmitted { get; set; }
        public string CreatedUserId { get; set; }
        public string CreatedDttm { get; set; }
        //public string SearchCreatedDttm { get; set; }
        public string ModifiedDttm { get; set; }
        //public string SearchModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string LGIDownloadedBy { get; set; }
        public string LGIDownloadTime { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string WireId { get; set; }
        public int GSTID { get; set; }
        public string IsBulkUpload { get; set; }
        public string ReasonforMismatch { get; set; }
        public string GSTR2AStatus { get; set; }
        public string PaymentDt { get; set; }
        public string ScheduledPaymentDt { get; set; }
        public string PaymentStatus { get; set; }
        //public string WireId { get; set; }
        //public string NDCInvoiceStatus { get; set; }
        public string IsExempted { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? IGSTAmtIn2A { get; set; }
        public double? IGSTIn2A { get; set; }
        public double? CGSTAmtIn2A { get; set; }
        public double? SGSTAmtIn2A { get; set; }
        public double? CGSTIn2A { get; set; }
        public double? SGSTIn2A { get; set; }
        public double? TCSAmt { get; set; }
    }
   

    public class APEYData
    {
        public string InvoiceSubmissionDt { get; set; }
        public double? CGSTAmt { get; set; }
        public double? SGSTAmt { get; set; }
        public double? IGSTAmt { get; set; }
        public string GSTR2AStatus { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string VendorGSTNumberIn2A { get; set; }
        public double? TaxableValueIn2A { get; set; }
        public double? CGSTIn2A { get; set; }
        public double? SGSTIn2A { get; set; }
        public double? IGSTIn2A { get; set; }
        public string ReasonforMismatch { get; set; }
        public string ModifiedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public double? BaseAmtIn2A { get; set; }
        public string SAPDocNo { get; set; }
        public string VendorGSTNumber { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        

    }
}
