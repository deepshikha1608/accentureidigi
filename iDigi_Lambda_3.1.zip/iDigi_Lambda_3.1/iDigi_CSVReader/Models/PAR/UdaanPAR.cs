﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models.PAR
{
    public class UdaanPAR
    {
        public UdaanPAR()
        {
           InvoiceHistoryLogs = new List<InvoiceHistory>();
        }

        public string VendorInvoiceNumber { get; set; }
        public string VendorCd { get; set; }
        public string DFMURN { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string IndexingNbr { get; set; }
        public string AssignmentNbr { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string LGIGenerated { get; set; }
        public string RTPRemarks { get; set; }
        public string ModifiedBy { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string RTPTeam { get; set; }
        public string SearchModifiedDttm { get; set; }
        public string ModifiedDttm { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string AttachedFile { get; set; }
        public string GSTR2AStatus { get; set; }
        public List<iDigi_CSVReader.Models.PAR.InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
    }
    public class InvoiceHistory
    {

        public InvoiceHistory()
        {

        }
        public int Id { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string CreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string DFMURN { get; set; }
        public string AttachedFile { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string SearchCreateDttm { get; set; }
    }
}
