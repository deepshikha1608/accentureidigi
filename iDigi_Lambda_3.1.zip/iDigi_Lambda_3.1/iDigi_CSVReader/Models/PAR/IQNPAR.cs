﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CSVReader.Models.PAR
{
    public class IQNPAR
    {
        public IQNPAR()
        { }

        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string DFMURN { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string IndexingNbr { get; set; }
        public string AssignmentNbr { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string LGIDownloaded { get; set; }
        public string AutomationTemplateDownloaded { get; set; }
        public string RTPRemarks { get; set; }
        public string ModifiedBy { get; set; }
        public string SearchModifiedDttm { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string RTPTeam { get; set; }
        public string ModifiedDttm { get; set; }
        public string AttachedFile { get; set; }
        public List<iDigi_CSVReader.Models.PAR.InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
        public string GSTR2AStatus { get; set; }

    }
}
