﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class PARFailedRecords
    {
        public PARFailedRecords()
        {

        }
      
        public string Email { get; set; }
        public string UploadedDt { get; set; }
        public string UploadedDttm { get; set; }
        public string UploadedBy { get; set; }
        public List<PARcsvData>  FailedRecords {get; set;}
        public PARcsvData FailedRecord { get; set; }
    }
}
