﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Threading.Tasks;

namespace iDigi_CSVReader
{
    public class POTransaction
    {
        public string SupplierID { get; set; }
        public string POLineItem { get; set; }
        public int POTransactionId { get; set; }
        public string CoCode { get; set; }
        public string PONumber { get; set; }
        public string GLCode { get; set; }
        public string Requester { get; set; }
        public string WBSE { get; set; }
        public string ProfitCenter { get; set; }
        public string LineItem { get; set; }
        public string SupplierName { get; set; }
        public string PoDeliveryDate { get; set; }
        public string LineDescription { get; set; }
        public string CostCenter { get; set; }
        public string Type { get; set; }
        public string Payment { get; set; }
        public string PurchageOrg { get; set; }
        public string Preparer { get; set; }
        public string MaterialGroup { get; set; }
        public string POType { get; set; }
        public string AccountAssignment { get; set; }
        public string LastInvDocPostingDate { get; set; }
        public string Open { get; set; }
        public string MaterialCodeDescription { get; set; }
        public string TrackingAssociatedCostCenter { get; set; }
        public string BusinessApprover { get; set; }
        public string AssetType { get; set; }
        public string ShipToAddress { get; set; }
        public string TaxCode { get; set; }
        public double? OpenValue { get; set; }
        public string Curr { get; set; }
        public string OrderedDate { get; set; }
        public double? OrderedQty { get; set; }
        public string UM { get; set; }
        public double? OrderAmount { get; set; }
        public double? OpenPOValue { get; set; }
        public double? OpenQty { get; set; }
        public double? AmountOfLastINV { get; set; }
        public string GSTNumber { get; set; }

        public string Other1 { get; set; }
        public string Other2 { get; set; }
        public string Other3 { get; set; }

        public string CreatedDttm { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedDttm { get; set; }
        public string UpdatedBy { get; set; }

        public string IsActive { get; set; } //True False

        public string FileUploadedDttm { get; set; }
    }
}
