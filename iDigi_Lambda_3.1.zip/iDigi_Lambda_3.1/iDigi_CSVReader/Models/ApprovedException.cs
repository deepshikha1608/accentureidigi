﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader.Models
{
    public class ApprovedException
    {
        public int VendorId { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorNm { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string InvoiceDt { get; set; }  
        public string InvoiceSubmittedFlag { get; set; }
        public string InvoiceSubmittedDt { get; set; }
        public string PoNbr { get; set; }
        public string PoLineNbr { get; set; }
        public double? ApprovedAmt { get; set; }
        public string  CreatedDttm { get; set; }
        public string ModifiedDttm { get; set; }
        public string ExceptionType { get; set; }
    }
}
