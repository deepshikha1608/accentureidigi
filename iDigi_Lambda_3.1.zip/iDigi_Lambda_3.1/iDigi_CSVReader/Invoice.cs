﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSVReader
{
    public class Invoice
    {
        public string Id { get; set; }
        public string InvoiceDataId { get; set; }
        public string CurrentInvoiceBatchId { get; set; }
        public string InternalInvoiceRefNbr { get; set; }
        public string VendorModuleCd { get; set; }


        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string CurrentLGIBatchFileToSAPId { get; set; }
        public string UserRoleBasedInd { get; set; }
        public string AssignedRoleCd { get; set; }
        public string AssignedUserLoginCd { get; set; }
        public string AssignedInternalUserId { get; set; }
        public string TPCd { get; set; }
        public string DCInd { get; set; }
        public string InvoiceDt { get; set; }
        public string TaxAmt { get; set; }
        public string FreightAmt { get; set; }
        public string GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public string Base1Amt { get; set; }
        public string Base2Amt { get; set; }
        public string Base3Amt { get; set; }
        public string Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string UpdateDttm { get; set; }
        public string UpdateUserId { get; set; }
        public string CreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string LGIDownloaded { get; set; }
        public string SAPDocNo { get; set; }
        public string DFMURN { get; set; }
        public string AutomationTemplateDownloaded { get; set; }
        public string RTPTeam { get; set; }
        public string RowType { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string Description { get; set; }
        public string TaxParameter1Amt { get; set; }
        public string TaxParameter2Amt { get; set; }
        public string LineAmt { get; set; }
        public string ChargedEntity { get; set; }
        public string Quantity { get; set; }
        public string PoNbr { get; set; }
        public string PoLineNbr { get; set; }
        public string Plant { get; set; }
        public string MaterialGroup { get; set; }
        public string UnitPrice { get; set; }
        public string InvoicePdf { get; set; }
        public string InvoiceDTId { get; set; }
        public string PageTitle { get; set; }
        public string HoldReason { get; set; }
        public string Remarks { get; set; }
        public string CompanyCd { get; set; }
        public string VendorGSTNumber { get; set; }
    }
}
