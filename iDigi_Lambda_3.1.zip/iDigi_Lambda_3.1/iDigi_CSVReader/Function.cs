using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.Lambda.Model;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using CsvHelper;
using iDigi_CSVReader.Models;
using MoreLinq;
using Newtonsoft.Json;
using OfficeOpenXml;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CSVReader
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        IAmazonDynamoDB DbClient { get; set; }
        string approvedExceptionTable = string.Empty;

        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
               // return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                if (DebugEnvironMent.ToLowerInvariant() == "true")
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); // windows os
                }
                else
                { return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); } // amazon linux os 

            }
        }
        public static string DebugEnvironMent
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("DebugEnvironMent");
            }

        }
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            S3Client = new AmazonS3Client();
            LambdaClient = new AmazonLambdaClient();
            DbClient = new AmazonDynamoDBClient();
            // CloudEnvironment = Environment.GetEnvironmentVariable("Environment");
        }
        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;

        }
        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            context.Logger.Log($"Lambda invoked");
            var s3Event = evnt.Records?[0].S3;
            string bucketName = evnt.Records[0].S3.Bucket.Name;
            try
            {
                string objectKeyForFetchingVendorName = System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '));
                string fileColsDbColsMappingTable = string.Empty;
                string poTransactionTable = string.Empty;
                string vendorMasterTable = string.Empty;
                string dataInserterLambda = string.Empty;
                string cwtEtravelDataTable = string.Empty;
                string airlineInvoiceDataTable = string.Empty;
                string GenericTableName = string.Empty;
                string VisaTableName = string.Empty;
                string IQNTableName = string.Empty;
                string vendorMasterTableName = string.Empty;
                string RealEstateTableName = string.Empty;
                string APInvoiceTableName = string.Empty;
                string ForexInvoiceTableName = string.Empty;
                string CWTInvoiceTableName = string.Empty;
                string GenericHistoryLogTable = string.Empty;
                string VisaHistoryLogTable = string.Empty;
                string APHistoryLogTable = string.Empty;
                string ForexHistoryLogTable = string.Empty;
                string IQNHistoryLogTable = string.Empty;
                string RealEstateHistoryLogTable = string.Empty;
                string PARFileUploadTableName = string.Empty;
                string gstr2aTable = string.Empty;
                string amountCategoryMasterTable = string.Empty;
                string EYPrivateBucket = string.Empty;
                string csrInvoiceTableName = string.Empty;
                string VendorCodeDfmurnindex = string.Empty;
                string configValueTable = string.Empty;
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CommonConstants.FileColsDbColsMappingTable;
                    poTransactionTable = CommonConstants.AirId + "_" + CommonConstants.PoTransactionTable;
                    vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                    dataInserterLambda = CommonConstants.POtransactionMasterDataInserterLambda;
                    approvedExceptionTable = CommonConstants.AirId + "_" + CommonConstants.ApprovedExceptionInvoicesTable;
                    cwtEtravelDataTable = CommonConstants.AirId + "_" + CommonConstants.CWTEtravelTable;
                    airlineInvoiceDataTable = CommonConstants.AirId + "_" + CommonConstants.AirlineInvoiceTable;
                    gstr2aTable = CommonConstants.AirId + "_" + CommonConstants.GSTR2aInvoiceTable;
                    GenericTableName = CommonConstants.AirId + "_" + CommonConstants.NewGenericInvoicetable;
                    IQNTableName = CommonConstants.AirId + "_" + CommonConstants.IQNInvoiceTable;
                    VisaTableName = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                    vendorMasterTableName = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                    RealEstateTableName = CommonConstants.AirId + "_" + CommonConstants.RealEstateInvoicesNewTable;
                    APInvoiceTableName = CommonConstants.AirId + "_" + CommonConstants.APInvoicesTable;
                    ForexInvoiceTableName = CommonConstants.AirId + "_" + CommonConstants.ForexInvoicesTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_" + CommonConstants.PARFileUploadTableName;
                    amountCategoryMasterTable = CommonConstants.AirId + "_" + CommonConstants.AmountCategoryMasterTable;
                    IQNHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.IQNHistoryLogTable;
                    VisaHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.VisaHistoryLogTable;
                    csrInvoiceTableName = CommonConstants.AirId  + "_" + CommonConstants.CSRTable;
                    ForexHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.ForexHistoryLogTable;
                    CWTInvoiceTableName = CommonConstants.AirId + "_" + CommonConstants.CWTInvoiceProdTable;
                    EYPrivateBucket = CommonConstants.EYPrivateBucketforProd;
                    VendorCodeDfmurnindex = CommonConstants.AirId + "_" + CommonConstants.VendorCodeDfmUrnIndex;
                    configValueTable = CommonConstants.AirId + "_" + CommonConstants.ConfigValueMasterTable;
                }
                else
                {
                    fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                                                 CommonConstants.FileColsDbColsMappingTable;
                    poTransactionTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                                         CommonConstants.PoTransactionTable;
                    vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                                        CommonConstants.VendorMasterTable;
                    dataInserterLambda = CommonConstants.POtransactionMasterDataInserterLambdaForStageAndDev;

                    approvedExceptionTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ApprovedExceptionInvoicesTable;
                    cwtEtravelDataTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTEtravelTable;
                    airlineInvoiceDataTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.AirlineInvoiceTable;
                    GenericTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.NewGenericInvoicetable;
                    IQNTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNInvoiceTable;
                    VisaTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                    vendorMasterTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                    RealEstateTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateInvoicesNewTable;
                    CWTInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoiceStageTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PARFileUploadTableName;
                    gstr2aTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                                 CommonConstants.GSTR2aInvoiceTable;
                    APInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APInvoicesTable;
                    ForexInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexInvoicesTable;
                    amountCategoryMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.AmountCategoryMasterTable;
                    IQNHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNHistoryLogTable;
                    VisaHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaHistoryLogTable;
                    APHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APHistoryLogTable;
                    EYPrivateBucket = CommonConstants.EYPrivateBucketforStage;
                    csrInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CSRTable;
                    VendorCodeDfmurnindex = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorCodeDfmUrnIndex;
                    configValueTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ConfigValueMasterTable;
                }
                context.Logger.Log($"{CloudEnvironment}");
                string[] objectKeySplited = objectKeyForFetchingVendorName.Split('/');
                #region Simplified GST changes 
                context.Logger.Log($"{objectKeyForFetchingVendorName}");
                //{bucketname}/EY

                if (objectKeySplited[0].ToLowerInvariant() == CommonConstants.EYcsvFile_FolderPath.ToLowerInvariant())
                {

                    context.Logger.Log($"Data :{objectKeySplited[0].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.EYcsvFile_FolderPath + "/", ""));
                    if (!fileName.Contains("CtrlLog"))
                    {
                        IDigiS3 s3 = new IDigiS3();
                        IDigiDynamoDb db = new IDigiDynamoDb();

                        var EYFile = await s3.GetFileFromS3(bucketName,
                        CommonConstants.EYcsvFile_FolderPath, fileName, context);
                        var RealEstateInvoiceData = new List<RealEstateInvoice>();
                        var GenericInvoiceData = new List<GenericInvoice>();
                        var IQNInvoiceData = new List<IQNInvoice>();
                        var UdaanInvoiceData = new List<UdaanInvoice>();
                        var ForexInvoiceData = new List<ForexInvoice>();
                        var APInvoiceData = new List<APInvoice>();
                        var csrInvoiceData = new List<CSRInvoice>();
                        List<EYData> EYDataList = new List<EYData>();                       

                        if (EYFile != null)
                        {
                            #region file reading part
                            using (var fs = new StreamReader(EYFile.ResponseStream))
                            {
                                EYData eyData = null;

                                var csv = new CsvReader(fs);
                                csv.Configuration.HasHeaderRecord = true;//CSV file from the DFM does  have Header 
                                csv.Configuration.Delimiter = "|";
                                string module = string.Empty;
                                string sapDocumentNumber = string.Empty;
                                string invoiceNumber = string.Empty;
                                string invoiceDate = string.Empty;
                                string accentureGSTIN = string.Empty;
                                string supplierGSTIN = string.Empty;
                                string taxableValue = string.Empty;
                                string cgstAmount = string.Empty;
                                string sgstAmount = string.Empty;
                                string igstAmount = string.Empty;
                                string matchingStatus = string.Empty;
                                string invoiceNumber2A = string.Empty;
                                string invoiceDate2A = string.Empty;
                                string accentureGSTIN2A = string.Empty;
                                string supplierGSTIN2A = string.Empty;
                                string taxableValue2A = string.Empty;
                                string cgstAmount2A = string.Empty;
                                string sgstAmount2A = string.Empty;
                                string igstAmount2A = string.Empty;
                                string reasonForMismatch = string.Empty;

                                context.Logger.Log($"Before entering the while loop");

                                while (csv.Read())
                                {
                                    eyData = new EYData();
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                    {
                                        eyData.module = csv.GetField<string>(0);
                                        context.Logger.Log($"module:{eyData.module}");
                                    }
                                    else
                                    {
                                        context.Logger.Log($"Log :module column is empty at row {csv.Row}");

                                    }
                                    if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                                    {
                                        eyData.sapDocumentNumber = csv.GetField<string>(1);
                                        context.Logger.Log($"sapDocumentNumber{eyData.sapDocumentNumber}");

                                    }
                                    else
                                    {
                                        // context.Logger.Log($"Log : sapDocumentNumber column is empty at row {csv.Row}");

                                    }

                                    if (!string.IsNullOrEmpty(csv.GetField<string>(2)))
                                    {
                                        eyData.invoiceNumber = csv.GetField<string>(2);
                                        context.Logger.Log($"invoiceNumber{eyData.invoiceNumber}");
                                    }
                                    else
                                    {
                                        // context.Logger.Log($"Error: The invoice number column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(3)))
                                    {
                                        eyData.invoiceDate = csv.GetField<string>(3);
                                        context.Logger.Log($"invoiceDate{eyData.invoiceDate}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The invoice Date column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(4)))
                                    {
                                        eyData.accentureGSTIN = csv.GetField<string>(4);
                                        context.Logger.Log($"accentureGSTIN{eyData.accentureGSTIN}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The accentureGSTIN column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(5)))
                                    {
                                        eyData.supplierGSTIN = csv.GetField<string>(5);
                                        context.Logger.Log($"supplierGSTIN{eyData.supplierGSTIN}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The supplierGSTIN column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(6)))
                                    {
                                        eyData.taxableValue = csv.GetField<string>(6);
                                        context.Logger.Log($"taxableValue{eyData.taxableValue}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The taxableValue column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(7)))
                                    {
                                        eyData.cgstAmount = csv.GetField<string>(7);
                                        context.Logger.Log($"cgstAmount{eyData.cgstAmount}");
                                    }
                                    else
                                    {
                                        // context.Logger.Log($"Error: The cgstAmountcolumn is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(8)))
                                    {
                                        eyData.sgstAmount = csv.GetField<string>(8);
                                        context.Logger.Log($"sgstAmount{eyData.sgstAmount}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: sgstAmount column is empty at:{csv.Row}");

                                    }

                                    if (!string.IsNullOrEmpty(csv.GetField<string>(9)))
                                    {
                                        eyData.igstAmount = csv.GetField<string>(9);
                                        context.Logger.Log($"igstAmount{eyData.igstAmount}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The igstAmount column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(10)))
                                    {
                                        eyData.matchingStatus = csv.GetField<string>(10);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The matchingStatus column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(11)))
                                    {
                                        eyData.invoiceNumber2A = csv.GetField<string>(11);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The invoiceNumber2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(12)))
                                    {
                                        eyData.invoiceDate2A = csv.GetField<string>(12);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The invoiceDate2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(13)))
                                    {
                                        eyData.accentureGSTIN2A = csv.GetField<string>(13);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The accentureGSTIN2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(14)))
                                    {
                                        eyData.supplierGSTIN2A = csv.GetField<string>(14);
                                    }
                                    else
                                    {
                                        // context.Logger.Log($"Error: The supplierGSTIN2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(15)))
                                    {
                                        eyData.taxableValue2A = csv.GetField<string>(15);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The taxableValue2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(16)))
                                    {
                                        eyData.cgstAmount2A = csv.GetField<string>(16);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The cgstAmount2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(17)))
                                    {
                                        eyData.sgstAmount2A = csv.GetField<string>(17);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The sgstAmount2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(18)))
                                    {
                                        eyData.igstAmount2A = csv.GetField<string>(18);
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The igstAmount2A column is empty at:{csv.Row}");

                                    }
                                    if (!string.IsNullOrEmpty(csv.GetField<string>(19)))
                                    {
                                        eyData.reasonForMismatch = csv.GetField<string>(19);
                                        context.Logger.Log($"reasonForMismatch{eyData.reasonForMismatch}");
                                    }
                                    else
                                    {
                                        //context.Logger.Log($"Error: The reasonForMismatch  column is empty at:{csv.Row}");
                                       // eyData.reasonForMismatch = string.Empty;
                                    }
                                    if (eyData.matchingStatus.ToLower() == "missing" || eyData.matchingStatus.ToLower().Contains("missing"))

                                    {

                                        eyData.matchingStatus = CommonConstants.GSTR2A_Missing_STATUS;
                                    }

                                    else if (eyData.matchingStatus.ToLower() == "match" || eyData.matchingStatus.ToLower() == "matched" || eyData.matchingStatus.ToLower().Contains("matched"))
                                    {

                                        eyData.matchingStatus = CommonConstants.GSTR2A_Matched_STATUS;
                                       

                                    }
                                    else if (eyData.matchingStatus.ToLower() == "mismatch" || eyData.matchingStatus.ToLower().Contains("mismatch"))
                                    {

                                        eyData.matchingStatus = CommonConstants.GSTR2A_Mismatched_STATUS;
                                        
                                    }
                                    context.Logger.Log($"Before add");
                                    EYDataList.Add(eyData);
                                   

                                        context.Logger.Log($"After add");

                                    context.Logger.Log($"EYData fetching....{JsonConvert.SerializeObject(eyData)}");

                                }
                            }
                            #endregion
                            #region Real estate
                            if (RealEstateInvoiceData != null && RealEstateInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"RealEstateInvoiceData fetching ....");
                                var scanFilterRealEstateTable = new ScanFilter();
                                scanFilterRealEstateTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanConfig.Filter = scanFilterRealEstateTable;
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "VendorGSTNumber", "InvoiceHistoryLogs", "GSTR2AStatus" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                RealEstateInvoiceData = await db.FilterScanSpecificAttribute<RealEstateInvoice>(scanConfig, RealEstateTableName);
                                context.Logger.Log($"Count of RealEstateInvoiceData fetched from db : {RealEstateInvoiceData.Count}");
                            }
                            var realEstateListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                             join invoiceData in RealEstateInvoiceData
                                                             on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                                             where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTNumber)) && gstr2aDatafromEy.supplierGSTIN == invoiceData.VendorGSTNumber)
                                                             select new RealEstateEYData
                                                             {
                                                                 GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                                 InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                                 VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                                 AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                                 VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                                 TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                                 CGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                                 SGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                                 IGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                                 ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                                 VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                                 VendorInvoiceNumber = invoiceData.VendorInvoiceNumber,//
                                                                 InvoiceHistoryLogs = invoiceData.InvoiceHistoryLogs
                                                             }).ToList();
                            
                            
                            Console.WriteLine($"realEstateListToBeUpdated : {JsonConvert.SerializeObject(realEstateListToBeUpdated)}");
                            foreach (var realEstateData in realEstateListToBeUpdated)
                            {
                                try
                                {
                                    
                                    //$"To update Logs only when GSTRA Matched"
                                    if (realEstateData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {

                                        realEstateData.ReasonforMismatch = "";
                                       
                                        context.Logger.LogLine($"GSTRA Matched for {realEstateData.VendorInvoiceNumber}");
                                        context.Logger.LogLine($"invoicedata : {JsonConvert.SerializeObject(realEstateData)}");
                                        InvoiceHistory invoiceHistoryLog = new InvoiceHistory()
                                        {
                                            InvoiceStatusCd = realEstateData.GSTR2AStatus,
                                            CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                                            CreateUserId = "SYSTEM",

                                        };
                                        context.Logger.LogLine($"invoiceHistoryLog :{JsonConvert.SerializeObject(invoiceHistoryLog)}");
                                        if (realEstateData != null)
                                        {
                                            if (realEstateData.InvoiceHistoryLogs != null)
                                            {
                                                realEstateData.InvoiceHistoryLogs.Add(invoiceHistoryLog);
                                            }
                                            else
                                            {
                                                List<InvoiceHistory> logs = new List<InvoiceHistory>();
                                                logs.Add(invoiceHistoryLog);
                                                realEstateData.InvoiceHistoryLogs.AddRange(logs);
                                            }

                                            context.Logger.LogLine($"invoice :{JsonConvert.SerializeObject(realEstateData)}");
                                        }
                                    }
                                    await db.UpdateItemAsync<RealEstateEYData>(realEstateData, RealEstateTableName, context);
                                    Console.WriteLine($"Updated the data for reals estate{JsonConvert.SerializeObject(realEstateData)}");
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }
                                context.Logger.Log($"RealEstate data updated for invoice number {realEstateData.VendorInvoiceNumber}");

                            }

                            #endregion
                            #region GENERIC
                            if (GenericInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"GenericInvoiceData fetching ....");
                                var scanFilterGenericTable = new ScanFilter();
                                scanFilterGenericTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanConfig.Filter = scanFilterGenericTable;
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "VendorGSTNumber", "GSTR2AStatus", "InvoiceHistoryLogs" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                GenericInvoiceData = await db.FilterScanSpecificAttribute<GenericInvoice>(scanConfig, GenericTableName);
                                context.Logger.Log($"GenericInvoiceData fetched from db : {GenericInvoiceData.Count}");
                            }
                            var genericListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                          join invoiceData in GenericInvoiceData
                                                          on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                                          where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTNumber)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.VendorGSTNumber.ToLowerInvariant())
                                                          select new GenericEYData
                                                          {
                                                              GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                              InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                              VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                              AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                              VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                              TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                              CGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                              SGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                              IGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                              ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                              VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                              VendorInvoiceNumber = invoiceData.VendorInvoiceNumber,//
                                                              InvoiceHistoryLogs = invoiceData.InvoiceHistoryLogs
                                                          }).ToList();

                            foreach (var genericData in genericListToBeUpdated)
                            {
                                try
                                {
                                    if (genericData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        genericData.ReasonforMismatch = "";
                                        context.Logger.LogLine($"GSTRA Matched for {genericData.VendorInvoiceNumber}");
                                        context.Logger.LogLine($"invoicedata : {JsonConvert.SerializeObject(genericData)}");
                                        //invoice = (from realdata in GenericInvoiceData
                                        //           where ((!string.IsNullOrEmpty(realdata.VendorInvoiceNumber) && realdata.VendorInvoiceNumber == eydata.invoiceNumber) && (!string.IsNullOrEmpty(realdata.VendorGSTNumber) && realdata.VendorGSTNumber == eydata.supplierGSTIN))
                                        //           select realdata).ToList().FirstOrDefault();
                                        context.Logger.LogLine($"invoice : {JsonConvert.SerializeObject(genericData)}");
                                        InvoiceHistory invoiceHistoryLog = new InvoiceHistory()
                                        {
                                            InvoiceStatusCd = genericData.GSTR2AStatus,
                                            CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                                            CreateUserId = "SYSTEM",

                                        };
                                        context.Logger.LogLine($"invoiceHistoryLog :{JsonConvert.SerializeObject(invoiceHistoryLog)}");
                                        if (genericData != null)
                                        {
                                            if (genericData.InvoiceHistoryLogs != null)
                                            {

                                                genericData.InvoiceHistoryLogs.Add(invoiceHistoryLog);

                                            }
                                            else
                                            {
                                                List<InvoiceHistory> logs = new List<InvoiceHistory>();
                                                logs.Add(invoiceHistoryLog);
                                                genericData.InvoiceHistoryLogs.AddRange(logs);
                                            }

                                            context.Logger.LogLine($"invoice :{JsonConvert.SerializeObject(genericData)}");
                                        }

                                    }
                                    await db.UpdateItemAsync<GenericEYData>(genericData, GenericTableName, context);
                                    context.Logger.Log($"Generic updated for invoice number {genericData.VendorInvoiceNumber}");
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }
                            }

                            #endregion
                            #region IQN
                            if (IQNInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"IQNInvoiceData fetching ....");
                                var scanFilterIQNTable = new ScanFilter();
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanFilterIQNTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "VendorGSTNumber", "GSTR2AStatus" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                scanConfig.Filter = scanFilterIQNTable;
                                IQNInvoiceData = await db.FilterScanSpecificAttribute<IQNInvoice>(scanConfig, IQNTableName);
                                context.Logger.Log($"IQNInvoiceData fetched from db : {IQNInvoiceData.Count}");
                            }
                            var iqnListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                      join invoiceData in IQNInvoiceData
                                                      on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                                      where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTNumber)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.VendorGSTNumber.ToLowerInvariant())
                                                      select new IQNEYData
                                                      {
                                                          GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                          InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                          VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                          AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                          VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                          TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                          CGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                          SGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                          IGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                          ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                          VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                          VendorInvoiceNumber = invoiceData.VendorInvoiceNumber//
                                                      }).ToList();
                            foreach (var invoiceData in iqnListToBeUpdated)
                            {
                                context.Logger.Log($"invoicedata -- {JsonConvert.SerializeObject(invoiceData)}");
                                if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                {
                                    invoiceData.ReasonforMismatch = "";
                                }
                                try
                                {
                                    await db.UpdateItemAsync<IQNEYData>(invoiceData, IQNTableName, context);
                                    context.Logger.Log($" updated  for invoice number {invoiceData.VendorInvoiceNumber}");
                                    if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        context.Logger.LogLine($"GSTRA Matched for {invoiceData.VendorInvoiceNumber}");


                                        await UpdateIQNorVisaHistoryLogTable(invoiceData.VendorRegisteredCd, invoiceData.VendorInvoiceNumber, invoiceData.GSTR2AStatus, context, IQNHistoryLogTable);
                                    }
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }

                            }


                            #endregion
                            #region VISA
                            if (UdaanInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"UdaanInvoiceData fetching ....");
                                var scanFilterRealUdaanTable = new ScanFilter();
                                scanFilterRealUdaanTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanConfig.Filter = scanFilterRealUdaanTable;
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "VendorCd", "VendorGSTNumber" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                UdaanInvoiceData = await db.FilterScanSpecificAttribute<UdaanInvoice>(scanConfig, VisaTableName);
                                context.Logger.Log($"UdaanInvoiceData fetched from db : {UdaanInvoiceData.Count}");
                            }

                            var invoicedata = (from gstr2aDatafromEy in EYDataList
                                               join invoiceData in UdaanInvoiceData
                                               on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                               where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTNumber)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.VendorGSTNumber.ToLowerInvariant())
                                               select new UdaanEYData
                                               {
                                                   GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                   InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                   VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                   AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                   VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                   TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),
                                                   CGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                   SGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                   IGSTAmtIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                   ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                   VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                   VendorInvoiceNumber = invoiceData.VendorInvoiceNumber,
                                                   VendorCd = invoiceData.VendorCd
                                               });

                            foreach (var invoice in invoicedata)
                            {
                                if (invoice.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                {
                                    invoice.ReasonforMismatch = "";
                                }
                                try
                                {
                                    await db.UpdateItemAsync<UdaanEYData>(invoice, VisaTableName, context);
                                    context.Logger.Log($" updated  for invoice number {invoice.VendorInvoiceNumber}");
                                    if (invoice.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        context.Logger.LogLine($"GSTRA Matched for {invoice.VendorInvoiceNumber}");
                                        await UpdateIQNorVisaHistoryLogTable(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, invoice.GSTR2AStatus, context, VisaHistoryLogTable);
                                    }
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }
                            }

                            #endregion
                            #region Forex
                            if (ForexInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"ForexInvoiceData fetching ....");
                                var scanFilterFOREXTable = new ScanFilter();
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanFilterFOREXTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "VendorGSTIN", "GSTR2AStatus" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                scanConfig.Filter = scanFilterFOREXTable;
                                ForexInvoiceData = await db.FilterScanSpecificAttribute<ForexInvoice>(scanConfig, ForexInvoiceTableName);
                                context.Logger.Log($"FOREXInvoiceData fetched from db : {ForexInvoiceData.Count}");
                            }
                            var forexListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                        join invoiceData in ForexInvoiceData
                                                        on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                                        where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTIN)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.VendorGSTIN.ToLowerInvariant())
                                                        select new ForexEYData
                                                        {
                                                            GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                            InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                            VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                            AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                            VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                            TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                            CGSTAmountIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                            SGSTAmountIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                            IGSTAmountIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                            ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                            VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                            VendorInvoiceNumber = invoiceData.VendorInvoiceNumber//
                                                        }).ToList();


                                foreach (var invoiceData in forexListToBeUpdated)
                            {
                                
                                context.Logger.Log($"invoicedata -- {JsonConvert.SerializeObject(invoiceData)}");
                                if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                {
                                    invoiceData.ReasonforMismatch ="";
                                }
                                    try
                                {
                                   
                                        
                                    
                                        await db.UpdateItemAsync<ForexEYData>(invoiceData, ForexInvoiceTableName, context);
                                    context.Logger.Log($" updated  for invoice number {invoiceData.VendorInvoiceNumber}");
                                    if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        context.Logger.LogLine($"GSTRA Matched for {invoiceData.VendorInvoiceNumber}");


                                        await UpdateIQNorVisaHistoryLogTable(invoiceData.VendorRegisteredCd, invoiceData.VendorInvoiceNumber, invoiceData.GSTR2AStatus, context, IQNHistoryLogTable);
                                    }
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }

                            }
                                
                            #endregion
                            #region AP
                            if (APInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"APInvoiceData fetching ....");
                                var scanFilterAPTable = new ScanFilter();
                                scanFilterAPTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanConfig.Filter = scanFilterAPTable;
                                scanConfig.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "VendorGSTNumber" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                APInvoiceData = await db.FilterScanSpecificAttribute<APInvoice>(scanConfig, APInvoiceTableName);
                                context.Logger.Log($"APInvoiceData fetched from db : {APInvoiceData.Count}");
                            }
                            var apListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                          join invoiceData in APInvoiceData
                                                          on gstr2aDatafromEy.invoiceNumber equals invoiceData.VendorInvoiceNumber
                                                          where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.VendorGSTNumber)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.VendorGSTNumber.ToLowerInvariant())
                                                          select new APEYData
                                                          {
                                                              GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                              InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                              VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                              AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                              VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                              TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                              CGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                              SGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                              IGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                              ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                              VendorRegisteredCd = invoiceData.VendorRegisteredCd,
                                                              VendorInvoiceNumber = invoiceData.VendorInvoiceNumber//
                                                                  }).ToList();
                            foreach (var invoiceData in apListToBeUpdated)
                            {
                                context.Logger.Log($"invoicedata -- {JsonConvert.SerializeObject(invoiceData)}");
                                if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                {
                                    invoiceData.ReasonforMismatch = "";
                                }
                                try
                                {
                                    await db.UpdateItemAsync<APEYData>(invoiceData, APInvoiceTableName, context);
                                    context.Logger.Log($" updated  for invoice number {invoiceData.VendorInvoiceNumber}");
                                    if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        context.Logger.LogLine($"GSTRA Matched for {invoiceData.VendorInvoiceNumber}");


                                        await UpdateIQNorVisaHistoryLogTable(invoiceData.VendorRegisteredCd, invoiceData.VendorInvoiceNumber, invoiceData.GSTR2AStatus, context, APHistoryLogTable);
                                    }
                                }
                                catch (Exception e)
                                {
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }

                            }
                            #endregion
                            #region CSR invoice data
                            if (csrInvoiceData.Count == 0)
                            {
                                context.Logger.Log($"CSR InvoiceData fetching ....");
                                var scanFilterCSRTable = new ScanFilter();
                                scanFilterCSRTable.AddCondition("GSTR2AStatus", ScanOperator.NotEqual, "GSTR2ANotRequired");
                                ScanOperationConfig scanConfig = new ScanOperationConfig();
                                scanConfig.Filter = scanFilterCSRTable;
                                scanConfig.AttributesToGet = new List<string>() { "VendorCd", "InvoiceNumber", "GSTR2AStatus", "PropertyGST" };
                                scanConfig.Select = SelectValues.SpecificAttributes;
                                csrInvoiceData = await db.FilterScanSpecificAttribute<CSRInvoice>(scanConfig, csrInvoiceTableName);
                                context.Logger.Log($"csr InvoiceData fetched from db : {csrInvoiceData.Count}");
                            }
                            var csrListToBeUpdated = (from gstr2aDatafromEy in EYDataList
                                                     join invoiceData in csrInvoiceData
                                                     on gstr2aDatafromEy.invoiceNumber equals invoiceData.InvoiceNumber
                                                     where ((!string.IsNullOrEmpty(gstr2aDatafromEy.supplierGSTIN) && !string.IsNullOrEmpty(invoiceData.PropertyGST)) && gstr2aDatafromEy.supplierGSTIN.ToLowerInvariant() == invoiceData.PropertyGST.ToLowerInvariant())
                                                     select new CSREYData
                                                     {
                                                         GSTR2AStatus = gstr2aDatafromEy.matchingStatus,
                                                         InvoiceDtIn2A = gstr2aDatafromEy.invoiceDate2A,
                                                         VendorInvoiceNumberIn2A = gstr2aDatafromEy.invoiceNumber2A,
                                                         AccentureGSTINIn2A = gstr2aDatafromEy.accentureGSTIN2A,
                                                         VendorGSTNumberIn2A = gstr2aDatafromEy.supplierGSTIN2A,
                                                         TaxableValueIn2A = Convert.ToDouble(gstr2aDatafromEy.taxableValue2A),//change to TaxableValueIn2A
                                                         CGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.cgstAmount2A),
                                                         SGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.sgstAmount2A),
                                                         IGSTIn2A = Convert.ToDouble(gstr2aDatafromEy.igstAmount2A),
                                                         ReasonforMismatch = gstr2aDatafromEy.reasonForMismatch,
                                                         VendorCd = invoiceData.VendorCd,
                                                         InvoiceNumber = invoiceData.InvoiceNumber//
                                                     }).ToList();
                            foreach (var invoiceData in csrListToBeUpdated)
                            {
                                context.Logger.Log($"invoicedata -- {JsonConvert.SerializeObject(invoiceData)}");
                                if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                {
                                    invoiceData.ReasonforMismatch = "";
                                }
                                try
                                {
                                    await db.UpdateItemAsync<CSREYData>(invoiceData, csrInvoiceTableName, context);
                                    context.Logger.Log($" updated  for invoice number {invoiceData.InvoiceNumber}");
                                    if (invoiceData.GSTR2AStatus.ToLower() == CommonConstants.GSTR2A_Matched_STATUS.ToLower())
                                    {
                                        context.Logger.LogLine($"GSTRA Matched for {invoiceData.InvoiceNumber}");

                                        //there is no history data we are capturing for csr
                                        
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine($"Exception occured in while updating the gstr2a data for CSR");
                                    context.Logger.LogLine($"{e.Message}");
                                    context.Logger.LogLine($"{e.InnerException}");

                                }

                            }
                            #endregion

                        }
                        else
                        {
                            context.Logger.Log($"There is no contents in CSV file-- EYFile");
                        }
                        string renamedFileName = RenameFile(fileName);
                        context.Logger.LogLine($"renamedFileName : {renamedFileName}");
                        context.Logger.LogLine($"EYPrivateBucket : {EYPrivateBucket}");
                        await s3.CopyFileFromOneFolderToOther(bucketName, EYPrivateBucket, CommonConstants.EYcsvFile_FolderPath, CommonConstants.EYPrivatePath, fileName, renamedFileName, context);
                        await s3.DeleteFile(bucketName, CommonConstants.EYcsvFile_FolderPath, fileName, context);
                    }
                    else
                    {
                        Console.WriteLine("File is GSTR2AReconCtrlLog, Hence, not reading..!!");
                    }
                    return;
                }


                #endregion

                #region NDC Payment Status Update
                context.Logger.LogLine($"{objectKeySplited[0]}");
                //publicpath {bucketname}/MySupplierPortal
                // path : /private/ndc/ndcpaymentstatuscsv ndcpayment
                if (objectKeySplited[0].ToLowerInvariant() == CommonConstants.NDCPaymentStatusUpdate_FilePath.ToLowerInvariant())
                {
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    Console.WriteLine("invoked NDCPaymentStatus Update");
                    IDigiS3 S3 = new IDigiS3();
                    string FileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(CommonConstants.NDCPaymentStatusUpdate_FilePath + "/", ""));
                    context.Logger.LogLine($"Start :{context.FunctionName} has invoked in {CloudEnvironment} environment by {FileName}");
                    Console.WriteLine("bucketName - " + bucketName + " , Ndc Payment Status Update - " + CommonConstants.NDCPaymentStatusUpdate_FilePath + " , FileName - " + FileName);
                    var csvFileData = await S3.GetFileFromS3(bucketName, CommonConstants.NDCPaymentStatusUpdate_FilePath, FileName, context);
                    Console.WriteLine("NDCPaymentStatusUpdate- got file from s3");
                    var GenericInvoiceData = new GenericInvoice();
                    var IQNInvoiceData = new IQNInvoice();
                    var UdaanInvoiceData = new UdaanInvoice();
                    var RealEstateInvoiceData = new RealEstateInvoice();
                    var APInvoiceData = new APInvoice();
                    var ForexInvoiceData = new ForexInvoice();
                    var CwtInvoiceData = new CWTInvoice();
                    List<PaymentData> paymentDataList = new List<PaymentData>();

                    List<string> attributesToGetFromVendorTable = new List<string>() { "VendorId", "VendorCode", "VendorCd" };
                    ScanOperationConfig scanOperationConfigForVendormaster = new ScanOperationConfig()
                    {
                        Select = SelectValues.SpecificAttributes,
                        AttributesToGet = attributesToGetFromVendorTable
                    };
                    var vendorMasterdetails = await ScanAndFindTheInvoice<VendorMaster>(new VendorMaster(), vendorMasterTableName, scanOperationConfigForVendormaster);

                    if (csvFileData != null)
                    {
                        using (var csvReadData = new System.IO.StreamReader(csvFileData.ResponseStream))
                        {
                            Console.WriteLine($"Process: Now StreamReader is reading the data from the file {FileName}");
                            var csv = new CsvHelper.CsvReader(csvReadData);
                            csv.Configuration.HasHeaderRecord = true;

                            DateTime datetime;
                            PaymentData pd = null;

                            while (csv.Read())
                            {
                                pd = new PaymentData();
                                pd.VendorRegisteredCd = csv.GetField<string>(0);

                                pd.VendorInvoiceNumber = csv.GetField<string>(1);

                                pd.PaymentStatus = csv.GetField<string>(4);
                                pd.NDCInvoiceStatus = csv.GetField<string>(4);
                                pd.ScheduledPaymentDt = csv.GetField<string>(5);

                                pd.WireId = csv.GetField<string>(6);

                                pd.PaymentDt = csv.GetField<string>(7);                                

                                if (!string.IsNullOrEmpty(pd.PaymentDt))
                                {
                                    if (DateTime.TryParseExact(pd.PaymentDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                    {
                                        pd.PaymentDt = DateTime.ParseExact(pd.PaymentDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff");
                                    }
                                }
                                //context.Logger.Log($"Log :paymentdt column after conversion {pd.paymentdt}");
                                if (!string.IsNullOrEmpty(pd.ScheduledPaymentDt))
                                {
                                    if (DateTime.TryParseExact(pd.ScheduledPaymentDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                    {
                                        pd.ScheduledPaymentDt = DateTime.ParseExact(pd.ScheduledPaymentDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff");
                                    }
                                }


                                paymentDataList.Add(pd);

                                // context.Logger.Log($"payment Data fetching....{JsonConvert.SerializeObject(pd)}");
                            }
                        }

                        context.Logger.Log($"Count of Payment data....{paymentDataList.Count}");
                        List<UdaanInvoice> udaanAllInvoiceDetails = new List<UdaanInvoice>();
                        List<GenericInvoice> newGenericTableData = new List<GenericInvoice>();
                        List<RealEstateInvoice> realEstateInvoicesDetails = new List<RealEstateInvoice>();
                        List<IQNInvoice> iqnAllInvoiceDetails = new List<IQNInvoice>();
                        List<APInvoice> apAllInvoiceDetails = new List<APInvoice>();
                        List<ForexInvoice> forexAllInvoiceDetails = new List<ForexInvoice>();
                        List<CWTInvoice> cwtAllInvoiceDetails = new List<CWTInvoice>();
                        foreach (var item in paymentDataList)
                        {

                            if (!string.IsNullOrWhiteSpace(item.VendorRegisteredCd) && !string.IsNullOrWhiteSpace(item.VendorInvoiceNumber))
                            {
                                // vendor registered code from the my supplier always contains the zero as prefix in iqn we are expecting zero in prefix not in other modules
                                string vendorCodeForIqn = item.VendorRegisteredCd;

                                if (item.VendorRegisteredCd.Length >= 10)
                                {

                                    item.VendorRegisteredCd = item.VendorRegisteredCd.Substring(1);
                                    Console.WriteLine($"{ item.VendorRegisteredCd}");
                                }

                                    if (IsVendorCodeBelongToParticularModule(("0" + item.VendorRegisteredCd.ToLowerInvariant()), vendorMasterdetails, "IQN VENDOR"))
                                    {
                                    Console.WriteLine($"Found one iqn invoice");
                                        #region IQN Invoice
                                        if (iqnAllInvoiceDetails != null && iqnAllInvoiceDetails.Count == 0)
                                        {
                                            var scanFilterForIQN = new ScanFilter();
                                            List<String> attibutesToGetFromIQNTbale = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber" };
                                            ScanOperationConfig scanOperationConfigForIQN = new ScanOperationConfig()
                                            {
                                                Select = SelectValues.SpecificAttributes,
                                                Filter = scanFilterForIQN,
                                                AttributesToGet = attibutesToGetFromIQNTbale
                                            };
                                            iqnAllInvoiceDetails = await ScanAndFindTheInvoice<IQNInvoice>(new IQNInvoice(), IQNTableName, scanOperationConfigForIQN);
                                            Console.WriteLine($"Total incoice count in IQN {iqnAllInvoiceDetails.Count}");
                                        }
                                    var iqnInvoices = iqnAllInvoiceDetails.Where(i => i.VendorRegisteredCd ==item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);
                                    var iqnInvoices2 = iqnAllInvoiceDetails.Where(i => i.VendorRegisteredCd == "0" + item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);
                                    iqnInvoices = iqnInvoices.Concat(iqnInvoices2);
                                    foreach (var invoice in iqnInvoices)
                                        {
                                            await UpdatePaymentData(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, IQNTableName);
                                        }

                                        #endregion
                                    }
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails, "FOREX VENDOR"))
                                    {
                                    Console.WriteLine($"Found one forex invoice");
                                        #region Forex Invoice
                                    if (forexAllInvoiceDetails != null && forexAllInvoiceDetails.Count == 0)
                                    {
                                        var scanFilterForForex = new ScanFilter();
                                        List<String> attibutesToGetFromForexTbale = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber" };
                                        ScanOperationConfig scanOperationConfigForForex = new ScanOperationConfig()
                                        {
                                            Select = SelectValues.SpecificAttributes,
                                            Filter = scanFilterForForex,
                                            AttributesToGet = attibutesToGetFromForexTbale
                                        };
                                        forexAllInvoiceDetails = await ScanAndFindTheInvoice<ForexInvoice>(new ForexInvoice(), ForexInvoiceTableName, scanOperationConfigForForex);
                                        Console.WriteLine($"Total incoice count in Forex {forexAllInvoiceDetails.Count}");
                                    }
                                    var forexInvoices = forexAllInvoiceDetails.Where(i => i.VendorRegisteredCd == item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);
                                    foreach (var invoice in forexInvoices)
                                    {
                                        await UpdatePaymentData(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, ForexInvoiceTableName);
                                    }

                                    #endregion
                                    }
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails, "AP VENDOR"))
                                    {
                                    Console.WriteLine($"Found one AP invoice");
                                        #region AP Invoice
                                    if (apAllInvoiceDetails != null && apAllInvoiceDetails.Count == 0)
                                    {
                                        var scanFilterForAP = new ScanFilter();                                        
                                        List<String> attibutesToGetFromApTable = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber" };                                        
                                        ScanOperationConfig scanOperationConfigForAP = new ScanOperationConfig()
                                        {
                                            Select = SelectValues.SpecificAttributes,
                                            Filter = scanFilterForAP,
                                            AttributesToGet = attibutesToGetFromApTable
                                        };                                        
                                        apAllInvoiceDetails = await ScanAndFindTheInvoice<APInvoice>(new APInvoice(), APInvoiceTableName, scanOperationConfigForAP);                                        
                                        Console.WriteLine($"Total incoice count in AP {apAllInvoiceDetails.Count}");                                       
                                    }
                                    var apInvoices = apAllInvoiceDetails.Where(i => i.VendorRegisteredCd == item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);                                    
                                    var apInvoice2= apAllInvoiceDetails.Where(i => i.VendorRegisteredCd == "0"+ item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);                                    
                                    apInvoices = apInvoices.Concat(apInvoice2);                                    
                                    foreach (var invoice in apInvoices)
                                    {                                        
                                        await UpdatePaymentData(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, APInvoiceTableName);                                        
                                    }                                    
                                    #endregion
                                    }
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails, "GRN VENDOR"))
                                    {
                                        #region Generic Invoice

                                        if (newGenericTableData != null && newGenericTableData.Count == 0)
                                        {
                                            List<string> attributeTogetFromNewGenericTable = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber" };
                                            var scanFilterGenericNewTable = new ScanFilter();
                                            ScanOperationConfig scnaOperationConfigNEwGenericTable = new ScanOperationConfig()
                                            {
                                                Select = SelectValues.SpecificAttributes,
                                                Filter = scanFilterGenericNewTable,
                                                AttributesToGet = attributeTogetFromNewGenericTable
                                            };
                                            newGenericTableData = await ScanAndFindTheInvoice<GenericInvoice>(new GenericInvoice(), GenericTableName, scnaOperationConfigNEwGenericTable);
                                            Console.WriteLine($"Total incoice count in generic {newGenericTableData.Count}");
                                        }
                                        var genericInvoice = newGenericTableData.Where(i => i.VendorRegisteredCd == item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber).ToList();
                                        foreach (var i in genericInvoice)
                                        {
                                            await UpdatePaymentData(i.VendorRegisteredCd, i.VendorInvoiceNumber, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, GenericTableName);
                                        }

                                        #endregion
                                    }
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails,"UDN VENDOR"))
                                    {
                                        #region Udaan Invoice
                                        if (udaanAllInvoiceDetails != null && udaanAllInvoiceDetails.Count == 0)
                                        {
                                            var scanFilterForUdaan = new ScanFilter();
                                            List<String> attibutesToGetFromUdaanTbale = new List<string>() { "VendorCd", "VendorRegisteredCd", "VendorInvoiceNumber" };
                                            ScanOperationConfig scanOperationConfigForUdaan = new ScanOperationConfig()
                                            {
                                                Select = SelectValues.SpecificAttributes,
                                                Filter = scanFilterForUdaan,
                                                AttributesToGet = attibutesToGetFromUdaanTbale
                                            };
                                            udaanAllInvoiceDetails = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), VisaTableName, scanOperationConfigForUdaan);
                                            Console.WriteLine($"Total incoice count in visa {udaanAllInvoiceDetails.Count}");
                                        }

                                        Console.WriteLine("Fetched udaan data record");
                                        await FetchUdaanInvoiceAndUpdateDFMUrn(item.VendorInvoiceNumber, item.VendorRegisteredCd, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, VisaTableName, context, udaanAllInvoiceDetails);
                                        Console.WriteLine("Updated belongs to module udaan module ");
                                        #endregion
                                    }
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails, "REAL VENDOR"))
                                    {
                                        #region RE Invoice
                                        if (realEstateInvoicesDetails != null && realEstateInvoicesDetails.Count == 0)
                                        {
                                            List<string> attributesToGetFromRealEstateInvoices = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber" };
                                            var scanfilterRealEstateVendor = new ScanFilter();
                                            ScanOperationConfig scanOperationConfigForRealEstateVendor = new ScanOperationConfig()
                                            {
                                                Select = SelectValues.SpecificAttributes,
                                                Filter = scanfilterRealEstateVendor,
                                                AttributesToGet = attributesToGetFromRealEstateInvoices

                                            };
                                            realEstateInvoicesDetails = await ScanAndFindTheInvoice<RealEstateInvoice>(new RealEstateInvoice(), RealEstateTableName, scanOperationConfigForRealEstateVendor);
                                            Console.WriteLine($"Total incoice count in Real estate {realEstateInvoicesDetails.Count}");
                                        }
                                        var realEstateInvoice = realEstateInvoicesDetails.Where(i => i.VendorRegisteredCd == item.VendorRegisteredCd && i.VendorInvoiceNumber == item.VendorInvoiceNumber);
                                        foreach (var invoice in realEstateInvoice)
                                        {
                                            await UpdatePaymentData(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, RealEstateTableName);
                                        }
                                        #endregion
                                    }                                                            
                                    if (IsVendorCodeBelongToParticularModule(item.VendorRegisteredCd.ToLowerInvariant(), vendorMasterdetails, "CWT VENDOR"))
                                    {                                    
                                    Console.WriteLine($"Found one CWT invoice");
                                        #region CWT Invoice
                                    if (cwtAllInvoiceDetails != null && cwtAllInvoiceDetails.Count == 0)
                                    {                                       
                                        var scanFilterForCWT = new ScanFilter();                                        
                                        List<String> attibutesToGetFromCWTTbale = new List<string>() { "VendorCd", "VendorInvoiceCRNo" };
                                        ScanOperationConfig scanOperationConfigForCWT = new ScanOperationConfig()
                                        {
                                            Select = SelectValues.SpecificAttributes,
                                            Filter = scanFilterForCWT,
                                            AttributesToGet = attibutesToGetFromCWTTbale
                                        };
                                        cwtAllInvoiceDetails = await ScanAndFindTheInvoice<CWTInvoice>(new CWTInvoice(), CWTInvoiceTableName, scanOperationConfigForCWT);
                                        Console.WriteLine($"Total incoice count in CWT {cwtAllInvoiceDetails.Count}");
                                    }
                                    Console.WriteLine("Fetched CWT data record");
                                    //await FetchCWTInvoiceAndUpdateDFMUrn(item.VendorInvoiceCRNo, item.VendorCd, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, CWTInvoiceTableName, context, cwtAllInvoiceDetails);
                                    //Console.WriteLine("Updated belongs to module CWT module ");
                                    var cwtInvoices = cwtAllInvoiceDetails.Where(i => i.VendorInvoiceCRNo == item.VendorInvoiceNumber);
                                    foreach (var invoice in cwtInvoices)
                                    {
                                        await UpdatePaymentDataCWT(invoice.VendorCd, invoice.VendorInvoiceCRNo, item.PaymentStatus, item.WireId, item.ScheduledPaymentDt, item.PaymentDt, CWTInvoiceTableName);
                                    }
                                    Console.WriteLine("Updated data belongs to CWT module");
                                    #endregion
                                }
                                else
                                    {
                                        Console.WriteLine($"Invoice number doesnot belong to any module {item.VendorRegisteredCd},{item.VendorInvoiceNumber}");
                                    }
                                }                            
                            else
                            {
                                context.Logger.Log($"Vendor Registered Code and Vendor Invoice Number are empty");

                            }

                        }
                    }
                    else
                    {
                        context.Logger.Log($"There is no contents in CSV file-- Payment Data");

                    }

                    string renamedFileName = RenameFile(FileName);
                    await S3.CopyFileFromOneFolderToOther(bucketName, bucketName, CommonConstants.NDCPaymentStatusUpdate_FilePath, CommonConstants.ndc_FileFolder, FileName, renamedFileName, context);
                    await S3.DeleteFile(bucketName, CommonConstants.NDCPaymentStatusUpdate_FilePath, FileName, context);
                    return;
                }
                #endregion

                #region POTransaction csv upload part

                if (objectKeySplited[2].ToLowerInvariant() == CommonConstants.PO_FileFolder.ToLowerInvariant())
                {
                    context.Logger.Log($"Data :{objectKeySplited[2].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.Procurement_POTrasaction_FilePath + "/", ""));
                    IDigiS3 s3 = new IDigiS3();
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal, CommonConstants.POTrans_FileModuleCd);
                    scanFilter.AddCondition("HeaderColType", ScanOperator.Equal,
                        CommonConstants.POTrans_CSVFile_HeaderColType);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList =
                        await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);
                    var poTransactioFile = await s3.GetFileFromS3(bucketName,
                        CommonConstants.Procurement_POTrasaction_FilePath, fileName, context);
                    List<POTransaction> poTransactionList = new List<POTransaction>();
                    string fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                        .ToString("MM/dd/yyyy HH:mm");
                   var configValue=await db.GetItem(configValueTable, "TCSBufferInPO", "Generic");
                   var configValueObject = IDigiDynamoDocumentConverter.ToObject<ConfigValueEntities>(configValue);

                    if (string.IsNullOrEmpty(configValueObject.ConfigValue))
                    {
                        context.Logger.Log($"Buffer % :{configValueObject.ConfigValue}");
                    }

                    using (var fs = new StreamReader(poTransactioFile.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        POTransaction poTransaction = null;
                        context.Logger.Log($"Before entering the while loop");
                        while (csv.Read())
                        {
                            poTransaction = new POTransaction();
                            poTransaction = ReadCSVDataBasedOnIndexRequired<POTransaction>(csv, poTransaction,
                                fileColsDBColsMappingList, context);
                            if (poTransaction != null && !string.IsNullOrEmpty(poTransaction.PONumber))
                            {
                                poTransaction.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                                    .ToString("MM/dd/yyyy HH:mm");
                                poTransaction.CreatedBy = CommonConstants.ProcurementTeam;
                                poTransaction.UpdatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                                    .ToString("MM/dd/yyyy HH:mm");


                                
                                if (null == poTransaction.OpenValue)
                                {
                                    //-- this means x is null
                                }
                                else if (poTransaction.OpenValue.GetValueOrDefault() == 0)
                                {
                                    //-- this means x is either null or 0 value
                                }
                                else
                                {
                                    //-- this means x is neither null nor 0, it has some value other than 0

                                    if (configValueObject.ConfigValue != null)
                                    {
                                      double bufferPercentage=  double.Parse(configValueObject.ConfigValue);

                                        poTransaction.OpenValue = poTransaction.OpenValue + ((bufferPercentage / 100)* poTransaction.OpenValue);
                                    }
                                   

                             
                                }

                                
                                poTransaction.FileUploadedDttm = fileUploadedDttm;
                                poTransactionList.Add(poTransaction);
                            }
                        }

                        context.Logger.Log($"out side while");
                        //InvokeRequest invoceRequest = new InvokeRequest();
                        //invoceRequest.FunctionName = dataInserterLambda;
                        //invoceRequest.InvocationType = InvocationType.Event;
                        context.Logger.Log($"before null check , list count{poTransactionList.Count}");

                        if (poTransactionList != null && poTransactionList.Count > 0)
                        {
                            context.Logger.Log("Data : inside the delete and insert loop");
                            int potransactionId = 0;
                            Stopwatch sw = new Stopwatch();
                            sw.Start();
                            List<POTransaction> potransactionTotalList = await DeleteTheDataFromPoTranscationTable(poTransactionTable, context);
                            DateTime datebeforeDelete = DateTime.UtcNow;

                            context.Logger.Log($"Data :Time difference between delete operation {sw.ElapsedMilliseconds / 1000} seconds / {sw.Elapsed}");
                            context.Logger.Log($"Data :Deleted all the data from table");
                            int nextIndex = 0;
                            int poTransactionIdToBePassed = 0;

                            var filteredlistCount = poTransactionList.RemoveAll(item => string.IsNullOrEmpty(item.LineItem) || string.IsNullOrEmpty(item.SupplierID) || string.IsNullOrEmpty(item.PONumber));

                            if (filteredlistCount != null && filteredlistCount != 0)
                            {
                                Console.WriteLine($"Po data has some empty entries @modatory fields {filteredlistCount}");
                            }

                            // var distinctPolist=  poTransactionList.DistinctBy(item => new  {item.SupplierID, item.PONumber, item.LineItem });



                            var filteredData = poTransactionList.Select(item =>
                            {
                                item.POLineItem = item.PONumber + "-" + item.LineItem;
                                return item;
                            });

                            int tenThousandsCount = 0;
                            Table table = Table.LoadTable(DbClient, poTransactionTable);
                            Stopwatch sw1 = new Stopwatch();
                            sw1.Start();
                            DocumentBatchWrite batchInsertItem = table.CreateBatchWrite();
                            int documentInserted = 0;
                            foreach (var potransaction in filteredData)
                            {

                                batchInsertItem.AddDocumentToPut(IDigiDynamoDocumentConverter.ToDocument(potransaction));
                                documentInserted = documentInserted + 1;
                                if (documentInserted == 25)
                                {
                                    await batchInsertItem.ExecuteAsync();
                                    batchInsertItem = table.CreateBatchWrite();
                                    documentInserted = 0;
                                }
                                tenThousandsCount = tenThousandsCount + 1;
                                //await table.PutItemAsync(IDigiDynamoDocumentConverter.ToDocument(potransaction));
                                if (tenThousandsCount == 10000)
                                {
                                    Console.WriteLine($"Data: Time taken for inserting 10000 records  {sw1.ElapsedMilliseconds / 1000} seconds");
                                    sw1.Restart();
                                    tenThousandsCount = 0;
                                }
                            }
                            if (documentInserted != 0)
                            {
                                await batchInsertItem.ExecuteAsync();
                                batchInsertItem = table.CreateBatchWrite();
                                documentInserted = 0;
                            }
                            Console.WriteLine($"Data : Time taken to insert the {tenThousandsCount} items {sw1.ElapsedMilliseconds / 1000} seconds");

                            #region Old Insertion Code
                            //if (poTransactionList.Count >= 100)
                            //{
                            //    int thousandsMultiple = poTransactionList.Count / 100;
                            //    int lessOrMoreThanThousandFiles = poTransactionList.Count % 100;
                            //    if (thousandsMultiple > 0)
                            //    {
                            //        for (int i = 0; i < thousandsMultiple; i++)
                            //        {
                            //            context.Logger.Log($"Data :Total number of iterations {thousandsMultiple}");
                            //            context.Logger.Log($"Iteration count {i}");
                            //            if (i == 0)
                            //            {
                            //                if (potransactionId==0)
                            //                {
                            //                    nextIndex = 0;
                            //                    poTransactionIdToBePassed = 0;
                            //                }
                            //                else
                            //                {
                            //                    //nextIndex = potransactionId;
                            //                    poTransactionIdToBePassed = potransactionId;
                            //                }

                            //            }
                            //            List<POTransaction> poTrasactionListCopy = poTransactionList.GetRange(nextIndex, 100);
                            //            DataToDynamoDb dataToDynamodb = new DataToDynamoDb()
                            //            {
                            //                POTransactionList = poTrasactionListCopy,
                            //                //InitialPOtransactionId = nextIndex + 1,
                            //                InitialPOtransactionId = poTransactionIdToBePassed + 1

                            //            };
                            //            context.Logger.Log($"starting index passed{poTransactionIdToBePassed + 1}");
                            //            invoceRequest.Payload = JsonConvert.SerializeObject(dataToDynamodb);
                            //            context.Logger.Log($"data insertion payload size{invoceRequest.Payload.Count()}");
                            //            var childLmbdaResponse = LambdaClient.InvokeAsync(invoceRequest);
                            //            nextIndex = nextIndex + 100;
                            //            poTransactionIdToBePassed = poTransactionIdToBePassed + 100;
                            //            LogChildLambdaResponse(childLmbdaResponse, context);                                       
                            //        }
                            //        if (lessOrMoreThanThousandFiles > 0)
                            //        {
                            //            context.Logger.Log($"Data: Remaining files{lessOrMoreThanThousandFiles}");
                            //            List<POTransaction> poTrasactionListCopy = poTransactionList.GetRange(nextIndex, lessOrMoreThanThousandFiles);
                            //            DataToDynamoDb dataToDynamodb = new DataToDynamoDb()
                            //            {
                            //                POTransactionList = poTrasactionListCopy,
                            //                InitialPOtransactionId = poTransactionIdToBePassed + 1
                            //            };
                            //            context.Logger.Log($"starting index passed{poTransactionIdToBePassed + 1}");
                            //            invoceRequest.Payload = JsonConvert.SerializeObject(dataToDynamodb);
                            //            var childLmbdaResponse = LambdaClient.InvokeAsync(invoceRequest);
                            //            LogChildLambdaResponse(childLmbdaResponse, context);
                            //        }
                            //    }
                            //}
                            //else                                                     //less than hundreds files condition
                            //{
                            //    context.Logger.Log($"Data :Count when the list is less than 100{poTransactionList.Count}");
                            //    DataToDynamoDb dataToDynamodb = new DataToDynamoDb()
                            //    {
                            //        POTransactionList = poTransactionList,
                            //        InitialPOtransactionId = potransactionId + 1
                            //    };
                            //    context.Logger.Log($"Data :Starting index passed{potransactionId + 1}");
                            //    invoceRequest.Payload = JsonConvert.SerializeObject(dataToDynamodb);
                            //    var childLmbdaResponse = LambdaClient.InvokeAsync(invoceRequest);
                            //    LogChildLambdaResponse(childLmbdaResponse, context);
                            //}
                            #endregion
                        }
                    }
                    return;
                }

                #endregion

                #region VendorMaster csv upload part

                if (objectKeySplited[2].ToLowerInvariant() ==
                    CommonConstants.VendorMaster_FileFolder.ToLowerInvariant())
                {
                    context.Logger.Log($"Data :{objectKeySplited[2].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.Procurement_VendorMaster_FilePath + "/", ""));
                    IDigiS3 s3 = new IDigiS3();
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal,
                        CommonConstants.VendorMaster_FileModuleCd);
                    scanFilter.AddCondition("HeaderColType", ScanOperator.Equal,
                        CommonConstants.VendorMaster_CSVFile_HeaderColType);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList =
                        await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);
                    var vendorMasterCSVFile = await s3.GetFileFromS3(bucketName,
                        CommonConstants.Procurement_VendorMaster_FilePath, fileName, context);

                    using (var fs = new StreamReader(vendorMasterCSVFile.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        VendorMaster vendorMaster = null;
                        while (csv.Read())
                        {
                            vendorMaster = new VendorMaster();
                            var data = ReadCSVDataBasedOnIndexRequired<VendorMaster>(csv, vendorMaster,
                                fileColsDBColsMappingList, context);

                            if (data != null)
                            {
                                context.Logger.Log($"reading one row is complete ");
                                data.VendorGroupObjectDetailId = 2;
                                data.IsActive = "True";
                                data.VendorCd = "GRN VENDOR";
                                data.ADGObjectDetailId = "28";
                                data.RoleObjectDetailId = "35";
                                data.RoleTypeObjectDetailId = "40";
                                data.RedirectURL = "/Generic/vendorinvoicedashboard";
                                data.VendorNm = data.Name1;
                                data.VendorMailId = data.Email;
                                data.CreatedBy = CommonConstants.ProcurementTeam;
                                data.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                                    .ToString("MM/dd/yyyy HH:mm");
                                data.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                                    .ToString("MM/dd/yyyy HH:mm");
                                if (data.VendorClassification == 0 || data.VendorClassification == 1 || data.VendorClassification == 2)
                                {
                                    data.IsExempted = "Exempted";
                                    data.GSTR2AVendorCategory = "Exempted";
                                }
                                if (data.VendorClassification == 3 || data.VendorClassification == 4 || data.VendorClassification == 5 || data.VendorClassification == 6)
                                {
                                    data.IsExempted = "NotApplicable";
                                    data.GSTR2AVendorCategory = "NotApplicable";
                                }
                                if (data.VendorCriticalityCategory.ToLower() == "critical")
                                    data.IsCritical = CommonConstants.IsCritical_Critical_Category;
                                if (data.VendorCriticalityCategory.ToLower() == "noncritical" || data.VendorCriticalityCategory.ToLower() == "non-critical" || string.IsNullOrEmpty(data.VendorCriticalityCategory))
                                    data.IsCritical =CommonConstants.IsCritical_NonCritical_Category;
                                await CheckTheVendorCodeExistInVendorMasterTable(data, vendorMasterTable, context);
                            }

                        }
                    }
                    return;
                }

                #endregion

                #region Approved exception csv upload part

                if (objectKeySplited[2].ToLowerInvariant() ==
                    CommonConstants.ApprovedException_FileFolder.ToLowerInvariant())
                {
                    context.Logger.Log($"Data :{objectKeySplited[2].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.Procurement_ApprovedException_FilePath + "/", ""));
                    context.Logger.Log($"{fileName}");
                    IDigiS3 s3 = new IDigiS3();
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal,
                        CommonConstants.ApprovedException_FileModuleCd);
                    scanFilter.AddCondition("HeaderColType", ScanOperator.Equal,
                        CommonConstants.ApprovedException_CSVFile_HeaderColType);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList =
                        await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);
                    var approvedExceptionCSVFile = await s3.GetFileFromS3(bucketName,
                        CommonConstants.Procurement_ApprovedException_FilePath, fileName, context);
                    using (var fs = new StreamReader(approvedExceptionCSVFile.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        csv.Configuration.HasHeaderRecord = true;
                        ApprovedException approvedException = new ApprovedException();
                        while (csv.Read())
                        {
                            var approvedExceptionObj = ReadCSVDataBasedOnIndexRequired<ApprovedException>(csv,
                                approvedException, fileColsDBColsMappingList, context);
                            context.Logger.Log($"Reading one row is complete ");
                            if (approvedExceptionObj != null)
                            {
                                if (!string.IsNullOrEmpty(approvedExceptionObj.VendorRegisteredCd) &&
                                    !string.IsNullOrEmpty(approvedException.VendorInvoiceNumber))
                                {
                                    context.Logger.Log($"{approvedExceptionObj.VendorRegisteredCd}");
                                    approvedExceptionObj.InvoiceSubmittedFlag = "N";
                                    approvedExceptionObj.CreatedDttm = TimeZoneInfo
                                        .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    approvedExceptionObj.ModifiedDttm = TimeZoneInfo
                                        .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    if (!string.IsNullOrEmpty(approvedExceptionObj.InvoiceDt))
                                    {
                                        if (approvedExceptionObj.InvoiceDt.Contains('/'))
                                        {
                                            var splitedDate = approvedExceptionObj.InvoiceDt.Split('/');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[0].Length == 1)
                                                {
                                                    splitedDate[0] = "0" + splitedDate[0];
                                                }

                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }

                                                approvedExceptionObj.InvoiceDt =
                                                    splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                            }
                                        }
                                    }

                                    await CheckTheDuplicateEntryInTheApprovedExceptionAndInsertData(
                                        approvedExceptionObj, approvedExceptionTable, context);
                                }
                            }
                        }
                    }
                    return;
                }

                #endregion

                #region cwt etravel data

                //private/cwt/etravel
                if (objectKeySplited[2].ToLowerInvariant() ==
                    CommonConstants.CWTEtravelData_FilePath.ToLowerInvariant())
                {
                    try
                    {
                        context.Logger.Log($"Data :{objectKeySplited[2].ToLowerInvariant()}");
                        string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                            .Replace(CommonConstants.Procurement_CWTEtravelData_FilePath + "/", ""));
                        IDigiS3 s3 = new IDigiS3();
                        IDigiDynamoDb db = new IDigiDynamoDb();
                        ScanFilter scanFilter = new ScanFilter();
                        scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal,
                            CommonConstants.CWTEtravelData_FileModuleCd);
                        scanFilter.AddCondition("HeaderColType", ScanOperator.Equal,
                            CommonConstants.CWTEtravelData_CSVFile_HeaderColType);
                        scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                        List<FileColsDBColsMapping> fileColsDBColsMappingList =
                            await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);
                        var cwtEtravelDataFile = await s3.GetFileFromS3(bucketName,
                            CommonConstants.Procurement_CWTEtravelData_FilePath, fileName, context);
                        string fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                            .ToString("MM/dd/yyyy HH:mm");
                        
                        Table table = Table.LoadTable(DbClient, cwtEtravelDataTable);
                        int totalCount = 0;
                        int iterationCount = 0;
                        using (var fs = new StreamReader(cwtEtravelDataFile.ResponseStream))
                        {
                            var csv = new CsvReader(fs);
                            csv.Configuration.HasHeaderRecord = true;
                            CwtEtravelData cwtEtravelData = new CwtEtravelData();
                            while (csv.Read())
                            {
                                var cwtEtravelDataObj = ReadCSVDataBasedOnIndexRequired<CwtEtravelData>(csv, cwtEtravelData,
                                    fileColsDBColsMappingList, context);

                                //cwtEtravelDataObj.DepDate;
                                if( !string.IsNullOrEmpty(cwtEtravelDataObj.TDDepDate) && cwtEtravelDataObj.TDDepDate.ToLower() != "null")
                                {
                                    if (cwtEtravelDataObj.TDDepDate.Contains("/"))
                                    {
                                        cwtEtravelDataObj.TDDepDate = ConvertDateTime(cwtEtravelDataObj.TDDepDate);
                                    }
                                    else
                                    {
                                        cwtEtravelDataObj.TDDepDate = null;
                                    }
                                }
                                else
                                {
                                    cwtEtravelDataObj.TDDepDate = null;
                                }

                                if (!string.IsNullOrEmpty(cwtEtravelDataObj.DepDate) && cwtEtravelDataObj.DepDate.ToLower() != "null")
                                {
                                    if (cwtEtravelDataObj.DepDate.Contains("/"))
                                    {
                                        cwtEtravelDataObj.DepDate = ConvertDateTime(cwtEtravelDataObj.DepDate);
                                    }
                                    else
                                    {
                                        cwtEtravelDataObj.DepDate = null;
                                    }
                                }
                                else
                                {
                                    cwtEtravelDataObj.DepDate = null;
                                }

                                if (!string.IsNullOrEmpty(cwtEtravelDataObj.RequestedOn) && cwtEtravelDataObj.RequestedOn.ToLower() != "null")
                                {
                                    if (cwtEtravelDataObj.RequestedOn.Contains("/"))
                                    {
                                        cwtEtravelDataObj.RequestedOn = ConvertDateTime(cwtEtravelDataObj.RequestedOn);
                                    }
                                    else
                                    {
                                        cwtEtravelDataObj.RequestedOn = null;
                                    }
                                }
                                else
                                {
                                    cwtEtravelDataObj.RequestedOn = null;
                                }

                                if (!string.IsNullOrEmpty(cwtEtravelDataObj.TicketNo))
                                {
                                    StringBuilder sb = new StringBuilder();
                                    if (cwtEtravelDataObj.TicketNo.Contains(","))
                                    {
                                        var commaSaparatedTickets = cwtEtravelDataObj.TicketNo.Split(",");
                                        int count = 0;
                                        foreach (var ticket in commaSaparatedTickets)
                                        {
                                            
                                            var splittedTicket = ticket.Split('-');
                                            if (splittedTicket.Length == 2)
                                            {
                                                if (!string.IsNullOrEmpty(splittedTicket[1]))
                                                {
                                                    if (!string.IsNullOrEmpty(sb.ToString()))
                                                    {
                                                        sb.Append(",");

                                                    }
                                                    sb.Append(splittedTicket[1]);
                                                                                                  
                                                }
                                                else
                                                {
                                                   // cwtEtravelDataObj.TicketNo = null;
                                                }
                                            }
                                        }
                                        if (!string.IsNullOrEmpty(sb.ToString()))
                                        {
                                            cwtEtravelDataObj.TicketNo = sb.ToString();
                                        }
                                        else
                                        {
                                            cwtEtravelDataObj.TicketNo = null;
                                        }                                       
                                    }
                                    else
                                    {
                                        var splitedTicketNumber = cwtEtravelDataObj.TicketNo.Split('-');
                                        if (splitedTicketNumber.Length == 2)
                                        {
                                            if (!string.IsNullOrEmpty(splitedTicketNumber[1]))
                                            {
                                                cwtEtravelDataObj.TicketNo = splitedTicketNumber[1];
                                            }
                                            else
                                            {
                                                cwtEtravelDataObj.TicketNo = null;
                                            }
                                        }
                                    }
                                }

                                if (cwtEtravelDataObj != null)
                                {
                                    if (!string.IsNullOrEmpty(cwtEtravelDataObj.RequestId.ToString()))
                                    {
                                        //context.Logger.Log($"now inserting data {JsonConvert.SerializeObject(cwtEtravelDataObj)}");
                                        cwtEtravelDataObj.IsTrCopyGenerated = "N";
                                        cwtEtravelDataObj.CreatedBy = CommonConstants.EtravelJob;
                                        cwtEtravelDataObj.CreatedDttm = TimeZoneInfo
                                            .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        cwtEtravelDataObj.ModifiedBy = TimeZoneInfo
                                            .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        var doc = IDigiDynamoDocumentConverter.ToDocument(cwtEtravelDataObj);
                                        await table.PutItemAsync(doc); //asynchronous call for inserting the data
                                        totalCount++;
                                        iterationCount++;
                                        if (iterationCount ==100)
                                        {
                                            Console.WriteLine($"{iterationCount} got insrted/updated in db");
                                            iterationCount = 0;
                                        }
                                    }
                                }                             
                            }
                            if (iterationCount != 0)
                            {
                                Console.WriteLine($"{iterationCount} got insrted/updated in db");
                                iterationCount = 0;
                            }
                            if (totalCount != 0)
                            {
                                Console.WriteLine($"Total item got inserted/updated in db {totalCount}");
                            }

                        }
                    }
                    catch (Exception e)
                    {
                        //Console.WriteLine($"Exception occured while reading andinserting etravel data {JsonConvert.SerializeObject(e)}");
                        Console.WriteLine($"{e.Message}");
                        Console.WriteLine($"{e.InnerException}");
                        Console.WriteLine($"{e.StackTrace}");
                    }
                    return;
                }

                #endregion

                #region Real estate Approved exception csv upload part

                if (objectKeySplited[2].ToLowerInvariant() ==
                    CommonConstants.RealEstateApprovedException_FileFolder.ToLowerInvariant())
                {
                    context.Logger.Log($"Data :{objectKeySplited[2].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.Procurement_RealEstateApprovedException_FilePath + "/", ""));
                    context.Logger.Log($"{fileName}");
                    IDigiS3 s3 = new IDigiS3();
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal,
                        CommonConstants.ApprovedException_FileModuleCd);
                    scanFilter.AddCondition("HeaderColType", ScanOperator.Equal,
                        CommonConstants.ApprovedException_CSVFile_HeaderColType);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList =
                        await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);
                    var approvedExceptionCSVFile = await s3.GetFileFromS3(bucketName,
                        CommonConstants.Procurement_RealEstateApprovedException_FilePath, fileName, context);
                    using (var fs = new StreamReader(approvedExceptionCSVFile.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        csv.Configuration.HasHeaderRecord = true;
                        RealEstateApprovedExceptionInvoices approvedException =
                            new RealEstateApprovedExceptionInvoices();
                        while (csv.Read())
                        {
                            var approvedExceptionObj =
                                ReadCSVDataBasedOnIndexRequired<RealEstateApprovedExceptionInvoices>(csv,
                                    approvedException, fileColsDBColsMappingList, context);
                            context.Logger.Log($"Reading one row is complete ");
                            if (approvedExceptionObj != null)
                            {
                                if (!string.IsNullOrEmpty(approvedExceptionObj.VendorRegisteredCd) &&
                                    !string.IsNullOrEmpty(approvedException.VendorInvoiceNumber))
                                {
                                    context.Logger.Log($"{approvedExceptionObj.VendorRegisteredCd}");
                                    approvedExceptionObj.InvoiceSubmittedFlag = "N";
                                    approvedExceptionObj.CreatedDttm = TimeZoneInfo
                                        .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    approvedExceptionObj.ModifiedDttm = TimeZoneInfo
                                        .ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                    if (!string.IsNullOrEmpty(approvedExceptionObj.InvoiceDt))
                                    {
                                        if (approvedExceptionObj.InvoiceDt.Contains('/'))
                                        {
                                            var splitedDate = approvedExceptionObj.InvoiceDt.Split('/');
                                            if (splitedDate.Length == 3)
                                            {
                                                if (splitedDate[0].Length == 1)
                                                {
                                                    splitedDate[0] = "0" + splitedDate[0];
                                                }

                                                if (splitedDate[1].Length == 1)
                                                {
                                                    splitedDate[1] = "0" + splitedDate[1];
                                                }
                                                approvedExceptionObj.InvoiceDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                            }
                                        }
                                    }
                                    await CheckTheDuplicateEntryInTheRealEsateApprovedExceptionTableAndInsertData(approvedExceptionObj, approvedExceptionTable, context);
                                }
                            }
                        }
                    }
                    return;
                }
                #endregion

                #region Airline credittaken flag update

                if (objectKeySplited[2].ToLowerInvariant() ==
                    CommonConstants.AirlineCreditTakenUpdateCsvFoplder.ToLowerInvariant())
                {
                    context.Logger.Log($"Data from file :{objectKeySplited[2].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.AirlineCreditTaken_FilePath + "/", ""));
                    IDigiS3 s3 = new IDigiS3();
                    IDigiDynamoDb db = new IDigiDynamoDb();

                    ScanFilter scanFilter = new ScanFilter();
                    List<AirlineInvoiceDetails> airlineData =
                        await db.ScanAsync<AirlineInvoiceDetails>(scanFilter, airlineInvoiceDataTable, context);

                    var airlineCreditTakenCsv = await s3.GetFileFromS3(bucketName,
                        CommonConstants.AirlineCreditTaken_FilePath, fileName, context);


                    List<AirlineCreditTaken> listOfData = new List<AirlineCreditTaken>();
                    using (var fs = new StreamReader(airlineCreditTakenCsv.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        csv.Configuration.HasHeaderRecord = true;
                        AirlineInvoiceDetails airline =
                            new AirlineInvoiceDetails();
                        AirlineCreditTaken airlineCreditTaken = null;
                        while (csv.Read())
                        {

                            airlineCreditTaken = new AirlineCreditTaken();
                            airlineCreditTaken.InvoiceNumber = csv.GetField<string>(0);
                            airlineCreditTaken.PNR = csv.GetField<string>(1);
                            airlineCreditTaken.TicketNumber = csv.GetField<string>(2);
                            airlineCreditTaken.CreditTakenDate = csv.GetField<string>(3);

                            if (!string.IsNullOrEmpty(airlineCreditTaken.CreditTakenDate))
                            {
                                airlineCreditTaken.CreditTakenDate = ConvertAirlineDateTime(airlineCreditTaken.CreditTakenDate);
                            }
                            if (!string.IsNullOrEmpty(airlineCreditTaken.InvoiceNumber) && !string.IsNullOrEmpty(airlineCreditTaken.CreditTakenDate))
                            {
                                listOfData.Add(airlineCreditTaken);
                            }
                            else
                            {
                                Console.WriteLine($"Modatory  collums are missing in csv ,row number{csv.Row}");
                            }

                        }
                    }
                    if (listOfData == null && listOfData.Count == 0)
                    {
                        Console.WriteLine($"CSV Doesnot Contain meaningfull data ");
                        return;
                    }
                    var distinctDataInCsv = listOfData.DistinctBy(x => x.InvoiceNumber).ToList();
                    var duplicateDatainCSV = listOfData.Except(distinctDataInCsv);
                    //duplicate in csv
                    if (duplicateDatainCSV != null && duplicateDatainCSV.Count() > 0)
                    {
                        Console.WriteLine($"Duplicate entries in csv is there");
                        //Console.WriteLine($"Duplicate entries in csv {JsonConvert.SerializeObject(duplicateDatainCSV)}");
                    }
                    //distinct in csv
                    if (distinctDataInCsv != null && distinctDataInCsv.Count > 0)
                    {
                        Console.WriteLine($"Distinct entries in csv is there");
                        // Console.WriteLine($"Distinct entries in csv {JsonConvert.SerializeObject(distinctDataInCsv)}");
                    }

                    var matchingAirLineData = from airline in airlineData
                                              join dataFromCsv in distinctDataInCsv
                                              on new { a1 = airline.InvoiceNbr, a2 = airline.CreditTaken } equals new { a1 = dataFromCsv.InvoiceNumber, a2 = "N" }
                                              where
                                              ((!string.IsNullOrEmpty(dataFromCsv.PNR) && !string.IsNullOrEmpty(dataFromCsv.TicketNumber)) ?
                                              (airline.PNR == dataFromCsv.PNR && airline.TicketNbr == dataFromCsv.TicketNumber) :
                                              (!string.IsNullOrEmpty(dataFromCsv.TicketNumber) ? airline.TicketNbr == dataFromCsv.TicketNumber :
                                              (!string.IsNullOrEmpty(dataFromCsv.PNR) ? airline.PNR == dataFromCsv.PNR : true)))
                                              select new AirlineInvoiceDetails
                                              {
                                                  VendorCd = airline.VendorCd,
                                                  InvoiceKey = airline.InvoiceKey,
                                                  InvoiceNbr = airline.InvoiceNbr,
                                                  CreditDttm = dataFromCsv.CreditTakenDate,

                                              };

                    if (matchingAirLineData != null && matchingAirLineData.Count() > 0)
                    {
                        Console.WriteLine($"Data entries which are ready to be updated in table ");
                    }
                    //invoices which have data in table but their credit taken is already Y
                    var matchingAirLineDataButCreditTakenFlag = from airline in airlineData
                                                                join dataFromCsv in distinctDataInCsv
                                                                on new { a1 = airline.InvoiceNbr, a2 = airline.CreditTaken } equals new { a1 = dataFromCsv.InvoiceNumber, a2 = "Y" }
                                                                where
                                                                ((!string.IsNullOrEmpty(dataFromCsv.PNR) && !string.IsNullOrEmpty(dataFromCsv.TicketNumber)) ?
                                                                (airline.PNR == dataFromCsv.PNR && airline.TicketNbr == dataFromCsv.TicketNumber) :
                                                                (!string.IsNullOrEmpty(dataFromCsv.TicketNumber) ? airline.TicketNbr == dataFromCsv.TicketNumber :
                                                                (!string.IsNullOrEmpty(dataFromCsv.PNR) ? airline.PNR == dataFromCsv.PNR : true)))
                                                                select airline;


                    if (matchingAirLineDataButCreditTakenFlag != null && matchingAirLineDataButCreditTakenFlag.Count() > 0)
                    {
                        Console.WriteLine($"Data entries where creaditaken flag is already Y  is there ");
                        //Console.WriteLine($"Data entries where creaditaken flag is already Y  is there /*{JsonConvert.SerializeObject(matchingAirLineDataButCreditTakenFlag)}*/");
                    }

                    var matchingInvoiceNumber = matchingAirLineData.Select(i => i.InvoiceNbr);
                    var notMatchingData = matchingAirLineDataButCreditTakenFlag.Select(j => j.InvoiceNbr);
                    var totalInvoiceNumber = distinctDataInCsv.Select(i => i.InvoiceNumber);
                    var wholeData = matchingInvoiceNumber.Concat(notMatchingData);
                    var dataNotThereInTable = totalInvoiceNumber.Except(wholeData);

                    if (dataNotThereInTable != null && dataNotThereInTable.Count() > 0)
                    {
                        Console.WriteLine($"Data entries whose data not in table is there");
                        //Console.WriteLine($"Data entries whose data not in table {JsonConvert.SerializeObject(dataNotavailableInTable)}");
                    }

                    MemoryStream stream2 = new MemoryStream();
                    using (var package = new ExcelPackage(new MemoryStream()))
                    {

                        Console.WriteLine("Process: inside excel genaration");
                        var workbook = package.Workbook;
                        var worksheet = workbook.Worksheets.Add("duplicateDatainCSV");
                        worksheet.Cells.LoadFromCollection(duplicateDatainCSV);

                        var worksheet2 = workbook.Worksheets.Add("distinctDataInCsv");
                        worksheet2.Cells.LoadFromCollection(distinctDataInCsv);

                        var worksheet3 = workbook.Worksheets.Add("matchingAirLineData");
                        worksheet3.Cells.LoadFromCollection(matchingAirLineData);

                        var worksheet4 = workbook.Worksheets.Add("matchingAirLineDataButCreditTakenFlagY");
                        worksheet4.Cells.LoadFromCollection(matchingAirLineDataButCreditTakenFlag);

                        var worksheet5 = workbook.Worksheets.Add("dataNotavailableInTable");
                        worksheet5.Cells.LoadFromCollection(dataNotThereInTable);

                        package.SaveAs(stream2);

                    }

                    Console.WriteLine($"Process: genarating new excel completed");

                    var s3Response2 = await S3Client.PutObjectAsync(new PutObjectRequest
                    {
                        BucketName = bucketName + "/" + CommonConstants.AirlineCreditTaken_FilePath,
                        Key = "AirlineCreditakenLogs" +
                              TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MMddyyyyHHmm") + ".xlsx",
                        InputStream = stream2
                    });
                    Console.WriteLine($"file has been saved  {bucketName + "/" + CommonConstants.AirlineCreditTaken_FilePath}/AirlineCreditakenLogs");




                    if (matchingAirLineData != null && matchingAirLineData.Count() > 0)
                    {
                        foreach (var dataFromCsv in matchingAirLineData)
                        {


                            await UpdateItem(airlineInvoiceDataTable, dataFromCsv.VendorCd, dataFromCsv.InvoiceKey, dataFromCsv.CreditDttm);

                            //var airlineInvoice = from airline in airlineData
                            //    where (dataFromCsv.InvoiceNumber == airline.InvoiceNbr && airline.CreditTaken != "Y" &&
                            //           (dataFromCsv.PNR != null && dataFromCsv.PNR == airline.PNR) &&
                            //           (dataFromCsv.TicketNumber != null && dataFromCsv.TicketNumber == airline.TicketNbr)) select airline ;      
                            //if (airlineInvoice != null && airlineInvoice.Count()>0)
                            //{
                            //    foreach (var invoice in airlineInvoice)
                            //    {
                            //        if (airlineInvoice.Count()>1)
                            //        {
                            //            Console.WriteLine($"Found multiple invoice {JsonConvert.SerializeObject(airlineInvoice)}");
                            //        }

                            //        await UpdateItem(airlineInvoiceDataTable, invoice.VendorCd,invoice.InvoiceKey, dataFromCsv.CreditTakenDate);
                            //    }                             
                            //}
                            //else
                            //{
                            //    Console.WriteLine($"Invoice is not found {JsonConvert.SerializeObject(dataFromCsv)}");
                            //}
                        }
                    }
                    else
                    {
                        Console.WriteLine($"There is no data to update");
                    }
                    return;
                }

                #endregion

                #region GSTR2A Matching

                if (objectKeySplited[1].ToLowerInvariant() ==
                   CommonConstants.GSTR2ACsvfolderPath.ToLowerInvariant())
                {
                    context.Logger.Log($"Data :{objectKeySplited[1].ToLowerInvariant()}");
                    string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '))
                        .Replace(CommonConstants.GSTR2A_FilePath + "/", ""));
                    IDigiS3 s3 = new IDigiS3();

                    IDigiDynamoDb db = new IDigiDynamoDb();
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal, CommonConstants.GSTR2A_FileModuleCd);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList =
                        await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);

                    ScanFilter scanFilter2 = new ScanFilter();
                    List<AmountCategoryMaster> amountCategoryMasterList =
                        await db.ScanAsync<AmountCategoryMaster>(scanFilter2, amountCategoryMasterTable, context);
                    var sortedAmtCatList = amountCategoryMasterList.OrderByDescending(i => i.SorttId);
                    string uploadedBy = fileName.Split('_')[1].ToString();

                    var gstr2aFile =
                        await s3.GetFileFromS3(bucketName, CommonConstants.GSTR2A_FilePath, fileName, context);
                    List<GSTR2AInvoice> gstr2aList = new List<GSTR2AInvoice>();

                    string fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                        .ToString("yyyy-MM-dd HH:mm:ss.fff");

                    using (var fs = new StreamReader(gstr2aFile.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        GSTR2AInvoice gstr2a = null;
                        context.Logger.Log($"Before entering the while loop");
                        while (csv.Read())
                        {
                            gstr2a = new GSTR2AInvoice();
                            gstr2a = ReadCSVDataBasedOnIndexRequired<GSTR2AInvoice>(csv, gstr2a,
                                fileColsDBColsMappingList, context);
                            if (gstr2a != null && !string.IsNullOrEmpty(gstr2a.VendorRegisteredCd))
                            {
                                if (!string.IsNullOrEmpty(gstr2a.IssueCategory))
                                {
                                    if (gstr2a.IssueCategory.ToLowerInvariant().Contains("gstr2a"))
                                    {
                                        gstr2a.IssueCategory = "Not found in GSTR2A";
                                    }
                                    else if (gstr2a.IssueCategory.ToLowerInvariant().Contains("single"))
                                    {
                                        gstr2a.IssueCategory = "Mismatch Cases - Single";
                                    }
                                    else if (gstr2a.IssueCategory.ToLowerInvariant().Contains("multiple"))
                                    {
                                        gstr2a.IssueCategory = "Mismatch Multiple issue";
                                    }
                                    else if (gstr2a.IssueCategory.ToLowerInvariant().Contains("purchase"))
                                    {

                                        gstr2a.IssueCategory = "Not found in Purchase register";
                                        if (string.IsNullOrEmpty(gstr2a.VendorInvoiceNumber))
                                        {
                                            if (!string.IsNullOrEmpty(gstr2a.VendorInvoiceNumberIn2A))
                                            {
                                                gstr2a.VendorInvoiceNumber = gstr2a.VendorInvoiceNumberIn2A;
                                            }
                                            else
                                            {
                                                Console.WriteLine($"Data error :Required field invoice no does not contains data , skipping this line item{gstr2a.VendorRegisteredCd}/{gstr2a.VendorInvoiceNumber}");
                                                continue;
                                            }

                                        }
                                    }

                                }
                                else
                                {
                                    Console.WriteLine($"Data error :Required field IssueCategory does not contains data , skipping this line item{gstr2a.VendorRegisteredCd}/{gstr2a.VendorInvoiceNumber}");
                                    continue;
                                }

                                if (!string.IsNullOrEmpty(gstr2a.InvoiceDt))
                                {

                                    if (!gstr2a.InvoiceDt.Contains("/") && gstr2a.InvoiceDt.Length == 7)
                                    {
                                        gstr2a.InvoiceDt = "0" + gstr2a.InvoiceDt;
                                    }
                                    DateTime datetime;
                                    if (DateTime.TryParseExact(gstr2a.InvoiceDt, "ddMMyyyy", CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out datetime))
                                    {
                                        var temp = DateTime
                                            .ParseExact(gstr2a.InvoiceDt, "ddMMyyyy", CultureInfo.InvariantCulture)
                                            .ToString("yyyy-MM-dd HH:mm:ss.fff");

                                        gstr2a.InvoiceDt = temp;
                                    }
                                    else if (DateTime.TryParseExact(gstr2a.InvoiceDt, "dMMyyyy", CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out datetime))
                                    {
                                        var temp = DateTime
                                            .ParseExact(gstr2a.InvoiceDt, "dMMyyyy", CultureInfo.InvariantCulture)
                                            .ToString("yyyy-MM-dd HH:mm:ss.fff");

                                        gstr2a.InvoiceDt = temp;
                                    }
                                    else
                                    {
                                        Console.WriteLine($"Data error :Required field InvoiceDt does not has data in proper format , skipping this line item {gstr2a.VendorRegisteredCd}/{gstr2a.VendorInvoiceNumber}");
                                        continue;
                                    }
                                }
                                else
                                {
                                    if (gstr2a.IssueCategory == "Not found in Purchase register" && !string.IsNullOrEmpty(gstr2a.InvoiceDtIn2A))
                                    {
                                        //if category is Not found in Purchase register then add the InvoiceDate in 2a in to the invoice date collum

                                    }
                                    else
                                    {
                                        Console.WriteLine($"Data error :Required field InvoiceDt does not has data , skipping this line item{gstr2a.VendorRegisteredCd}/{gstr2a.VendorInvoiceNumber}");
                                        continue;
                                    }

                                }

                                if (!string.IsNullOrEmpty(gstr2a.InvoiceDtIn2A))
                                {

                                    if (!gstr2a.InvoiceDtIn2A.Contains("/") && gstr2a.InvoiceDtIn2A.Length == 7)
                                    {
                                        gstr2a.InvoiceDtIn2A = "0" + gstr2a.InvoiceDtIn2A;
                                    }

                                    DateTime datetime;
                                    if (DateTime.TryParseExact(gstr2a.InvoiceDtIn2A, "ddMMyyyy", CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out datetime))
                                    {
                                        var temp = DateTime
                                             .ParseExact(gstr2a.InvoiceDtIn2A, "ddMMyyyy", CultureInfo.InvariantCulture)
                                             .ToString("yyyy-MM-dd HH:mm:ss.fff");

                                        gstr2a.InvoiceDtIn2A = temp;
                                    }
                                    else if (DateTime.TryParseExact(gstr2a.InvoiceDtIn2A, "dMMyyyy", CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out datetime))
                                    {
                                        var temp = DateTime
                                             .ParseExact(gstr2a.InvoiceDtIn2A, "dMMyyyy", CultureInfo.InvariantCulture)
                                             .ToString("yyyy-MM-dd HH:mm:ss.fff");

                                        gstr2a.InvoiceDtIn2A = temp;
                                    }
                                    else
                                    {
                                        gstr2a.InvoiceDtIn2A = null;
                                    }
                                    if (gstr2a.IssueCategory == "Not found in Purchase register" && string.IsNullOrEmpty(gstr2a.InvoiceDt))
                                    {
                                        //if category is Not found in Purchase register then add the InvoiceDate in 2a in to the invoice date collum
                                        gstr2a.InvoiceDt = gstr2a.InvoiceDtIn2A;
                                    }
                                }
                                double baseAmtForCompr = 0; //default value
                                if (gstr2a.BaseAmt.GetValueOrDefault() == 0)
                                {
                                    if (gstr2a.BaseAmtIn2A.GetValueOrDefault() == 0)
                                    {
                                        gstr2a.BaseAmtForCompr = 0;
                                    }
                                    else
                                    {
                                        gstr2a.BaseAmtForCompr = gstr2a.BaseAmtIn2A;
                                    }
                                }
                                else
                                {
                                    gstr2a.BaseAmtForCompr = gstr2a.BaseAmt;
                                }
                                baseAmtForCompr = Math.Abs(Convert.ToDouble(gstr2a.BaseAmtForCompr)); // convert to double 

                                foreach (var amtCat in sortedAmtCatList)
                                {

                                    if (amtCat.MaxAmt == -1) // more than crore till infinity!!??
                                    {
                                        if (baseAmtForCompr >= amtCat.MinAmt)
                                        {
                                            gstr2a.AmtCategory = amtCat.CategoryNm;
                                        }
                                    }
                                    else
                                    {

                                        if (baseAmtForCompr >= amtCat.MinAmt && baseAmtForCompr < amtCat.MaxAmt)
                                        {
                                            gstr2a.AmtCategory = amtCat.CategoryNm;
                                        }
                                    }

                                }
                                gstr2a.IsRTPDownloaded = "N";
                                gstr2a.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE)
                                    .ToString("yyyy-MM-dd HH:mm:ss.fff");
                                gstr2a.CreatedBy = uploadedBy;
                                //gstr2a.ModifiedBy = uploadedBy;
                                if (!string.IsNullOrEmpty(gstr2a.VendorRegisteredCd) && !string.IsNullOrEmpty(gstr2a.VendorInvoiceNumber) && !string.IsNullOrEmpty(gstr2a.IssueCategory))
                                {
                                    gstr2aList.Add(gstr2a);
                                }

                            }
                        }
                    }

                    var distinctInvoiceList = gstr2aList.DistinctBy(i => new { i.VendorRegisteredCd, i.VendorInvoiceNumber });
                    var duplicates = gstr2aList.Except(distinctInvoiceList);
                    if (duplicates != null && duplicates.Count() > 0)
                    {
                        Console.WriteLine($"Data error: has duplicate data {JsonConvert.SerializeObject(duplicates)}");
                    }

                    if (distinctInvoiceList.Count() > 0)
                    {
                        await DeleteTheDataFromGSTR2ATable(gstr2aTable, context, bucketName,
                            CommonConstants.GSTR2A_FilePath);


                        int tenThousandsCount = 0;
                        Table table = Table.LoadTable(DbClient, gstr2aTable);
                        Stopwatch sw1 = new Stopwatch();
                        sw1.Start();
                        DocumentBatchWrite batchInsertItem = table.CreateBatchWrite();
                        int documentInserted = 0;
                        foreach (var gstr2a in distinctInvoiceList)
                        {

                            batchInsertItem.AddDocumentToPut(IDigiDynamoDocumentConverter.ToDocument(gstr2a));
                            documentInserted = documentInserted + 1;
                            if (documentInserted == 25)
                            {
                                await batchInsertItem.ExecuteAsync();
                                batchInsertItem = table.CreateBatchWrite();
                                documentInserted = 0;
                            }


                            tenThousandsCount = tenThousandsCount + 1;
                            if (tenThousandsCount == 10000)
                            {
                                Console.WriteLine(
                                    $"Data: Time taken for inserting 10000 records  {sw1.ElapsedMilliseconds / 1000} seconds");
                                sw1.Restart();
                                tenThousandsCount = 0;
                            }
                        }
                        if (batchInsertItem != null && documentInserted > 0)
                        {
                            await batchInsertItem.ExecuteAsync();
                        }
                        Console.WriteLine($"Data : Time taken to insert the {tenThousandsCount} items {sw1.ElapsedMilliseconds / 1000} seconds");
                    }
                    return;
                }

                #endregion

                #region Post Approval Rejection
                // path : /public/PostApprovalRejection 
                if (objectKeySplited[1].ToLowerInvariant() == CommonConstants.S3_Post_ApprovalRejection_Path.ToLowerInvariant())
                { 
                    Console.WriteLine("invoked post approval rejection part of lambda");
                    IDigiS3 S3 = new IDigiS3();
                    string FileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(CommonConstants.PARFolder_FilePath + "/", ""));
                    context.Logger.LogLine($"Start :{context.FunctionName} has invoked in {CloudEnvironment} environment by {FileName}");
                    Console.WriteLine("bucketName - " + bucketName + " , PARcsvdumpFolder - " + CommonConstants.PARFolder_FilePath + " , FileName - " + FileName);
                    var csvFileData = await S3.GetFileFromS3(bucketName, CommonConstants.PARFolder_FilePath, FileName, context);
                    Console.WriteLine("PAR- got file from s3");
                    var allGenericInvoiceData = new List<GenericInvoice>();
                    var allIQNInvoiceData = new List<Models.PAR.IQNPAR>();
                    var allUdaanInvoiceData = new List<Models.PAR.UdaanPAR>();
                    var allRealEstateInvoiceData = new List<RealEstateInvoice>();
                    var allAPInvoiceData = new List<APInvoice>();
                    var allForexInvoiceData = new List<ForexPAR>();
                    //if (FileName.Contains("Generic"))
                    //{
                    //    var scanFilterGenericTable = new ScanFilter();
                    //    scanFilterGenericTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
                    //    ScanOperationConfig scanOperationConfigGenericTable = new ScanOperationConfig()
                    //    {
                    //        Filter = scanFilterGenericTable,
                    //        Select = SelectValues.SpecificAttributes,
                    //        AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile", "BusinessPlaceId", "GSTID" }
                    //    };
                    //    allGenericInvoiceData = await ScanAndFindTheInvoice<GenericInvoice>(new GenericInvoice(), GenericTableName, scanOperationConfigGenericTable);
                    //    Console.WriteLine("Fetched generic data - rtp Received");
                    //}
                    if (FileName.Contains("IQN"))
                    {
                        var scanFilterIQNTable = new ScanFilter();
                        scanFilterIQNTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
                        ScanOperationConfig scanOperationConfigIQNTable = new ScanOperationConfig()
                        {
                            Filter = scanFilterIQNTable,
                            Select = SelectValues.SpecificAttributes,
                            AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd" , "AttachedFile", "BusinessPlaceId", "GSTID" }
                        };
                        allIQNInvoiceData = await ScanAndFindTheInvoice<Models.PAR.IQNPAR>(new Models.PAR.IQNPAR(), IQNTableName, scanOperationConfigIQNTable);
                        Console.WriteLine("Fetched iqn data - rtp Received - with specific attributes");
                    }
                    if (FileName.Contains("Visa"))
                    {
                        var scanFilterVisaTable = new ScanFilter();
                        scanFilterVisaTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
                        ScanOperationConfig scanOperationConfigVisaTable = new ScanOperationConfig()
                        {
                            Filter = scanFilterVisaTable,
                            Select = SelectValues.SpecificAttributes,
                            AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorCd","VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile", "BusinessPlaceId", "GSTID" }
                        };
                        allUdaanInvoiceData = await ScanAndFindTheInvoice<Models.PAR.UdaanPAR>(new Models.PAR.UdaanPAR(), VisaTableName, scanOperationConfigVisaTable);
                        Console.WriteLine("Fetched visa data - rtp Received - with specific attributes");
                    }
                    if (FileName.Contains("RealEstate"))
                    {
                        var scanFilterRealEstateTable = new ScanFilter();
                        scanFilterRealEstateTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
                        ScanOperationConfig scanOperationConfigRealEstateTable = new ScanOperationConfig()
                        {
                            Filter = scanFilterRealEstateTable,
                            Select = SelectValues.SpecificAttributes,
                            AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile", "BusinessPlaceId", "GSTID" }
                       
                    };
                        allRealEstateInvoiceData = await ScanAndFindTheInvoice<RealEstateInvoice>(new RealEstateInvoice(), RealEstateTableName, scanOperationConfigRealEstateTable);
                        Console.WriteLine("Fetched realestate data - rtp Received - with specific attributes");
                    }
                    if (FileName.Contains("AP"))
                    {
                        var scanFilterAPInvoiceTable = new ScanFilter();
                        scanFilterAPInvoiceTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "Received");
                        ScanOperationConfig scanOperationConfigAPInvoiceTable = new ScanOperationConfig()
                        {
                            Filter = scanFilterAPInvoiceTable,
                             Select = SelectValues.SpecificAttributes,
                            AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMBarCode", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile", "BusinessPlaceId", "GSTID" }
                        };
                        allAPInvoiceData = await ScanAndFindTheInvoice<APInvoice>(new APInvoice(), APInvoiceTableName, scanOperationConfigAPInvoiceTable);
                        Console.WriteLine("Fetched AP data - received - with specific attributes");
                    }
                    if (FileName.Contains("Forex"))
                    {
                        var scanFilterForexTable = new ScanFilter();
                        scanFilterForexTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
                        ScanOperationConfig scanOperationConfigForexTable = new ScanOperationConfig()
                        {
                            Filter = scanFilterForexTable,
                            Select = SelectValues.SpecificAttributes,
                            AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile", "BusinessPlaceId", "GSTID" }
                        };
                        allForexInvoiceData = await ScanAndFindTheInvoice<ForexPAR>(new ForexPAR(), ForexInvoiceTableName, scanOperationConfigForexTable);
                        Console.WriteLine("Fetched Forex data - rtp Received - with specific attributes");
                    }
                    int TotalCount = 0;
                    int SuccessfullyChangedCount = 0;
                    PARcsvData SuccessfulRecord = null;
                    List<PARcsvData> SuccessfulRecordList = new List<PARcsvData>();
                    PARcsvData FailedRecord = null;
                    List<PARcsvData> FailedRecordList = new List<PARcsvData>();

                    if (csvFileData != null)
                    {
                        using (var csvReadData = new System.IO.StreamReader(csvFileData.ResponseStream))
                        {
                            Console.WriteLine($"Process: Now StreamReader is reading the data from the file {FileName}");
                            var csv = new CsvHelper.CsvReader(csvReadData);
                            csv.Configuration.HasHeaderRecord = true;//CSV file from the DFM does not have Header 
                            string vendorRegisteredCode = string.Empty;
                            string DFMURN = string.Empty;
                            string RtpRemarks = string.Empty;
                            string fileName1 = string.Empty;
                            string fileName2 = string.Empty;
                            var filePath1 = string.Empty;
                            var filePath2 = string.Empty;
                            var Email = string.Empty;
                            
                            while (csv.Read())
                            {
                                int ChangeFlag = 0;
                                SuccessfulRecord = new PARcsvData();
                                FailedRecord = new PARcsvData();
                                DFMURN = csv.GetField<string>(0);
                                vendorRegisteredCode = csv.GetField<string>(1);
                                string tempVendorCd = csv.GetField<string>(1);
                                RtpRemarks = csv.GetField<string>(2);
                                Console.WriteLine(" DFMURN" + DFMURN + ",vendorRegisteredCode " + vendorRegisteredCode + ",RtpRemarks " + RtpRemarks + ", FileName " + FileName);
                                if (!string.IsNullOrWhiteSpace(DFMURN) && !string.IsNullOrWhiteSpace(vendorRegisteredCode) && !string.IsNullOrWhiteSpace(RtpRemarks))
                                {
                                    TotalCount = TotalCount + 1;
                                    if (FileName.Contains("Visa"))
                                    {
                                        Models.PAR.UdaanPAR updatedInvoiceData = new Models.PAR.UdaanPAR();
                                        updatedInvoiceData = allUdaanInvoiceData.FirstOrDefault(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.DFMURN == DFMURN && invoice.InvoiceStatusCd == "RTP Received");
                                        if (updatedInvoiceData != null)
                                        {
                                            await VisaInvoiceUpdateStatus(vendorRegisteredCode, DFMURN, RtpRemarks, FileName, VisaTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from visa table");
                                        }
                                    }
                                    if (FileName.Contains("Generic"))
                                    {
                                        List<GenericInvoice> updatedInvoiceDataList = new List<GenericInvoice>();
                                        GenericInvoice updatedInvoiceData = new GenericInvoice();
                                        QueryRequest genericrequest = new QueryRequest
                                        {
                                            TableName = GenericTableName,
                                            IndexName = VendorCodeDfmurnindex,
                                            KeyConditionExpression = "VendorRegisteredCd=:vendorCode AND DFMURN=:dfm",
                                            ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                        {
                            {":vendorCode", new AttributeValue{S=vendorRegisteredCode} },
                            {":dfm", new AttributeValue{S=DFMURN} }
                        }
                                        };
                                        updatedInvoiceDataList =await QueryTheTable<GenericInvoice>(genericrequest);
                                        updatedInvoiceData = updatedInvoiceDataList.FirstOrDefault<GenericInvoice>();
                                        if (updatedInvoiceData != null)
                                        {
                                            await GenericInvoiceUpdateStatus(vendorRegisteredCode, updatedInvoiceData.VendorInvoiceNumber, DFMURN, RtpRemarks, FileName, GenericTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from generic table");
                                        }
                                    }
                                    if (FileName.Contains("IQN"))
                                    {
                                        if (tempVendorCd.Count() == 9)
                                        {
                                            tempVendorCd = "0" + tempVendorCd;
                                            vendorRegisteredCode = tempVendorCd;
                                        }
                                        else if (tempVendorCd.Count() == 10)
                                        {
                                            vendorRegisteredCode = tempVendorCd;
                                        }
                                        Models.PAR.IQNPAR updatedInvoiceData = new Models.PAR.IQNPAR();
                                        updatedInvoiceData = allIQNInvoiceData.FirstOrDefault(invoice => invoice.VendorRegisteredCd == (vendorRegisteredCode) && invoice.DFMURN == DFMURN && invoice.InvoiceStatusCd == "RTP Received");
                                        if (updatedInvoiceData != null)
                                        {
                                            await IQNInvoiceUpdateStatus(vendorRegisteredCode, DFMURN, RtpRemarks, FileName, IQNTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from iqn table");
                                        }
                                    }
                                    if (FileName.Contains("RealEstate"))
                                    {
                                        RealEstateInvoice updatedInvoiceData = new RealEstateInvoice();
                                        updatedInvoiceData = allRealEstateInvoiceData.FirstOrDefault(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.DFMURN == DFMURN && invoice.InvoiceStatusCd == "RTP Received");
                                        if (updatedInvoiceData != null)
                                        {
                                            await RealEstateInvoiceUpdateStatus(vendorRegisteredCode, DFMURN, RtpRemarks, FileName, RealEstateTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from RealEstate table");
                                        }
                                    }
                                    if (FileName.Contains("AP"))
                                    {
                                        APInvoice updatedInvoiceData = new APInvoice();
                                        updatedInvoiceData = allAPInvoiceData.FirstOrDefault(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.DFMBarCode == DFMURN && invoice.InvoiceStatusCd == "Received");
                                        if (updatedInvoiceData != null)
                                        {
                                            await APInvoiceUpdateStatus(vendorRegisteredCode, DFMURN, RtpRemarks, FileName, APInvoiceTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from APInvoices table");
                                        }
                                    }
                                    if (FileName.Contains("Forex"))
                                    {
                                        ForexPAR updatedInvoiceData = new ForexPAR();
                                        updatedInvoiceData = allForexInvoiceData.FirstOrDefault(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && /*invoice.DFMBarCode == DFMURN*/invoice.DFMURN == DFMURN && invoice.InvoiceStatusCd == "RTP Received");
                                        if (updatedInvoiceData != null)
                                        {
                                            await ForexInvoiceUpdateStatus(vendorRegisteredCode, DFMURN, RtpRemarks, FileName, ForexInvoiceTableName, updatedInvoiceData, context, bucketName);
                                            ChangeFlag = 1;
                                            Console.WriteLine("PAR- updated one invoice from ForexInvoices table");
                                        }
                                    }
                                    if (ChangeFlag == 0)
                                    {
                                        FailedRecord.DFMURN = DFMURN;
                                        FailedRecord.VendorCode = vendorRegisteredCode;
                                        FailedRecord.RejectionReason = RtpRemarks;
                                        FailedRecordList.Add(FailedRecord);
                                    }

                                }
                                else
                                {
                                    context.Logger.Log($"Log : One of the following parameter is null or empty VendorRegisteredCd : {vendorRegisteredCode}, DFMURN :{DFMURN}");
                                    context.Logger.Log($"contd..  FileName :{FileName}");
                                }

                            }
                            if (FailedRecordList.Count > 0)
                            {
                                fileName2 = "Fail_" + FileName;
                                if (fileName2.Contains("Fail"))
                                {
                                    if (fileName2.Contains("Visa"))
                                    {
                                        filePath2 = "private/postapprovalrejection/udaan/RejectedDump";
                                    }
                                    if (fileName2.Contains("Generic"))
                                    {
                                        filePath2 = "private/postapprovalrejection/generic/RejectedDump";
                                    }
                                    if (fileName2.Contains("IQN"))
                                    {
                                        filePath2 = "private/postapprovalrejection/iqn/RejectedDump";
                                    }
                                    if (fileName2.Contains("RealEstate"))
                                    {
                                        filePath2 = "private/postapprovalrejection/realestate/RejectedDump";
                                    }
                                    if (fileName2.Contains("AP"))
                                    {
                                        filePath2 = "private/postapprovalrejection/ap/RejectedDump";
                                    }
                                    if (fileName2.Contains("Forex"))
                                    {
                                        filePath2 = "private/postapprovalrejection/forex/RejectedDump";
                                    }
                                }
                                var splittedname1 = FileName.Split('_');
                                string ToId = splittedname1[1];
                                var scanFilterVendorTable = new ScanFilter();
                                List<VendorMaster> UserData = new List<VendorMaster>();
                                scanFilterVendorTable.AddCondition("VendorUserId", ScanOperator.Equal, ToId);
                                ScanOperationConfig scanOperationConfigVendorTable = new ScanOperationConfig()
                                {
                                    Filter = scanFilterVendorTable
                                };
                                UserData = await ScanAndFindTheInvoice<VendorMaster>(new VendorMaster(), vendorMasterTable, scanOperationConfigVendorTable);
                                foreach (var item in UserData)
                                {
                                    Console.WriteLine("Fetched user's email" + item.Email);
                                    Email = item.Email;
                                }
                            }
                            Console.WriteLine("Fetched user's email" + Email);
                            var splittedname = FileName.Split('_');
                            PostApprovalRejectionEntities NewPARRecord = new PostApprovalRejectionEntities();
                            NewPARRecord.ModuleNm = splittedname[0];
                            NewPARRecord.UploadDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                            NewPARRecord.UploadedBy = splittedname[1];
                            NewPARRecord.FileNm = FileName;
                            NewPARRecord.FilePath = CommonConstants.PARFolder_FilePath;
                            if (FailedRecordList.Count > 0)
                            {
                                NewPARRecord.ErrorFileNm = fileName2;
                                NewPARRecord.ErrorFilePath = filePath2;
                                MemoryStream stream2 = new MemoryStream();
                                using (var package = new ExcelPackage(new MemoryStream()))
                                {
                                    Console.WriteLine("inside 1st excel generation");
                                    var workbook = package.Workbook;
                                    Console.WriteLine("work book");
                                    var worksheet = workbook.Worksheets.Add("Failed Invoices");
                                    Console.WriteLine("work Sheet");
                                    Console.WriteLine(FailedRecordList.Count);
                                    worksheet.Cells.LoadFromCollection(FailedRecordList, true, OfficeOpenXml.Table.TableStyles.None);
                                    Console.WriteLine("before saving");
                                    package.SaveAs(stream2);
                                    Console.WriteLine("after saving");
                                }
                                await S3.PutFileToS3(bucketName, filePath2, stream2, fileName2, context);
                                Console.WriteLine("putting file" + fileName2 + "at path :" + filePath2);
                            }
                            NewPARRecord.TotalRecCnt = TotalCount.ToString();
                            NewPARRecord.ErrorRecCnt = (TotalCount - SuccessfullyChangedCount).ToString();
                            NewPARRecord.IsActive = 1;
                            IDigiDynamoDb db = new IDigiDynamoDb();
                            await db.InsertAsync<PostApprovalRejectionEntities>(NewPARRecord, PARFileUploadTableName, context);
                            context.Logger.Log($"File Upload Data saved successfully for {FileName}");
                            Console.Write($"File Upload Data saved successfully for {FileName}");
                            if (FailedRecordList.Count > 0)
                            {
                                Console.WriteLine("entering failedrecord addition function");
                                await FailedRecordAddition(FailedRecordList, NewPARRecord.UploadedBy, Email, context);
                            }

                        }
                    }
                    return;
                }

                #endregion


            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
            //}
            return;
        }
        private string ConvertAirlineDateTime(string date)
        {
            DateTime datetime;
            string convertedDate = string.Empty;
            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is coming as mm/dd/yyyy in cwt
                    convertedDate = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];

                    if (DateTime.TryParseExact(convertedDate, "MM/dd/yyyy", CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out datetime))
                    {
                        convertedDate = DateTime
                            .ParseExact(convertedDate, "MM/dd/yyyy", CultureInfo.InvariantCulture)
                            .ToString("yyyy-MM-dd HH:mm:ss.fff");
                    }
                }
            }
            return convertedDate;
        }
        private async Task<int> ScanAndFetchThePrimaryKey(string tableName, ILambdaContext context)
        {
            IDigiDynamoDb db1 = new IDigiDynamoDb();
            ScanFilter scanFilter1 = new ScanFilter();
            ApprovedException approvedException = new ApprovedException();
            List<ApprovedException> approvedExceptionList = await db1.ScanAsync<ApprovedException>(scanFilter1, tableName, context);
            if (approvedExceptionList != null && approvedExceptionList.Count != 0)
            {
                var max = approvedExceptionList.Max(r => r.VendorId);
                return max + 1;
            }
            else
            {
                return 1;
            }
        }
        private async Task CheckTheVendorCodeExistInVendorMasterTable(VendorMaster vendorMaster, string tableName, ILambdaContext context)
        {

            ScanFilter scanFilter1 = new ScanFilter();
            scanFilter1.AddCondition("VendorId", ScanOperator.GreaterThan, 0);
            IDigiDynamoDb db1 = new IDigiDynamoDb();
            List<VendorMaster> vendorMasterCompleteList = await db1.ScanAsync<VendorMaster>(scanFilter1, tableName, context);
            var existingVendorDetails = vendorMasterCompleteList.Where(existingVendorInfo => existingVendorInfo.VendorCode == vendorMaster.VendorCode).ToList();
            if (existingVendorDetails != null && existingVendorDetails.Count > 0)
            {
                foreach (var obj in existingVendorDetails)
                {
                    vendorMaster.VendorId = obj.VendorId;
                    vendorMaster.VendorGroupObjectDetailId = obj.VendorGroupObjectDetailId;
                    await db1.UpdateItemAsync<VendorMaster>(vendorMaster, tableName, context);
                }
            }
            else
            {

                if (vendorMasterCompleteList != null && vendorMasterCompleteList.Count != 0)
                {
                    var max = vendorMasterCompleteList.Max(r => r.VendorId);
                    vendorMaster.VendorId = max + 1;
                }
                else
                {
                    vendorMaster.VendorId = 1;
                }
                await InsertIntoDb<VendorMaster>(vendorMaster, tableName, context);
            }
        }
        private void LogChildLambdaResponse(dynamic childLmbdaResponse, ILambdaContext context)
        {
            context.Logger.Log($"Running Child lambdas instace id: {childLmbdaResponse.Id}");
            context.Logger.Log($"Is Child lambda Instace :{childLmbdaResponse.Id} cancelled :{childLmbdaResponse.IsCanceled}");
            context.Logger.Log($"is faulted{childLmbdaResponse.IsFaulted} ");
            context.Logger.Log($"result is {childLmbdaResponse.Result} ");
            context.Logger.Log($"status is{childLmbdaResponse.Status} ");
        }
        private async Task InsertDataIntoPoTransctionTable(List<POTransaction> poTranscationlist, ILambdaContext context, string poTransactionTable)
        {
            for (int i = 1; i < poTranscationlist.Count; i++)
            {
                context.Logger.Log($"reading and inserting row is complete{i} ");
                poTranscationlist.ElementAt(i).IsActive = "True";
                poTranscationlist.ElementAt(i).POTransactionId = i;
                poTranscationlist.ElementAt(i).IsActive = "True";
                await InsertIntoDb<POTransaction>(poTranscationlist.ElementAt(i), poTransactionTable, context);

            }


        }
        //private async Task ScanCompleteTableAndDeleteBatchOfDocumentsInParallel(List<POTransaction> completeDocumentList, string tableName, ILambdaContext context)
        //{

        //    Amazon.Lambda.Model.InvokeRequest invokeRequest = new Amazon.Lambda.Model.InvokeRequest();
        //    invokeRequest.FunctionName = "7433_iDIgi_LogicController";
        //    invokeRequest.InvocationType = InvocationType.Event;
        //    if (completeDocumentList != null)
        //    {
        //        int count = 1;
        //        int noOfIterartion = completeDocumentList.Count / 100;
        //        int lessOrMoreThanThousandFiles = completeDocumentList.Count % 100;
        //        int nextIndex = 0;
        //        if (completeDocumentList.Count > 100)
        //        {
        //            context.Logger.Log($"Total number of iteration {noOfIterartion}");
        //            if (noOfIterartion > 0)
        //            {
        //                for (int i = 1; i <= noOfIterartion; i++)
        //                {
        //                    if (i == 1)
        //                    {
        //                        nextIndex = 0;
        //                    }
        //                    List<POTransaction> tempDocList = completeDocumentList.GetRange(nextIndex, 100);
        //                    context.Logger.Log($"The number of files passed in iteration no {i} is from {nextIndex} to {tempDocList.Count}");
        //                    count = i;
        //                    invokeRequest.Payload = JsonConvert.SerializeObject(tempDocList);
        //                    context.Logger.Log($"data deletion payload size{invokeRequest.Payload.Count()}");
        //                    nextIndex = nextIndex + 100;
        //                    var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
        //                    LogChildLambdaResponse(childLmbdaResponse, context);
        //                }
        //            }
        //            if (lessOrMoreThanThousandFiles > 0)
        //            {
        //                count++;
        //                context.Logger.Log($"More than {lessOrMoreThanThousandFiles}");
        //                List<POTransaction> tempDocList = completeDocumentList.GetRange(nextIndex, lessOrMoreThanThousandFiles);
        //                invokeRequest.Payload = JsonConvert.SerializeObject(tempDocList);
        //                context.Logger.Log($"data deletion payload size{invokeRequest.Payload.Count()}");
        //                var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
        //                LogChildLambdaResponse(childLmbdaResponse, context);
        //            }
        //            context.Logger.Log("Here awaiting all the delete tasks result ");

        //        }
        //        else
        //        {
        //            context.Logger.Log($"Document count list when the count less than 1000 : {completeDocumentList.Count}");
        //            invokeRequest.Payload = JsonConvert.SerializeObject(completeDocumentList);
        //            context.Logger.Log($"data deletion payload size{invokeRequest.Payload.Count()}");
        //            var childLmbdaResponse = LambdaClient.InvokeAsync(invokeRequest);
        //            LogChildLambdaResponse(childLmbdaResponse, context);
        //        }
        //    }

        //}
        private async Task<List<POTransaction>> DeleteTheDataFromPoTranscationTable(string tableName, ILambdaContext context)
        {
            try
            {
                context.Logger.Log("Process: Now inside delete method");
                ScanFilter scanFilter = new ScanFilter();
                ScanOperationConfig scanConfig = new ScanOperationConfig()
                {
                    AttributesToGet = new List<string> { "SupplierID", "POLineItem" },
                    Filter = scanFilter,
                    Select = SelectValues.SpecificAttributes
                };
                Table table = Table.LoadTable(DbClient, tableName);
                Search search = table.Scan(scanConfig);
                List<POTransaction> potransactionList = new List<POTransaction>();
                List<Document> listOfDocument = new List<Document>();
                do
                {
                    List<Document> documentList = await search.GetNextSetAsync();
                    foreach (var document in documentList)
                    {
                        listOfDocument.Add(document);
                        //potransactionList.Add(IDigiDynamoDocumentConverter.ToObject<POTransaction>(document));
                    }
                } while (!search.IsDone);
                Console.WriteLine($"Data: Total items in Potransaction table {listOfDocument.Count}");

                int tenThousandsCount = 0;
                Stopwatch sw1 = new Stopwatch();
                sw1.Start();
                int documentsToDelete = 0;
                DocumentBatchWrite documentBatchWrite = table.CreateBatchWrite();

                foreach (var document in listOfDocument)
                {

                    documentBatchWrite.AddItemToDelete(document);
                    documentsToDelete = documentsToDelete + 1;
                    if (documentsToDelete == 25)
                    {
                        await documentBatchWrite.ExecuteAsync();
                        documentBatchWrite = table.CreateBatchWrite();
                        documentsToDelete = 0;
                    }
                    //await table.DeleteItemAsync(document);
                    tenThousandsCount = tenThousandsCount + 1;
                    if (tenThousandsCount == 10000)
                    {
                        Console.WriteLine($"Data: Time taken for deleting 10000 records  {sw1.ElapsedMilliseconds / 1000} seconds");
                        sw1.Restart();
                        tenThousandsCount = 0;
                    }
                }
                if (documentsToDelete != 0)
                {
                    await documentBatchWrite.ExecuteAsync();
                    documentBatchWrite = table.CreateBatchWrite();
                    documentsToDelete = 0;
                }
                Console.WriteLine($"Data: Time taken for deleting {tenThousandsCount} records  {sw1.ElapsedMilliseconds / 1000} seconds");
                return potransactionList;
            }
            catch (Exception e)
            {
                context.Logger.Log($"{e.Message}");
                return null;
            }
        }
        private async Task RunDeleteMethodAsync(List<Document> docList, string tableName, int count, ILambdaContext context)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            context.Logger.Log($"Deleting the document from iteration no {count}");
            foreach (var doc in docList)
            {
                await table.DeleteItemAsync(doc);
            }
        }
        private async Task InsertIntoDb<T>(T tObject, string tableName, ILambdaContext context)
        {
            IDigiDynamoDb db = new IDigiDynamoDb();
            await db.InsertAsync<T>(tObject, tableName, context);
        }
        private T ReadCSVDataBasedOnIndexRequired<T>(CsvReader csv, T tObject, List<FileColsDBColsMapping> fileColsDBColsMappinglist, ILambdaContext context)
        {
            try
            {

                foreach (var fileColsDBColsMap in fileColsDBColsMappinglist)
                {
                    string requiredFieldname = fileColsDBColsMap.ReqFieldNm;
                    int indexInCsv = fileColsDBColsMap.IndexOfCollInCsvfile;

                    PropertyInfo propertyInfo = tObject.GetType().GetProperty(requiredFieldname);
                    if (propertyInfo != null)
                    {

                        var propType = propertyInfo.PropertyType;

                        if (propType == typeof(string))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                propertyInfo.SetValue(tObject, csv.GetField<string>(indexInCsv));
                            }
                        }
                        if (propType == typeof(int) || propType == typeof(int?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                int a;
                                if (int.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, int.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        if (propType == typeof(double) || propType == typeof(double?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                double a;
                                if (double.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, double.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        if (propType == typeof(float) || propType == typeof(float?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                float a;
                                if (float.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, float.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                       
                    }
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"{e.Message}");
                context.Logger.Log($"{e.InnerException}");
                context.Logger.Log($"{e.StackTrace}");
            }
            return tObject;
        }
        private async Task CheckTheDuplicateEntryInTheApprovedExceptionAndInsertData(ApprovedException approvedException, string tableName, ILambdaContext context)
        {
            ScanFilter scanFilter1 = new ScanFilter();
            scanFilter1.AddCondition("VendorId", ScanOperator.GreaterThan, 0);
            IDigiDynamoDb db1 = new IDigiDynamoDb();
            List<ApprovedException> listApprovedexception = await db1.ScanAsync<ApprovedException>(scanFilter1, tableName, context);

            var duplicateEntryList = listApprovedexception.Where(apprvdException => apprvdException.VendorRegisteredCd == approvedException.VendorRegisteredCd &&
            apprvdException.VendorInvoiceNumber == approvedException.VendorInvoiceNumber).ToList();

            if (duplicateEntryList != null && duplicateEntryList.Count > 0)
            {
                foreach (var obj in duplicateEntryList)
                {
                    context.Logger.Log($"Data :The approval exception duplicate data has apeared :{JsonConvert.SerializeObject(obj)} it will not be entered into the db");
                }
            }
            else
            {
                listApprovedexception.Max(r => r.VendorId);
                if (listApprovedexception != null && listApprovedexception.Count != 0)
                {
                    var max = listApprovedexception.Max(r => r.VendorId);
                    approvedException.VendorId = max + 1;
                }
                else
                {
                    approvedException.VendorId = 1;
                }
                await InsertIntoDb<ApprovedException>(approvedException, tableName, context);
            }
        }
        private async Task CheckTheDuplicateEntryInTheRealEsateApprovedExceptionTableAndInsertData(RealEstateApprovedExceptionInvoices approvedException, string tableName, ILambdaContext context)
        {
            ScanFilter scanFilter1 = new ScanFilter();
            scanFilter1.AddCondition("VendorId", ScanOperator.GreaterThan, 0);
            IDigiDynamoDb db1 = new IDigiDynamoDb();
            List<RealEstateApprovedExceptionInvoices> listApprovedexception = await db1.ScanAsync<RealEstateApprovedExceptionInvoices>(scanFilter1, tableName, context);

            var duplicateEntryList = listApprovedexception.Where(apprvdException => apprvdException.VendorRegisteredCd == approvedException.VendorRegisteredCd &&
            apprvdException.VendorInvoiceNumber == approvedException.VendorInvoiceNumber).ToList();

            if (duplicateEntryList != null && duplicateEntryList.Count > 0)
            {
                foreach (var obj in duplicateEntryList)
                {
                    context.Logger.Log($"Data :The approval exception duplicate data has apeared :{JsonConvert.SerializeObject(obj)} it will not be entered into the db");
                }
            }
            else
            {
                listApprovedexception.Max(r => r.VendorId);
                if (listApprovedexception != null && listApprovedexception.Count != 0)
                {
                    var max = listApprovedexception.Max(r => r.VendorId);
                    approvedException.VendorId = max + 1;
                }
                else
                {
                    approvedException.VendorId = 1;
                }
                await InsertIntoDb<RealEstateApprovedExceptionInvoices>(approvedException, tableName, context);
            }
        }
        private string ConvertDateTime(string date)
        {
            string convertedDate = string.Empty;
            if (date.Contains("/"))
            {
                var splitedDate = date.Split('/');
                if (splitedDate.Length == 3)
                {
                    if (splitedDate[0].Length == 1)
                    {
                        splitedDate[0] = "0" + splitedDate[0];
                    }
                    if (splitedDate[1].Length == 1)
                    {
                        splitedDate[1] = "0" + splitedDate[1];
                    }
                    //date format is coming as mm/dd/yyyy in cwt
                    convertedDate = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                }
            }
            return convertedDate;
        }
        private async Task UpdateItem(string tableName, string vendorCd, string invoiceKey, string CreditTakenDttm)
        {
            var updateItemRequest = new UpdateItemRequest
            {
                TableName = tableName,
                Key = new Dictionary<string, AttributeValue>()
                {
                    { "VendorCd", new AttributeValue { S= vendorCd} },
                    { "InvoiceKey",new AttributeValue {S = invoiceKey} }
                },
                UpdateExpression = "SET CreditTaken = :CreditTaken, CreditDttm=:CreditDttm",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                {
                    {":CreditTaken",new AttributeValue {S="Y"} },
                    {":CreditDttm",new AttributeValue { S= CreditTakenDttm} }
                }
            };
            var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
            Console.WriteLine($" Updated {vendorCd},{invoiceKey} ");
        }
        private async Task GenericInvoiceUpdateStatus(string vendorRegisteredCode, string vendorInvoiceNumber, string dfmUrn, string RTPRemarks, string FileName, string tableName, GenericInvoice updatedInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string GenericHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    GenericHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.GenericHistoryLogTable;
                }
                else
                {
                    GenericHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GenericHistoryLogTable;
                }
                var splittedname = FileName.Split('_');
                GenericInvoice updateInvoiceData = new GenericInvoice();
                updateInvoiceData = updatedInvoiceData;
                updateInvoiceData.DFMURN = string.Empty;
                updateInvoiceData.ReferenceKey1Str = string.Empty;
                updateInvoiceData.IndexingNbr = string.Empty;
                updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.LGIDownloaded = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.UpdateUserId = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "NC Rejected";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];
                updateInvoiceData.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                InvoiceHistory invoiceHistoryLog = new InvoiceHistory()
                {
                    InvoiceStatusCd = updateInvoiceData.InvoiceStatusCd,
                    CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                    SearchCreateDttm = updateInvoiceData.SearchModifiedDttm,
                    CreateUserId = updateInvoiceData.UpdateUserId,
                    DFMURN = updateInvoiceData.DFMURN,
                    AttachedFile = updateInvoiceData.AttachedFile,
                    InvoiceReceiptDt = updateInvoiceData.InvoiceReceiptDt
                };
                updateInvoiceData.InvoiceHistoryLogs.Add(invoiceHistoryLog);
                Console.WriteLine($"Updating for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                //   await table.PutItemAsync(doc);
                IDigiDynamoDb db1 = new IDigiDynamoDb();
                await db1.UpdateItemAsync(updateInvoiceData, tableName, context);
                Console.WriteLine($"Updated for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Console.WriteLine($"Updating History for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updatedInvoiceData.VendorRegisteredCd + "-" + updatedInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updatedInvoiceData.RTPTeam;
                    Newlog.StatusCd = updatedInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updatedInvoiceData.ModifiedDttm;
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                        }
                    }
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, GenericHistoryLogTable, context);
                Console.WriteLine($"Updating History for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                if (!string.IsNullOrEmpty(updatedInvoiceData.AttachedFile))
                {
                    var sourcepath = CommonConstants.GenericInvoicePath;
                    var destinationpath = CommonConstants.GenericRejectedInvoicePath;
                    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updatedInvoiceData.AttachedFile);
                    if (respose.HttpStatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("ENTERED STATUS CODE DELETE BLOCK " + " " + " -" + HttpStatusCode.OK);
                        await DeleteFile(BucketName, sourcepath, updatedInvoiceData.AttachedFile);
                    }
                    context.Logger.Log($"Now the file { updatedInvoiceData.AttachedFile} associated with the invoice number { updatedInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                }
                await UpdateApprovedExceptionFlagonRejection(updateInvoiceData.VendorInvoiceNumber, updateInvoiceData.VendorRegisteredCd, context);
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        private async Task IQNInvoiceUpdateStatus(string vendorRegisteredCode, string dfmUrn, string RTPRemarks, string FileName, string tableName, Models.PAR.IQNPAR updatedInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string IQNHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    IQNHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.IQNHistoryLogTable;
                }
                else
                {
                    IQNHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNHistoryLogTable;
                }
                Console.WriteLine($"Updating for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                var splittedname = FileName.Split('_');
                Models.PAR.IQNPAR updateInvoiceData = new Models.PAR.IQNPAR();
                updateInvoiceData = updatedInvoiceData;
                updateInvoiceData.DFMURN = string.Empty;
                updateInvoiceData.ReferenceKey1Str = string.Empty;
                updateInvoiceData.IndexingNbr = string.Empty;
                updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.LGIDownloaded = "N";
                updateInvoiceData.AutomationTemplateDownloaded = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.ModifiedBy = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "Non Compliant";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];                
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                Models.PAR.InvoiceHistory invoiceHistoryLog = new Models.PAR.InvoiceHistory()
                {
                    InvoiceStatusCd = updateInvoiceData.InvoiceStatusCd,
                    CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                    SearchCreateDttm = updateInvoiceData.SearchModifiedDttm,
                    CreateUserId = updateInvoiceData.ModifiedBy,
                    DFMURN = updateInvoiceData.DFMURN,
                    AttachedFile = updateInvoiceData.AttachedFile,
                    InvoiceReceiptDt = updateInvoiceData.InvoiceReceiptDt
                };
                updateInvoiceData.InvoiceHistoryLogs.Add(invoiceHistoryLog);
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                 //await table.PutItemAsync(doc);
                await table.UpdateItemAsync(doc);
                Console.WriteLine($"Updated for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                Console.WriteLine($"Updating History for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updatedInvoiceData.VendorRegisteredCd + "-" + updatedInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updatedInvoiceData.RTPTeam;
                    Newlog.StatusCd = updatedInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updatedInvoiceData.ModifiedDttm;
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                        }
                    }
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, IQNHistoryLogTable, context);
                Console.WriteLine($"Updated History for  {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                if (!string.IsNullOrEmpty(updatedInvoiceData.AttachedFile))
                {
                    var sourcepath = CommonConstants.IQNInvoicePath;
                    var destinationpath = CommonConstants.IQNRejectedInvoicePath;
                    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updatedInvoiceData.AttachedFile);
                    if (respose.HttpStatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("eNTERED STATTUS CODE DELTEE BLOCK " + " " + " -" + HttpStatusCode.OK);
                        await DeleteFile(BucketName, sourcepath, updatedInvoiceData.AttachedFile);
                    }
                    context.Logger.Log($"Now the file { updatedInvoiceData.AttachedFile} associated with the invoice number { updatedInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                }
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        private async Task RealEstateInvoiceUpdateStatus(string vendorRegisteredCode, string dfmUrn, string RTPRemarks, string FileName, string tableName, RealEstateInvoice oldInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string RealEstateHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    RealEstateHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.RealEstateHistoryLogTable;
                }
                else
                {
                    RealEstateHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateHistoryLogTable;
                }
                var splittedname = FileName.Split('_');
                RealEstateInvoice updateInvoiceData = new RealEstateInvoice();
                updateInvoiceData = oldInvoiceData;
                updateInvoiceData.DFMURN = string.Empty;
                updateInvoiceData.ReferenceKey1Str = string.Empty;
                updateInvoiceData.IndexingNbr = string.Empty;
                updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.LGIDownloaded = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.UpdateUserId = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "NC Rejected";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                InvoiceHistory invoiceHistoryLog = new InvoiceHistory()
                {
                    InvoiceStatusCd = updateInvoiceData.InvoiceStatusCd,
                    CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                    CreateUserId = updateInvoiceData.UpdateUserId,
                    DFMURN = updateInvoiceData.DFMURN,
                    AttachedFile = updateInvoiceData.AttachedFile,
                    InvoiceReceiptDt = updateInvoiceData.InvoiceReceiptDt
                };
                updateInvoiceData.InvoiceHistoryLogs.Add(invoiceHistoryLog);
                Console.WriteLine($"Updating for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                //await table.PutItemAsync(doc);
                await table.UpdateItemAsync(doc);
                Console.WriteLine($"Updated for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Console.WriteLine($"Updating History for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updateInvoiceData.VendorRegisteredCd + "-" + updateInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updateInvoiceData.RTPTeam;
                    Newlog.StatusCd = updateInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updateInvoiceData.ModifiedDttm;
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                        }
                    }
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, RealEstateHistoryLogTable, context);
                Console.WriteLine($"Updated History for{updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                if (!string.IsNullOrEmpty(updateInvoiceData.AttachedFile))
                {
                    var sourcepath = CommonConstants.RealEstateInvoicePath;
                    var destinationpath = CommonConstants.RealEstateRejectedInvoicePath;
                    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updateInvoiceData.AttachedFile);
                    if (respose.HttpStatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("eNTERED STATTUS CODE DELTEE BLOCK " + " " + " -" + HttpStatusCode.OK);
                        await DeleteFile(BucketName, sourcepath, updateInvoiceData.AttachedFile);
                    }
                    context.Logger.Log($"Now the file { updateInvoiceData.AttachedFile} associated with the invoice number { updateInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                }
                await UpdateApprovedExceptionFlagonRejection(updateInvoiceData.VendorInvoiceNumber, updateInvoiceData.VendorRegisteredCd, context);
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }

        private async Task APInvoiceUpdateStatus(string vendorRegisteredCode, string dfmUrn, string RTPRemarks, string FileName, string tableName, APInvoice oldInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string APHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    APHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.APHistoryLogTable;
                }
                else
                {
                    APHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APHistoryLogTable;
                }
                var splittedname = FileName.Split('_');
                APInvoice updateInvoiceData = new APInvoice();
                updateInvoiceData = oldInvoiceData;
                updateInvoiceData.DFMBarCode = string.Empty;
                updateInvoiceData.ReferenceKey1Str = string.Empty;
                updateInvoiceData.IndexingNbr = string.Empty;
                updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.LGIDownloaded = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.ModifiedBy = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "NC Rejected";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];
                //updateInvoiceData.GSTR2AStatus = "Recon Pending";
               // updateInvoiceData.GSTR2AStatus =!string.IsNullOrEmpty(oldInvoiceData.IsExempted) ? (oldInvoiceData.IsExempted == "NotApplicable") ? "GSTR2ANotRequired" : "GSTR2AReconPending" : "GSTR2AReconPending";


                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff");
             

             
                Console.WriteLine($"Updating for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                //await table.PutItemAsync(doc);
                IDigiDynamoDb db1 = new IDigiDynamoDb();
                await db1.UpdateItemAsync(updateInvoiceData, tableName, context);
                Console.WriteLine($"Updated for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Console.WriteLine($"Updating History for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updateInvoiceData.VendorRegisteredCd + "-" + updateInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updateInvoiceData.RTPTeam;
                    Newlog.StatusCd = updateInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updateInvoiceData.ModifiedDttm;
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, APHistoryLogTable, context);
                Console.WriteLine($"Updated History for{updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        private async Task ForexInvoiceUpdateStatus(string vendorRegisteredCode, string dfmUrn, string RTPRemarks, string FileName, string tableName, ForexPAR oldInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string ForexHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    ForexHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.ForexHistoryLogTable;
                }
                else
                {
                    ForexHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexHistoryLogTable;
                }
                var splittedname = FileName.Split('_');
                ForexPAR updateInvoiceData = new ForexPAR();
                updateInvoiceData = oldInvoiceData;
                // updateInvoiceData.DFMBarCode = string.Empty;
               // updateInvoiceData.ReferenceKey1Str = string.Empty;
                //   updateInvoiceData.IndexingNbr = string.Empty;
                //   updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.DFMURN = string.Empty;
                updateInvoiceData.LGIDownloaded = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.ModifiedBy = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "Non Compliant";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                Console.WriteLine($"Modified date: {updateInvoiceData.ModifiedDttm}");
                Console.WriteLine($"Updating for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Table table = Table.LoadTable(DbClient, tableName);
                //Amazon.DynamoDBv2.DataModel.DynamoDBContext d1 = new Amazon.DynamoDBv2.DataModel.DynamoDBContext(DbClient);
                //var document = d1.ToDocument(updateInvoiceData);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                IDigiDynamoDb db1 = new IDigiDynamoDb();
                await db1.UpdateItemAsync(updateInvoiceData, tableName, context);
                Console.WriteLine($"Updated for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                Console.WriteLine($"Updating History for {updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updateInvoiceData.VendorRegisteredCd + "-" + updateInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updateInvoiceData.RTPTeam;
                    Newlog.StatusCd = updateInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updateInvoiceData.ModifiedDttm;
                    Console.WriteLine($"Status date: {Newlog.StatusDt}");
                    // Newlog.SearchStatusDt = updateInvoiceData.ModifiedDttm;
                    //if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    //{
                    //    if (DateTime.TryParseExact(updateInvoiceData.ModifiedDttm, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                    //    {
                    //        Newlog.StatusDt = DateTime.ParseExact(updateInvoiceData.ModifiedDttm, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                    //        Console.WriteLine($"Status date: {Newlog.StatusDt}");
                    //    }
                    //}
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                            Console.WriteLine($"SearchStatus date: { Newlog.SearchStatusDt}");
                        }
                    }
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, ForexHistoryLogTable, context);
                Console.WriteLine($"Updated History for{updateInvoiceData.VendorInvoiceNumber} - {updateInvoiceData.VendorRegisteredCd}");
                if (!string.IsNullOrEmpty(updateInvoiceData.AttachedFile))
                {
                    var sourcepath = CommonConstants.ForexInvoicePath;
                    var destinationpath = CommonConstants.ForexRejectedInvoicePath;
                    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updateInvoiceData.AttachedFile);
                    if (respose.HttpStatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("eNTERED STATTUS CODE DELTEE BLOCK " + " " + " -" + HttpStatusCode.OK);
                        await DeleteFile(BucketName, sourcepath, updateInvoiceData.AttachedFile);
                    }
                    context.Logger.Log($"Now the file { updateInvoiceData.AttachedFile} associated with the invoice number { updateInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                }
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        private async Task VisaInvoiceUpdateStatus(string vendorRegisteredCode, string dfmUrn, string RTPRemarks, string FileName, string tableName, Models.PAR.UdaanPAR updatedInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                string VisaHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    VisaHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.VisaHistoryLogTable;
                }
                else
                {
                    VisaHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaHistoryLogTable;
                }

                Console.WriteLine($"Updating for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                var splittedname = FileName.Split('_');
                Models.PAR.UdaanPAR updateInvoiceData = new Models.PAR.UdaanPAR();
                updateInvoiceData.VendorCd = updatedInvoiceData.VendorCd;
                updateInvoiceData = updatedInvoiceData;
                updateInvoiceData.DFMURN = string.Empty;
                updateInvoiceData.ReferenceKey1Str = string.Empty;
                updateInvoiceData.IndexingNbr = string.Empty;
                updateInvoiceData.AssignmentNbr = string.Empty;
                updateInvoiceData.InvoiceReceiptDt = string.Empty;
                updateInvoiceData.LGIGenerated = "N";
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.ModifiedBy = splittedname[1];
                updateInvoiceData.InvoiceStatusCd = "NC Rejected";
                updateInvoiceData.GSTR2AStatus = "GSTRNotRequired";
                updateInvoiceData.RTPTeam = splittedname[1];
                updateInvoiceData.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");

                Models.PAR.InvoiceHistory invoiceHistoryLog = new Models.PAR.InvoiceHistory()
                {
                    InvoiceStatusCd = updateInvoiceData.InvoiceStatusCd,
                    CreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy"),
                    SearchCreateDttm = updateInvoiceData.SearchModifiedDttm,
                    CreateUserId = updateInvoiceData.ModifiedBy,
                    DFMURN = updateInvoiceData.DFMURN,
                    AttachedFile = updateInvoiceData.AttachedFile,
                    InvoiceReceiptDt = updateInvoiceData.InvoiceReceiptDt
                };
                updateInvoiceData.InvoiceHistoryLogs.Add(invoiceHistoryLog);
                //if (updateInvoiceData.InvoiceHistoryLogs != null && updateInvoiceData.InvoiceHistoryLogs.Count > 0)
                //{ }
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                //await table.PutItemAsync(doc);
                await table.UpdateItemAsync(doc);
                Console.WriteLine($"Updated for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");

                Console.WriteLine($"Updating History for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                {
                    Newlog.SourceId = updatedInvoiceData.VendorRegisteredCd + "-" + updatedInvoiceData.VendorInvoiceNumber;
                    Newlog.ModifiedBy = updatedInvoiceData.RTPTeam;
                    Newlog.StatusCd = updatedInvoiceData.InvoiceStatusCd;
                    Newlog.StatusDt = updatedInvoiceData.ModifiedDttm;
                    Newlog.VendorCd = updatedInvoiceData.VendorCd;
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                        }
                    }
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, VisaHistoryLogTable, context);
                if (!string.IsNullOrEmpty(updatedInvoiceData.AttachedFile))
                {
                    var sourcepath = CommonConstants.VisaInvoicePath;
                    var destinationpath = CommonConstants.VisaRejectedInvoicePath;
                    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updatedInvoiceData.AttachedFile);
                    if (respose.HttpStatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("eNTERED STATTUS CODE DELTEE BLOCK " + " " + " -" + HttpStatusCode.OK);
                        await DeleteFile(BucketName, sourcepath, updatedInvoiceData.AttachedFile);
                    }
                    context.Logger.Log($"Now the file { updatedInvoiceData.AttachedFile} associated with the invoice number { updatedInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                }
                Console.WriteLine($"Updated for {updatedInvoiceData.VendorInvoiceNumber} - {updatedInvoiceData.VendorRegisteredCd}");
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        public async Task UpdateApprovedExceptionFlagonRejection(string vendorInvoiceNumbr, string vendorRegisteredCd, ILambdaContext context)
        {
            DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
            IDigiDynamoDb db1 = new IDigiDynamoDb();
            try
            {
                List<ApprovedException> filteredapprovedExceptionDetails = null;
                ScanFilter scanFilter = new ScanFilter();
                scanFilter.AddCondition("VendorRegisteredCd", ScanOperator.Equal, vendorRegisteredCd);
                scanFilter.AddCondition("VendorInvoiceNumber", ScanOperator.Equal, vendorInvoiceNumbr);
                ScanOperationConfig scanOperationConfig = new ScanOperationConfig()
                {
                    Filter = scanFilter,
                };
                filteredapprovedExceptionDetails = await ScanAndFindTheInvoice<ApprovedException>(new ApprovedException(), approvedExceptionTable, scanOperationConfig);
                filteredapprovedExceptionDetails = filteredapprovedExceptionDetails.ToList();
                if (filteredapprovedExceptionDetails != null && filteredapprovedExceptionDetails.Count > 0)
                {
                    foreach (var updateInvoiceStatus in filteredapprovedExceptionDetails)
                    {
                        ApprovedException obj1 = new ApprovedException() { VendorId = updateInvoiceStatus.VendorId };
                        obj1.InvoiceSubmittedFlag = "N";
                        obj1.ModifiedDttm = indianTime.ToString("MM/dd/yyyy");
                        obj1.VendorRegisteredCd = updateInvoiceStatus.VendorRegisteredCd;
                        await db1.UpdateItemAsync(obj1, approvedExceptionTable, context);
                        //dynamoDbContextObject.ConditionalUpdate(obj1, "VendorId", updateInvoiceStatus.VendorId);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;
            }
        }
        private async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            List<T> resultList = new List<T>();
            int count = 0;
            try
            {
                Table table = Table.LoadTable(DbClient, tableName);
                Search search = table.Scan(scanOperationConfig);
              
               
                do
                {
                    count = count + 1;
                    List<Document> docList = await search.GetNextSetAsync();
                    foreach (var document in docList)
                    {
                        resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                    }
                }
                while (!search.IsDone);
                Console.WriteLine($"Data :Total number of iteration  :{count}");
                Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return resultList;
        }
        public async Task SendMail(string mailBody, string ToId)
        {
            string cs = "Data Source=rds2sqs0067.c1rqiq13m2ud.us-east-1.rds.amazonaws.com,1433;Integrated Security=SSPI;Initial Catalog=7433_iDigi;Persist Security Info=True;User ID=A07433DIR_MRDR_Test;Password=bS7Ud4Y0x693w51Rq2V2;pooling = False; MultipleActiveResultSets = True;";
            try
            {
                Console.WriteLine($"{cs} inside send mail method");
                Console.WriteLine("line 0");
                Console.WriteLine(mailBody);
                System.Data.SqlClient.SqlConnection myConnection = new System.Data.SqlClient.SqlConnection(cs);
                Console.WriteLine("line 1");
                Console.WriteLine($"{myConnection} myConnection");
                SqlCommand cmd = new SqlCommand("ET_ALERTCOMPONENT_INSERT", myConnection);
                Console.WriteLine("line 2");
                Console.WriteLine($"{cmd} cmd before intialisation");
                cmd.CommandType = CommandType.StoredProcedure;
                Console.WriteLine("line 3");
                cmd.Connection = myConnection;
                cmd.Parameters.Add("@Body", SqlDbType.VarChar).Value = mailBody;
                cmd.Parameters.Add("@Subject", SqlDbType.VarChar).Value = "Post Approval Rejection Mailers";
                cmd.Parameters.Add("@From", SqlDbType.VarChar).Value = "idigi.lad.support";
                cmd.Parameters.Add("@To", SqlDbType.VarChar).Value = ToId;
                cmd.Parameters.Add("@Cc", SqlDbType.VarChar).Value = "idigi.lad.support";
                cmd.Parameters.Add("@Module", SqlDbType.VarChar).Value = "na";
                cmd.Parameters.Add("@MailImportance", SqlDbType.SmallInt).Value = 3;
                cmd.Parameters.Add("@ShortMsgTxt", SqlDbType.VarChar).Value = "code";
                cmd.Parameters.Add("@CreateUserId", SqlDbType.VarChar).Value = "98";
                cmd.Parameters.Add("@AttachmentList", SqlDbType.VarChar).Value = "";
                Console.WriteLine($"{cmd} inside send mail method");
                myConnection.Open();
                cmd.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine($"error in send mail method {e.Message}{e.InnerException.ToString()},{e.StackTrace}");
            }
        }
        public string PreparingMailContent(List<PARcsvData> FailedRecordList)
        {
            StringBuilder mailBody = new StringBuilder();
            string MailContent = string.Empty;
            {
                mailBody.Append("<html><body>");
                mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">**THIS IS AN AUTO-GENERATED MAIL. PLEASE DON'T REPLY TO THIS MAIL**</p>");
                mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">If you have questions about this payment or other invoicing matters, please email at:<a href=" + "mailto:" + "ap.india.support@accenture.com" + ">ap.india.support@accenture.com</a></p>");
                mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">Dear IDigi User,</p>");
                mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">Below are the records which failed during Post Approval Rejection of invoices.</p>");
                mailBody.Append("<br/>");
                mailBody.Append("<table border=" + 1 + ">");
                mailBody.Append("<tbody><tr><th width =" + 190 + "style=" + "background-color:#AF7AC5;" + ">");
                mailBody.Append("<p>DFMURN</p>");
                mailBody.Append("</th>");
                mailBody.Append("<th width =" + 190 + "style=" + "background-color:#AF7AC5;" + ">");
                mailBody.Append("<p>Vendor Registered Code</p>");
                mailBody.Append("</th>");
                mailBody.Append("<th width =" + 190 + "style=" + "background-color:#AF7AC5;" + ">");
                mailBody.Append("<p>Rejection Reason</p>");
                mailBody.Append("</th></tr>");
                for (int i = 0; i < FailedRecordList.Count; i++)
                {
                    mailBody.Append("<tr><td>");
                    mailBody.Append("<p style=" + "font-family:Calibri Light;>" + FailedRecordList[i].DFMURN + "</p>");
                    mailBody.Append("</td>");
                    mailBody.Append("<td>");
                    mailBody.Append("<p style=" + "font-family:Calibri Light;>" + FailedRecordList[i].VendorCode + "</p>");
                    mailBody.Append("</td>");
                    mailBody.Append("<td>");
                    mailBody.Append("<p style=" + "font-family:Calibri Light;>" + FailedRecordList[i].RejectionReason + "</p>");
                    mailBody.Append("</td></tr> ");
                }
            }
            mailBody.Append("</tbody></table>");
            mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">Kind regards</p>");
            mailBody.Append("<p style=" + "font-family:Calibri Light;" + ">Accenture Payable Team</p>");
            mailBody.Append("</html></body>");
            string mailBd = mailBody.ToString();
            return mailBd;
        }
        public async Task FailedRecordAddition(List<PARcsvData> FailedRecordList, string UploadedBy, string Email, ILambdaContext context)
        {
            string PARFailedRecordsTable = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                PARFailedRecordsTable = CommonConstants.AirId + "_" + CommonConstants.PARFailedRecordsTableName;
            }
            else
            {
                PARFailedRecordsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PARFailedRecordsTableName;
            }
            PARFailedRecords obj = new PARFailedRecords();
            obj.UploadedBy = UploadedBy;
            obj.Email = Email;
            obj.UploadedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
            obj.UploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
            obj.FailedRecords = new List<PARcsvData>();
            obj.FailedRecord = new PARcsvData();
            foreach (var item in FailedRecordList)
            {
                obj.FailedRecord.DFMURN = item.DFMURN;
                obj.FailedRecord.RejectionReason = item.RejectionReason;
                obj.FailedRecord.VendorCode = item.VendorCode;
                obj.FailedRecords.Add(obj.FailedRecord);
            }
            IDigiDynamoDb db = new IDigiDynamoDb();
            await db.InsertAsync<PARFailedRecords>(obj, PARFailedRecordsTable, context);
        }
        private async Task<List<GSTR2AInvoice>> DeleteTheDataFromGSTR2ATable(string tableName, ILambdaContext context, string bucketName, string path)
        {
            try
            {
                context.Logger.Log("Process: Now inside delete method");
                ScanFilter scanFilter = new ScanFilter();
                ScanOperationConfig scanConfig = new ScanOperationConfig()
                {
                    //AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber" },
                    Filter = scanFilter,
                    //Select = SelectValues.SpecificAttributes
                };
                Table table = Table.LoadTable(DbClient, tableName);
                Search search = table.Scan(scanConfig);
                List<GSTR2AInvoice> gstr2AList = new List<GSTR2AInvoice>();
                List<Document> listOfDocument = new List<Document>();
                do
                {
                    List<Document> documentList = await search.GetNextSetAsync();
                    foreach (var document in documentList)
                    {
                        listOfDocument.Add(document);
                        gstr2AList.Add(IDigiDynamoDocumentConverter.ToObject<GSTR2AInvoice>(document));
                    }
                } while (!search.IsDone);
                Console.WriteLine($"Data: Total items in GSTR2a table {listOfDocument.Count}");


                MemoryStream stream2 = new MemoryStream();
                using (var package = new ExcelPackage(new MemoryStream()))
                {

                    Console.WriteLine("Process: inside excel genaration");
                    var workbook = package.Workbook;
                    var worksheet = workbook.Worksheets.Add("TotalDatainOldTable");
                    worksheet.Cells.LoadFromCollection(gstr2AList);
                    package.SaveAs(stream2);

                }

                Console.WriteLine($"Process: genarating new excel completed");

                var s3Response2 = await S3Client.PutObjectAsync(new PutObjectRequest
                {
                    BucketName = bucketName + "/" + path,
                    Key = "GSTR2A" +
                          TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MMddyyyyHHmm") + ".xlsx",
                    InputStream = stream2
                });
                Console.WriteLine($"file has been saved  {bucketName + "/" + path}/GSTR2A");



                int tenThousandsCount = 0;
                Stopwatch sw1 = new Stopwatch();
                sw1.Start();
                int documentsToDelete = 0;
                DocumentBatchWrite documentBatchWrite = table.CreateBatchWrite();

                foreach (var document in listOfDocument)
                {

                    documentBatchWrite.AddItemToDelete(document);
                    documentsToDelete = documentsToDelete + 1;
                    if (documentsToDelete == 25)
                    {
                        await documentBatchWrite.ExecuteAsync();
                        documentBatchWrite = table.CreateBatchWrite();
                        documentsToDelete = 0;
                    }
                    //await table.DeleteItemAsync(document);
                    tenThousandsCount = tenThousandsCount + 1;
                    if (tenThousandsCount == 10000)
                    {
                        Console.WriteLine($"Data: Time taken for deleting 10000 records  {sw1.ElapsedMilliseconds / 1000} seconds");
                        sw1.Restart();
                        tenThousandsCount = 0;
                    }
                }
                if (documentBatchWrite != null && documentsToDelete > 0)
                {
                    await documentBatchWrite.ExecuteAsync();
                }

                Console.WriteLine($"Data: Time taken for deleting {tenThousandsCount} records  {sw1.ElapsedMilliseconds / 1000} seconds");
                return gstr2AList;
            }
            catch (Exception e)
            {
                context.Logger.Log($"{e.Message}");
                return null;
            }
        }
        private async Task<CopyObjectResponse> CopyFileFromOneFolderToOther(string sourceBucket, string sourceFolder, string destinationBucket, string destinationFolder, string fileName)
        {
            var copyObjectRequest = new CopyObjectRequest()
            {
                DestinationKey = fileName,
                SourceKey = fileName,
                DestinationBucket = destinationBucket + "/" + destinationFolder,
                SourceBucket = sourceBucket + "/" + sourceFolder,
            };
            CopyObjectResponse copyObjectReponse = await S3Client.CopyObjectAsync(copyObjectRequest);
            return copyObjectReponse;
        }
        private async Task<DeleteObjectResponse> DeleteFile(string bucket, string folder, string file)
        {
            var deleteObjectRequest = new DeleteObjectRequest()
            {
                BucketName = bucket + "/" + folder,
                Key = file
            };
            var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);
            return deleteObjectResponse;
        }

        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
        private async Task UpdateIQNorVisaHistoryLogTable(string VendorRegisteredCd, string VendorInvoiceNumber, string GSTRStatusCd, ILambdaContext context, string tableName)
        {
            try
            {
                DateTime datetime = new DateTime();
                InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                var ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                context.Logger.LogLine($"Inside method UpdateIQNorVisaHistoryLogTable ");
                {
                    Newlog.SourceId = VendorRegisteredCd + "-" + VendorInvoiceNumber;
                    Newlog.ModifiedBy = "SYSTEM";
                    Newlog.StatusCd = GSTRStatusCd;
                    Newlog.StatusDt = ModifiedDttm;
                    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                    {
                        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                        {
                            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                        }
                    }
                    context.Logger.LogLine($"{JsonConvert.SerializeObject(Newlog)} ");
                }
                IDigiDynamoDb db = new IDigiDynamoDb();
                await db.InsertAsync<InvoiceHistoryLogs>(Newlog, tableName, context);
                context.Logger.LogLine($"Insert Log successfull");
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
            }
        }
        private async Task FetchUdaanInvoiceAndUpdateDFMUrn(string vendorInvoiceNumber, string vendorRegisteredCode, string status, string wireid, string scheduleddate, string paymentdt, string tableName, ILambdaContext context, List<UdaanInvoice> allUdaanInvoices)
        {
            //context.Logger.Log($"Process :Now updating the table with the dfm urn :{dfmUrn} for vendor invoice number :{vendorInvoiceNumber} table {tableName} ");
            try
            {
                if (!string.IsNullOrEmpty(vendorRegisteredCode))
                {

                    var udaanInvoice = allUdaanInvoices.Where(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.VendorInvoiceNumber == vendorInvoiceNumber).ToList();

                    // Console.WriteLine($"{JsonConvert.SerializeObject(udaanInvoice)}");

                    if (udaanInvoice != null && udaanInvoice.Count > 0)
                    {
                        foreach (var item in udaanInvoice)
                        {
                            if (!string.IsNullOrEmpty(item.VendorCd))
                            {
                                context.Logger.Log($"Process :Now updating the table with payment data :{status} for vendor invoice number :{vendorInvoiceNumber} table {tableName}, {item.VendorCd},{vendorRegisteredCode},{wireid},{scheduleddate},{paymentdt}");
                                await UpdatePaymentsDataForUdaan(item.VendorCd, vendorInvoiceNumber, status, wireid, scheduleddate, paymentdt, tableName);
                                context.Logger.LogLine($"Success: Payments data updated successfully");
                            }

                        }
                    }
                    else
                    {
                        context.Logger.Log($"Data Error :There is no Invoice Matching the Inv no :{vendorInvoiceNumber} vendorRegisteredCd :{vendorRegisteredCode}");
                    }

                }
            }
            catch (Exception e)
            {
                //mail
                context.Logger.Log($"Error :Exception message :{e.Message}");
                context.Logger.Log($"Error :Exception inner message {e.InnerException}");
                context.Logger.Log($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }     
        private async Task UpdatePaymentsDataForUdaan(string VendorCd, string VendorInvoiceNumber, string status, string wireid, string scheduleddate, string paymentdt, string udaanTableName)
        {
            try
            {
                Console.WriteLine($"Now updating {udaanTableName},{VendorCd},{VendorInvoiceNumber}");
                StringBuilder sb = new StringBuilder();
                var expressionAttributeValues = new Dictionary<string, AttributeValue>() { };
                sb.Append("SET #s = :PaymentStatus, #n = :NDCInvoiceStatus ");
               // sb.Append(" AND SET #n = :NDCInvoiceStatus");
                expressionAttributeValues.Add(":PaymentStatus", new AttributeValue { S = status });
                expressionAttributeValues.Add(":NDCInvoiceStatus", new AttributeValue { S = status });
                var expressionAttributeNames = new Dictionary<string, string>() { };
                expressionAttributeNames.Add("#s", "PaymentStatus");
                expressionAttributeNames.Add("#n", "NDCInvoiceStatus");
                if (!string.IsNullOrEmpty(wireid))
                {
                    sb.Append(", WireId=:WireId");
                    expressionAttributeValues.Add(":WireId", new AttributeValue { S = wireid });
                }
                if (!string.IsNullOrEmpty(scheduleddate))
                {
                    sb.Append(", ScheduledPaymentDt=:ScheduledPaymentDt");
                    expressionAttributeValues.Add(":ScheduledPaymentDt", new AttributeValue { S = scheduleddate });
                }
                if (!string.IsNullOrEmpty(paymentdt))
                {
                    sb.Append(", PaymentDt=:PaymentDt");
                    expressionAttributeValues.Add(":PaymentDt", new AttributeValue { S = paymentdt });
                }
                var updateItemRequest = new UpdateItemRequest
                {
                    TableName = udaanTableName,
                    Key = new Dictionary<string, AttributeValue>()
                    {
                      { "VendorCd", new AttributeValue { S= VendorCd} },
                      { "VendorInvoiceNumber",new AttributeValue {S = VendorInvoiceNumber} }
                    },
                    UpdateExpression = sb.ToString(),
                    ExpressionAttributeValues = expressionAttributeValues,
                    ExpressionAttributeNames = expressionAttributeNames
                };
                var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error :Exception message :{e.Message}");
                Console.WriteLine($"Error :Exception inner message {e.InnerException}");
                Console.WriteLine($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }

        private bool IsVendorCodeBelongToParticularModule(string vendorCode, List<VendorMaster> vendorDetails, string vendorModule)
        {
            Console.WriteLine($"Checking vendor module code {vendorModule}");
            if (vendorDetails != null && vendorDetails.Count > 0)
            {
                Console.WriteLine($" vendor details count {vendorDetails.Count}");
                //var list = vendorDetails.Where(vendorDetail => vendorDetail.VendorCode == vendorCode && vendorDetail.VendorCd == vendorModule);
                var matchedVendorList = new List<VendorMaster>();
                foreach (var vendorList in vendorDetails)
                {
                    if (!string.IsNullOrEmpty(vendorList.VendorCode) && !string.IsNullOrEmpty(vendorList.VendorCd))
                    {
                        if(vendorModule== "AP VENDOR")
                        {
                            if (vendorList.VendorCode == vendorCode && (vendorList.VendorCd == "GRN VENDOR" || vendorList.VendorCd == "IQN VENDOR" || vendorList.VendorCd == "REAL VENDOR" || vendorList.VendorCd == "UDN VENDOR" || vendorList.VendorCd == "FOREX VENDOR"))
                            {
                                matchedVendorList.Add(vendorList);
                            }
                        }
                        else if (vendorList.VendorCode == vendorCode && vendorList.VendorCd == vendorModule)
                        {
                            matchedVendorList.Add(vendorList);
                        }
                    }
                }

                if (matchedVendorList != null && matchedVendorList.Count() > 0)
                    return true;
                else
                    return false;
            }
            else
            {
                return false;
            }

        }       
       
        private async Task UpdatePaymentData(string VendorRegisteredCd, string VendorInvoiceNumber, string status, string wireid, string scheduleddate, string paymentdt, string tableName)
        {
            try
            {
                Console.WriteLine($"Now updating {tableName},{VendorRegisteredCd},{VendorInvoiceNumber}");
                StringBuilder sb = new StringBuilder();
                var expressionAttributeValues = new Dictionary<string, AttributeValue>() { };
                sb.Append("SET #s = :PaymentStatus , #n = :NDCInvoiceStatus ");
               // sb.Append(" AND SET #n = :NDCInvoiceStatus");
                expressionAttributeValues.Add(":PaymentStatus", new AttributeValue { S = status });
                expressionAttributeValues.Add(":NDCInvoiceStatus", new AttributeValue { S = status });
                var expressionAttributeNames = new Dictionary<string, string>() { };
                expressionAttributeNames.Add("#s", "PaymentStatus");
                expressionAttributeNames.Add("#n", "NDCInvoiceStatus");
                if (!string.IsNullOrEmpty(wireid))
                {
                    sb.Append(", WireId=:WireId");
                    expressionAttributeValues.Add(":WireId", new AttributeValue { S = wireid });
                }
                if (!string.IsNullOrEmpty(scheduleddate))
                {
                    sb.Append(", ScheduledPaymentDt=:ScheduledPaymentDt");
                    expressionAttributeValues.Add(":ScheduledPaymentDt", new AttributeValue { S = scheduleddate });
                }
                if (!string.IsNullOrEmpty(paymentdt))
                {
                    sb.Append(", PaymentDt=:PaymentDt");
                    expressionAttributeValues.Add(":PaymentDt", new AttributeValue { S = paymentdt });
                }

                var updateItemRequest = new UpdateItemRequest
                {
                    TableName = tableName,
                    Key = new Dictionary<string, AttributeValue>()
                    {
                      { "VendorRegisteredCd", new AttributeValue { S= VendorRegisteredCd} },
                      { "VendorInvoiceNumber",new AttributeValue {S = VendorInvoiceNumber} }
                    },
                    UpdateExpression = sb.ToString(),
                    ExpressionAttributeValues = expressionAttributeValues,
                    ExpressionAttributeNames = expressionAttributeNames
                };
                //if (tableName.Contains("Forex"))
                //{
                //    var updateItemRequest1 = new UpdateItemRequest
                //    {
                //        TableName = ForexHistoryLogTable,
                //        Key = new Dictionary<string, AttributeValue>()
                //    {
                //      { "VendorRegisteredCd", new AttributeValue { S= VendorRegisteredCd} },
                //      { "VendorInvoiceNumber",new AttributeValue {S = VendorInvoiceNumber} }
                //    },
                //        UpdateExpression = sb.ToString(),
                //        ExpressionAttributeValues = expressionAttributeValues,
                //        ExpressionAttributeNames = expressionAttributeNames
                //    };
                //}
                var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error :Exception message :{e.Message}");
                Console.WriteLine($"Error :Exception inner message {e.InnerException}");
                Console.WriteLine($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }

        private async Task UpdatePaymentDataCWT(string VendorCd, string VendorInvoiceCRNo, string status, string wireid, string scheduleddate, string paymentdt, string tableName)
        {
            try
            {
                Console.WriteLine($"Now updating {tableName},{VendorCd},{VendorInvoiceCRNo}");
                StringBuilder sb = new StringBuilder();
                var expressionAttributeValues = new Dictionary<string, AttributeValue>() { };
                sb.Append("SET #s = :PaymentStatus , #n = :NDCInvoiceStatus ");
                // sb.Append(" AND SET #n = :NDCInvoiceStatus");
                expressionAttributeValues.Add(":PaymentStatus", new AttributeValue { S = status });
                expressionAttributeValues.Add(":NDCInvoiceStatus", new AttributeValue { S = status });
                var expressionAttributeNames = new Dictionary<string, string>() { };
                expressionAttributeNames.Add("#s", "PaymentStatus");
                expressionAttributeNames.Add("#n", "NDCInvoiceStatus");
                if (!string.IsNullOrEmpty(wireid))
                {
                    sb.Append(", WireId=:WireId");
                    expressionAttributeValues.Add(":WireId", new AttributeValue { S = wireid });
                }
                if (!string.IsNullOrEmpty(scheduleddate))
                {
                    sb.Append(", ScheduledPaymentDt=:ScheduledPaymentDt");
                    expressionAttributeValues.Add(":ScheduledPaymentDt", new AttributeValue { S = scheduleddate });
                }
                if (!string.IsNullOrEmpty(paymentdt))
                {
                    sb.Append(", PaymentDt=:PaymentDt");
                    expressionAttributeValues.Add(":PaymentDt", new AttributeValue { S = paymentdt });
                }
                var updateItemRequest = new UpdateItemRequest
                {
                    TableName = tableName,
                    Key = new Dictionary<string, AttributeValue>()
                    {
                      { "VendorCd", new AttributeValue { S= VendorCd} },
                      { "VendorInvoiceCRNo",new AttributeValue {S = VendorInvoiceCRNo} }
                    },
                    UpdateExpression = sb.ToString(),
                    ExpressionAttributeValues = expressionAttributeValues,
                    ExpressionAttributeNames = expressionAttributeNames
                };               
                var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error :Exception message :{e.Message}");
                Console.WriteLine($"Error :Exception inner message {e.InnerException}");
                Console.WriteLine($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }
        private async Task UpdateItem(UpdateItemRequest updateItemRequest)
        {
            try
            {
                var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error :Exception message :{e.Message}");
                Console.WriteLine($"Error :Exception inner message {e.InnerException}");
                Console.WriteLine($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }
        public async Task<List<T>> QueryTheTable<T>(QueryRequest queryRequest)
        {
            List<T> lisOfT = new List<T>();
            QueryResponse response = null;
            do
            {
                response = await DbClient.QueryAsync(queryRequest);
                if (response != null && response.Count > 0)
                {
                    foreach (var item in response.Items)
                    {
                        var document = Document.FromAttributeMap(item);
                        lisOfT.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                    }
                }
                if (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0)
                {
                    queryRequest.ExclusiveStartKey = response.LastEvaluatedKey;
                }
            }
            while (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0);
            return lisOfT;

        }

    }
}




