using System;
using System.IO;
using System.Text;

using Newtonsoft.Json;
using Amazon.S3;
using Amazon.Lambda.Core;
using Amazon.Lambda.DynamoDBEvents;
using Amazon.DynamoDBv2.Model;
using Amazon.S3.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CopyApprovedInvoicesToDfmFolder
{
    public class Function
    {
        private static readonly JsonSerializer _jsonSerializer = new JsonSerializer();

        //private string environment = Environment.GetEnvironmentVariable("Environment");
        //private string bucketName = Environment.GetEnvironmentVariable("BucketName");
        //private string vendorInvoicesFolderInS3 = Environment.GetEnvironmentVariable("InvoicesS3Folder");
        //private string vendorDFMDumpFolderinS3 = Environment.GetEnvironmentVariable("DFMDumpFolder");

        private string environment = Environment.GetEnvironmentVariable("Environment");
        private string bucketName = Environment.GetEnvironmentVariable("BucketName");
        private string genericVendorInvoicesFolderInS3 = Environment.GetEnvironmentVariable("InvoicesS3Folder");
        private string iqnInvoiceFolder = Environment.GetEnvironmentVariable("IqnInvoiceFolder");
        private string udaanInvoiceFolder = Environment.GetEnvironmentVariable("UdaanInvoiceFolder");
        private string realRealEstateInvoiceFolder = Environment.GetEnvironmentVariable("RealEstateInvoiceFolder");
        private string forexInvoiceFolder = Environment.GetEnvironmentVariable("ForexInvoiceFolder");
        //private string iqnInvoiceFolder = "private/iqn/invoice";
        //private string udaanInvoiceFolder = "private/udaan/invoice";

        private string vendorDFMDumpFolderinS3 = Environment.GetEnvironmentVariable("DFMDumpFolder");


        public async Task FunctionHandler(DynamoDBEvent dynamoEvent, ILambdaContext context)
        {

            context.Logger.Log($"The lambda executing environment is : {environment} bucketname : {bucketName} vendor DFM dump folder : {vendorDFMDumpFolderinS3}");
            context.Logger.LogLine($"Beginning to process {dynamoEvent.Records.Count} records...");

            context.Logger.Log($"Data :Complete dynamodb event record :{JsonConvert.SerializeObject(dynamoEvent)}");




            string invoiceStatusCdNewEntry = string.Empty;
            string invoiceStatusCdOldEntry = string.Empty;
            string invoiceNumber = string.Empty;
            string attachedFileName = string.Empty;
            string vendorRegisteredCd = string.Empty;
            string vendorModuleCd = string.Empty;
            try
            {
                foreach (var record in dynamoEvent.Records)
                {
                    context.Logger.LogLine($"Event ID: {record.EventID}");
                    context.Logger.LogLine($"Event Name: {record.EventName}");

                    string streamRecordJson = SerializeStreamRecord(record.Dynamodb);
                    context.Logger.LogLine($"DynamoDB Record:");
                    context.Logger.LogLine(streamRecordJson);
                    //when db entry is of type INSERT or REMOVE ignore -Do nothing
                    if (record.EventName == "MODIFY")
                    {
                        #region when the event is of type Modify(Update)
                        foreach (var keyValuePair in record.Dynamodb.NewImage)
                        {
                            if (keyValuePair.Key == "InvoiceStatusCd")
                            {
                                invoiceStatusCdNewEntry = keyValuePair.Value.S;
                                context.Logger.Log($"invoiceStatusCdNewEntry: {keyValuePair.Value.S}");
                            }
                            if (keyValuePair.Key == "VendorInvoiceNumber")
                            {
                                invoiceNumber = keyValuePair.Value.S;
                                context.Logger.Log($"InvoiceNumber: {keyValuePair.Value.S}");
                            }
                            if (keyValuePair.Key == "AttachedFile")
                            {
                                attachedFileName = keyValuePair.Value.S;
                                context.Logger.Log($"attachedFileName: {keyValuePair.Value.S}");
                            }
                            if (keyValuePair.Key == "VendorRegisteredCd")
                            {
                                vendorRegisteredCd = keyValuePair.Value.S;
                                context.Logger.Log($"vendorRegisteredCd: {keyValuePair.Value.S}");
                            }
                            if (keyValuePair.Key == "VendorModuleCd")
                            {
                                vendorModuleCd = keyValuePair.Value.S;
                                context.Logger.Log($"vendorModuleCd: {keyValuePair.Value.S}");
                            }

                        }
                        context.Logger.Log($"Vendor module code before checking old image: {vendorModuleCd}");
                        foreach (var keyValuePair in record.Dynamodb.OldImage)
                        {
                            if (keyValuePair.Key == "InvoiceStatusCd")
                            {
                                invoiceStatusCdOldEntry = keyValuePair.Value.S;
                                context.Logger.Log($" invoiceStatusCdOldEntry :{keyValuePair.Value.S}");
                                context.Logger.Log($" invoiceStatusCdOldEntry :{keyValuePair.Value.S}");
                            }
                        }
                        //check the conditions 
                        if ((invoiceStatusCdNewEntry == "RTP Approved" && invoiceStatusCdOldEntry != "RTP Approved")
                            || (invoiceStatusCdNewEntry == "RTP Received" && invoiceStatusCdOldEntry != "RTP Received"))
                        {
                            context.Logger.Log($"Attached file name :{attachedFileName}");
                            if (!string.IsNullOrWhiteSpace(attachedFileName))
                            {
                                context.Logger.Log($"Vendor module code before sending to duplicate check : {vendorModuleCd}");
                                if (await CheckFileExistsOrNOt(vendorRegisteredCd, vendorModuleCd, attachedFileName, context))
                                {
                                    context.Logger.Log($"Now copying the {attachedFileName} to dfm dump folder");
                                    await CopyFileToDFMDumpFolder(vendorRegisteredCd, vendorModuleCd, invoiceNumber, attachedFileName, context);
                                    // get suggestion on this trigger mail
                                }
                                else
                                {

                                    context.Logger.Log($"File name : {attachedFileName} associated with the invoice number {invoiceNumber} does not exist in the S3 folder :.");
                                    //trigger mail
                                }

                            }
                            else
                            {
                                context.Logger.Log($"Db entry doesnot contain the associated invoice pdf name of invoice number {invoiceNumber}.");
                                //triger mail

                            }

                        }
                        else
                        {
                            context.Logger.Log($"This is not a RTP approved request {vendorRegisteredCd}/{invoiceNumber}.");
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                context.Logger.Log($"Message: {ex.Message}");
                context.Logger.Log($"Inner exception {ex.InnerException}");
                context.Logger.Log($"Stack trace {ex.StackTrace}");
            }
            context.Logger.LogLine("Stream processing complete.");
        }

        private async Task<bool> CheckFileExistsOrNOt(string vendorRegisteredCd, string vendorModuleCd, string attachedFileName, ILambdaContext context)
        {
            IAmazonS3 s3Client = new AmazonS3Client();
            List<string> fileNameList = new List<string>();
            string invoiceFileFolder = string.Empty;
            context.Logger.Log($"Data :Recieved vendor module code :{vendorModuleCd}");
            //if (!string.IsNullOrEmpty(vendorModuleCd) || !string.IsNullOrEmpty(vendorRegisteredCd))
            if (!string.IsNullOrEmpty(vendorModuleCd) || !string.IsNullOrEmpty(vendorRegisteredCd))
            {
                if (vendorModuleCd.ToLowerInvariant() == "iqn")
                {
                    invoiceFileFolder = iqnInvoiceFolder;
                }
                //else if (vendorModuleCd.ToLowerInvariant() == "100252385" || vendorModuleCd.ToLowerInvariant() == "0100252385")
                //{
                //    invoiceFileFolder = udaanInvoiceFolder;
                //}
                else if (vendorModuleCd.ToLowerInvariant() == "udnag")
                {
                    invoiceFileFolder = udaanInvoiceFolder;
                }
                else if (vendorModuleCd.ToLowerInvariant() == "realag")
                {

                    invoiceFileFolder = realRealEstateInvoiceFolder;
                }
                else if (vendorModuleCd.ToLowerInvariant() == "forex")
                {

                    invoiceFileFolder = forexInvoiceFolder;
                }
                else
                {
                    invoiceFileFolder = genericVendorInvoicesFolderInS3;
                }
            }
            //else
            //{
            //    invoiceFileFolder = genericVendorInvoicesFolderInS3;
            //}

            //as we are trying to find the single file. below logic will work without looping
            context.Logger.Log($"{bucketName},{invoiceFileFolder},{attachedFileName}");
            var listObjectresponse = await s3Client.ListObjectsAsync(new ListObjectsRequest
            {
                BucketName = bucketName,
                Prefix = invoiceFileFolder + "/" + attachedFileName,
            });
            if (listObjectresponse.S3Objects.Count > 0)
                return true;
            else
                return false;
            #region edited code
            //foreach (var s3Object in listObjectresponse.S3Objects)
            //{
            //    if (!s3Object.Key.EndsWith(".csv"))
            //    {
            //        if (s3Object.Key.Contains("."))
            //        {
            //            string tmpFileName = s3Object.Key.Replace(vendorInvoicesFolderInS3 + "/", "");
            //            fileNameList.Add( tmpFileName);
            //        }
            //    }
            //}
            //if (fileNameList != null)
            //{
            //    foreach (var varfileName in fileNameList)
            //    {

            //        if (varfileName == attachedFileName)
            //        {
            //            isFileExist = true;
            //        }
            //        else
            //        {
            //            isFileExist = false;
            //        }
            //    }
            //}
            //else {
            //    context.Logger.Log($"Generic private folder{vendorInvoicesFolderInS3} doesnot contain the file {attachedFileName}");
            //    isFileExist = false;
            //}   
            //return isFileExist;
            #endregion
        }
        //check on the return type
        private async Task CopyFileToDFMDumpFolder(string vendorRegisteredCd, string vendorModuleCd, string invoiceNumber, string attachedFileName, ILambdaContext context)
        {
            string invoiceFileFolder = string.Empty;
            if (!string.IsNullOrEmpty(vendorModuleCd))
            {
                if (vendorModuleCd.ToLowerInvariant() == "iqn")
                {
                    invoiceFileFolder = iqnInvoiceFolder;
                }
                else if (vendorModuleCd.ToLowerInvariant() == "udnag")
                {
                    invoiceFileFolder = udaanInvoiceFolder;
                }
                else if (vendorModuleCd.ToLowerInvariant() == "realag")
                {

                    invoiceFileFolder = realRealEstateInvoiceFolder;
                }
                else if (vendorModuleCd.ToLowerInvariant() == "forex")
                {

                    invoiceFileFolder = forexInvoiceFolder;
                }
                else
                {
                    invoiceFileFolder = genericVendorInvoicesFolderInS3;
                }
            }
            if (!string.IsNullOrWhiteSpace(attachedFileName))
            {
                context.Logger.Log($"Data :Now copying {attachedFileName} file from { bucketName + "/" + invoiceFileFolder} to { bucketName + vendorDFMDumpFolderinS3} folder");
                IAmazonS3 s3Client = new AmazonS3Client();
                var copyObjectRequest = new CopyObjectRequest()
                {
                    DestinationBucket = bucketName + "/" + vendorDFMDumpFolderinS3,
                    SourceBucket = bucketName + "/" + invoiceFileFolder,
                    SourceKey = attachedFileName,
                    DestinationKey = attachedFileName,
                };
                var copyObjectResponse = await s3Client.CopyObjectAsync(copyObjectRequest);
            }
            else
            {
                context.Logger.Log($"Error : Db entry doesnot contain the associated invoice pdf name of invoice number {invoiceNumber}");
                //Triggermail();
            }
        }

        private string SerializeStreamRecord(StreamRecord streamRecord)
        {
            using (var writer = new StringWriter())
            {
                _jsonSerializer.Serialize(writer, streamRecord);
                return writer.ToString();
            }
        }
    }
}