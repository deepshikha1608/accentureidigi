using _7433_iDigi_SimplifiedGSTCSVReader;
using _7433_iDigi_SimplifiedGSTCSVReader.Models;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Model;
using CsvHelper;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
//using OfficeOpenXml.Core.ExcelPackage;
//using ExcelWorksheet = OfficeOpenXml.ExcelWorksheet;
//using ExcelPackage = OfficeOpenXml.ExcelPackage;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_SimplifiedGSTCSVReader
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        IAmazonDynamoDB DbClient { get; set; }
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        /// 
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public static TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                if (System.Environment.GetEnvironmentVariable("DebugEnvironMent") == "true")
                { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                }
            }
        }
        public Function()
        {
            S3Client = new AmazonS3Client();
            LambdaClient = new AmazonLambdaClient();
            DbClient = new AmazonDynamoDBClient();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
        }

        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            context.Logger.Log($"PaymentBlock Dashboard Lambda invoked");
            var s3Event = evnt.Records?[0].S3;
            Console.WriteLine($"{s3Event}");
            string bucketName = evnt.Records[0].S3.Bucket.Name;
            Console.WriteLine($"{bucketName}");
            try
            {
                context.Logger.Log($"objectKeyForFetchingFolderName before: {evnt.Records[0].S3.Object.Key}");
                string objectKeyForFetchingFolderName = System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '));
                Console.WriteLine($"{objectKeyForFetchingFolderName}");
                string fileColsDbColsMappingTable = string.Empty;
                
                string GenericTableName = string.Empty;
                string VisaTableName = string.Empty;
                string IQNTableName = string.Empty;
                string ForexTableName = string.Empty;
                string vendorMasterTableName = string.Empty;
                string RealEstateTableName = string.Empty;
                //string GenericHistoryLogTable = string.Empty;
                //string VisaHistoryLogTable = string.Empty;
                //string IQNHistoryLogTable = string.Empty;
                //string ForexHistoryLogTable = string.Empty;
                //string RealEstateHistoryLogTable = string.Empty;
                string APTableName = string.Empty;
                //string APHistoryLogTable = string.Empty;
                //string PaymentCheckLogTable = string.Empty;
                string destinationpath = string.Empty;
                string PARFileUploadTableName = string.Empty;
                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CommonConstants.FileColsDbColsMappingTable;
                    GenericTableName = CommonConstants.AirId + "_" + CommonConstants.GenericInvoicetable;
                    IQNTableName = CommonConstants.AirId + "_" + CommonConstants.IQNInvoiceTable;
                    ForexTableName = CommonConstants.AirId + "_" + CommonConstants.ForexInvoiceTable;
                    VisaTableName = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                    RealEstateTableName = CommonConstants.AirId + "_" + CommonConstants.RealEstateInvoicesNewTable;
                    APTableName = CommonConstants.AirId + "_" + CommonConstants.APInvoiceTable;
                    //APHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.APHistoryLogTable;
                    vendorMasterTableName = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                    //GenericHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.GenericHistoryLogTable;
                    //IQNHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.IQNHistoryLogTable;
                    //ForexHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.ForexHistoryLogTable;
                    //RealEstateHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.RealEstateHistoryLogTable;
                    //VisaHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.VisaHistoryLogTable;
                    //PaymentCheckLogTable = CommonConstants.AirId + "_" + CommonConstants.PaymentCheckLogTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_" + CommonConstants.PARFileUploadTableName;
                }
                else
                {
                    fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.FileColsDbColsMappingTable;
                    GenericTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GenericInvoicetable;
                    IQNTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNInvoiceTable;
                    ForexTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexInvoiceTable;
                    VisaTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                    vendorMasterTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                    RealEstateTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateInvoicesNewTable;
                    //GenericHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GenericHistoryLogTable;
                    //IQNHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNHistoryLogTable;
                    //ForexHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexHistoryLogTable;
                    //RealEstateHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateHistoryLogTable;
                    //VisaHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaHistoryLogTable;
                    //PaymentCheckLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PaymentCheckLogTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PARFileUploadTableName;
                    APTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APInvoiceTable;
                    //APHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APHistoryLogTable;
                }
                context.Logger.Log($"{CloudEnvironment}"); 
                string[] objectKeySplited = objectKeyForFetchingFolderName.Split('/'); 
                Console.WriteLine($"{objectKeySplited[1]}");
                string fileName = objectKeySplited[2]; 
                context.Logger.Log($"filename :{fileName}"); Console.WriteLine($"{fileName}");
                if (objectKeySplited[1].ToLowerInvariant() == CommonConstants.SimplifiedCSVPath.ToLowerInvariant() && fileName.ToLowerInvariant() != CommonConstants.Payment_Check.ToLowerInvariant())
                {

                    IDigiS3 s3 = new IDigiS3();
                    Console.WriteLine($"{"s3"}");
                    IDigiDynamoDb db = new IDigiDynamoDb();
                    Console.WriteLine($"{"db"}");
                    ScanFilter scanFilter = new ScanFilter();
                    scanFilter.AddCondition("VendorModuleCd", ScanOperator.Equal, CommonConstants.PaymentRun_FileModuleCd);
                    scanFilter.AddCondition("IsActive", ScanOperator.Equal, CommonConstants.IsActiveTRUE);
                    List<FileColsDBColsMapping> fileColsDBColsMappingList = await db.ScanAsync<FileColsDBColsMapping>(scanFilter, fileColsDbColsMappingTable, context);

                    var PaymentRunCsv = await s3.GetFileFromS3(bucketName, objectKeySplited[0].ToLowerInvariant() + "/" + objectKeySplited[1].ToLowerInvariant(), fileName, context);
                    Console.WriteLine("getting file from s3 ....  filenaME" + fileName + "path   :   " + CommonConstants.SimplifiedCSVPath);

                    List<PaymentRun> paymentRunList = new List<PaymentRun>();
                    List<PaymentRun> paymentRunList1 = new List<PaymentRun>();
                    List<PaymentRun> paymentRunListIQN = new List<PaymentRun>();                   
                    List<PaymentRun> paymentRunList2 = new List<PaymentRun>();
                    List<PaymentRun> paymentRunReport = new List<PaymentRun>();
                    List<PaymentRun> PaymentRunNotPresent = new List<PaymentRun>();

                    List<PaymentRun> paymentRunListNotAP = new List<PaymentRun>();
                    List<PaymentRun> paymentRunListNotIQN = new List<PaymentRun>();
                    string fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff");
                    string uploadedBy = fileName.Split('_')[1].ToString();
                    if(PaymentRunCsv!=null)
                        { 
                    using (var fs = new StreamReader(PaymentRunCsv.ResponseStream))
                    {
                        var csv = new CsvReader(fs);
                        PaymentRun paymentRun = null;
                        context.Logger.Log($"Before entering the while loop");
                        while (csv.Read())
                        {
                            paymentRun = new PaymentRun();
                            paymentRun = ReadCSVDataBasedOnIndexRequired<PaymentRun>(csv, paymentRun, fileColsDBColsMappingList, context);
                            //Console.WriteLine($"{ JsonConvert.SerializeObject(paymentRun)}");
                            paymentRunList.Add(paymentRun);  
                        }
                            ScanFilter scanFilter1 = new ScanFilter();
                            scanFilter1.AddCondition("VendorId", ScanOperator.GreaterThan, 0);
                            List<VendorMaster> vendorMasterCompleteList = await db.ScanAsync<VendorMaster>(scanFilter1, vendorMasterTableName, context);

                            //paymentRunList.ForEach(x => { var y = vendorMasterCompleteList.Where(z => x.VendorRegisteredCd == z.VendorCode).FirstOrDefault();x.VendorModuleCd = !string.IsNullOrEmpty(y.VendorCd)? y.VendorCd:string.Empty; });
                            Console.WriteLine($"First { JsonConvert.SerializeObject(paymentRunList)}");
                            //paymentRunList1 = paymentRunList.Join(vendorMasterCompleteList, x => x.VendorRegisteredCd.Trim(), y => y.VendorCode.Trim(), (x, y) => { x.VendorModuleCd = y.VendorCd; x.IsExempted = y.IsExempted; return x; }).ToList();

                           
                            
                               Console.WriteLine($"Second { JsonConvert.SerializeObject(paymentRunList)}");

                           

                                Console.WriteLine($"Thrid { JsonConvert.SerializeObject(paymentRunList)}");
                            if (paymentRunList != null)
                                Console.WriteLine($"No of paymentRunList without applying distinct" + paymentRunList.Count());
                            if (paymentRunList != null)
                            {
                                paymentRunList = paymentRunList.Distinct().ToList();
                            }
                            

                            if (paymentRunList != null)
                            {
                                Console.WriteLine($"Count of payment list after the distinct function" + paymentRunList.Count());
                                Console.WriteLine($" Fourth { JsonConvert.SerializeObject(paymentRunList)}");
                            }

                            //foreach (var item in paymentRunList)
                            //{
                            //    item.VendorModuleCd = vendorMasterCompleteList.FirstOrDefault(x => x.VendorCode == item.VendorRegisteredCd) != null ? vendorMasterCompleteList.FirstOrDefault(x => x.VendorCode == item.VendorRegisteredCd).VendorCd : string.Empty;
                            //}

                            //var APPaymentRun= paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.AP_Vendor);

                            #region PaymentRun CSV 
                            if (fileName.ToLowerInvariant().Contains(CommonConstants.PaymentRunSapInsert.ToLowerInvariant()))
                            {
                                Console.WriteLine($"Upload Payment Run Lambda Invoked");
                                destinationpath = CommonConstants.PaymentRunReportCSVPath;
                                var count = paymentRunList.Count;

                                //PaymentCheckLog fileLog = new PaymentCheckLog()
                                //{
                                //    Id = 1,
                                //    FileNm = fileName,
                                //    CurrentStatus = CommonConstants.PaymentCheckStatus_SapDocNoUpdating,
                                //    CreatedBy = uploadedBy,
                                //    CreatedDttm = fileUploadedDttm
                                //};
                                //Table table = Table.LoadTable(DbClient, PaymentCheckLogTable);
                                //var doc = IDigiDynamoDocumentConverter.ToDocument(fileLog);
                                //await table.PutItemAsync(doc);
                                if (paymentRunList.Count() > 0)
                                {
                                    //Console.WriteLine($"AP:{ JsonConvert.SerializeObject(paymentRunList)}");
                                    var scanFilterAPTable = new ScanFilter();
                                    scanFilterAPTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                                    ScanOperationConfig scanOperationConfigAPTable = new ScanOperationConfig()
                                    {
                                        Filter = scanFilterAPTable
                                    };
                                    scanOperationConfigAPTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                    scanOperationConfigAPTable.Select = SelectValues.SpecificAttributes;
                                    var allAPInvoiceData = await ScanAndFindTheInvoice<APInvoice>(new APInvoice(), APTableName, scanOperationConfigAPTable);
                                    Console.WriteLine($"Data from AP");

                                    foreach (var item in paymentRunList)
                                    {
                                        var APInvoice = allAPInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber
                                                                           != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());                                     
                                        if (APInvoice != null)
                                        {
                                            Console.WriteLine($"Inserting into AP List");
                                            Console.WriteLine($"AP:{ JsonConvert.SerializeObject(item)}");
                                            if (APInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || APInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || APInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                                item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                            else
                                                item.PaymentStatus = CommonConstants.Payment_Block_STATUS;

                                            //await UpdateItem(APTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            //await Update_PaymentStatusAP(APTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                            item.Module = "AP";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = APInvoice.VendorInvoiceNumber, GSTR2AStatus = APInvoice.GSTR2AStatus, IsExempted = APInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });
                                        }
                                        else
                                        {
                                            paymentRunListNotAP.Add(item);
                                        }
                                    }
                                    if(paymentRunReport!=null)
                                        Console.WriteLine($"AP Invoices added to list" + paymentRunReport.Count());
                                    if(paymentRunListNotAP!=null)
                                        Console.WriteLine($"Invoices not added to list" + paymentRunListNotAP.Count());                                   
                                }

                                if (paymentRunListNotAP.Count() > 0)
                                {
                                    var scanFilterIqnTable = new ScanFilter();
                                    scanFilterIqnTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                                    ScanOperationConfig scanOperationConfigIqnTable = new ScanOperationConfig()
                                    {
                                        Filter = scanFilterIqnTable
                                    };
                                    scanOperationConfigIqnTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                    scanOperationConfigIqnTable.Select = SelectValues.SpecificAttributes;
                                    var allIqnnvoiceData = await ScanAndFindTheInvoice<IQNInvoice>(new IQNInvoice(), IQNTableName, scanOperationConfigIqnTable);
                                    Console.WriteLine($"Data from IQN");
                                    //Console.WriteLine($"IQN Invoices:{ JsonConvert.SerializeObject(iqnPaymentRun1)}");

                                    foreach (var item in paymentRunListNotAP)
                                    {
                                        var IQNInvoice = allIqnnvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber
                                                                           != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == '0'+item.VendorRegisteredCd.Trim());
                                        if (IQNInvoice != null)
                                        {
                                            Console.WriteLine($"Inserting into AP List");
                                            Console.WriteLine($"AP:{ JsonConvert.SerializeObject(item)}");
                                            if (IQNInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || IQNInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || IQNInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                                item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                            else
                                                item.PaymentStatus = CommonConstants.Payment_Block_STATUS;

                                            //await UpdateItem(APTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            //await Update_PaymentStatusAP(APTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                            item.Module = "IQN";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = IQNInvoice.VendorInvoiceNumber, GSTR2AStatus = IQNInvoice.GSTR2AStatus, IsExempted = IQNInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });
                                        }
                                        else
                                        {
                                            paymentRunListNotIQN.Add(item);
                                        }
                                    }
                                    if (paymentRunReport != null)
                                        Console.WriteLine($"AP Invoices and IQN Invoices added to list" + paymentRunReport.Count());
                                    
                                }




                                paymentRunList2 = paymentRunListNotIQN;
                                if (paymentRunList2 != null)
                                {
                                    Console.WriteLine($"No of paymentRunList2" + paymentRunList2.Count());
                                    foreach (var item in paymentRunList2)
                                    {
                                        var Invoice = vendorMasterCompleteList.FirstOrDefault(x => x.VendorCode != null && item.VendorRegisteredCd != null && x.VendorCode.Trim() == item.VendorRegisteredCd.Trim());
                                        if (Invoice != null)
                                        {
                                            paymentRunList1.Add(new PaymentRun { VendorRegisteredCd = Invoice.VendorCode, VendorModuleCd = Invoice.VendorCd, VendorInvoiceNumber = item.VendorInvoiceNumber, IsExempted = Invoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, SAPDocNo = item.SAPDocNo });
                                        }
                                        var Invoice1 = vendorMasterCompleteList.FirstOrDefault(x => x.VendorCode != null && item.VendorRegisteredCd != null && x.VendorCode.Trim() == "0" + item.VendorRegisteredCd.Trim());
                                        if (Invoice1 != null)
                                        {
                                            paymentRunListIQN.Add(new PaymentRun { VendorRegisteredCd = Invoice1.VendorCode, VendorModuleCd = Invoice1.VendorCd, VendorInvoiceNumber = item.VendorInvoiceNumber, IsExempted = Invoice1.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, SAPDocNo = item.SAPDocNo });
                                        }
                                    }
                                }
                                var IQNNotFound = paymentRunListIQN.Where(x => !paymentRunList1.Any(y => y.VendorRegisteredCd == x.VendorRegisteredCd.TrimStart(new Char[] { '0' })));
                                if(IQNNotFound!=null && IQNNotFound.Count()>0)
                                {
                                    foreach(var item in IQNNotFound)
                                    {
                                        item.Module = "IQN";
                                        item.PaymentStatus = "Invoice Not Found in Table";
                                        item.GSTR2AStatus = "Invoice Not Found in Table";
                                        PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, PaymentStatus = item.PaymentStatus, GSTR2AStatus=item.GSTR2AStatus });

                                    }
                                }
                                paymentRunList = new List<PaymentRun>();
                                paymentRunList = paymentRunList1;

                                var genericPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.Generic_Vendor);
                                var realPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.Realestate_Vendor);
                                var visaPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.Visa_Vendor);
                                //var iqnPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.IQN_Vendor);
                                var forexPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.Forex_Vendor);
                                //var cwtPaymentRun1 = paymentRunList.Where(x => x.VendorModuleCd == CommonConstants.CWT_Vendor);
                                //if (cwtPaymentRun1 != null && cwtPaymentRun1.Count() > 0)
                                //{
                                //    foreach (var item in cwtPaymentRun1)
                                //    {
                                //        item.Module = "CWT";
                                //        item.Comment = "Invoice Not Found in Table";
                                //        PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, Comment = item.Comment });

                                //    }
                                //}

                                if (genericPaymentRun1.Count() > 0)
                            {
                                var scanFilterGenTable = new ScanFilter();
                                scanFilterGenTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                                ScanOperationConfig scanOperationConfigGenTable = new ScanOperationConfig()
                                {
                                    Filter = scanFilterGenTable
                                };
                                scanOperationConfigGenTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                scanOperationConfigGenTable.Select = SelectValues.SpecificAttributes;
                                var allGenInvoiceData = await ScanAndFindTheInvoice<GenericInvoice>(new GenericInvoice(), GenericTableName, scanOperationConfigGenTable);
                                Console.WriteLine($"Data from Generic");
                                
                                    foreach (var item in genericPaymentRun1)
                                {
                                        var GenInvoice = allGenInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());
                                        if (GenInvoice != null)
                                    {
                                        Console.WriteLine($"Inserting into Generic List");
                                        Console.WriteLine($"Generic:{ JsonConvert.SerializeObject(item)}");
                                        if (GenInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || GenInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || GenInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                            item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                        else
                                            item.PaymentStatus = CommonConstants.Payment_Block_STATUS;
                                            //await UpdateItem(GenericTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            //await Update_PaymentStatus(GenericTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                           item.Module = "Generic";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = GenInvoice.VendorInvoiceNumber, GSTR2AStatus = GenInvoice.GSTR2AStatus, IsExempted = GenInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });

                                    }
                                        else
                                        {
                                            item.Module = "Generic";
                                            item.PaymentStatus = "Invoice Not Found in Table";
                                            item.GSTR2AStatus = "Invoice Not Found in Table";
                                            PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, PaymentStatus = item.PaymentStatus,GSTR2AStatus=item.GSTR2AStatus });
                                        }
                                }
                                    if (paymentRunReport != null)
                                        Console.WriteLine($"Generic + AP + IQN Invoices added to list" + paymentRunReport.Count());

                                }
                                if (realPaymentRun1.Count() > 0)
                            {
                                var scanFilterRealTable = new ScanFilter();
                                scanFilterRealTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                                ScanOperationConfig scanOperationConfigRealTable = new ScanOperationConfig()
                                {
                                    Filter = scanFilterRealTable
                                };
                                scanOperationConfigRealTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                scanOperationConfigRealTable.Select = SelectValues.SpecificAttributes;
                                var allRealInvoiceData = await ScanAndFindTheInvoice<RealEstateInvoice>(new RealEstateInvoice(), RealEstateTableName, scanOperationConfigRealTable);
                                    Console.WriteLine($"Data from Real Estate");
                                    //Console.WriteLine($"Real:{ JsonConvert.SerializeObject(realPaymentRun1)}");
                                    foreach (var item in realPaymentRun1)
                                {
                                        var RealInvoice = allRealInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());
                                        if (RealInvoice != null)
                                    {
                                        Console.WriteLine($"Inserting into Real Estate List");
                                        Console.WriteLine($"Real:{ JsonConvert.SerializeObject(item)}");
                                        if (RealInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || RealInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || RealInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                            item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                        else
                                            item.PaymentStatus = CommonConstants.Payment_Block_STATUS;
                                            //await UpdateItem(RealEstateTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            //await Update_PaymentStatus(RealEstateTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                            item.Module = "Real Estate";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = RealInvoice.VendorInvoiceNumber, GSTR2AStatus = RealInvoice.GSTR2AStatus, IsExempted = RealInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });

                                    }
                                        else
                                        {
                                            item.Module = "Real Estate";
                                            item.PaymentStatus = "Invoice Not Found in Table";
                                            item.GSTR2AStatus = "Invoice Not Found in Table";
                                            PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, PaymentStatus = item.PaymentStatus,GSTR2AStatus=item.GSTR2AStatus });

                                        }
                                    }
                                    if (paymentRunReport != null)
                                        Console.WriteLine($"RealEstate + Generic + AP + IQN Invoices added to list" + paymentRunReport.Count());
                                }
                            //    if (iqnPaymentRun1.Count() > 0)
                            //{
                            //    var scanFilterIqnTable = new ScanFilter();
                            //    scanFilterIqnTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                            //    ScanOperationConfig scanOperationConfigIqnTable = new ScanOperationConfig()
                            //    {
                            //        Filter = scanFilterIqnTable
                            //    };
                            //    scanOperationConfigIqnTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                            //    scanOperationConfigIqnTable.Select = SelectValues.SpecificAttributes;
                            //    var allIqnnvoiceData = await ScanAndFindTheInvoice<IQNInvoice>(new IQNInvoice(), IQNTableName, scanOperationConfigIqnTable);
                            //        Console.WriteLine($"Data from IQN");
                            //        //Console.WriteLine($"IQN Invoices:{ JsonConvert.SerializeObject(iqnPaymentRun1)}");
                            //        foreach (var item in iqnPaymentRun1)
                            //    {
                            //            var IqnInvoice = allIqnnvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());
                            //            if (IqnInvoice != null)
                            //        {
                            //            Console.WriteLine($"Inserting into IQN List");
                            //            Console.WriteLine($"IQN:{ JsonConvert.SerializeObject(item)}");
                            //            if (IqnInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || IqnInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || IqnInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                            //                item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                            //            else
                            //                item.PaymentStatus = CommonConstants.Payment_Block_STATUS;
                            //                //await Update_PaymentStatusIQN(IQNTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                            //                //await UpdateItem(IQNTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                            //                item.Module = "IQN";
                            //                paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = IqnInvoice.VendorInvoiceNumber, GSTR2AStatus = IqnInvoice.GSTR2AStatus, IsExempted = IqnInvoice.IsExempted, FinancialYear = item.FinancialYear.Trim(), CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });

                            //        }
                            //            else
                            //            {
                            //                item.Module = "IQN";
                            //                item.Comment = "Invoice Not Found in Table";
                            //                PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, Comment = item.Comment });

                            //            }
                            //        }
                            //        if (paymentRunReport != null)
                            //            Console.WriteLine($"IQN + RealEstate + Generic + AP Invoices added to list" + paymentRunReport.Count());
                            //    }

                            if (visaPaymentRun1.Count() > 0)
                            {
                                //Console.WriteLine($"Visa:{ JsonConvert.SerializeObject(visaPaymentRun1)}");
                                var scanFilterVisaTable = new ScanFilter();
                                scanFilterVisaTable.AddCondition("VendorCd", ScanOperator.IsNotNull);
                                ScanOperationConfig scanOperationConfigVisaTable = new ScanOperationConfig()
                                {
                                    Filter = scanFilterVisaTable
                                };
                                scanOperationConfigVisaTable.AttributesToGet = new List<string>() { "VendorCd", "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                scanOperationConfigVisaTable.Select = SelectValues.SpecificAttributes;
                                var allUdaanInvoiceData = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), VisaTableName, scanOperationConfigVisaTable);
                                    Console.WriteLine($"Data from Visa");
                                    foreach (var item in visaPaymentRun1)
                                {

                                        var visaInvoice = allUdaanInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());

                                        if (visaInvoice != null)
                                            {
                                        Console.WriteLine($"Inserting into Visa List");
                                        Console.WriteLine($"Visa:{ JsonConvert.SerializeObject(item)}");
                                        if (visaInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || visaInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || visaInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                            item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                        else
                                            item.PaymentStatus = CommonConstants.Payment_Block_STATUS;
                                            //await UpdateVisaItem(VisaTableName, visaInvoice.VendorCd, visaInvoice.VendorInvoiceNumber, item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            //await Update_VisaPaymentStatus(VisaTableName, visaInvoice.VendorCd.Trim(), visaInvoice.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                            item.Module = "Visa";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = visaInvoice.VendorInvoiceNumber, GSTR2AStatus = visaInvoice.GSTR2AStatus, IsExempted = visaInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module= item.Module });

                                            }
                                        else
                                        {
                                            item.Module = "Visa";
                                            item.PaymentStatus = "Invoice Not Found in Table";
                                            item.GSTR2AStatus = "Invoice Not Found in Table";
                                            PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, PaymentStatus = item.PaymentStatus,GSTR2AStatus=item.GSTR2AStatus });

                                        }
                                    }
                                    if (paymentRunReport != null)
                                        Console.WriteLine($"Visa + IQN + RealEstate + Generic + AP + IQN Invoices added to list" + paymentRunReport.Count());
                                }
                                if (forexPaymentRun1.Count() > 0)
                            {
                                var scanFilterforexTable = new ScanFilter();
                                scanFilterforexTable.AddCondition("VendorRegisteredCd", ScanOperator.IsNotNull);
                                ScanOperationConfig scanOperationConfigforexTable = new ScanOperationConfig()
                                {
                                    Filter = scanFilterforexTable
                                };
                                scanOperationConfigforexTable.AttributesToGet = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "GSTR2AStatus", "IsExempted" };
                                scanOperationConfigforexTable.Select = SelectValues.SpecificAttributes;
                                var allforexvoiceData = await ScanAndFindTheInvoice<ForexInvoice>(new ForexInvoice(), ForexTableName, scanOperationConfigforexTable);
                                    Console.WriteLine($"Data from Forex");
                                    // Console.WriteLine($"Forex Invoices:{ JsonConvert.SerializeObject(forexPaymentRun1)}");
                                    foreach (var item in forexPaymentRun1)
                                {
                                        var forexInvoice = allforexvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber != null && item.VendorInvoiceNumber != null && x.VendorInvoiceNumber.Trim() == item.VendorInvoiceNumber.Trim() && x.VendorRegisteredCd != null && item.VendorRegisteredCd != null && x.VendorRegisteredCd.Trim() == item.VendorRegisteredCd.Trim());
                                        if (forexInvoice != null)
                                        {
                                            Console.WriteLine($"Inserting into Forex List");
                                            Console.WriteLine($"Forex:{ JsonConvert.SerializeObject(item)}");
                                            if (forexInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || forexInvoice.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || forexInvoice.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
                                                item.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
                                            else
                                                item.PaymentStatus = CommonConstants.Payment_Block_STATUS;
                                            //await Update_PaymentStatusIQN(IQNTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.PaymentStatus.Trim(), fileUploadedDttm.Trim(), uploadedBy.Trim(), item.SAPDocNo.Trim(), item.FinancialYear.Trim(), item.CompanyCd.Trim());
                                            //await UpdateItem(IQNTableName, item.VendorRegisteredCd.Trim(), item.VendorInvoiceNumber.Trim(), item.SAPDocNo, item.FinancialYear, item.CompanyCd, fileUploadedDttm, uploadedBy);
                                            item.Module = "Forex";
                                            paymentRunReport.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = forexInvoice.VendorInvoiceNumber, GSTR2AStatus = forexInvoice.GSTR2AStatus, IsExempted = forexInvoice.IsExempted, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, PaymentStatus = item.PaymentStatus, Module = item.Module });

                                        }
                                        else
                                        {

                                            item.Module = "Forex";
                                            item.PaymentStatus = "Invoice Not Found in Table";
                                            item.GSTR2AStatus = "Invoice Not Found in Table";
                                            PaymentRunNotPresent.Add(new PaymentRun { SAPDocNo = item.SAPDocNo, VendorRegisteredCd = item.VendorRegisteredCd, VendorInvoiceNumber = item.VendorInvoiceNumber, FinancialYear = item.FinancialYear, CompanyCd = item.CompanyCd, Module = item.Module, PaymentStatus = item.PaymentStatus,GSTR2AStatus=item.GSTR2AStatus });
                                        }
                                    }
                                    if (paymentRunReport != null)
                                        Console.WriteLine($"Forex + Visa + IQN + RealEstate + Generic + AP + IQN Invoices added to list" + paymentRunReport.Count());
                                }
                                //fileLog = new PaymentCheckLog()
                                //{
                                //    Id = 1,
                                //    FileNm = fileName,
                                //    CurrentStatus = CommonConstants.PaymentCheckStatus_SapDocNoUpdated,
                                //    CreatedBy = uploadedBy,
                                //    CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff")
                                //};
                                //table = Table.LoadTable(DbClient, PaymentCheckLogTable);
                                //doc = IDigiDynamoDocumentConverter.ToDocument(fileLog);
                                //await table.PutItemAsync(doc);
                                List<PaymentRun1> paymentRunReport1 = new List<PaymentRun1>();

                                if (paymentRunReport.Count() > 0)
                                {
                                    
                                    foreach (var x in paymentRunReport)
                                    {
                                        paymentRunReport1.Add(new PaymentRun1 { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd, PaymentStatus = x.PaymentStatus, Module = x.Module });
                                    }
                                }
                                if(PaymentRunNotPresent!=null && PaymentRunNotPresent.Count()>0)
                                    {
                                        foreach (var x in PaymentRunNotPresent)
                                        {
                                            paymentRunReport1.Add(new PaymentRun1 { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd, PaymentStatus = x.PaymentStatus, Module = x.Module});
                                        }
                                    }
                                if(paymentRunReport1 != null && paymentRunReport1.Count()>0)
                                    { 
                                    MemoryStream stream2 = new MemoryStream();
                                using (var package = new ExcelPackage(new MemoryStream()))
                                {
                                    Console.WriteLine("inside 1st excel generation");
                                    var workbook = package.Workbook;
                                    Console.WriteLine("work book");
                                    var worksheet = workbook.Worksheets.Add("Payment Run Report");
                                    Console.WriteLine("work Sheet");
                                    Console.WriteLine(paymentRunReport1.Count);
                                    worksheet.Cells.LoadFromCollection(paymentRunReport1, true, OfficeOpenXml.Table.TableStyles.None);
                                    Console.WriteLine("before saving");
                                    package.SaveAs(stream2);
                                    Console.WriteLine("after saving");
                                }




                                IDigiS3 s4 = new IDigiS3();
                                //fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("ddMMyyyyHHmm");
                                string fileNm = CommonConstants.PaymentRunReportName + "_" + fileUploadedDttm + "_" + ".xlsx";
                                await s4.PutFileToS3(bucketName, CommonConstants.PaymentRunReport, stream2, fileNm, context);
                                PaymentCheckLog fileLog = new PaymentCheckLog()
                                {
                                    Id = 1,
                                    ModuleNm = "PostingBlock",
                                    FileNm = fileName,
                                    IsActive = 1,
                                    ReportName = fileNm,
                                    UploadedBy = uploadedBy,
                                    UploadDttm = fileUploadedDttm,
                                    TotalRecCnt = count.ToString(),
                                    FilePath = CommonConstants.Filepath,
                                    ReportFilePath = CommonConstants.PaymentRunReport
                                };
                                    Table table = Table.LoadTable(DbClient, PARFileUploadTableName);
                                    var doc = IDigiDynamoDocumentConverter.ToDocument(fileLog);
                                    await table.PutItemAsync(doc);
                                    //await db.UpdateItemAsync(fileLog, PaymentCheckLogTable, context);
                                }

                        }
                        #endregion

                        #region Payment block override
                        //if (fileName.ToLowerInvariant().Contains(CommonConstants.PaymentBlock_Override.ToLowerInvariant()))
                        //{
                        //    Console.WriteLine($"Payment Block override Lambda Invoked");
                        //    //List<InvoiceHistory> historyLogs = new List<InvoiceHistory>();
                        //    destinationpath = CommonConstants.PaymentBlock_OverrideReportCSVPath;
                        //    if (genericPaymentRun.Count() > 0)
                        //    {

                        //        Console.WriteLine($"Generic:{ JsonConvert.SerializeObject(genericPaymentRun)}");
                        //        foreach (var item in genericPaymentRun)
                        //        {
                        //            //await Update_PaymentStatus(GenericTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (realPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Real:{ JsonConvert.SerializeObject(realPaymentRun)}");
                        //        foreach (var item in realPaymentRun)
                        //        {
                        //            //var realList = await QueryTheTable<RealEstateInvoice>(item.VendorRegisteredCd, item.VendorInvoiceNumber, GenericTableName);
                        //            //await Update_PaymentStatus(RealEstateTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (iqnPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"IQN:{ JsonConvert.SerializeObject(iqnPaymentRun)}");
                        //        foreach (var item in iqnPaymentRun)
                        //        {
                        //           // await Update_PaymentStatus(IQNTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy);
                        //            //await Insert_HistoryLogs(IQNHistoryLogTable, item.VendorInvoiceNumber, item.VendorRegisteredCd, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy, context);
                        //        }
                        //    }
                        //    if (forexPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Forex:{ JsonConvert.SerializeObject(forexPaymentRun)}");
                        //        foreach (var item in forexPaymentRun)
                        //        {
                        //            //await Update_PaymentStatus(ForexTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy);
                        //            //await Insert_HistoryLogs(ForexHistoryLogTable, item.VendorInvoiceNumber, item.VendorRegisteredCd, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy, context);
                        //        }
                        //    }
                        //    if (visaPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Visa:{ JsonConvert.SerializeObject(visaPaymentRun)}");
                        //        var scanFilterVisaTable = new ScanFilter();
                        //        scanFilterVisaTable.AddCondition("VendorCd", ScanOperator.IsNotNull);
                        //        ScanOperationConfig scanOperationConfigVisaTable = new ScanOperationConfig()
                        //        {
                        //            Filter = scanFilterVisaTable
                        //        };
                        //        var allUdaanInvoiceData = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), VisaTableName, scanOperationConfigVisaTable);
                        //        foreach (var item in visaPaymentRun)
                        //        {
                        //            var visaInvoice = allUdaanInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber == item.VendorInvoiceNumber && x.VendorRegisteredCd == item.VendorRegisteredCd);
                        //            //await Update_VisaPaymentStatus(VisaTableName, visaInvoice.VendorCd, visaInvoice.VendorInvoiceNumber, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy);
                        //            //await Insert_HistoryLogs(VisaHistoryLogTable, item.VendorInvoiceNumber, item.VendorRegisteredCd, CommonConstants.Payment_BlockOverride_STATUS, fileUploadedDttm, uploadedBy, context);
                        //        }
                        //    }
                        //}
                        #endregion

                        #region Payment delete sapdoc nbr
                        //if (fileName.ToLowerInvariant().Contains(CommonConstants.Payment_DeleteSapDocNo.ToLowerInvariant()))
                        //{
                        //    Console.WriteLine($"Delete SAP Doc Lambda Invoked");
                        //    destinationpath = CommonConstants.Payment_DeleteSapDocNoCSVPath;
                        //    PaymentCheckLog fileLog = new PaymentCheckLog()
                        //    {
                        //        Id = 1,
                        //        FileNm = fileName,

                        //        UploadedBy = uploadedBy,
                        //        UploadDttm = fileUploadedDttm
                        //    };
                        //    Table table = Table.LoadTable(DbClient, PaymentCheckLogTable);
                        //    var doc = IDigiDynamoDocumentConverter.ToDocument(fileLog);
                        //    await table.PutItemAsync(doc);
                        //    if (genericPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Generic:{ JsonConvert.SerializeObject(genericPaymentRun)}");
                        //        foreach (var item in genericPaymentRun)
                        //        {
                        //            await UpdateItem(GenericTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, string.Empty, string.Empty, string.Empty, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (realPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Real:{ JsonConvert.SerializeObject(realPaymentRun)}");
                        //        foreach (var item in realPaymentRun)
                        //        {
                        //            await UpdateItem(RealEstateTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, string.Empty, string.Empty, string.Empty, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (iqnPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"IQN:{ JsonConvert.SerializeObject(iqnPaymentRun)}");
                        //        foreach (var item in iqnPaymentRun)
                        //        {
                        //            await UpdateItem(IQNTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, string.Empty, string.Empty, string.Empty, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (forexPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Forex:{ JsonConvert.SerializeObject(forexPaymentRun)}");
                        //        foreach (var item in forexPaymentRun)
                        //        {
                        //            await UpdateItem(ForexTableName, item.VendorRegisteredCd, item.VendorInvoiceNumber, string.Empty, string.Empty, string.Empty, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    if (visaPaymentRun.Count() > 0)
                        //    {
                        //        Console.WriteLine($"Visa:{ JsonConvert.SerializeObject(visaPaymentRun)}");
                        //        var scanFilterVisaTable = new ScanFilter();
                        //        scanFilterVisaTable.AddCondition("VendorCd", ScanOperator.IsNotNull);
                        //        ScanOperationConfig scanOperationConfigVisaTable = new ScanOperationConfig()
                        //        {
                        //            Filter = scanFilterVisaTable
                        //        };
                        //        var allUdaanInvoiceData = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), VisaTableName, scanOperationConfigVisaTable);
                        //        foreach (var item in visaPaymentRun)
                        //        {
                        //            var visaInvoice = allUdaanInvoiceData.FirstOrDefault(x => x.VendorInvoiceNumber == item.VendorInvoiceNumber && x.VendorRegisteredCd == item.VendorRegisteredCd);
                        //            await UpdateVisaItem(VisaTableName, visaInvoice.VendorCd, visaInvoice.VendorInvoiceNumber, string.Empty, string.Empty,string.Empty, fileUploadedDttm, uploadedBy);
                        //        }
                        //    }
                        //    fileLog = new PaymentCheckLog()
                        //    {
                        //        Id = 1,
                        //        FileNm = fileName,
                        //        IsActive=1,
                        //        UploadedBy = uploadedBy,
                        //        UploadDttm= fileUploadedDttm
                        //    };
                        //    var doc1 = IDigiDynamoDocumentConverter.ToDocument(fileLog);
                        //    await table.PutItemAsync(doc);
                        //}
                        #endregion
                    }
                }
                else {
                        Console.WriteLine("no csv available");

                    }
                }
                #region Payment Check Lambda
     //           if (fileName.ToLowerInvariant().Contains(CommonConstants.Payment_Check.ToLowerInvariant()))
     //           {
     //               Console.WriteLine($"PaymentCheck Lambda Invoked");
     //               IDigiDynamoDb db = new IDigiDynamoDb();
     //               string fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff");
     //               string uploadedBy = "Lambda";
     //               destinationpath = CommonConstants.Payment_CheckCSVPath;
     //               //PaymentCheckLog fileLog = new PaymentCheckLog()
     //               //{
     //               //    Id = 1,
     //               //    CurrentStatus = CommonConstants.PaymentCheckStatus_PaymentCheck,
     //               //    IsReportAvailable = 0,
     //               //    CreatedBy = uploadedBy,
     //               //    CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff")
     //               //};
     //               //await db.UpdateItemAsync(fileLog, PaymentCheckLogTable, context);
     //               var scanFilter = new ScanFilter();
     //               List<PaymentRun> paymentRunReport = new List<PaymentRun>();
     //               scanFilter.AddCondition("SAPDocNo", ScanOperator.IsNotNull);
     //              scanFilter.AddCondition("PaymentStatus", ScanOperator.Contains, CommonConstants.Payment_PendingCheck_STATUS);
     //               ScanOperationConfig scanOperationConfig = new ScanOperationConfig()
     //               {
     //                   Filter = scanFilter
     //               };
					//ScanOperationConfig scanOperationConfigVis = new ScanOperationConfig()
					//{
					//	Filter = scanFilter
					//};
					//scanOperationConfig.AttributesToGet = new List<string>() {"VendorRegisteredCd", "VendorInvoiceNumber", "PaymentStatus", "SAPDocNo", "GSTR2AStatus", "IsExempted", "FinancialYear", "CompanyCd" };
					//scanOperationConfig.Select = SelectValues.SpecificAttributes;

					//scanOperationConfigVis.AttributesToGet = new List<string>() { "VendorCd", "VendorRegisteredCd", "VendorInvoiceNumber", "PaymentStatus", "SAPDocNo", "GSTR2AStatus", "IsExempted", "FinancialYear", "CompanyCd" };
					//scanOperationConfigVis.Select = SelectValues.SpecificAttributes;
					//var allGenericInvoiceData = await ScanAndFindTheInvoice<GenericInvoice>(new GenericInvoice(), GenericTableName, scanOperationConfig);

     //               var allIQNInvoiceData = await ScanAndFindTheInvoice<IQNInvoice>(new IQNInvoice(), IQNTableName, scanOperationConfig);
                  
     //               var allUdaanInvoiceData = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), VisaTableName, scanOperationConfigVis);

     //               var allRealEstateInvoiceData = await ScanAndFindTheInvoice<RealEstateInvoice>(new RealEstateInvoice(), RealEstateTableName, scanOperationConfig);
     //               var allAPInvoiceData = await ScanAndFindTheInvoice<APInvoice>(new APInvoice(), APTableName, scanOperationConfig);
     //               if (allGenericInvoiceData.Count() > 0)
     //               {
     //                   Console.WriteLine($"PaymentCheck:");
     //                   foreach (var x in allGenericInvoiceData)
     //                   {
     //                       Console.WriteLine($"Generic:{ JsonConvert.SerializeObject(x)}");
     //                       if (x.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
     //                           x.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
     //                       else
     //                           x.PaymentStatus = CommonConstants.Payment_Block_STATUS;

     //                       //await Update_PaymentStatus(GenericTableName, x.VendorRegisteredCd, x.VendorInvoiceNumber, x.PaymentStatus, fileUploadedDttm, uploadedBy);
     //                       paymentRunReport.Add(new PaymentRun { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //               }
     //               if (allIQNInvoiceData.Count() > 0)
     //               {
     //                   foreach (var x in allIQNInvoiceData)
     //                   {
     //                       Console.WriteLine($"IQN:{ JsonConvert.SerializeObject(x)}");
     //                       if (x.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
     //                           x.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
     //                       else
     //                           x.PaymentStatus = CommonConstants.Payment_Block_STATUS;
     //                       //await Update_PaymentStatusIQN(IQNTableName, x.VendorRegisteredCd, x.VendorInvoiceNumber, x.PaymentStatus, fileUploadedDttm, uploadedBy);
     //                     //  await Insert_HistoryLogs(IQNHistoryLogTable, x.VendorInvoiceNumber, x.VendorRegisteredCd, x.PaymentStatus, fileUploadedDttm, uploadedBy, context);
     //                       paymentRunReport.Add(new PaymentRun { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //               }
                    
     //               if (allRealEstateInvoiceData.Count() > 0)
     //               {
     //                   foreach (var x in allRealEstateInvoiceData)
     //                   {
     //                       Console.WriteLine($"Real:{ JsonConvert.SerializeObject(x)}");
     //                       if (x.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
     //                           x.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
     //                       else
     //                           x.PaymentStatus = CommonConstants.Payment_Block_STATUS;
     //                       //await Update_PaymentStatus(RealEstateTableName, x.VendorRegisteredCd, x.VendorInvoiceNumber, x.PaymentStatus, fileUploadedDttm, uploadedBy);
     //                       paymentRunReport.Add(new PaymentRun { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //               }
     //               if (allUdaanInvoiceData.Count() > 0)
     //               {
     //                   foreach (var x in allUdaanInvoiceData)
     //                   {
     //                       Console.WriteLine($"Visa:{ JsonConvert.SerializeObject(x)}");
     //                       if (x.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
     //                           x.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
     //                       else
     //                           x.PaymentStatus = CommonConstants.Payment_Block_STATUS;
     //                       //await Update_VisaPaymentStatus(VisaTableName, x.VendorCd, x.VendorInvoiceNumber, x.PaymentStatus, fileUploadedDttm, uploadedBy);
     //                       //await Insert_HistoryLogs(VisaHistoryLogTable, x.VendorInvoiceNumber, x.VendorRegisteredCd, x.PaymentStatus, fileUploadedDttm, uploadedBy, context);
     //                       paymentRunReport.Add(new PaymentRun { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //               }
     //               if (allAPInvoiceData.Count() > 0)
     //               {
     //                   foreach (var x in allAPInvoiceData)
     //                   {
     //                       Console.WriteLine($"AP:{ JsonConvert.SerializeObject(x)}");
     //                       if (x.GSTR2AStatus == CommonConstants.GSTR2A_Matched_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_Credit_STATUS || x.GSTR2AStatus == CommonConstants.GSTR2A_NotRequied_STATUS)
     //                           x.PaymentStatus = CommonConstants.Payment_GoodToPay_Status;
     //                       else
     //                           x.PaymentStatus = CommonConstants.Payment_Block_STATUS;
     //                       //await Update_PaymentStatusAP(APTableName, x.VendorRegisteredCd, x.VendorInvoiceNumber, x.PaymentStatus, fileUploadedDttm, uploadedBy);
     //                      // await Insert_HistoryLogs(APHistoryLogTable, x.VendorInvoiceNumber, x.VendorRegisteredCd, x.PaymentStatus, fileUploadedDttm, uploadedBy, context);
     //                       paymentRunReport.Add(new PaymentRun { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //               }
                    

     //               if (paymentRunReport.Count() > 0)
     //               {
     //                   List<PaymentRun1> paymentRunReport1 = new List<PaymentRun1>();
     //                   foreach (var x in paymentRunReport)
     //                   {
     //                       paymentRunReport1.Add(new PaymentRun1 { SAPDocNo = x.SAPDocNo, VendorRegisteredCd = x.VendorRegisteredCd, VendorInvoiceNumber = x.VendorInvoiceNumber, GSTR2AStatus = x.GSTR2AStatus, IsExempted = x.IsExempted, FinancialYear = x.FinancialYear, CompanyCd = x.CompanyCd });
     //                   }

     //                       MemoryStream stream2 = new MemoryStream();
     //                   using (var package = new ExcelPackage(new MemoryStream()))
     //                   {
     //                       Console.WriteLine("inside 1st excel generation");
     //                       var workbook = package.Workbook;
     //                       Console.WriteLine("work book");
     //                       var worksheet = workbook.Worksheets.Add("Payment Run Report");
     //                       Console.WriteLine("work Sheet");
     //                       Console.WriteLine(paymentRunReport1.Count);
     //                       worksheet.Cells.LoadFromCollection(paymentRunReport1, true, OfficeOpenXml.Table.TableStyles.None);
     //                       Console.WriteLine("before saving");
     //                       package.SaveAs(stream2);
     //                       Console.WriteLine("after saving");
     //                   }



                        
     //                   IDigiS3 s3 = new IDigiS3();
     //                   fileUploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("ddMMyyyyHHmm");
     //                   string fileNm = CommonConstants.PaymentRunReportName + "_" + fileUploadedDttm + "_" + ".xlsx";
     //                   await s3.PutFileToS3(bucketName, CommonConstants.PaymentRunReport, stream2, fileNm, context);
     //                   //fileLog = new PaymentCheckLog()
     //                   //{
     //                   //    Id = 1,
     //                   //    CurrentStatus = CommonConstants.PaymentCheckStatus_PaymentCheckCompleted,
     //                   //    IsReportAvailable = 1,
     //                   //    ReportName = fileNm,
     //                   //    CreatedBy = uploadedBy,
     //                   //    CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff")
     //                   //};
     //                   //await db.UpdateItemAsync(fileLog, PaymentCheckLogTable, context);
     //               }
     //           }
                #endregion
                if (!string.IsNullOrEmpty(fileName))
                {
                    var sourcepath = "public/"+CommonConstants.SimplifiedCSVPath;
                    if (!(fileName.ToLowerInvariant().Contains(CommonConstants.Payment_Check.ToLowerInvariant())))
                    {
                        Console.WriteLine("bucket name : " + bucketName + "   sourcepath is :" + sourcepath + "  destination path is :" + destinationpath + "  file name is : " + fileName);
                        await CopyFileFromOneFolderToOther(bucketName, sourcepath, bucketName, destinationpath, fileName) ;
                        await DeleteFile(bucketName, sourcepath, fileName);
                    }

                    context.Logger.Log($"Now the file { fileName} is moved to private {bucketName + destinationpath}");
                }
            }
            catch (Exception e)
            {
                //context.Logger.LogLine($"Error getting object {s3Event.Object.Key} from bucket {s3Event.Bucket.Name}. Make sure they exist and your bucket is in the same region as this function.");
                context.Logger.LogLine(e.Message);
                context.Logger.LogLine(e.StackTrace);
                throw;
            }
        }
  //      private async Task UpdateItem(string tableName, string vendorCd, string invoiceNbr, string sapDocNo,string financialyear,string CompanyCd, string uplodedDttm, string uploadedBy)
  //      {
  //          var updateItemRequest = new UpdateItemRequest
  //          {
  //              TableName = tableName,
  //              Key = new Dictionary<string, AttributeValue>()
  //              {
  //                  { "VendorRegisteredCd", new AttributeValue { S= vendorCd} },
  //                  { "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
  //              },
  //              UpdateExpression = "SET SAPDocNo = :SAPDocNo, PaymentStatus =:PaymentStatus, FinancialYear = :FinancialYear, CompanyCd = :CompanyCd",// ,ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SearchModifiedDttm=:SearchModifiedDttm
  //              ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
  //              {
  //                  {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":PaymentStatus",new AttributeValue {S="PendingPaymentCheck"} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} }, 
  //                  //{":ModefiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm")} },
  //                  //{":SearchModifiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm")} },
  //                  //{":ModefiedBy",new AttributeValue { S= uploadedBy} },
  //              }
  //          };
  //          var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
  //          Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
  //      }
  //      private async Task Update_PaymentStatus(string tableName, string vendorCd, string invoiceNbr, string paymentStatus, string uplodedDttm, string uploadedBy, string sapDocNo, string financialyear, string CompanyCd)
  //      {

  //          var updateItemRequest = new UpdateItemRequest
  //          {
  //              TableName = tableName,
  //              Key = new Dictionary<string, AttributeValue>()
  //              {
  //                  { "VendorRegisteredCd", new AttributeValue { S= vendorCd} },
  //                  { "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
  //              },
  //              UpdateExpression = "SET PaymentStatus = :PaymentStatus, ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SearchModifiedDttm=:SearchModifiedDttm, SAPDocNo = :SAPDocNo, FinancialYear = :FinancialYear, CompanyCd = :CompanyCd",
  //              ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
  //              {
  //                  {":PaymentStatus",new AttributeValue {S=paymentStatus} },
  //                    {":ModefiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm")} },
  //                  {":SearchModifiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm")} },
  //                  {":ModefiedBy",new AttributeValue { S= uploadedBy} },
  //                  {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} },
  //              }
  //          };



  //          //if (!tableName.Contains("IQN") || !tableName.Contains("Forex"))
  //          //{
  //          //    Dictionary<string, AttributeValue> invoiceHistoryLog = new Dictionary<string, AttributeValue>();
  //          //    invoiceHistoryLog.Add("InvoiceStatusCd", new AttributeValue { S = paymentStatus });
  //          //    invoiceHistoryLog.Add("CreateDttm", new AttributeValue { S = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm") });
  //          //    invoiceHistoryLog.Add("SearchCreateDttm", new AttributeValue { S = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm") });
  //          //    invoiceHistoryLog.Add("CreateUserId", new AttributeValue { S = uploadedBy });
  //          //    updateItemRequest.ExpressionAttributeNames.Add("#invoiceHistoryLog", "InvoiceHistoryLogs");
  //          //    updateItemRequest.ExpressionAttributeValues.Add(":invoiceHistoryLog", new AttributeValue
  //          //    {
  //          //        L = new List<AttributeValue>()
  //          //                { new AttributeValue() { M = invoiceHistoryLog}}
  //          //    });
  //          //    updateItemRequest.UpdateExpression = "SET PaymentStatus = :PaymentStatus, ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SearchModifiedDttm=:SearchModifiedDttm,#invoiceHistoryLog=list_append(#invoiceHistoryLog,:invoiceHistoryLog)";
  //          //}
  //          var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
  //          Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
  //      }

		//private async Task Update_PaymentStatusIQN(string tableName, string vendorCd, string invoiceNbr, string paymentStatus, string uplodedDttm, string uploadedBy, string sapDocNo, string financialyear, string CompanyCd)
		//{

		//	var updateItemRequest = new UpdateItemRequest
		//	{
		//		TableName = tableName,
		//		Key = new Dictionary<string, AttributeValue>()
		//		{
		//			{ "VendorRegisteredCd", new AttributeValue { S= vendorCd} },
		//			{ "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
		//		},
		//		UpdateExpression = "SET PaymentStatus = :PaymentStatus,SearchModifiedDttm=:SearchModifiedDttm,SAPDocNo = :SAPDocNo, FinancialYear = :FinancialYear, CompanyCd = :CompanyCd",
		//		ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
		//		{
		//			{":PaymentStatus",new AttributeValue {S=paymentStatus} },
		//		    {":SearchModifiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm")} },
  //                   {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} },

  //              }
		//	};

		//	var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
		//	Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
		//}


		//private async Task Update_PaymentStatusAP(string tableName, string vendorCd, string invoiceNbr, string paymentStatus, string uplodedDttm, string uploadedBy, string sapDocNo, string financialyear, string CompanyCd)
  //      {
  //          Console.WriteLine("Inside payment status ap");
  //          var updateItemRequest = new UpdateItemRequest
  //          {
  //              TableName = tableName,
  //              Key = new Dictionary<string, AttributeValue>()
  //              {
  //                  { "VendorRegisteredCd", new AttributeValue { S= vendorCd} },
  //                  { "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
  //              },
  //              UpdateExpression = "SET PaymentStatus = :PaymentStatus, ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SAPDocNo = :SAPDocNo, FinancialYear = :FinancialYear, CompanyCd = :CompanyCd",
  //              ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
  //              {
  //                  {":PaymentStatus",new AttributeValue {S=paymentStatus} },
  //                    {":ModefiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm")} },
  //                   {":ModefiedBy",new AttributeValue { S= uploadedBy} },
  //                    {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} },
  //              }
  //          };

  //          var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
  //          Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
  //      }
  //      private async Task Update_VisaPaymentStatus(string tableName, string vendorCd, string invoiceNbr, string paymentStatus, string uplodedDttm, string uploadedBy, string sapDocNo, string financialyear, string CompanyCd)
  //      {
  //          var updateItemRequest = new UpdateItemRequest
  //          {
  //              TableName = tableName,
  //              Key = new Dictionary<string, AttributeValue>()
  //              {
  //                  { "VendorCd", new AttributeValue { S= vendorCd} },
  //                  { "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
  //              },
  //              UpdateExpression = "SET PaymentStatus = :PaymentStatus, ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SearchModifiedDttm=:SearchModifiedDttm,SAPDocNo = :SAPDocNo, FinancialYear = :FinancialYear, CompanyCd = :CompanyCd",
  //              ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
  //              {
  //                  {":PaymentStatus",new AttributeValue {S=paymentStatus} },
  //                 {":ModefiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm")} },
  //                  {":SearchModifiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm")} },
  //                  {":ModefiedBy",new AttributeValue { S= uploadedBy} },
  //                   {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} },
  //              }
  //          };
  //          var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
  //          Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
  //      }
  //      private async Task UpdateVisaItem(string tableName, string vendorCd, string invoiceNbr, string sapDocNo,string financialyear,string CompanyCd, string uplodedDttm, string uploadedBy)
  //      {
  //          var updateItemRequest = new UpdateItemRequest
  //          {
  //              TableName = tableName,
  //              Key = new Dictionary<string, AttributeValue>()
  //              {
  //                  { "VendorCd", new AttributeValue { S= vendorCd} },
  //                  { "VendorInvoiceNumber",new AttributeValue {S = invoiceNbr} }
  //              },
  //              UpdateExpression = "SET SAPDocNo = :SAPDocNo, PaymentStatus =:PaymentStatus, FinancialYear = :FinancialYear, CompanyCd =:CompanyCd",//, ModefiedDttm=:ModefiedDttm,ModefiedBy=:ModefiedBy,SearchModifiedDttm=:SearchModifiedDttm
  //              ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
  //              {
  //                  {":SAPDocNo",new AttributeValue {S=sapDocNo} },
  //                  {":FinancialYear",new AttributeValue {S=financialyear} },
  //                  {":PaymentStatus",new AttributeValue {S="PendingPaymentCheck"} },
  //                  {":CompanyCd",new AttributeValue {S=CompanyCd} }, 
  //                  //{":ModefiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm")} },
  //                  //{":SearchModifiedDttm",new AttributeValue { S= TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm")} },
  //                  //{":ModefiedBy",new AttributeValue { S= uploadedBy} },
  //              }
  //          };
  //          var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
  //          Console.WriteLine($" Updated {vendorCd},{invoiceNbr} ");
  //      }
  //      //private async Task Insert_HistoryLogs(string tableNm, string invNbr, string vendorCd, string status, string modefiedDttm, string modefiedBy, ILambdaContext context)
  //      //{
  //      //    DateTime datetime = new DateTime();
  //      //    IDigiDynamoDb db = new IDigiDynamoDb();
  //      //    InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
  //      //    {
  //      //        Newlog.SourceId = vendorCd + "-" + invNbr;
  //      //        Newlog.ModifiedBy = modefiedBy;
  //      //        Newlog.StatusCd = status;
  //      //        Newlog.StatusDt = modefiedDttm;
  //      //        Newlog.VendorCd = vendorCd;
  //      //        if (!string.IsNullOrEmpty(Newlog.StatusDt))
  //      //        {
  //      //            if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
  //      //            {
  //      //                Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
  //      //            }
  //      //        }
  //      //    }
  //      //    await db.InsertAsync<InvoiceHistoryLogs>(Newlog, tableNm, context);
  //      //}
        private async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            Search search = table.Scan(scanOperationConfig);
            List<T> resultList = new List<T>();
            int count = 0;
            do
            {
                count = count + 1;
                List<Document> docList = await search.GetNextSetAsync();
                foreach (var document in docList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            }
            while (!search.IsDone);
            Console.WriteLine($"Data :Total number of iteration  :{count}");
            Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
            return resultList;
        }
        private async Task<List<T>> QueryTheTable<T>(string vendorCode, string invNumber, string tableNm)
        {
            List<T> lisofT = new List<T>();
            IDigiDynamoDb db = new IDigiDynamoDb();
            QueryRequest q = new QueryRequest()
            {
                KeyConditionExpression = "VendorRegisteredCd = :VendorCode AND VendorInvoiceNumber = :VendorInvoiceNumber",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                {
                    [":VendorCode"] = new AttributeValue { S = vendorCode },
                    [":VendorInvoiceNumber"] = new AttributeValue { S = invNumber }
                },
                TableName = tableNm,
                ProjectionExpression = "VendorRegisteredCd,VendorInvoiceNumber,InvoiceHistoryLogs"
            };
            lisofT = await db.QueryTheTable<T>(q);
            return lisofT;

        }
        private T ReadCSVDataBasedOnIndexRequired<T>(CsvReader csv, T tObject, List<FileColsDBColsMapping> fileColsDBColsMappinglist, ILambdaContext context)
        {
            try
            {

                foreach (var fileColsDBColsMap in fileColsDBColsMappinglist)
                {
                    string requiredFieldname = fileColsDBColsMap.ReqFieldNm;
                    int indexInCsv = fileColsDBColsMap.IndexOfCollInCsvfile;

                    PropertyInfo propertyInfo = tObject.GetType().GetProperty(requiredFieldname);
                    if (propertyInfo != null)
                    {

                        var propType = propertyInfo.PropertyType;

                        if (propType == typeof(string))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                propertyInfo.SetValue(tObject, csv.GetField<string>(indexInCsv));
                            }
                        }
                        else if (propType == typeof(int) || propType == typeof(int?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                int a;
                                if (int.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, int.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        else if (propType == typeof(double) || propType == typeof(double?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                double a;
                                if (double.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, double.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                        else if (propType == typeof(float) || propType == typeof(float?))
                        {
                            if (!string.IsNullOrEmpty(csv.GetField<string>(indexInCsv)))
                            {
                                float a;
                                if (float.TryParse(csv.GetField<string>(indexInCsv), out a))
                                {
                                    propertyInfo.SetValue(tObject, float.Parse(csv.GetField<string>(indexInCsv)));
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"{e.Message}");
                context.Logger.Log($"{e.InnerException}");
                context.Logger.Log($"{e.StackTrace}");
            }
            return tObject;
        }
        public static MemoryStream ExportToExcel<T>(List<T> icObjectList, string filename)
        {
            MemoryStream outputStream = new MemoryStream();
            if (icObjectList.Count > 0)
            {
                using (ExcelPackage excelPackage = new ExcelPackage())
                {
                    var t = typeof(T);
                    var Headings = t.GetProperties();
                    var workSheet = GetWorkSheetDetails<T>(excelPackage, icObjectList, filename);
                    workSheet.Cells["A2"].LoadFromCollection(icObjectList, false, OfficeOpenXml.Table.TableStyles.Medium1);

                    excelPackage.SaveAs(outputStream);
                }
            }


            return outputStream;
        }
        private static ExcelWorksheet GetWorkSheetDetails<T>(ExcelPackage excelPackage, List<T> lstIcOutput, string filename)
        {
            filename = filename + DateTime.Now.ToString();
            var workSheet = excelPackage.Workbook.Worksheets.Add(filename);
            workSheet.View.ShowGridLines = false;
            workSheet.DefaultColWidth = 20;
            GetColumnHeading<T>(lstIcOutput, workSheet);
            return workSheet;
        }
        public static void GetColumnHeading<T>(List<T> query, ExcelWorksheet ws)
        {
            var t = typeof(T);
            var Headings = t.GetProperties();
            for (int i = 0; i < Headings.Count(); i++)
            {
                ws.Cells[1, i + 1].Value = Headings[i].Name;
                ws.Cells[1, i + 1].Style.Font.Bold = true;

            }
        }
        private async Task<CopyObjectResponse> CopyFileFromOneFolderToOther(string sourceBucket, string sourceFolder, string destinationBucket, string destinationFolder, string fileName)
        {
            var copyObjectRequest = new CopyObjectRequest()
            {
                DestinationKey = fileName,
                SourceKey = fileName,
                DestinationBucket = destinationBucket + "/" + destinationFolder,
                SourceBucket = sourceBucket + "/" + sourceFolder,
            };
            CopyObjectResponse copyObjectReponse = await S3Client.CopyObjectAsync(copyObjectRequest);
            return copyObjectReponse;
        }
        private async Task<DeleteObjectResponse> DeleteFile(string bucket, string folder, string file)
        {
            var deleteObjectRequest = new DeleteObjectRequest()
            {
                BucketName = bucket + "/" + folder,
                Key = file
            };
            var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);
            return deleteObjectResponse;
        }
    }
}
