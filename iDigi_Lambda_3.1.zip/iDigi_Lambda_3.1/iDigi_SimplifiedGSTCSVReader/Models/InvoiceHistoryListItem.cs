﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _7433_iDigi_SimplifiedGSTCSVReader.Models
{
    public class InvoiceHistoryListItem
    {
        public InvoiceHistoryListItem()
        {

        }       
        public int Id { get; set; }
        public string InvoiceStatusCd { get; set; }       
        public string CreateDttm { get; set; }
        public string SearchCreateDttm { get; set; }
        public string CreateUserId { get; set; }     
        public string DFMURN { get; set; }       
        public string AttachedFile { get; set; }       
        public string InvoiceReceiptDt { get; set; }        
        public string SearchInvoiceReceiptDt { get; set; }       
        public string RejectionReason { get; set; }

    }
}
