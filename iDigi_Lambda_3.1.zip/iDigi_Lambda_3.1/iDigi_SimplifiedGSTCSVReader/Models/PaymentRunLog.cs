﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _7433_iDigi_SimplifiedGSTCSVReader.Models
{
    public class PaymentCheckLog
    {

        public string ReportFilePath { get; set; }
        public string ReportName { get; set; }
        public int Id { get; set; }
        public string ModuleNm { get; set; }
        public string UploadDttm { get; set; }
        public string UploadedBy { get; set; }
        public string FileNm { get; set; }
        public string FilePath { get; set; }
        public string TotalRecCnt { get; set; }
        
        public int IsActive { get; set; }

    }
}
