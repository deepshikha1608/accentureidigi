﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _7433_iDigi_SimplifiedGSTCSVReader.Models
{
    public class PaymentRun
    {
        public string SAPDocNo { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string GSTR2AStatus { get; set; }
        public string IsExempted { get; set; }
        public string VendorModuleCd { get; set; }
        public string FinancialYear { get; set; }
        public string CompanyCd { get; set; }
        public string PaymentStatus { get; set; }
        public string Module { get; set; }

    }
}
