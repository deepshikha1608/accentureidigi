﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _7433_iDigi_SimplifiedGSTCSVReader
{
    public class FileColsDBColsMapping
    {
        public int FileColsDBColsMappingId { get; set; }
        public int IndexOfCollInCsvfile { get; set; }
        public string ReqFieldNm { get; set; }
        public string FileTypeCd { get; set; }
        public string HeaderColType { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorModuleCd { get; set; }
        public string IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }

    }
}
