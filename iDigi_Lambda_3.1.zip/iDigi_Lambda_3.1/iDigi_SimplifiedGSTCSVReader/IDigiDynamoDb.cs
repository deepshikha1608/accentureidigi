﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_SimplifiedGSTCSVReader
{
    public class IDigiDynamoDb
    {
        static IAmazonDynamoDB dbClient { get; set; }
        static Amazon.DynamoDBv2.DataModel.DynamoDBContext db { get; set; }
        public IDigiDynamoDb()
        {
            dbClient = new AmazonDynamoDBClient();
            db = new DynamoDBContext(dbClient);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InsertAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            var document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.PutItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task UpdateItemAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Document document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.UpdateItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="scanFilterCondition"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<List<T>> ScanAsync<T>(ScanFilter scanFilterCondition, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            do
            {
                List<Document> documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }

        /// <summary>
        /// QueryThetableForCount
        /// </summary>
        /// <param name="queryRequest"></param>
        /// <returns></returns>
        public async Task<List<T>> QueryTheTable<T>(QueryRequest queryRequest)
        {
            List<T> lisOfT = new List<T>();
            QueryResponse response = null;
            do
            {
                response = await dbClient.QueryAsync(queryRequest);
                if (response != null && response.Count > 0)
                {
                    foreach (var item in response.Items)
                    {
                        var document = Document.FromAttributeMap(item);
                        lisOfT.Add(db.FromDocument<T>(document));
                    }
                }
                if (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0)
                {
                    queryRequest.ExclusiveStartKey = response.LastEvaluatedKey;
                }
            }
            while (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0);
            return lisOfT;

        }


    }
}
