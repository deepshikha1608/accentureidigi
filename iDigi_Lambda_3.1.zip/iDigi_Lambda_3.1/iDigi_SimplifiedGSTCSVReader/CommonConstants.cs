﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_SimplifiedGSTCSVReader
{
    
    public static class CommonConstants
    {
        public const string AirId = "7433";
        public const string VendorMasterTable = "VendorMaster";
        public const string FileColsDbColsMappingTable = "FileColsDBColsMapping";
        public const string PARFileUploadTableName = "PARFileUploadDetails";
        public const string Filepath = "public/simplifiedgst";
        public const string GenericInvoicetable = "GenericInvoices";
        public const string IQNInvoiceTable = "IQNInvoices";
        public const string ForexInvoiceTable = "ForexInvoices";
        public const string UdaanInvoiceTable = "VisaInvoiceDetails";
        public const string RealEstateInvoicesNewTable = "RealEstateInvoices";
        public const string APInvoiceTable = "APInvoices";
        public const string APHistoryLogTable = "APInvoiceHistoryLogs";
        public const string GenericHistoryLogTable = "GenericInvoiceHistoryLogs";
        public const string VisaHistoryLogTable = "VisaInvoiceHistoryLogs";
        public const string IQNHistoryLogTable = "IqnInvoiceHistoryLogs";
        public const string ForexHistoryLogTable = "ForexHistoryLogs";
        public const string RealEstateHistoryLogTable = "RealEstateInvoiceHistoryLogs";
        public const string IQN_NonCompliant_STATUS = "Non Compliant";
        public const string SimplifiedCSVPath = "simplifiedgst";
        public const string PaymentRunSapInsert = "PaymentRunSap";
        public const string PaymentBlock_Override = "PaymentBlockOverride";
        public const string Payment_DeleteSapDocNo = "DeleteSAPDocNo";
        public const string Payment_Check = "Dummyfile.csv";
        public const string PaymentRunReportCSVPath = "private/simplifiedgst/paymentruncsv";
        public const string PaymentBlock_OverrideReportCSVPath = "private/simplifiedgst/paymentblockoverride";
        public const string Payment_DeleteSapDocNoCSVPath = "private/simplifiedgst/deletesapdocnbr";
        public const string Payment_CheckCSVPath = "private/simplifiedgst/paymentcheck";
        public const string IsActiveTRUE = "TRUE";
        public const string PaymentRun_FileModuleCd = "PaymentRun";
        public const string Generic_Vendor = "GRN VENDOR";
        public const string Realestate_Vendor = "REAL VENDOR";
        public const string IQN_Vendor = "IQN VENDOR";
        public const string Forex_Vendor = "FOREX VENDOR";
       // public const string CWT_Vendor = "CWT VENDOR";
        public const string AP_Vendor = "AP VENDOR";
        public const string Visa_Vendor = "UDN VENDOR";
        public const string Payment_GoodToPay_Status = "GoodToPay";
        public const string Payment_Block_STATUS = "PaymentBlock";
        public const string Payment_BlockOverride_STATUS = "PaymentBlockOverride";
        public const string GSTR2A_Matched_STATUS = "GSTR2AMatched";
        public const string GSTR2A_Mismatched_STATUS = "GSTR2AMismatched";
        public const string GSTR2A_Missing_STATUS = "GSTR2AMissing";
        public const string GSTR2A_Credit_STATUS = "Credit Lapsed";
        public const string GSTR2A_NotRequied_STATUS = "GSTR2ANotRequired";

        public const string VendorCategory_Exempted_STATUS = "Exempted";
        public const string VendorCategory_NonExempted_STATUS = "NonExempted";
        public const string VendorCategory_NotApplicable_STATUS = "NotApplicable";
        public const string PaymentRunReport = "private/simplifiedgst/PaymentRunReport";
        public const string ReportFilePath = "private/simplifiedgst";
        public const string PaymentRunReportName = "PaymentRunReport";
        public const string PaymentCheckLogTable = "PaymentCheckLog";
        public const string PaymentCheckStatus_SapDocNoUpdating = "SapDocNoUpdating";
        public const string PaymentCheckStatus_SapDocNoUpdated = "SapDocNoUpdated";
        public const string PaymentCheckStatus_SapDocNoDeleting = "SapDocNoDeleting";
        public const string PaymentCheckStatus_SapDocNoDeleted = "SapDocNoDeleted";
        public const string PaymentCheckStatus_PaymentCheck = "PaymentCheckHappening";
        public const string PaymentCheckStatus_PaymentCheckCompleted = "PaymentCheckCompleted";
        public const string Payment_PendingCheck_STATUS = "PendingPaymentCheck";



    }
}
