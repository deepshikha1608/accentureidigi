﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace iDigi_Forex
{
    public class Invoice
    {
        public Invoice()
        {
            InvoiceLineItems = new List<InvoiceLineItem>();
            InvoiceHistoryLogs = new List<InvoiceHistory>();
        }

        //  public int? CurrentInvoiceBatchId { get; set; }
        //  public string InternalInvoiceRefNbr { get; set; }
        //  public string VendorModuleCd { get; set; }
        //  //[DynamoDBRangeKey]
        //  public string VendorRegisteredCd { get; set; }
        //  public string VendorInvoiceNumber { get; set; }
        //  public string VendorGSTNumber { get; set; }
        //  public string InvoiceStatusCd { get; set; }
        //  public int CurrentLGIBatchFileToSAPId { get; set; }
        //  public string UserRoleBasedInd { get; set; }
        //  public string AssignedRoleCd { get; set; }
        //  public string AssignedUserLoginCd { get; set; }
        //  public string AssignedInternalUserId { get; set; }
        //  public string TPCd { get; set; }
        //  public string DCInd { get; set; }
        //  public string InvoiceDt { get; set; }
        //  public string SearchInvoiceDt { get; set; }
        //  public double? TaxAmt { get; set; }
        //  public double? FreightAmt { get; set; }
        //  public double? GrossAmt { get; set; }
        //  public string CurrencyCd { get; set; }
        //  public string RequestorNm { get; set; }
        //  public string InvoiceReferenceNbr { get; set; }
        //  public string PaymentReferenceNbr { get; set; }
        //  public string PaymentStatus { get; set; }
        //  public string AlternativePayeeNm { get; set; }
        //  public string PORReferenceNbr { get; set; }
        //  public string IndexingNbr { get; set; }
        //  public string ReserverdInd { get; set; }
        //  public string InvoiceReceiptDt { get; set; }
        //  public string SearchInvoiceReceiptDt { get; set; }
        //  public string BusinessPlace { get; set; }
        //  public string ReferenceKey1Str { get; set; }
        //  public string ReferenceKey2Str { get; set; }
        //  public string ReferenceKey3Str { get; set; }
        //  public string AssignmentNbr { get; set; }
        //  public double? Base1Amt { get; set; }
        //  public double? Base2Amt { get; set; }
        //  public double? Base3Amt { get; set; }
        //  public double? Base4Amt { get; set; }
        //  public string AccentureGSTPartnerNm { get; set; }
        //  public string GSTPartnerNm { get; set; }
        //  public string POSStr { get; set; }
        //  public string UpdateDttm { get; set; }
        //  public string SearchUpdateDttm { get; set; }
        //  public string UpdateUserId { get; set; }
        //  public string CreateDttm { get; set; }
        //  public string SearchCreateDttm { get; set; }
        //  public string CreateUserId { get; set; }
        //  public string AttachedFile { get; set; }
        //  public string TaxRate { get; set; }
        //  public string TaxParameter { get; set; }
        //  public string HSNSAC { get; set; }
        //  public string LGIDownloaded { get; set; }
        //  public string SAPDocNo { get; set; }
        //  public string DFMURN { get; set; }
        //  public string AutomationTemplateDownloaded { get; set; }
        //  public string RTPTeam { get; set; }
        //  public string RowType { get; set; }
        //  public string GSTTin { get; set; }
        //  public string TaxType { get; set; }
        //  public string Description { get; set; }
        //  public double? TaxParameter1Amt { get; set; }
        //  public double? TaxParameter2Amt { get; set; }
        //  public double? LineAmt { get; set; }
        //  public string ChargedEntity { get; set; }
        //  public double? Quantity { get; set; }
        //  public string PoNbr { get; set; }
        //  public double? PoLineNbr { get; set; }
        //  public string Plant { get; set; }
        //  public string MaterialGroup { get; set; }
        //  public double? UnitPrice { get; set; }
        //  public string InvoicePdf { get; set; }
        //  //public int InvoiceDTId { get; set; }
        //  public string PageTitle { get; set; }
        //  public string HoldReason { get; set; }
        //  public string Remarks { get; set; }
        //  public string RTPRemarks { get; set; }
        //  public string CompanyCd { get; set; }
        //  public byte IsOverrideProcessingBlock { get; set; }
        ////  public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        ////  public InvoiceLineItem InvoiceLineItem { get; set; }

        //  public string RTPActionOnLGI { get; set; }
        //  public string RTPActionOnPDF { get; set; }

        //  public string ModifiedDttm { get; set; }
        //  public string SearchModifiedDttm { get; set; }
        //  public string ModifiedBy { get; set; }

        //  public string InvoiceSubmissionDt { get; set; }
        //  public string SearchInvoiceSubmissionDt { get; set; }
        //  public string GSTR2AStatus { get; set; }
        //  public string IsExempted { get; set; }
        //  public string SGSTAmount { get; set; }

        //  public string CGSTAmount { get; set; }
        //  public string IGSTAmount { get; set; }

        //  public string SKU { get; set; }
        //  public double? TaxableValue { get; set; }

        //  public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        //  public InvoiceHistory InvoiceHistory { get; set; }

        public string SKU { get; set; }
        public string AttachedFile { get; set; }
        public string VendorModuleCd { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeNm { get; set; }
        public string Currency { get; set; }
        public double IssuedOnCard { get; set; }
        public double IssuedOnCash { get; set; }
        public double TotalAmountInFCY { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string RequestorNm { get; set; }   //added Requestor Name
        public string Remarks { get; set; }    // added Remarks column
        public string VendorGSTNumberIn2A { get; set; } //added VendorGst Number In2A column 
        public string WireId { get; set; }  // added WIRE ID column
        public string PaymentDt { get; set; } // added Payment Date column
        public string InvoiceDt { get; set; }
        public string InvoiceSubmissionDt { get; set; }
        public string Policy { get; set; }
        public string Category { get; set; }
        public string CompanyCd { get; set; }
        public string BusinessPlace { get; set; }
        public string POS { get; set; }
        public string AccentureGSTIN { get; set; }
        public string VendorGSTIN { get; set; }
        public string DateOfExcelSubmission { get; set; }
        public string RecoCode { get; set; }
        public double ExchangeRate { get; set; }
        public double ValueOfSupply { get; set; }
        public string IsExempted { get; set; }
        public double CGSTAmount { get; set; }
        public double SGSTAmount { get; set; }
        public double IGSTAmount { get; set; }
        public double TotalAmountINR { get; set; }
        public string GSTPartner { get; set; }
        public string TypeOfTransaction { get; set; }
        public string HSNSAC { get; set; }
        public double TotalTax { get; set; }
        public double ValueInExchangeRate { get; set; }
        public string TaxType { get; set; }
        public string GSTPartnerNm { get; set; }
        public string DFMURN { get; set; }
        public string TaxPercentage { get; set; }
        public string IsBulkUploaded { get; set; }
        public string LGIDownloaded { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string VendorInvoiceNumberIn2A { get; set; }
        public string InvoiceDtIn2A { get; set; }
        public string AccentureGSTINIn2A { get; set; }
        public string SupplierGSTNIn2A { get; set; }
        public double TaxableValueIn2A { get; set; }
        public double CGSTAmountIn2A { get; set; }
        public double SGSTAmountIn2A { get; set; }
        public double IGSTAmountIn2A { get; set; }
        public string VendorRemarks { get; set; }
        public string RTPRemarks { get; set; }
        public string PaymentStatus { get; set; }
        public string ReasonForMismatch { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string GSTR2AStatus { get; set; }
        public string VendorGSTNumber { get; set; }
        public string VendorNm { get; set; }
        public string RTPActionOnLGI { get; set; }
        public string SAPDocNo { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string LGIDownloadedBy { get; set; }
        public string LGIDownloadTime { get; set; }
        public string IsGSTError { get; set; }
        public string AEEAction { get; set; }
        public string CreateUserId { get; set; }
        public string UpdateUserId { get; set; }
        public string UpdateDttm { get; set; }
        public string CreatedDttm { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string AlternativePayeeNm { get; set; }
        public byte IsOverrideProcessingBlock { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string STPISEZ { get; set; }  

        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public double BulkExchangeRate { get; set; }

        public List<InvoiceLineItem> InvoiceLineItems { get; set; } // added the invoice line item list
                                                                    ////  public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        public InvoiceLineItem InvoiceLineItem { get; set; }

        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
    }

    public class InvoiceLineItem
    {
        public InvoiceLineItem()
        {
        }
        public string VendorInvoiceNumber { get; set; }
        public double? TaxAmt { get; set; }
        public string DCInd { get; set; }
        public int InvoiceDTId { get; set; }
        public int InvoiceDataId { get; set; }
        public double? TaxRate { get; set; }
        public double? TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string RowType { get; set; }
        public string TaxType { get; set; }
        public string Description { get; set; }
        public double? TaxParameter1Amt { get; set; }
        public double? TaxParameter2Amt { get; set; }
        public double? LineAmt { get; set; }
        public string ChargedEntity { get; set; }
        public double? Quantity { get; set; }
        public string PoNbr { get; set; }
        public double? PoLineNbr { get; set; }
        public string Plant { get; set; }
        public string MaterialGroup { get; set; }
        public double? UnitPrice { get; set; }
        public string CompanyCd { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string DFMURN { get; set; }
        public string LGIDownloaded { get; set; }
        public string LGIDownloadedBy { get; set; }
        public string LGIDownloadTime { get; set; }

       



    }
}