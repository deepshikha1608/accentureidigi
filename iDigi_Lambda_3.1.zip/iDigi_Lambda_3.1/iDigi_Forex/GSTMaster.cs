﻿namespace iDigi_Forex
{
    public class GSTMaster
    {
        public GSTMaster()
        {
        }
        public int Id { get; set; }
        public string BusinessPlace { get; set; }
        public string City { get; set; }
        public string CompanyCode { get; set; }
        public string Country { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string FacilityName { get; set; }
        public string FaxNumber { get; set; }
        public int GSTID { get; set; }
        public string GSTIN { get; set; }
        public string IsActive { get; set; }
        public string LegalEntity { get; set; }
        public string Name1 { get; set; }
        public string Name2 { get; set; }

        public string NotUsed { get; set; }
        public string PaymasterEntity { get; set; }
        public string Plant { get; set; }
        public string PoBox { get; set; }
        public int PostCode { get; set; }
        public string Region { get; set; }

        public string Remarks { get; set; }
        public string Street { get; set; }
        public string TaxFillingGroup { get; set; }

        public string TelNumber { get; set; }
        public string Type { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDttm { get; set; }

    }
}