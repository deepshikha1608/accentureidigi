
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Util;
using Amazon.S3.Model;
using CsvHelper;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
//using Amazon.Lambda;
using Amazon.Lambda.Model;
using System.Globalization;
using System.Text.RegularExpressions;
using Amazon.Lambda.Core;
using Amazon.Lambda;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_Forex
{
    public class Function
    {

        IAmazonS3 S3Client { get; set; }

        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            S3Client = new AmazonS3Client();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
        }

        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public static TimeZoneInfo INDIAN_ZONE
        {

            get
            {
                if (System.Environment.GetEnvironmentVariable("DebugEnvironMent") == "true")
                { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                }
                //return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            }
        }
        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            InvokeRequest invokeRequest = new InvokeRequest();
            invokeRequest.FunctionName = "";
            invokeRequest.InvocationType = InvocationType.Event;
            DateTime datetime = new DateTime();
            string invoiceTable = string.Empty;
            string historyTable = string.Empty;
            string vendorMasterTable = string.Empty;
            string GSTMasterTable = string.Empty;
            string paramTable = string.Empty;
            string forexPrivateLgiCsvFolder = CommonConstants.Private_Folder + "/" + CommonConstants.ForexVendor_FilePath + "/" + CommonConstants.ForexPrivateLgicsvFolder;
            string forexLgiCsvDumpFolder = CommonConstants.Public_Folder + "/" + CommonConstants.ForexVendor_FilePath;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                invoiceTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceTable;
                historyTable = CommonConstants.AirId + "_" + CommonConstants.HistoryTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                GSTMasterTable = CommonConstants.AirId + "_" + CommonConstants.GSTMaster;
                paramTable = CommonConstants.AirId + "_" + CommonConstants.ParamTable;
            }
            else
            {
                invoiceTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceTable;
                historyTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.HistoryTable;
                vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                GSTMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.GSTMaster;
                paramTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ParamTable;
            }

            try
            {
                //var response = await this.S3Client.GetObjectMetadataAsync(s3Event.Bucket.Name, s3Event.Object.Key);
                //return response.Headers.ContentType;
                IDigiDynamoDb db = new IDigiDynamoDb();
                string bucketName = evnt.Records[0].S3.Bucket.Name;
                string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(forexLgiCsvDumpFolder + "/", ""));
                var lgiCSVFileData = await GetFileFromS3(bucketName, forexLgiCsvDumpFolder, fileName, context);

                ScanFilter filter = new ScanFilter();
                //filter.AddCondition("InvoiceID", ScanOperator.GreaterThan, 0);

                context.Logger.Log($"Data inserted successfully forexinvoicetable");
                var result = await db.ScanAsync<Invoice>(filter, invoiceTable, context);

                if (result != null)
                {
                    context.Logger.Log($"count from forexinvoices : {result.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from forexinvoices ");
                }

                context.Logger.Log($"fetching data from vendormastertable");
                var mastertable = await db.ScanAsync<VendorMasterEntities>(filter, vendorMasterTable, context);
                //  var forexVendors = mastertable.Where(x => x.VendorCd == "FOREX VENDOR").Select(x=>x.Status, x.cc).ToList();

                if (mastertable != null)
                {
                    context.Logger.Log($"count from vendormaster : {mastertable.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from vendormaster ");
                }
                context.Logger.Log($"fetching data from gstmastertable");
                // List<GSTMaster> gstMasterList = new List<GSTMaster>();
                //  gstMasterList = await db.ScanAsync<VendorMasterEntities>(filter, vendorMasterTable, context);
                var gstMasterList = await db.ScanAsync<GSTMasterEntities>(filter, GSTMasterTable, context);
                if (gstMasterList != null)
                {
                    context.Logger.Log($"count from Gstmaster : {gstMasterList.Count}");
                }
                else
                {
                    context.Logger.Log($"No data fetched from gstmaster ");
                }
                using (var csvReadData = new System.IO.StreamReader(lgiCSVFileData.ResponseStream))
                {
                    context.Logger.Log($"Proccess :Now StreamReader is reading the data from the csv file");
                    var csv = new CsvReader(csvReadData);
                    csv.Configuration.HasHeaderRecord = false;

                    Invoice invoice = new Invoice();
                    VendorMasterEntities vendordetail = new VendorMasterEntities();
                    int dtCount = 0;
                    while (csv.Read())
                    {
                        string rowType = csv.GetField<string>(0);
                        if (!string.IsNullOrWhiteSpace(rowType))
                        {
                            if (rowType == "Employee ID")
                            { }
                            else
                            {
                                #region HD 
                                //context.Logger.Log($"DT count while reading the HD data{dtCount}");
                                //if (dtCount > 0)
                                {
                                    try
                                    {
                                        invoice = new Invoice();
                                        context.Logger.Log($"Line items(dt) count :{dtCount}");
                                        // if (invoice != null)
                                        //{
                                        // context.Logger.Log($"Now inserting data into the dynamo db when we encountered the next HD");

                                        invoice.VendorModuleCd = CommonConstants.ForexTeam;
                                        invoice.RTPActionOnLGI = "Y";
                                        // invoice.AutomationTemplateDownloaded = "N";
                                        invoice.LGIDownloaded = "N";
                                        invoice.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        invoice.UpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        invoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                        invoice.InvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");//TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
                                        Console.WriteLine($"INV SUBMISSION DATE{invoice.InvoiceSubmissionDt}");                                                                            //  invoice.SearchCreateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                                                                                                                                                                           // invoice.SearchUpdateDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                                                                                                                                                                           // invoice.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                                                                                                                                                                           //invoice.SearchInvoiceSubmissionDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd");
                                        invoice.CreateUserId = CommonConstants.ForexTeam;
                                        invoice.UpdateUserId = CommonConstants.ForexTeam;
                                        invoice.InvoiceStatusCd = CommonConstants.StatusPDFAwaited;

                                        //invoice.InvoiceID = invoiceId;


                                        //invoiceId =invoiceId + 1;
                                        // invoice = new Invoice(); 
                                        //   dtCount = 0;
                                        //}


                                        // }                                                             
                                        //context.Logger.Log($" Instance type {invoice.GetType().Name}");

                                        //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                        //{
                                        //    invoice.RowType = csv.GetField<string>(0);
                                        //    context.Logger.Log($"Row type {invoice.RowType}");
                                        //}

                                        InvoiceErrorDetails invoiceErrorDetails = new InvoiceErrorDetails();

                                        // List<ErrorDetails> errorList = new List<ErrorDetails>(); 



                                        string tempVendorCd = (fileName.Split('_'))[0];
                                        invoice.VendorRegisteredCd = tempVendorCd.ToUpper();
                                        var forexVendor = mastertable.Where(x => x.VendorCode == invoice.VendorRegisteredCd).FirstOrDefault();
                                        if (forexVendor.Status == "Active" && forexVendor.CC == "8100")
                                        {
                                            invoice.AlternativePayeeNm = forexVendor.AlternatePayeeCode;
                                        }
                                        context.Logger.Log($" {invoice.VendorRegisteredCd}");
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                                        {
                                            invoice.EmployeeID = csv.GetField<string>(0);
                                            context.Logger.Log($" {invoice.EmployeeID}");
                                            //string tempVendorCd = csv.GetField<string>(1);
                                            //if (tempVendorCd.Count() == 9)
                                            //{
                                            //    tempVendorCd = "0" + tempVendorCd;
                                            //    invoice.TPCd = tempVendorCd;//tp code and Vendor 
                                            //    invoice.VendorRegisteredCd = tempVendorCd;
                                            //    context.Logger.Log($" {invoice.TPCd}");
                                            //}
                                            //else if (tempVendorCd.Count() == 10)
                                            //{
                                            //    invoice.TPCd = tempVendorCd;//tp code and Vendor 
                                            //    invoice.VendorRegisteredCd = tempVendorCd;
                                            //    context.Logger.Log($" {invoice.TPCd}");
                                            //}
                                        }
                                        else
                                        {
                                            context.Logger.Log($"EmployeeID code is missing");
                                        }

                                        invoice.IsExempted = CommonConstants.VendorCategory_NonExempted_STATUS;
                                        invoice.GSTR2AStatus = CommonConstants.GSTR2A_ReconPending_STATUS;
                                        context.Logger.Log($"enter code to check vendormaster");
                                        VendorMasterEntities vendorDet = CheckExemptedVendorCode(mastertable, invoice.VendorRegisteredCd, context);
                                        context.Logger.Log($"vendor obj  found");

                                        if (vendorDet.IsExempted == CommonConstants.VendorCategory_Exempted_STATUS)
                                        {
                                            invoice.GSTR2AStatus = CommonConstants.GSTR2A_ReconPending_STATUS;
                                            invoice.IsExempted = CommonConstants.VendorCategory_Exempted_STATUS;

                                        }
                                        if (vendorDet.IsExempted == CommonConstants.VendorCategory_NonExempted_STATUS)
                                        {
                                            invoice.GSTR2AStatus = CommonConstants.GSTR2A_ReconPending_STATUS;
                                            invoice.IsExempted = CommonConstants.VendorCategory_NonExempted_STATUS;
                                        }

                                        if (vendorDet.IsExempted == CommonConstants.VendorCategory_NotApplicable_STATUS)
                                        {

                                            invoice.GSTR2AStatus = CommonConstants.GSTR2A_NotRequired_STATUS;
                                            invoice.IsExempted = CommonConstants.VendorCategory_NotApplicable_STATUS;

                                        }
                                        context.Logger.Log($" { invoice.IsExempted}");
                                        context.Logger.Log($" {invoice.GSTR2AStatus}");
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                                        { invoice.EmployeeNm = csv.GetField<string>(1); }

                                        //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                                        //{ invoice.DCInd = csv.GetField<string>(2); }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(2)))
                                        { invoice.Currency = csv.GetField<string>(2); }

                                        //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                        //{ invoice.IssuedOnCard = csv.GetField<string>(3); }

                                        //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                        //{ invoice.IssuedOnCash = csv.GetField<string>(4); }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(3)))
                                        {
                                            double b;
                                            if (double.TryParse(csv.GetField<string>(3), out b))
                                            {
                                                invoice.IssuedOnCard = double.Parse(csv.GetField<string>(3));
                                            }

                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(4)))
                                        {
                                            double b;
                                            if (double.TryParse(csv.GetField<string>(4), out b))
                                            {
                                                invoice.IssuedOnCash = double.Parse(csv.GetField<string>(4));
                                            }

                                        }
                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(5)))
                                        {
                                            double b;
                                            if (double.TryParse(csv.GetField<string>(5), out b))
                                            {
                                                invoice.TotalAmountInFCY = double.Parse(csv.GetField<string>(5));
                                            }
                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                                        {
                                            Regex rgx = new Regex(@"^[a-zA-Z0-9/-]{0,16}$");
                                            invoice.VendorInvoiceNumber = csv.GetField<string>(6);
                                            context.Logger.Log($"Vendor Invoice number: {invoice.VendorInvoiceNumber} :");
                                            if (rgx.IsMatch(csv.GetField<string>(6)))
                                            {
                                                //context.Logger.Log($"{invoicenumber} : Invoioce no is in proper format and added to the list");
                                                invoice.VendorInvoiceNumber = csv.GetField<string>(6);
                                            }
                                            else
                                            {
                                                Console.WriteLine($"gst error 1");
                                                invoice.IsGSTError = "Y";
                                                // invoice.AEEAction = "Rejected by System";

                                                ErrorDetails errorDetails = new ErrorDetails();
                                                errorDetails.Error = "POS is Mandatory field";
                                                errorDetails.IsValidError = "true";
                                                //errorDetails.VendorType = "AEE";

                                                invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                context.Logger.Log($"Error: {invoice.VendorInvoiceNumber} :Not matching alphanumeric 8-16 digit invoice number format");
                                            }

                                        }

                                        if (!string.IsNullOrWhiteSpace(csv.GetField<string>(7)))
                                        {
                                            invoice.InvoiceDt = csv.GetField<string>(7);
                                            var splitedDate2 = invoice.InvoiceDt.Split('/');
                                            if (splitedDate2.Length == 3)
                                            {
                                                if (splitedDate2[0].Length == 1)
                                                {
                                                    splitedDate2[0] = "0" + splitedDate2[0];
                                                }
                                                if (splitedDate2[1].Length == 1)
                                                {
                                                    splitedDate2[1] = "0" + splitedDate2[1];
                                                }
                                                //when date is of format mm/dd/yyyy
                                                //invoice.InvoiceDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                                //when date is of format dd/mm/yyyy uat testing lgi have this dd/mm/yyyy format
                                                // invoice.InvoiceDt = splitedDate2[1] + "/" + splitedDate2[0] + "/" + splitedDate2[2];
                                                invoice.InvoiceDt = splitedDate2[2] + "/" + splitedDate2[0] + "/" + splitedDate2[1];
                                                // if (DateTime.TryParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                                //  {
                                                //  invoice.InvoiceDt = DateTime.ParseExact(invoice.InvoiceDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                                // }
                                            }
                                            context.Logger.Log($"Invoice Date :{invoice.InvoiceDt}");
                                        }
                                        //yyyy/mm/dd
                                        var splitedDate = invoice.InvoiceSubmissionDt.Split('/');
                                        //  if (splitedDate.Length == 3)
                                        {
                                            if (splitedDate[2].Length == 1)
                                            {
                                                splitedDate[2] = "0" + splitedDate[0];
                                            }
                                            if (splitedDate[1].Length == 1)
                                            {
                                                splitedDate[1] = "0" + splitedDate[1];
                                            }

                                            //invoice.InvoiceSubmissionDt = splitedDate[1] + "/" + splitedDate[0] + "/" + splitedDate[2];

                                            // invoice.InvoiceSubmissionDt = splitedDate[0] + "/" + splitedDate[1] + "/" + splitedDate[2];
                                            context.Logger.Log($"Invoice submission Date :{invoice.InvoiceSubmissionDt }");
                                            // }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(8)))
                                            { invoice.Policy = csv.GetField<string>(8); }

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(6)))
                                            //{
                                            //    double b;
                                            //    if (double.TryParse(csv.GetField<string>(6), out b))
                                            //    {
                                            //        invoice.FreightAmt = double.Parse(csv.GetField<string>(6));
                                            //    }

                                            //}
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(9)))
                                            { invoice.Category = csv.GetField<string>(9); }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(10)))
                                            { invoice.CompanyCd = csv.GetField<string>(10); }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(11)))
                                            { invoice.BusinessPlace = csv.GetField<string>(11); }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(12)))
                                            {
                                                invoice.POS = csv.GetField<string>(12);
                                                if (invoice.POS.Length == 1)
                                                {
                                                    invoice.POS = "0" + invoice.POS;

                                                    context.Logger.Log($"POS:{invoice.POS}");
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine($"gst error 1");
                                                invoice.IsGSTError = "Y";
                                                // invoice.AEEAction = "Rejected by System";

                                                ErrorDetails errorDetails = new ErrorDetails();
                                                errorDetails.Error = "POS is Mandatory field";
                                                errorDetails.IsValidError = "true";
                                                //errorDetails.VendorType = "AEE";

                                                invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                            }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(13)))
                                            { invoice.AccentureGSTIN = csv.GetField<string>(13); }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(14)))
                                            { invoice.VendorGSTIN = csv.GetField<string>(14); }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(15)))
                                            { invoice.Remarks = csv.GetField<string>(15); }

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(16)))
                                            //{ invoice.DateOfExcelSubmission = csv.GetField<string>(16); }



                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(16)))
                                            {
                                                //invoice.InvoiceReceiptDt = csv.GetField<string>(16);

                                                invoice.DateOfExcelSubmission = csv.GetField<string>(16);
                                                var splitedDate1 = invoice.DateOfExcelSubmission.Split('/');
                                                if (splitedDate1.Length == 3)
                                                {
                                                    if (splitedDate1[0].Length == 1)
                                                    {
                                                        splitedDate1[0] = "0" + splitedDate1[0];
                                                    }
                                                    if (splitedDate1[1].Length == 1)
                                                    {
                                                        splitedDate1[1] = "0" + splitedDate1[1];
                                                    }

                                                    //when date is of format mm/dd/yyyy 
                                                    invoice.DateOfExcelSubmission = splitedDate1[0] + "/" + splitedDate1[1] + "/" + splitedDate1[2];
                                                    //when date is of format yyyy/mm/dd 
                                                    //  invoice.DateOfExcelSubmission = splitedDate1[2] + "/" + splitedDate1[0] + "/" + splitedDate1[1];

                                                    //when date is of format dd/mm/yyyy uat testing lgi have this dd/mm/yyyy format
                                                    // invoice.DateOfExcelSubmission = splitedDate[2] + "/" + splitedDate[0] + "/" + splitedDate[1];

                                                    //if (DateTime.TryParseExact(invoice.DateOfExcelSubmission, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                                    //{
                                                    //    invoice.DateOfExcelSubmission = DateTime.ParseExact(invoice.DateOfExcelSubmission, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
                                                    //}
                                                }
                                                context.Logger.Log($"Excel Submission Date :{invoice.DateOfExcelSubmission}");

                                            }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(17)))
                                            { invoice.RecoCode = csv.GetField<string>(17); }

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(17)))
                                            //{
                                            //    invoice.BusinessPlaceNm = csv.GetField<string>(17);
                                            //}
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(18)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(18), out b))
                                                {
                                                    invoice.ExchangeRate = double.Parse(csv.GetField<string>(18));
                                                }

                                            }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(19)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(19), out b))
                                                {
                                                    if (double.Parse(csv.GetField<string>(19)) != 0)
                                                    {
                                                        invoice.ValueOfSupply = double.Parse(csv.GetField<string>(19));

                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine($"gst error 2");
                                                        invoice.IsGSTError = "Y";
                                                        // invoice.AEEAction = "Rejected by System";

                                                        ErrorDetails errorDetails = new ErrorDetails();
                                                        errorDetails.Error = "Value of supply can not be Zero";
                                                        errorDetails.IsValidError = "true";
                                                        // errorDetails.VendorType = "AEE";

                                                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                    }

                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine($"gst error 2");
                                                invoice.IsGSTError = "Y";
                                                // invoice.AEEAction = "Rejected by System";

                                                ErrorDetails errorDetails = new ErrorDetails();
                                                errorDetails.Error = "Value of supply is mandatory fields";
                                                errorDetails.IsValidError = "true";
                                                // errorDetails.VendorType = "AEE";

                                                invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                            }

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(20)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(20), out b))
                                                {
                                                    invoice.CGSTAmount = double.Parse(csv.GetField<string>(20));
                                                }
                                            }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(21)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(21), out b))
                                                {
                                                    invoice.SGSTAmount = double.Parse(csv.GetField<string>(21));
                                                }
                                            }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(22)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(22), out b))
                                                {
                                                    invoice.IGSTAmount = double.Parse(csv.GetField<string>(22));
                                                }
                                            }
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(23)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(23), out b))
                                                {
                                                    invoice.TotalAmountINR = double.Parse(csv.GetField<string>(23));
                                                }
                                            }
                                            //   context.Logger.Log($"Invoice BPNm :{invoice.BusinessPlaceNm}");
                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(24)))
                                            { invoice.GSTPartner = csv.GetField<string>(24); }
                                            context.Logger.Log($"GSTPartner :{invoice.GSTPartner}");

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(25)))
                                            { invoice.TypeOfTransaction = csv.GetField<string>(25); }
                                            context.Logger.Log($"Type Of Transaction :{invoice.TypeOfTransaction}");

                                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(26)))
                                            {
                                                double b;
                                                if (double.TryParse(csv.GetField<string>(26), out b))
                                                {
                                                    invoice.BulkExchangeRate = double.Parse(csv.GetField<string>(26));
                                                }
                                            }
                                            context.Logger.Log($"Bulk Exchange Rate :{invoice.BulkExchangeRate}");

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(26)))
                                            //{
                                            //    invoice.DtofGoodsDelivery = csv.GetField<string>(26);
                                            //    var splitedDate3 = invoice.DtofGoodsDelivery.Split('/');
                                            //    if (splitedDate3.Length == 3)
                                            //    {
                                            //        if (splitedDate3[0].Length == 1)
                                            //        {
                                            //            splitedDate3[0] = "0" + splitedDate3[0];
                                            //        }
                                            //        if (splitedDate3[1].Length == 1)
                                            //        {
                                            //            splitedDate3[1] = "0" + splitedDate3[1];
                                            //        }
                                            //           invoice.DtofGoodsDelivery = splitedDate3[0] + "/" + splitedDate3[1] + "/" + splitedDate3[2];

                                            //    }
                                            //    context.Logger.Log($"Date Of Goods Delivery:{invoice.DtofGoodsDelivery}");
                                            //}
                                            //else
                                            //{
                                            //    Console.WriteLine($"gst error 1");
                                            //    invoice.IsGSTError = "Y";                                        
                                            //    ErrorDetails errorDetails = new ErrorDetails();
                                            //    errorDetails.Error = "Date Of Goods Delivery is Mandatory field";
                                            //    errorDetails.IsValidError = "true";                                             
                                            //    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                            //}
                                            #region comment
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(20)))
                                            //{
                                            //    invoice.ReferenceKey3Str = csv.GetField<string>(20);
                                            //}
                                            //context.Logger.Log($"Invoice ref key 3 :{invoice.ReferenceKey3Str}");
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(21)))
                                            //{
                                            //    invoice.AssignmentNbr = csv.GetField<string>(21);
                                            //}
                                            //context.Logger.Log($"Invoice assnbr :{invoice.AssignmentNbr}");

                                            //Before production we are not expecting  these below collumns 

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(22)))
                                            //{
                                            //    double a;
                                            //    if (double.TryParse(csv.GetField<string>(22), out a))
                                            //    {
                                            //        invoice.Base1Amt = double.Parse(csv.GetField<string>(22));
                                            //    }
                                            //}

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(23)))
                                            //{
                                            //    double a;
                                            //    if (double.TryParse(csv.GetField<string>(23), out a))
                                            //    {
                                            //        invoice.Base2Amt = double.Parse(csv.GetField<string>(23));
                                            //    }
                                            //}
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(24)))
                                            //{
                                            //    double a;
                                            //    if (double.TryParse(csv.GetField<string>(24), out a))
                                            //    {
                                            //        invoice.Base3Amt = double.Parse(csv.GetField<string>(24));
                                            //    }
                                            //}
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(25)))
                                            //{
                                            //    double a;
                                            //    if (double.TryParse(csv.GetField<string>(25), out a))
                                            //    {
                                            //        invoice.Base4Amt = double.Parse(csv.GetField<string>(25));
                                            //    }
                                            //}
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(26)))
                                            //{
                                            //    invoice.GSTPartnerNm = csv.GetField<string>(26);
                                            //}
                                            //context.Logger.Log($" { invoice.GSTPartnerNm}");

                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(27)))
                                            //{
                                            //    invoice.POSStr = csv.GetField<string>(27);
                                            //}
                                            //context.Logger.Log($"Invoice POSStr :{invoice.POSStr}");
                                            //string output = string.Empty;
                                            //if (!string.IsNullOrWhiteSpace(csv.GetField<string>(28)))
                                            //{
                                            //    invoice.SAPDocNo = csv.GetField<string>(28);
                                            //}
                                            //context.Logger.Log($"SAPDocNo :{invoice.SAPDocNo}");

                                            //if (csv.TryGetField(28, out output))
                                            //{
                                            //    if (!string.IsNullOrEmpty(csv.GetField<string>(28)))
                                            //    {
                                            //        invoice.SAPDocNo = csv.GetField<string>(28);

                                            //    }
                                            //}

                                            //context.Logger.Log($"GrossAmt :{invoice.GrossAmt}");
                                            //context.Logger.Log($"TaxAmt :{invoice.TaxAmt}");

                                            //invoice.TaxableValue = invoice.GrossAmt - invoice.TaxAmt;
                                            //context.Logger.Log($"TaxableValue :{invoice.TaxableValue}");
                                            //if (invoice.TaxableValue != null)
                                            //{
                                            //    invoice.TaxableValue = Math.Round((double)invoice.TaxableValue, 2);

                                            //}
                                            #endregion
                                            Guid objsku = Guid.NewGuid();
                                            invoice.SKU = objsku.ToString();
                                            context.Logger.Log($"BusinessPlaceNm :{invoice.BusinessPlace}");
                                            if (!string.IsNullOrWhiteSpace(invoice.BusinessPlace))
                                            {
                                                GSTMasterEntities obj = getGstMasterDetail(gstMasterList, invoice.BusinessPlace);
                                                if (obj != null)
                                                {
                                                    context.Logger.Log($"obj found ");

                                                }
                                                string type = obj.Type;
                                                string accenturegstn = obj.GSTIN;
                                                string partnerCode = invoice.VendorRegisteredCd;
                                                invoice.STPISEZ = type;
                                                //if (partnerCode.Count() == 9)
                                                //{
                                                //    partnerCode = "0" + partnerCode;
                                                //}

                                                VendorMasterEntities vendorData = CheckExemptedVendorCode(mastertable, partnerCode, context);
                                                string vendorgstnumber = "";
                                                if (vendorData != null)
                                                {
                                                    context.Logger.Log($"vendordata found ");
                                                    vendorgstnumber = vendorData.GSTNumber;
                                                    invoice.VendorGSTNumber = vendorgstnumber;
                                                    invoice.AccentureGSTPartnerNm = accenturegstn;
                                                }
                                                else
                                                {
                                                    if (partnerCode.StartsWith("0"))
                                                    {
                                                        context.Logger.Log($"starts with 0");
                                                        partnerCode = partnerCode.Substring(1, (partnerCode.Length - 1));

                                                    }
                                                    else
                                                    {
                                                        context.Logger.Log($"Appended 0");
                                                        partnerCode = "0" + partnerCode;
                                                    }
                                                    vendorData = CheckExemptedVendorCode(mastertable, partnerCode, context);
                                                    if (vendorData != null)
                                                    {
                                                        context.Logger.Log($"vendordata found in else");
                                                        vendorgstnumber = vendorData.GSTNumber;
                                                        invoice.VendorGSTNumber = vendorgstnumber;
                                                        invoice.AccentureGSTPartnerNm = accenturegstn;
                                                    }
                                                }




                                                context.Logger.Log($"VendorGSTNumber { invoice.VendorGSTNumber}");
                                                context.Logger.Log($"AccentureGSTPartnerNm { invoice.AccentureGSTPartnerNm}");
                                                context.Logger.Log($"type {type}");

                                                if (invoice.STPISEZ == "SEZ")
                                                {
                                                    invoice.TaxPercentage = "0%";
                                                }
                                                else
                                                {
                                                    invoice.TaxPercentage = "18%";
                                                }
                                                context.Logger.Log($"TaxPercentage {invoice.TaxPercentage}");
                                                invoice.TotalTax = invoice.CGSTAmount + invoice.SGSTAmount + invoice.IGSTAmount;
                                                context.Logger.Log($"TotalTax { invoice.TotalTax}");
                                                invoice.ValueInExchangeRate = invoice.ExchangeRate * invoice.TotalAmountInFCY;
                                                context.Logger.Log($"ValueInExchangeRate { invoice.ValueInExchangeRate}");
                                                if (invoice.IGSTAmount != 0)
                                                {
                                                    invoice.TaxType = CommonConstants.TAXIGST;
                                                }
                                                else if (invoice.CGSTAmount != 0 && invoice.SGSTAmount != 0)
                                                {
                                                    invoice.TaxType = CommonConstants.TAXCGSTSGST;
                                                }
                                                else if (invoice.IGSTAmount == 0 && invoice.CGSTAmount == 0 && invoice.SGSTAmount == 0)
                                                {
                                                    invoice.TaxType = "NIL";
                                                }
                                                //    if (type != null && type != "")
                                                //    {
                                                //        if ((type.ToUpper() == CommonConstants.TAXTypeHO) || (type.ToUpper() == CommonConstants.TAXTypeSTPI) || (type.ToUpper() == CommonConstants.TAXTypeIDB) || (type.ToUpper().Contains(CommonConstants.TAXTypeneitherstpinorSEZ)))
                                                //        {
                                                //            if (vendorgstnumber != null && vendorgstnumber != "" && vendorgstnumber.Length >= 2 && accenturegstn != null && accenturegstn != "" && accenturegstn.Length > 2)
                                                //            {
                                                //                if (vendorgstnumber.Substring(0, 2) == accenturegstn.Substring(0, 2))
                                                //                {

                                                //                    invoice.TaxType = CommonConstants.TAXCGSTSGST;

                                                //                    if (invoice.TaxAmt == null)
                                                //                        invoice.TaxAmt = 0;
                                                //                    }
                                                //                    var amt = invoice.TaxAmt / 2;
                                                //                    invoice.CGST = amt + "";
                                                //                    invoice.SGST = amt + "";
                                                //                    invoice.IGST = 0 + "";
                                                //                }
                                                //                else
                                                //                {
                                                //                    invoice.TaxType = CommonConstants.TAXIGST;
                                                //                    invoice.CGST = 0 + "";
                                                //                    invoice.SGST = 0 + "";
                                                //                    invoice.IGST = invoice.TaxAmt + "";
                                                //                }


                                                //            }

                                                //        }
                                                //        if (type.ToUpper() == CommonConstants.TAXTypeSEZ)
                                                //        {
                                                //            if (invoice.TaxAmt == 0)
                                                //            {
                                                //                invoice.TaxType = CommonConstants.TAXExempt;
                                                //                invoice.CGST = 0 + "";
                                                //                invoice.SGST = 0 + "";
                                                //                invoice.IGST = 0 + "";
                                                //            }
                                                //            else
                                                //            {
                                                //                invoice.TaxType = CommonConstants.TAXIGST;
                                                //                invoice.CGST = 0 + "";
                                                //                invoice.SGST = 0 + "";
                                                //                invoice.IGST = invoice.TaxAmt + "";
                                                //            }

                                                //        }
                                                //    }
                                            }

                                            context.Logger.Log($"TAXType { invoice.TaxType}");
                                            context.Logger.Log($"CGST { invoice.CGSTAmount}");
                                            context.Logger.Log($"SGST { invoice.SGSTAmount}");
                                            context.Logger.Log($"IGST { invoice.IGSTAmount}");
                                            #region Validation
                                            DateTime preGST = new DateTime(2017, 06, 30);
                                            DateTime invDt = Convert.ToDateTime(invoice.InvoiceDt);
                                            if (invDt > preGST)
                                            {
                                                #region Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields
                                                if (string.IsNullOrEmpty(invoice.AccentureGSTIN) || string.IsNullOrEmpty(invoice.TaxType) || /*string.IsNullOrEmpty(invoice.TaxRate) || */string.IsNullOrEmpty(invoice.BusinessPlace) || string.IsNullOrEmpty(invoice.POS))
                                                {
                                                    Console.WriteLine($"gst error 1");
                                                    invoice.IsGSTError = "Y";
                                                    // invoice.AEEAction = "Rejected by System";

                                                    ErrorDetails errorDetails = new ErrorDetails();
                                                    errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                                                    errorDetails.IsValidError = "true";
                                                    // errorDetails.VendorType = "AEE";

                                                    invoiceErrorDetails.ErrorsList.Add(errorDetails);

                                                }
                                                #endregion
                                                #region
                                                if (!string.IsNullOrEmpty(invoice.BusinessPlace) && !string.IsNullOrEmpty(invoice.POS) && !string.IsNullOrEmpty(invoice.AccentureGSTIN))
                                                {
                                                    string GSTRegion = string.Empty;
                                                    string actualACcentureGSTNUmber = string.Empty;
                                                    string GSTBusinessPlace = string.Empty;
                                                    var gstData = gstMasterList.Where(X => X.BusinessPlace == invoice.BusinessPlace && X.Region == invoice.POS && X.GSTIN == invoice.AccentureGSTIN);
                                                    if (gstData != null && gstData.Count() > 0)
                                                    {
                                                        foreach (var data in gstData)
                                                        {
                                                            actualACcentureGSTNUmber = data.GSTIN;
                                                            GSTRegion = data.Region;
                                                            GSTBusinessPlace = data.BusinessPlace;
                                                        }

                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine($"gst error 9");
                                                        invoice.IsGSTError = "Y";

                                                        ErrorDetails errorDetails = new ErrorDetails();
                                                        errorDetails.Error = "Business Place, AccentureGSTNumber and POS are not matching as per the Accenture master data.";
                                                        errorDetails.IsValidError = "true";
                                                        //  errorDetails.VendorType = "AEE";
                                                    }
                                                }
                                                #endregion

                                                #region Business Place and Accenture GST number are not matching as per the Accenture master data.
                                                string plantType = string.Empty;
                                                if (!string.IsNullOrEmpty(invoice.AccentureGSTIN))
                                                {
                                                    string accentureGSTEnetered = invoice.AccentureGSTIN;
                                                    string actualACcentureGSTNUmber = string.Empty;
                                                    if (!string.IsNullOrEmpty(accentureGSTEnetered))
                                                    {
                                                        var gstData = gstMasterList.Where(r => r.GSTIN == accentureGSTEnetered);
                                                        if (gstData != null && gstData.Count() > 0)
                                                        {
                                                            foreach (var data in gstData)
                                                            {
                                                                actualACcentureGSTNUmber = data.GSTIN;
                                                                plantType = data.Type;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine($"gst error 3");
                                                            invoice.IsGSTError = "Y";
                                                            //  invoice.AEEAction = "Rejected by System";

                                                            ErrorDetails errorDetails = new ErrorDetails();
                                                            errorDetails.Error = "Business Place and Accenture GST number are not matching as per the Accenture master data.";
                                                            errorDetails.IsValidError = "true";
                                                            //  errorDetails.VendorType = "AEE";

                                                            invoiceErrorDetails.ErrorsList.Add(errorDetails);

                                                        }
                                                    }
                                                }
                                                context.Logger.Log($"Plant type{plantType}");
                                                #endregion
                                                #region If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.
                                                if (invoice.Currency == "INR" && !string.IsNullOrEmpty(invoice.AccentureGSTIN) && !string.IsNullOrEmpty(invoice.VendorGSTNumber))
                                                {
                                                    string firstTwoLetterAccentureGST = invoice.AccentureGSTIN.Substring(0, 2).ToLowerInvariant();
                                                    string firstTwoLetterVendorGSt = invoice.VendorGSTNumber.Substring(0, 2).ToLowerInvariant();
                                                    Console.WriteLine($"firstTwoLetterAccentureGST{firstTwoLetterAccentureGST}");
                                                    Console.WriteLine($"firstTwoLetterVendorGSt{firstTwoLetterVendorGSt}");
                                                    if (!string.IsNullOrEmpty(invoice.TaxType))
                                                    {
                                                        Console.WriteLine($"Invoice.TaxType {invoice.TaxType}");
                                                        string taxtype = invoice.TaxType.ToLowerInvariant();
                                                        Console.WriteLine($"taxtype {taxtype}");
                                                        if (firstTwoLetterAccentureGST == firstTwoLetterVendorGSt)
                                                        {
                                                            if (!string.IsNullOrEmpty(plantType))   //If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.
                                                            {
                                                                Console.WriteLine($"plantType{plantType}");
                                                                if (plantType.ToLower() == "sez")
                                                                {
                                                                    if (taxtype.Equals("igst") || taxtype.Equals("zero") || taxtype.Equals("exempt") || taxtype.Equals("reverse charge"))
                                                                    {
                                                                        //expected
                                                                    }
                                                                    else
                                                                    {
                                                                        Console.WriteLine($"gst error 7");
                                                                        invoice.IsGSTError = "Y";
                                                                        //  invoice.AEEAction = "Rejected by System";

                                                                        ErrorDetails errorDetails = new ErrorDetails();
                                                                        errorDetails.Error = "If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.";
                                                                        errorDetails.IsValidError = "true";
                                                                        // errorDetails.VendorType = "AEE";

                                                                        invoiceErrorDetails.ErrorsList.Add(errorDetails);

                                                                    }
                                                                }
                                                                else if (taxtype.ToLowerInvariant() != "cgst+sgst")
                                                                {
                                                                    Console.WriteLine($"gst error 7");
                                                                    invoice.IsGSTError = "Y";
                                                                    // invoice.AEEAction = "Rejected by System";

                                                                    ErrorDetails errorDetails = new ErrorDetails();
                                                                    errorDetails.Error = "If the first 2 digit of Accenture GST = First 2 digit of Vendor GST, Then the Tax Type field should be CGST + SGST. Exception to the above Rule: If the Plant Type of the Accenture GST is SEZ then the Tax Type should be either IGST or NIL or EXEMPT.";
                                                                    errorDetails.IsValidError = "true";
                                                                    //  errorDetails.VendorType = "AEE";

                                                                    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else
                                                    {
                                                        Console.WriteLine($"gst error 8");
                                                        invoice.IsGSTError = "Y";
                                                        //  invoice.AEEAction = "Rejected by System";
                                                        ErrorDetails errorDetails = new ErrorDetails();
                                                        errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                                                        errorDetails.IsValidError = "true";
                                                        // errorDetails.VendorType = "AEE";

                                                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                    }
                                                }
                                                #endregion
                                                #region Businessplace=IN49
                                                //if (invoice.BusinessPlace == "IN49" && (invoice.VendorGSTIN == null || invoice.VendorGSTIN == "" || invoice.VendorGSTIN == "undefined"))
                                                //{
                                                //    Console.WriteLine($"gst error 7");
                                                //    invoice.IsGSTError = "Y";
                                                //    // invoice.AEEAction = "Rejected by System";

                                                //    ErrorDetails errorDetails = new ErrorDetails();
                                                //    errorDetails.Error = "Vendor GST number should not be blank for Business Place = IN49, Business Place is IN49 and the vendor GST number is blank. Change Business place to  IN40.";
                                                //    errorDetails.IsValidError = "true";
                                                //    //errorDetails.VendorType = "AEE";

                                                //    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                //}
                                                #endregion
                                                #region GSTID
                                                if (invoice.AccentureGSTIN != null && invoice.BusinessPlace != null)
                                                {
                                                    var gstData = gstMasterList.Where(X => X.BusinessPlace == invoice.BusinessPlace && X.GSTIN == invoice.AccentureGSTIN);
                                                    if (gstData != null && gstData.Count() > 0)
                                                    {
                                                        foreach (var gst in gstData)
                                                        {
                                                            invoice.GSTID = gst.GSTID;
                                                            invoice.BusinessPlaceId = gst.GSTID;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine($"gst error 5");
                                                        invoice.IsGSTError = "Y";


                                                        ErrorDetails errorDetails = new ErrorDetails();
                                                        errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                                                        errorDetails.IsValidError = "true";


                                                        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                    }
                                                }
                                                else
                                                {
                                                    Console.WriteLine($"gst error 6");
                                                    invoice.IsGSTError = "Y";


                                                    ErrorDetails errorDetails = new ErrorDetails();
                                                    errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate are mandatory fields";
                                                    errorDetails.IsValidError = "true";


                                                    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                }

                                                #endregion
                                                //#region
                                                //if (invoice.POS != null && invoice.BusinessPlace != null)
                                                //{
                                                //    var gstData = gstMasterList.Where(X => X.BusinessPlace == invoice.BusinessPlace && X.Region == invoice.POS);
                                                //    if (gstData != null && gstData.Count() > 0)
                                                //    {
                                                //        foreach (var gst in gstData)
                                                //        {
                                                //            invoice.POS = gst.Region;
                                                //            invoice.BusinessPlace = gst.BusinessPlace;
                                                //        }
                                                //    }
                                                //    else
                                                //    {
                                                //        Console.WriteLine($"gst error 5");
                                                //        invoice.IsGSTError = "Y";


                                                //        ErrorDetails errorDetails = new ErrorDetails();
                                                //        errorDetails.Error = " POS and Business place are not matching as per the Accenture master data";
                                                //        errorDetails.IsValidError = "true";


                                                //        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                //    }
                                                //}
                                                //else
                                                //{
                                                //    Console.WriteLine($"gst error 10");
                                                //    invoice.IsGSTError = "Y";


                                                //    ErrorDetails errorDetails = new ErrorDetails();
                                                //    errorDetails.Error = "Tax Type, Accenture GST, Business place,POS and Tax Rate are mandatory fields";
                                                //    errorDetails.IsValidError = "true";


                                                //    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                //}
                                                //#endregion
                                                //#region
                                                //if (invoice.AccentureGSTIN != null && invoice.POS != null)
                                                //{
                                                //    var gstData = gstMasterList.Where(X => X.Region == invoice.POS && X.GSTIN == invoice.AccentureGSTIN);
                                                //    if (gstData != null && gstData.Count() > 0)
                                                //    {
                                                //        foreach (var gst in gstData)
                                                //        {
                                                //            invoice.POS = gst.Region;
                                                //            invoice.AccentureGSTIN = gst.GSTIN;
                                                //        }
                                                //    }
                                                //    else
                                                //    {
                                                //        Console.WriteLine($"gst error 5");
                                                //        invoice.IsGSTError = "Y";


                                                //        ErrorDetails errorDetails = new ErrorDetails();
                                                //        errorDetails.Error = " Accenture GST and POS  are not matching as per the Accenture master data";
                                                //        errorDetails.IsValidError = "true";


                                                //        invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                //    }
                                                //}
                                                //else
                                                //{
                                                //    Console.WriteLine($"gst error 11");
                                                //    invoice.IsGSTError = "Y";


                                                //    ErrorDetails errorDetails = new ErrorDetails();
                                                //    errorDetails.Error = "Tax Type, Accenture GST, Business place,Tax Rate and POS are mandatory fields";
                                                //    errorDetails.IsValidError = "true";


                                                //    invoiceErrorDetails.ErrorsList.Add(errorDetails);
                                                //}
                                                //#endregion                                               
                                                #endregion
                                            }
                                            if (invoice.IsGSTError == "Y")
                                            {
                                                invoice.InvoiceStatusCd = CommonConstants.StausError;
                                            }
                                            invoice.IsOverrideProcessingBlock = 0;
                                            #endregion
                                            //  #endregion
                                            bool isDuplicate = await CheckDuplicateInvoiceNumberForVendorCode(db, invoiceTable, invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, context, result);
                                            if (!isDuplicate)
                                            {
                                                InvoiceHistory invoiceHistory = new InvoiceHistory();
                                                {
                                                    invoiceHistory.SourceId = invoice.VendorRegisteredCd + "-" + invoice.VendorInvoiceNumber;
                                                    invoiceHistory.ModifiedBy = CommonConstants.ForexTeam;
                                                    // invoiceHistory.StatusCd = CommonConstants.StatusPDFAwaited;
                                                    if (invoice.IsGSTError == "Y")
                                                    {
                                                        invoiceHistory.StatusCd = CommonConstants.StausError;
                                                    }
                                                    else
                                                    {
                                                        invoiceHistory.StatusCd = CommonConstants.StatusPDFAwaited;
                                                    }
                                                    invoiceHistory.StatusDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                                    if (DateTime.TryParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                                                    {
                                                        invoiceHistory.SearchStatusDt = DateTime.ParseExact(invoiceHistory.StatusDt, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                                                    }
                                                }
                                                await db.InsertAsync<Invoice>(invoice, invoiceTable, context);
                                                await db.InsertAsync<InvoiceHistory>(invoiceHistory, historyTable, context);
                                                context.Logger.Log($"Data inserted successfully {invoice.VendorRegisteredCd}, {invoice.VendorInvoiceNumber}");
                                            }
                                            else
                                            {
                                                Console.WriteLine($"Duplicate invoice found {invoice.VendorRegisteredCd},{invoice.VendorInvoiceNumber}");
                                            }
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        context.Logger.Log($"Exception while inserting the data inside the HD  {e.Message}");
                                        context.Logger.Log($"Innner exception :{e.InnerException}");
                                        context.Logger.Log($"Stack trace :{e.StackTrace}");
                                    }
                                }


                            }
                        }

                    }
                    if (!string.IsNullOrEmpty(fileName))
                    {
                        string renamedFile = RenameFile(fileName);
                        await CopyFileFromOneFolderToOther(bucketName, bucketName, forexLgiCsvDumpFolder, forexPrivateLgiCsvFolder, fileName, renamedFile, context);
                        await DeleteFile(bucketName, forexLgiCsvDumpFolder, fileName, context);
                    }

                }
            }
            catch (Exception e)
            {
                //context.Logger.LogLine($"Error getting object {s3Event.Object.Key} from bucket {s3Event.Bucket.Name}. Make sure they exist and your bucket is in the same region as this function.");
                //context.Logger.LogLine(e.Message);
                //context.Logger.LogLine(e.StackTrace);
                //throw;
                context.Logger.Log($"Exception in main block :{e.Message}");
                context.Logger.Log($"Innner exception :{e.InnerException}");
                context.Logger.Log($"Stack trace :{e.StackTrace}");
                context.Logger.Log($"{e.Source}");
                context.Logger.Log($"{e.HResult}");
            }
        }
        private async Task<GetObjectResponse> GetFileFromS3(string bucketName, string folderName, string fileName, ILambdaContext context)
        {
            GetObjectResponse getObjectResponse = null;
            if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderName) && !string.IsNullOrEmpty(fileName))
            {
                var getObjectRequest = new GetObjectRequest
                {
                    BucketName = bucketName + "/" + folderName,
                    Key = fileName
                };

                getObjectResponse = await
                    S3Client.GetObjectAsync(getObjectRequest);
            }
            else
            {
                context.Logger.Log($"Log: File path mentioned does not exists :{bucketName}/{folderName}/{fileName}");
            }

            return getObjectResponse;


        }
        private async Task<bool> CheckDuplicateInvoiceNumberForVendorCode(IDigiDynamoDb db, string tableName, string vendorCode, string invoiceNumber, ILambdaContext logger, List<Invoice> listOfInvoices)
        {

            if (listOfInvoices.Any(invoice => invoice.VendorInvoiceNumber == invoiceNumber && invoice.VendorRegisteredCd == vendorCode && invoice.VendorModuleCd == CommonConstants.ForexTeam))
            {
                if (listOfInvoices.Any(invoice => invoice.VendorInvoiceNumber == invoiceNumber && invoice.VendorRegisteredCd == vendorCode && invoice.VendorModuleCd == CommonConstants.ForexTeam && invoice.IsGSTError == "Y"))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        private VendorMasterEntities CheckExemptedVendorCode(List<VendorMasterEntities> masterdata, string vendorcode, ILambdaContext context)
        {
            try
            {
                context.Logger.Log($"exemption check vendorcode {vendorcode}");


                var obj = new VendorMasterEntities();
                List<VendorMasterEntities> filteredVendorMasterDetails = new List<VendorMasterEntities>();
                filteredVendorMasterDetails = masterdata.Where(x => x.VendorCode == vendorcode).ToList();
                if (filteredVendorMasterDetails != null && filteredVendorMasterDetails.Count > 0)
                {
                    obj = filteredVendorMasterDetails[0];
                    return obj;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                context.Logger.Log($"exception in checkexemptedcode");

                context.Logger.Log($" {e.Message}");
                context.Logger.Log($" {e}");
                return null;

            }


        }



        private GSTMasterEntities getGstMasterDetail(List<GSTMasterEntities> masterdata, string businessPlace)
        {
            var obj = new GSTMasterEntities();
            List<GSTMasterEntities> filteredGSTMasterDetails = new List<GSTMasterEntities>();
            filteredGSTMasterDetails = masterdata.Where(x => x.BusinessPlace.ToUpper() == businessPlace.ToUpper()).ToList();
            if (filteredGSTMasterDetails != null && filteredGSTMasterDetails.Count > 0)
            {
                obj = filteredGSTMasterDetails[0];
                return obj;
            }
            else
            {
                return null;
            }

        }
        private async Task CopyFileFromOneFolderToOther(string sourceBucket, string destinationBucket, string sourceFolder, string destinationFolder, string srcfileName, string destFileName, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(srcfileName) && !string.IsNullOrEmpty(destFileName))
            {
                var copyObjectRequest = new CopyObjectRequest()
                {
                    SourceBucket = sourceBucket + "/" + sourceFolder,
                    DestinationBucket = destinationBucket + "/" + destinationFolder,
                    SourceKey = srcfileName,
                    DestinationKey = destFileName
                };
                context.Logger.Log($"Process :before copying the file : {srcfileName} from :{sourceBucket + "/" + sourceFolder} to {destinationBucket + "/" + destinationFolder}");
                await S3Client.CopyObjectAsync(copyObjectRequest);
                context.Logger.Log($"Log :Copied successfully");
            }
            else
            {
                context.Logger.Log($"Error :One of the passed parameter is empty");
            }
        }
        private async Task DeleteFile(string bucket, string folder, string file, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(file) && !string.IsNullOrEmpty(bucket) && !string.IsNullOrEmpty(folder))
            {
                var deleteObjectRequest = new DeleteObjectRequest()
                {
                    BucketName = bucket + "/" + folder,
                    Key = file
                };
                context.Logger.Log($"Now deleting the file name :{file} from folder {bucket}/{folder}");
                var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);

            }
        }

        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
        private void LogChildLambdaResponse(dynamic childLmbdaResponse, ILambdaContext context)
        {
            context.Logger.Log($"Log: Running Child lambda instace id :{childLmbdaResponse.Id}");
            context.Logger.Log($"Log: Is Child lambda Instace :{childLmbdaResponse.Id} cancelled :{childLmbdaResponse.IsCanceled}");
            context.Logger.Log($"Log: Is child lambda instance faulted :{childLmbdaResponse.IsFaulted} ");
            context.Logger.Log($"Log: Result  :{childLmbdaResponse.Result} ");
            context.Logger.Log($"Log: Status  :{childLmbdaResponse.Status} ");
        }
    }
}

