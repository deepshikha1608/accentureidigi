﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_Forex
{
    public class VendorMasterEntities
    {
        public VendorMasterEntities()
        {

        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Entity Framework proxies requrie it.")]

        public VendorMasterEntities(int id)
        {
            Id = id;
        }

        public int Id { get; set; }
        public string UserId { get; set; }
        public string IsActive { get; set; }
        public string VendorCd { get; set; }
        public string VendorNm { get; set; }
        public string VendorCode { get; set; }
        public string VendorCodeId { get; set; }
        public string VendorMailId { get; set; }
        public string VendorUserId { get; set; }
        public string GSTNumber { get; set; }
        public string ParentVendorId { get; set; }
        public int VendorId { get; set; }
        public string CC { get; set; }
        public string VendorCategory { get; set; }
        public string ModifiedDttm { get; set; }
        public string Name1 { get; set; }
        public string StreetName { get; set; }
        public string Ctry { get; set; }
        public string Region { get; set; }
        public string PostalCode { get; set; }
        public string Location { get; set; }
        public string CreatedOn { get; set; }
        public string Status { get; set; }
        public string DelFlg { get; set; }
        public string PAN { get; set; }
        public string TaxNo3 { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string ForeignTaxNumber { get; set; }
        public string FreeText1 { get; set; }
        public string FreeText2 { get; set; }
        public string FreeText3 { get; set; }
        public string BusinessGroup { get; set; }
        public string ADGObjectDetailId { get; set; }
        public int VendorGroupObjectDetailId { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string RedirectURL { get; set; }
        public string RoleObjectDetailId { get; set; }
        public string AlternatePayeeCode { get; set; }
        public string AlternatePayeeName { get; set; }
        public string IsAgreed { get; set; }

        public string IsExempted { get; set; }
    }
}
