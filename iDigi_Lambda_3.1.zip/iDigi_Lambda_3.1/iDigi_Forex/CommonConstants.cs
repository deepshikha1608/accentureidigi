﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace iDigi_Forex
{
    public class CommonConstants
    {
        public const string AirId = "7433";

        public const string LambdaLogDetailsTable = "LambdaLogDetails";
        public const string FileColsDbColsMappingTable = "FileColsDBColsMapping";
        public const string PoTransactionTable = "POTransaction";
        public const string VendorMasterTable = "VendorMaster";
        public const string ApprovedExceptionInvoicesTable = "ApprovedExceptionInvoices";
        public const string InvoiceBatchTable = "InvoiceBatch";
        public const string UdaanInvoiceTable = "UdaanInvoiceDetails";
        public const string InvoiceTable = "ForexInvoices";
        public const string HistoryTable = "ForexHistoryLogs";
        public const string GSTMaster = "GSTMaster";
        public const string PO_FileFolder = "PO";
        public const string VendorMaster_FileFolder = "Vendor";
        public const string ApprovedException_FileFolder = "approvedexception";

        public const string Procurement_POTrasaction_FilePath = "private/procurement/PO";
        public const string Procurement_VendorMaster_FilePath = "private/procurement/Vendor";
        public const string Procurement_ApprovedException_FilePath = "private/procurement/approvedexception";

        public const string Public_Folder = "public";
        public const string Private_Folder = "private";
        public const string UdaanVendor_FilePath = "udaan";
        public const string ForexVendor_FilePath = "forex";
        public const string ParamTable = "Param";

        public const string ForexPrivateLgicsvFolder = "csv";
        public const string ForexPrivateInvoiceFolder = "invoice";
        public const string UdaanInvoiceSubmission = "invoicesubmissioncsv";
        public const string ForexInvoiceSubmission = "invoicesubmissioncsv";
        public const string POTrans_FileModuleCd = "POTRANS";
        public const string POTrans_CSVFile_HeaderColType = "HR";


        public const string VendorMaster_FileModuleCd = "VNDRMAS";
        public const string VendorMaster_CSVFile_HeaderColType = "HR";

        public const string ApprovedException_FileModuleCd = "APVDEXPN";
        public const string ApprovedException_CSVFile_HeaderColType = "HR";

        public const string POtransactionMasterDataInserterLambdaForStageAndDev = "7433_iDIgi_RTPValidator";
        public const string POtransactionMasterDataInserterLambda = "7433_iDIgi_CSVDataInserter";

        public const string ProcurementTeam = "Procurement";
        public const string UdaanTeam = "UDNAG";
        public const string ForexTeam = "Forex";

        public const string StatusDuplicate = "Duplicate";
        public const string IsActiveTRUE = "TRUE";
        public const string StatusPDFAwaited = "PDF Awaited";
        public const string StatusNonCompliant = "Non Compliant";       
        public const string StausError = "Error";
        public const string VendorCategory_Exempted_STATUS = "Exempted";
        public const string VendorCategory_NonExempted_STATUS = "NonExempted";
        public const string VendorCategory_NotApplicable_STATUS = "NotApplicable";
        public const string GSTR2A_NotRequired_STATUS = "GSTR2ANotRequired";
        public const string GSTR2A_ReconPending_STATUS = "GSTR2AReconPending";
        public const string TAXExempt = "EXEMPT";
        public const string TAXCGSTSGST = "CGST + SGST";
        public const string TAXIGST = "IGST";
        public const string TAXTypeHO = "H.O.";
        public const string TAXTypeSTPI = "STPI";
        public const string TAXTypeIDB = "IDB";
        public const string TAXTypeSEZ = "SEZ";
        public const string TAXTypeneitherstpinorSEZ = "NEITHER STPI NOR SEZ";
    }
}