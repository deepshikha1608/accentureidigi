using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using iDigi_ReadCSVandUpdateDFMURN.Model;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_ReadCSVandUpdateDFMURN
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonDynamoDB DbClient { get; set; }
        //static Amazon.DynamoDBv2.DataModel.DynamoDBContext db { get; set; }
        public string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }

        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                if (System.Environment.GetEnvironmentVariable("DebugEnvironMent") == "true")
                { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                }
                //return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            }
        }
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            S3Client = new AmazonS3Client();
            DbClient = new AmazonDynamoDBClient();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client, IAmazonDynamoDB DbClient, string cloudEnvironment)
        {
            this.S3Client = s3Client;
            this.DbClient = DbClient;
            //this.CloudEnvironment = cloudEnvironment;
        }
        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {

            string udaanTable = string.Empty;
            string IqnTableName = string.Empty;
            string vendorMasterTableName = string.Empty;
            string realEstateTableName = string.Empty;
            string newGenericTableName = string.Empty;
            string ForexTableName = string.Empty;
            string GenericInvoiceStatusIndex = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                IqnTableName = CommonConstants.AirId + "_" + CommonConstants.IQNInvoiceTable;
                udaanTable = CommonConstants.AirId + "_" + CommonConstants.UdaanInvoiceTable;
                vendorMasterTableName = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;
                realEstateTableName = CommonConstants.AirId + "_" + CommonConstants.RealEstateInvoicesNewTable;
                newGenericTableName = CommonConstants.AirId + "_" + CommonConstants.NewGenericInvoicetable;
                ForexTableName = CommonConstants.AirId + "_" + CommonConstants.ForexInvoicesTable;
                GenericInvoiceStatusIndex = CommonConstants.AirId + "_" + CommonConstants.InvoiceStatusIndex;
            }
            else
            {
                IqnTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNInvoiceTable;
                udaanTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                vendorMasterTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                realEstateTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateInvoicesNewTable;
                newGenericTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.NewGenericInvoicetable;
                ForexTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexInvoicesTable;
                GenericInvoiceStatusIndex = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceStatusIndex;
            }
            string dfmCSVdumpFolder = CommonConstants.DFMcsvFile_FolderPath;
            string bucketName = evnt.Records[0].S3.Bucket.Name;
            var scanFilterForUdaan = new ScanFilter();
            //scanFilterForUdaan.AddCondition("InvoiceId", ScanOperator.GreaterThanOrEqual, 0);
            List<String> attibutesToGetFromUdaanTbale = new List<string>() { "VendorCd", "VendorRegisteredCd", "InvoiceStatusCd", "AttachedFile", "DFMURN" };
            ScanOperationConfig scanOperationConfigForUdaan = new ScanOperationConfig()
            {
                Select = SelectValues.SpecificAttributes,
                Filter = scanFilterForUdaan,
                AttributesToGet = attibutesToGetFromUdaanTbale
            };
            var scanFilterForIQN = new ScanFilter();
            scanFilterForIQN.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
            List<String> attibutesToGetFromIQNTbale = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "InvoiceStatusCd", "AttachedFile", "VendorModuleCd", "DFMURN" };
            ScanOperationConfig scanOperationConfigForIQN = new ScanOperationConfig()
            {
                Select = SelectValues.SpecificAttributes,
                Filter = scanFilterForIQN,
                AttributesToGet = attibutesToGetFromIQNTbale
            };
            //var scanFilterForVendorMasterTable = new ScanFilter();
            //scanFilterForVendorMasterTable.AddCondition("VendorCd", ScanOperator.Equal, "REAL VENDOR");
            List<string> attributesToGetFromVendorTable = new List<string>() { "VendorId", "VendorCode", "VendorCd" };
            ScanOperationConfig scanOperationConfigForVendormaster = new ScanOperationConfig()
            {
                Select = SelectValues.SpecificAttributes,
                //Filter = scanFilterForVendorMasterTable,
                AttributesToGet = attributesToGetFromVendorTable
            };

            List<string> attributesToGetFromRealEstateInvoices = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "InvoiceStatusCd", "AttachedFile", "VendorModuleCd", "DFMURN" };
            var scanfilterRealEstateVendor = new ScanFilter();
            scanfilterRealEstateVendor.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");


            ScanOperationConfig scanOperationConfigForRealEstateVendor = new ScanOperationConfig()
            {
                Select = SelectValues.SpecificAttributes,
                Filter = scanfilterRealEstateVendor,
                AttributesToGet = attributesToGetFromRealEstateInvoices

            };

            //List<string> attributeTogetFromNewGenericTable = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "InvoiceStatusCd", "AttachedFile", "VendorModuleCd", "DFMURN" };
            //var scanFilterGenericNewTable = new ScanFilter();
            //scanFilterGenericNewTable.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
            //ScanOperationConfig scnaOperationConfigNEwGenericTable = new ScanOperationConfig()
            //{
            //    Select = SelectValues.SpecificAttributes,
            //    Filter = scanFilterGenericNewTable,
            //    AttributesToGet = attributeTogetFromNewGenericTable
            //};
            QueryRequest genericrequest = new QueryRequest
            {
                TableName = newGenericTableName,
                IndexName = GenericInvoiceStatusIndex,
                KeyConditionExpression = "InvoiceStatusCd=:Status",
                FilterExpression = "attribute_not_exists(DFMURN)",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                        {
                            {":Status", new AttributeValue{S="RTP Received"} },
                        }
            };
            var newGenericTableData = await QueryTheTable<GenericInvoice>(genericrequest);

            var scanFilterForForex = new ScanFilter();
            scanFilterForForex.AddCondition("InvoiceStatusCd", ScanOperator.Equal, "RTP Received");
            List<String> attibutesToGetFromForexTbale = new List<string>() { "VendorRegisteredCd", "VendorInvoiceNumber", "InvoiceStatusCd", "AttachedFile", "VendorModuleCd", "DFMURN" };
            ScanOperationConfig scanOperationConfigForForex = new ScanOperationConfig()
            {
                Select = SelectValues.SpecificAttributes,
                Filter = scanFilterForForex,
                AttributesToGet = attibutesToGetFromForexTbale
            };
            //var newGenericTableData = await ScanAndFindTheInvoice<GenericInvoice>(new GenericInvoice(), newGenericTableName, scnaOperationConfigNEwGenericTable);

            var realEstateInvoicesDetails = await ScanAndFindTheInvoice<RealEstateInvoice>(new RealEstateInvoice(), realEstateTableName, scanOperationConfigForRealEstateVendor);

            Console.WriteLine($"Real estate invoice detail {realEstateInvoicesDetails.Count}");
            var vendorMasterdetails = await ScanAndFindTheInvoice<VendorMaster>(new VendorMaster(), vendorMasterTableName, scanOperationConfigForVendormaster);

            var udaanAllInvoiceDetails = await ScanAndFindTheInvoice<UdaanInvoice>(new UdaanInvoice(), udaanTable, scanOperationConfigForUdaan);
            var iqnAllInvoiceDetails = await ScanAndFindTheInvoice<IQNInvoice>(new IQNInvoice(), IqnTableName, scanOperationConfigForIQN);
            var forexAllInvoiceDetails = await ScanAndFindTheInvoice<ForexInvoice>(new ForexInvoice(), ForexTableName, scanOperationConfigForForex);
            context.Logger.LogLine($"Data :Total Generic invoice count {newGenericTableData.Count}");
            context.Logger.LogLine($"Data :Total Visa invoice count {udaanAllInvoiceDetails.Count}");
            context.Logger.LogLine($"Data :Total Forex invoice count {forexAllInvoiceDetails.Count}");
            try
            {
                string fileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(dfmCSVdumpFolder + "/", ""));
                context.Logger.LogLine($"Start :{context.FunctionName} has invoked in {CloudEnvironment} environment by {fileName}");
                var csvFileData = await GetFileFromS3(bucketName, dfmCSVdumpFolder, fileName, context);
                if (csvFileData != null)
                {
                    using (var csvReadData = new System.IO.StreamReader(csvFileData.ResponseStream))
                    {
                        context.Logger.Log($"Process: Now StreamReader is reading the data from the file {fileName}");
                        var csv = new CsvHelper.CsvReader(csvReadData);
                        csv.Configuration.HasHeaderRecord = false;//CSV file from the DFM does not have Header 
                        string vendorInvoiceNumber = string.Empty;
                        string vendorRegisteredCode = string.Empty;
                        string fileNameFromDFMCsv = string.Empty;
                        string dfmUrn = string.Empty;
                        string invoiceRecieptDate = string.Empty;
                        while (csv.Read())
                        {
                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(0)))
                            {
                                dfmUrn = csv.GetField<string>(0);
                            }
                            else
                            {
                                context.Logger.Log($"Log : DFM number collumn is empty at row {csv.Row}");
                                continue;
                            }
                            if (!string.IsNullOrWhiteSpace(csv.GetField<string>(1)))
                            {
                                fileNameFromDFMCsv = csv.GetField<string>(1);
                                string[] splitedstring = fileNameFromDFMCsv.Split('_');
                                vendorInvoiceNumber = splitedstring[1];
                                vendorRegisteredCode = splitedstring[0];
                            }
                            else
                            {
                                context.Logger.Log($"Log : FileName collumn is empty at row {csv.Row}");
                                continue;
                            }

                            if (!string.IsNullOrEmpty(csv.GetField<string>(2)))
                            {
                                if (csv.GetField<string>(2).Contains('-'))
                                {
                                    string strDate = csv.GetField<string>(2);
                                    context.Logger.Log($"Log : Reciept date as it recieved{csv.GetField<string>(2)}");
                                    string[] splitedString = csv.GetField<string>(2).Split('-');
                                    string dateString = string.Empty;
                                    if (splitedString.Length == 3)
                                    {
                                        if (splitedString[2].Length == 1)
                                        {
                                            splitedString[2] = "0" + splitedString[0];
                                        }
                                        if (splitedString[1].Length == 1)
                                        {
                                            splitedString[1] = "0" + splitedString[1];
                                        }
                                        //converted MM/dd/yyyy
                                        dateString = splitedString[1] + "/" + splitedString[2] + "/" + splitedString[0];
                                        invoiceRecieptDate = dateString;
                                        context.Logger.Log($"Data : Reciept date after conversion {invoiceRecieptDate}");
                                    }
                                }
                                else
                                {
                                    context.Logger.Log($"Error :The Reciept date format is invalid at :{csv.Row}");
                                    continue;
                                }
                            }
                            else
                            {
                                context.Logger.Log($"Error: The Reciept date collumn is empty at:{csv.Row}");
                                continue;
                            }
                            Console.WriteLine($" invoice number {vendorInvoiceNumber},dfm urn {dfmUrn},vendorregistered code  {vendorRegisteredCode},file name {fileNameFromDFMCsv}");
                            if (!string.IsNullOrWhiteSpace(vendorInvoiceNumber) && !string.IsNullOrWhiteSpace(dfmUrn) && !string.IsNullOrWhiteSpace(invoiceRecieptDate) && !string.IsNullOrWhiteSpace(fileNameFromDFMCsv) && !string.IsNullOrEmpty(vendorRegisteredCode))
                            {

                                if (IsVendorCodeBelongToParticularModule(vendorRegisteredCode.ToLowerInvariant(), vendorMasterdetails, "UDN VENDOR")) //udaan and fcm
                                {
                                    context.Logger.Log($"Data :found Visa vendor");
                                    await FetchUdaanInvoiceAndUpdateDFMUrn(vendorInvoiceNumber, vendorRegisteredCode, fileNameFromDFMCsv, dfmUrn, invoiceRecieptDate, udaanTable, context, udaanAllInvoiceDetails);
                                }
                                else
                                {   //Real estate
                                    if (IsVendorCodeBelongToParticularModule(vendorRegisteredCode.ToLowerInvariant(), vendorMasterdetails, "REAL VENDOR"))
                                    {
                                        if (realEstateInvoicesDetails != null && realEstateInvoicesDetails.Count > 0)
                                        {
                                            var invoiceDetails = realEstateInvoicesDetails.Where(realEstateInvoiceDetail => realEstateInvoiceDetail.VendorRegisteredCd == vendorRegisteredCode && realEstateInvoiceDetail.AttachedFile.ToLowerInvariant() == fileNameFromDFMCsv.ToLowerInvariant() && (realEstateInvoiceDetail.InvoiceStatusCd != "RTP Rejected" || realEstateInvoiceDetail.InvoiceStatusCd != "NC Rejected") && (realEstateInvoiceDetail.InvoiceStatusCd == "RTP Approved" || realEstateInvoiceDetail.InvoiceStatusCd == "RTP Received") && string.IsNullOrEmpty(realEstateInvoiceDetail.DFMURN)).ToList();

                                            Console.WriteLine($"Number of invoices matching {invoiceDetails.Count}");
                                            foreach (var realEstateDetail in invoiceDetails)
                                            {
                                                Console.WriteLine($"Found real estate vendor {vendorRegisteredCode.ToLowerInvariant()} {fileNameFromDFMCsv}");
                                                await UpdateDfmURNNewTableDesign(realEstateDetail.VendorRegisteredCd, realEstateDetail.VendorInvoiceNumber, dfmUrn, invoiceRecieptDate, realEstateTableName);

                                            }
                                        }

                                    }
                                    //generic vendor
                                    else if (IsVendorCodeBelongToParticularModule(vendorRegisteredCode.ToLowerInvariant(), vendorMasterdetails, "GRN VENDOR"))
                                    {
                                        Console.WriteLine($" Inside the if condition ");
                                        if (newGenericTableData != null && newGenericTableData.Count > 0)
                                        {
                                            Console.WriteLine($" Inside the data list ");
                                            var newGenericInvoiceDetails = new List<GenericInvoice>();
                                            foreach (var genericData in newGenericTableData)
                                            {
                                                if (!string.IsNullOrEmpty(genericData.VendorRegisteredCd) && !string.IsNullOrEmpty(genericData.AttachedFile) && !string.IsNullOrEmpty(genericData.InvoiceStatusCd))
                                                {
                                                    if (genericData.VendorRegisteredCd == vendorRegisteredCode && genericData.AttachedFile.ToLowerInvariant() == fileNameFromDFMCsv.ToLowerInvariant() && (genericData.InvoiceStatusCd != "RTP Rejected" || genericData.InvoiceStatusCd != "NC Rejected") && (genericData.InvoiceStatusCd == "RTP Approved" || genericData.InvoiceStatusCd == "RTP Received") && string.IsNullOrEmpty(genericData.DFMURN))
                                                    {
                                                        newGenericInvoiceDetails.Add(genericData);
                                                    }
                                                }
                                            }
                                            Console.WriteLine($"Total number of invoices matching {newGenericInvoiceDetails.Count}");
                                            foreach (var invoice in newGenericInvoiceDetails)
                                            {
                                                Console.WriteLine($"Found New Generic invoice {vendorRegisteredCode},{fileNameFromDFMCsv}");
                                                await UpdateDfmURNNewTableDesign(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, dfmUrn, invoiceRecieptDate, newGenericTableName);
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine($"Generic table data count is zero");
                                        }
                                    }
                                    else if(IsVendorCodeBelongToParticularModule(vendorRegisteredCode.ToLowerInvariant(), vendorMasterdetails, "IQN VENDOR"))
                                    //else if (iqnAllInvoiceDetails != null && iqnAllInvoiceDetails.Count > 0)
                                    {  //iqn 

                                        {
                                            var iqnInvoiceDetails = new List<IQNInvoice>();
                                            foreach (var iqnData in iqnAllInvoiceDetails)
                                            {
                                                if (!string.IsNullOrEmpty(iqnData.VendorRegisteredCd) && !string.IsNullOrEmpty(iqnData.AttachedFile) && !string.IsNullOrEmpty(iqnData.InvoiceStatusCd))
                                                {
                                                    if (iqnData.VendorRegisteredCd == vendorRegisteredCode && iqnData.AttachedFile.ToLowerInvariant() == fileNameFromDFMCsv.ToLowerInvariant() && iqnData.InvoiceStatusCd != "Non Compliant" && iqnData.InvoiceStatusCd == "RTP Received" && string.IsNullOrEmpty(iqnData.DFMURN))
                                                    {
                                                        iqnInvoiceDetails.Add(iqnData);
                                                    }
                                                }
                                            }
                                            foreach (var invoice in iqnInvoiceDetails)
                                            {
                                                await UpdateDfmURNNewTableDesign(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, dfmUrn, invoiceRecieptDate, IqnTableName);
                                            }
                                        }
                                    }
                                    else
                                    {  //forex 
                                        if (IsVendorCodeBelongToParticularModule(vendorRegisteredCode.ToLowerInvariant(), vendorMasterdetails, "FOREX VENDOR"))
                                           // if (forexAllInvoiceDetails != null && forexAllInvoiceDetails.Count > 0)
                                        {
                                            var forexInvoiceDetails = new List<ForexInvoice>();
                                            foreach (var forexData in forexAllInvoiceDetails)
                                            {
                                                if (!string.IsNullOrEmpty(forexData.VendorRegisteredCd) && !string.IsNullOrEmpty(forexData.AttachedFile) && !string.IsNullOrEmpty(forexData.InvoiceStatusCd))
                                                {
                                                    if (forexData.VendorRegisteredCd == vendorRegisteredCode && forexData.AttachedFile.ToLowerInvariant() == fileNameFromDFMCsv.ToLowerInvariant() && forexData.InvoiceStatusCd != "Non Compliant" && forexData.InvoiceStatusCd == "RTP Received" && string.IsNullOrEmpty(forexData.DFMURN))
                                                    {
                                                        forexInvoiceDetails.Add(forexData);
                                                    }
                                                }
                                            }
                                            foreach (var invoice in forexInvoiceDetails)
                                            {
                                                await UpdateDfmURNNewTableDesign(invoice.VendorRegisteredCd, invoice.VendorInvoiceNumber, dfmUrn, invoiceRecieptDate, ForexTableName);
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                context.Logger.Log($"Log : One of the fallowing parmeter is null or empty VendorInvoiceNumber :{vendorInvoiceNumber},DFM URN :{dfmUrn}");
                                context.Logger.Log($"contd.. RecieptDate :{invoiceRecieptDate}, FileNamefromdfmcsv :{fileNameFromDFMCsv}");
                            }
                        }
                    }
                }

            }
            catch (Exception e)
            {

                context.Logger.LogLine($"Exception: {e.Message}");
                context.Logger.LogLine($"Exception: Inner exception - {e.InnerException}");
                context.Logger.LogLine($"Exception: Stack trace - {e.StackTrace}");
                //throw;
            }
        }
        private async Task FetchUdaanInvoiceAndUpdateDFMUrn(string vendorInvoiceNumber, string vendorRegisteredCode, string fileNameFromDFMCsv, string dfmUrn, string invoiceRecieptDate, string tableName, ILambdaContext context, List<UdaanInvoice> allUdaanInvoices)
        {
            //context.Logger.Log($"Process :Now updating the table with the dfm urn :{dfmUrn} for vendor invoice number :{vendorInvoiceNumber} table {tableName} ");
            try
            {
                if (!string.IsNullOrEmpty(vendorRegisteredCode))
                {
                    #region udaan                        
                    var udaanInvoice = allUdaanInvoices.Where(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.AttachedFile == fileNameFromDFMCsv && (invoice.InvoiceStatusCd != "RTP Rejected" || invoice.InvoiceStatusCd != "NC Rejected") && (invoice.InvoiceStatusCd == "RTP Approved" || invoice.InvoiceStatusCd == "RTP Received") && string.IsNullOrEmpty(invoice.DFMURN)).ToList();

                    // Console.WriteLine($"{JsonConvert.SerializeObject(udaanInvoice)}");

                    if (udaanInvoice != null && udaanInvoice.Count > 0)
                    {
                        foreach (var item in udaanInvoice)
                        {
                            if (!string.IsNullOrEmpty(item.VendorCd))
                            {
                                context.Logger.Log($"Process :Now updating the table with the dfm urn :{dfmUrn} for vendor invoice number :{vendorInvoiceNumber} table {tableName}, {item.VendorCd},{vendorRegisteredCode},{invoiceRecieptDate}");
                                await UpdateDfmURNUdaan(item.VendorCd, vendorInvoiceNumber, dfmUrn, invoiceRecieptDate, tableName);
                                context.Logger.LogLine($"Success: DFM URN updated successfully");
                            }

                        }
                    }
                    else
                    {
                        context.Logger.Log($"Data Error :There is no Invoice Matching the Inv no :{vendorInvoiceNumber} vendorRegisteredCd :{vendorRegisteredCode} file name: {fileNameFromDFMCsv} and vendoporCd ");
                    }
                    #endregion
                }
            }
            catch (Exception e)
            {
                //mail
                context.Logger.Log($"Error :Exception message :{e.Message}");
                context.Logger.Log($"Error :Exception inner message {e.InnerException}");
                context.Logger.Log($"Error :Exception Stack trace :{e.StackTrace}");
            }
        }
        //private async Task FetchIQNInvoiceAndUpdateDFMUrn(string vendorInvoiceNumber, string vendorRegisteredCode, string fileNameFromDFMCsv, string dfmUrn, string invoiceRecieptDate, string tableName, ILambdaContext context, List<GenericInvoice> allGenericInvoices)
        //{
        //    try
        //    {
        //        if (!string.IsNullOrEmpty(vendorRegisteredCode))
        //        {
        //            var genricInvoice = allGenericInvoices.Where(invoice => invoice.VendorRegisteredCd == vendorRegisteredCode && invoice.AttachedFile == fileNameFromDFMCsv && invoice.InvoiceStatusCd != "RTP Rejected" && invoice.InvoiceStatusCd == "RTP Approved" && string.IsNullOrEmpty(invoice.DFMURN)).ToList();
        //            if (genricInvoice != null && genricInvoice.Count > 0)
        //            {
        //                foreach (var item in genricInvoice)
        //                {
        //                    if (!string.IsNullOrEmpty(item.InvoiceID.ToString()))
        //                    {
        //                        context.Logger.Log($"Process :Now updating the table with the dfm urn :{dfmUrn} for vendor invoice number :{vendorInvoiceNumber} table {tableName}, {item.InvoiceID},{vendorRegisteredCode},{invoiceRecieptDate}");
        //                        await UpdateDfmURN(item.InvoiceID.ToString(), vendorRegisteredCode, dfmUrn, invoiceRecieptDate, tableName);
        //                        context.Logger.LogLine($"Success: DFM URN updated successfully");
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                context.Logger.Log($"Data Error :There is no Invoice Matching the Inv no :{vendorInvoiceNumber} vendorRegisteredCd :{vendorRegisteredCode} file name: {fileNameFromDFMCsv} ");
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        //mail
        //        context.Logger.Log($"Error :Exception message :{e.Message}");
        //        context.Logger.Log($"Error :Exception inner message {e.InnerException}");
        //        context.Logger.Log($"Error :Exception Stack trace :{e.StackTrace}");
        //    }
        //}
        private async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            Search search = table.Scan(scanOperationConfig);
            List<T> resultList = new List<T>();
            int count = 0;
            do
            {
                //Console.WriteLine($"Data :Scan operation :iteration number{count}");
                count = count + 1;
                List<Document> docList = await search.GetNextSetAsync();
                foreach (var document in docList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
                //Console.WriteLine($"Data :Document count in iteration number :{count} is {docList.Count}");
            }
            while (!search.IsDone);
            Console.WriteLine($"Data :Total number of iteration  :{count}");
            Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
            return resultList;
        }
        public async Task<List<T>> QueryTheTable<T>(QueryRequest queryRequest)
        {
            List<T> lisOfT = new List<T>();
            QueryResponse response = null;
            do
            {
                response = await DbClient.QueryAsync(queryRequest);
                if (response != null && response.Count > 0)
                {
                    foreach (var item in response.Items)
                    {
                        var document = Document.FromAttributeMap(item);
                        //lisOfT.Add(db.FromDocument<T>(document));
                        lisOfT.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                    }
                }
                if (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count != 0)
                {
                    queryRequest.ExclusiveStartKey = response.LastEvaluatedKey;
                }
                else
                {
                    queryRequest.ExclusiveStartKey = new Dictionary<string, AttributeValue>();
                }
            } while (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0);
            return lisOfT;
        }
        private async Task UpdateDfmURNUdaan(string VendorCd, string VendorInvoiceNumber, string dfmUrn, string invoiceRecieptDate, string udaanTableName)
        {
            var date = DateTime.ParseExact(invoiceRecieptDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

            var searchInvoiceReceiptDt = date.ToString("yyyy/MM/dd");

            var updateItemRequest = new UpdateItemRequest
            {
                TableName = udaanTableName,
                Key = new Dictionary<string, AttributeValue>()
                    {
                      { "VendorCd", new AttributeValue { S= VendorCd} },
                      { "VendorInvoiceNumber",new AttributeValue {S = VendorInvoiceNumber} }
                    },
                UpdateExpression = "SET DFMURN = :dfmurn, ReferenceKey1Str=:dfmurn,IndexingNbr=:dfmurn,AssignmentNbr=:dfmurn,InvoiceReceiptDt=:invRecieptDate,SearchInvoiceReceiptDt=:SearchInvoiceReceiptDt",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                    {
                        {":dfmurn",new AttributeValue {S= dfmUrn} },
                        {":invRecieptDate",new AttributeValue { S= invoiceRecieptDate} },
                        {":SearchInvoiceReceiptDt",new AttributeValue {S= searchInvoiceReceiptDt} }
                    }
            };
            var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);

        }
        private async Task UpdateDfmURN(string invoiceID, string vendorRegisteredCode, string dfmUrn, string invoiceRecieptDate, string tableName)
        {
            var updateItemRequest = new UpdateItemRequest
            {
                TableName = tableName,
                Key = new Dictionary<string, AttributeValue>()
                    {
                      { "InvoiceID", new AttributeValue { N= invoiceID} },
                      { "VendorRegisteredCd",new AttributeValue {S = vendorRegisteredCode} }
                    },
                UpdateExpression = "SET DFMURN = :dfmurn, ReferenceKey1Str=:dfmurn,IndexingNbr=:dfmurn,AssignmentNbr=:dfmurn,InvoiceReceiptDt=:invRecieptDate",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                    {
                        {":dfmurn",new AttributeValue {S= dfmUrn} },
                        {":invRecieptDate",new AttributeValue { S= invoiceRecieptDate} }
                    }
            };
            var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
        }
        private async Task<GetObjectResponse> GetFileFromS3(string sourceBucket, string publicFolder, string fileName, ILambdaContext context)
        {
            context.Logger.Log($"Process: Now fetching {fileName} from {sourceBucket}/{publicFolder}");
            try
            {
                return await S3Client.GetObjectAsync(
                           new GetObjectRequest
                           {
                               BucketName = sourceBucket + "/" + publicFolder,
                               Key = fileName
                           });
            }
            catch (Exception e)
            {
                //Do call the Api for  exception Mail , Once Ready
                context.Logger.Log($"Exception Occured while fetching {fileName} from bucket {sourceBucket}");
                context.Logger.Log($"Exception message {e.Message}");
                context.Logger.Log($"Exception stack trace {e.StackTrace}");
                return null;
            }
        }

        private bool IsVendorCodeBelongToParticularModule(string vendorCode, List<VendorMaster> vendorDetails, string vendorModule)
        {
            Console.WriteLine($"Checking vendor module code {vendorModule}");
            if (vendorDetails != null && vendorDetails.Count > 0)
            {
                Console.WriteLine($" vendor details count {vendorDetails.Count}");
                //var list = vendorDetails.Where(vendorDetail => vendorDetail.VendorCode == vendorCode && vendorDetail.VendorCd == vendorModule);
                var matchedVendorList = new List<VendorMaster>();
                foreach (var vendorList in vendorDetails)
                {
                    if (!string.IsNullOrEmpty(vendorList.VendorCode) && !string.IsNullOrEmpty(vendorList.VendorCd))
                    {
                        if (vendorList.VendorCode == vendorCode && vendorList.VendorCd == vendorModule)
                        {
                            matchedVendorList.Add(vendorList);
                        }
                    }
                }

                if (matchedVendorList != null && matchedVendorList.Count() > 0)
                    return true;
                else
                    return false;
            }
            else
            {
                return false;
            }

        }

        private async Task UpdateDfmURNNewTableDesign(string vendorRegisteredCode, string vendorInvoiceNumber, string dfmUrn, string invoiceRecieptDate, string tableName)
        {
            Console.WriteLine($"Updating {vendorRegisteredCode},{vendorInvoiceNumber}");
            var updateItemRequest = new UpdateItemRequest();
            StringBuilder sb = new StringBuilder();
            Dictionary<string, AttributeValue> expressionAttributeAVlues = new Dictionary<string, AttributeValue>();
            expressionAttributeAVlues.Add(":dfmurn", new AttributeValue { S = dfmUrn });
            expressionAttributeAVlues.Add(":invRecieptDate", new AttributeValue { S = invoiceRecieptDate });
            DateTime datetime = new DateTime();
            sb.Append("SET DFMURN = :dfmurn, ReferenceKey1Str=:dfmurn,IndexingNbr=:dfmurn,AssignmentNbr=:dfmurn,InvoiceReceiptDt=:invRecieptDate");
            //if (!string.IsNullOrEmpty(invoiceRecieptDate))
            //{
            //    if (DateTime.TryParseExact(invoiceRecieptDate, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
            //    {
            //        var SearchInvoiceReceiptDt = DateTime.ParseExact(invoiceRecieptDate, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
            //        expressionAttributeAVlues.Add(":InvoiceReceiptDt", new AttributeValue { S = SearchInvoiceReceiptDt });
            //        sb.Append(",InvoiceReceiptDt=:InvoiceReceiptDt");
            //    }
            //}
            updateItemRequest.TableName = tableName;
            updateItemRequest.Key = new Dictionary<string, AttributeValue>()
                    {
                      { "VendorRegisteredCd",new AttributeValue {S = vendorRegisteredCode} },
                      { "VendorInvoiceNumber", new AttributeValue { S= vendorInvoiceNumber} },
                    };
            updateItemRequest.UpdateExpression = sb.ToString();
            updateItemRequest.ExpressionAttributeValues = expressionAttributeAVlues;
            var updateItemResponse = await DbClient.UpdateItemAsync(updateItemRequest);
        }
    }
}
