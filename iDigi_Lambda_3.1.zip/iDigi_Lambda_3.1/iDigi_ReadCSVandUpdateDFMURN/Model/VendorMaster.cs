﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_ReadCSVandUpdateDFMURN.Model
{
    public class VendorMaster
    {
        public int VendorId { get; set; }
        public int VendorGroupObjectDetailId { get; set; }
        public string ADGObjectDetailId { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string IsActive { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string RoleObjectDetailId { get; set; }
        public string RoleTypeObjectDetailId { get; set; }
        public string VendorCd { get; set; }
        //vendor code in 
        public string VendorCode { get; set; }
        public string VendorMailId { get; set; }
        public string VendorNm { get; set; }
        public string VendorUserId { get; set; }
        public string RedirectURL { get; set; }
        //new properties
        //Mapping factor
        //public int VendorId { get; set; }

        public string CC { get; set; }
        public string Name1 { get; set; }
        public string StreetName { get; set; }
        public string Ctry { get; set; }
        public string Region { get; set; }
        public int PostalCode { get; set; }
        public string Location { get; set; }
        public string CreatedOn { get; set; }
        public string Status { get; set; }
        public string DelFlg { get; set; }
        public string PAN { get; set; }
        public string TaxNo3 { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string ForeignTaxNumber { get; set; }
        public string ParentVendorId { get; set; }
        public string GSTNumber { get; set; }
        public string VendorCategory { get; set; }
        public int GSTPatner { get; set; }
        public string FreeText1 { get; set; }
        public string FreeText2 { get; set; }
        public string FreeText3 { get; set; }
    }
}
