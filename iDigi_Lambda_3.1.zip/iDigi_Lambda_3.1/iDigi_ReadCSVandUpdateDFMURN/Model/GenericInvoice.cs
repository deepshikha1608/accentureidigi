﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_ReadCSVandUpdateDFMURN.Model
{
    public class GenericInvoice
    {
        public GenericInvoice()
        {

        }
        public GenericInvoice(int id)
        {
            Id = id;
        }
        public int Id { get; set; }
        public int InvoiceID { get; set; }
        public int? InvoiceDataId { get; set; }
        public int? CurrentInvoiceBatchId { get; set; }
        public string InternalInvoiceRefNbr { get; set; }
        public string VendorModuleCd { get; set; }
        public string InvoiceSubmissionDt { get; set; }
        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public string VendorRegisteredCd { get; set; }
        public string VendorInvoiceNumber { get; set; }
        public string VendorGSTNumber { get; set; }
        public string InvoiceStatusCd { get; set; }
        public int CurrentLGIBatchFileToSAPId { get; set; }
        public string UserRoleBasedInd { get; set; }
        public string AssignedRoleCd { get; set; }
        public string AssignedUserLoginCd { get; set; }
        public string AssignedInternalUserId { get; set; }
        public string TPCd { get; set; }
        public string DCInd { get; set; }
        public string InvoiceDt { get; set; }
        public double? TaxAmt { get; set; }
        public double? FreightAmt { get; set; }
        public double? GrossAmt { get; set; }
        public string CurrencyCd { get; set; }
        public string RequestorNm { get; set; }
        public string InvoiceReferenceNbr { get; set; }
        public string PaymentReferenceNbr { get; set; }
        public string AlternativePayeeNm { get; set; }
        public string PORReferenceNbr { get; set; }
        public string IndexingNbr { get; set; }
        public string ReserverdInd { get; set; }
        public string InvoiceReceiptDt { get; set; }
        public string BusinessPlaceNm { get; set; }
        public string ReferenceKey1Str { get; set; }
        public string ReferenceKey2Str { get; set; }
        public string ReferenceKey3Str { get; set; }
        public string AssignmentNbr { get; set; }
        public double? Base1Amt { get; set; }
        public double? Base2Amt { get; set; }
        public double? Base3Amt { get; set; }
        public double? Base4Amt { get; set; }
        public string AccentureGSTPartnerNm { get; set; }
        public string GSTPartnerNm { get; set; }
        public string POSStr { get; set; }
        public string UpdateDttm { get; set; }
        public string UpdateUserId { get; set; }
        public string CreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string AttachedFile { get; set; }
        public string TaxRate { get; set; }
        public string TaxParameter { get; set; }
        public string HSNSAC { get; set; }
        public string LGIDownloaded { get; set; }
        public string SAPDocNo { get; set; }
        public string DFMURN { get; set; }
        public string AutomationTemplateDownloaded { get; set; }
        public string RTPTeam { get; set; }
        public string RowType { get; set; }
        public string GSTTin { get; set; }
        public string TaxType { get; set; }
        public string InvoicePdf { get; set; }
        public int InvoiceDTId { get; set; }
        public string PageTitle { get; set; }
        public string HoldReason { get; set; }
        public string Remarks { get; set; }
        public string RTPRemarks { get; set; }
        public string CompanyCd { get; set; }
        public string ExceptionReason { get; set; }
        public string IsBulkUploaded { get; set; }
        public string ModifiedDttm { get; set; }

        public string ModifiedBy { get; set; }
        public string VendorNm { get; set; }
        public string RejectionReason { get; set; }
        public string RejectionDate { get; set; }
        public string BusinessGroup { get; set; }
        public string CurrentTeam { get; set; }

        public List<InvoiceLineItem> InvoiceLineItems { get; set; }
        public InvoiceLineItem InvoiceLineItem { get; set; }
        public List<InvoiceHistory> InvoiceHistoryLogs { get; set; }
        public InvoiceHistory InvoiceHistory { get; set; }
        public string LutExpDt { get; set; }
        public string LutNo { get; set; }
        public string RTPRejectionRemarks { get; set; }
        public string BizRejectionRemarks { get; set; }
        public string SearchInvoiceReceiptDt { get; set; }
    }
}
