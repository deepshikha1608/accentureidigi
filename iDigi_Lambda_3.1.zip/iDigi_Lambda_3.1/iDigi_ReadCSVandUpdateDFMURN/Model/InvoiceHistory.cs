﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_ReadCSVandUpdateDFMURN.Model
{
    public class InvoiceHistory
    {
        public InvoiceHistory()
        {

        }
        public int Id { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string CreateDttm { get; set; }
        public string CreateUserId { get; set; }
        public string DFMURN { get; set; }
        public string AttachedFile { get; set; }
        public string InvoiceReceiptDt { get; set; }
    }
}
