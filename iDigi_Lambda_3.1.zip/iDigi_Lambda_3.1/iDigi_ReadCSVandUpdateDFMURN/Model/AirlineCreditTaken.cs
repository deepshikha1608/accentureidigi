﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_ReadCSVandUpdateDFMURN.Model
{
    public class AirlineCreditTaken
    {
        public string InvoiceNumber { get; set; }
        public string PNR { get; set; }
        public string TicketNumber { get; set; }
        public string CreditTakenDate { get; set; }

    }
}
