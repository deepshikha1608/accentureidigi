﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_ReadCSVandUpdateDFMURN
{
    public class CommonConstants
    {
        public const string AirId = "7433";
        //public const string UdaanInvoiceTable = "UdaanInvoiceDetails";
        public const string IQNInvoiceTable = "IQNInvoices";
        public const string UdaanInvoiceTable = "VisaInvoiceDetails";//new  visa module table
        public const string ForexInvoicesTable = "ForexInvoices";
        //public const string GenericAndIQNTable= "Invoices";
        public const string VendorMasterTable = "VendorMaster";
        public const string RealEstateInvoicesNewTable = "RealEstateInvoices";
        public const string NewGenericInvoicetable = "GenericInvoices";
        public const string DFMcsvFile_FolderPath = "dfm/csv";
        public const string UdaanVendorCode = "100252385";
        public const string FCMVendorCode = "100407668";
        public const string InvoiceStatusIndex = "InvoiceStatusCd_LGIDownloaded_index";
    }
}
