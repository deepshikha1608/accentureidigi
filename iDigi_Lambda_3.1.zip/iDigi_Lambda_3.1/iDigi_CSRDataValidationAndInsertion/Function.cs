using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using iDigi_CSRDataValidationAndInsertion.Model;
using Newtonsoft.Json;
using Amazon.DynamoDBv2.DocumentModel;
using iDigi_CSRDataValidationAndInsertion.Models;
using Amazon.DynamoDBv2;
using iTextSharp.text.pdf;
using Amazon.S3.Model;
using System.Collections;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CSRDataValidationAndInsertion
{
    public class Function
    {
        IAmazonDynamoDB dbClient { get; set; }
        public Function()
        {
            dbClient = new AmazonDynamoDBClient();
        }
        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public TimeZoneInfo INDIAN_ZONE
        {
            get
            {
                return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
            }
        }
        public static string CSRDestinationBucket
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("CSRDestinationBucket");
            }
        }
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(MasterClass masterclass, ILambdaContext context)
        {
            context.Logger.Log($"Process :Lambda invoked {masterclass.GetType().ToString()}");
            IDigiDynamoDb db = new IDigiDynamoDb();
            IDigiS3 s3 = new IDigiS3();


            string attachedInvoiceFileName = string.Empty;
            string renamedInvoiceFileName = string.Empty;
            string attchedTRtFileName = string.Empty;
            string renamedTRFileName = string.Empty;

            string csrTable = string.Empty;
            string paramTable = string.Empty;
            string invoiceBatchTable = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                invoiceBatchTable = CommonConstants.AirId + "_" + CommonConstants.InvoiceBatchTable;
                csrTable = CommonConstants.AirId + "_" + CommonConstants.CSRInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CommonConstants.ParamTable;

            }
            else
            {
                invoiceBatchTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.InvoiceBatchTable;
                csrTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CSRInvoiceTable;
                paramTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ParamTable;
            }
            InvoiceBatch invoiceBatch = null;
            if (masterclass != null)
            {
                context.Logger.Log($"Vendor :{masterclass.Vendor}");
                var document = await db.GetItem(invoiceBatchTable, masterclass.Vendor, masterclass.InvoiceBatchDttm);
                context.Logger.Log($"Data :{invoiceBatchTable} {JsonConvert.SerializeObject(masterclass)} ");
                invoiceBatch = IDigiDynamoDocumentConverter.ToObject<InvoiceBatch>(document);
                context.Logger.Log($"{JsonConvert.SerializeObject(invoiceBatch.ValidFileList)}");
                context.Logger.Log($"{JsonConvert.SerializeObject(invoiceBatch.InValidFileList)}");
            }

            CSRInvoice csrInvoice = new CSRInvoice();
            if (masterclass != null && masterclass.CSRInvoice != null)
            {
                try
                {
                    context.Logger.Log($"Inside master class loop");
                    csrInvoice = masterclass.CSRInvoice;
                    csrInvoice.CreatedBy = CommonConstants.CSRTeam;
                    csrInvoice.GSTR2AStatus = "GSTR2AReconPending";
                    csrInvoice.CreatedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff");
                    context.Logger.Log($"created dttm");
                    csrInvoice.ModifiedBy = CommonConstants.CSRTeam;
                    csrInvoice.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy-MM-dd HH:mm:ss.fff");
                    context.Logger.Log($"modified dttm");
                    context.Logger.Log($" CSR file  :  {invoiceBatch.ValidFileList.Count} { masterclass.CSRInvoice.InvoiceNumber}");
                    if (invoiceBatch != null && invoiceBatch.ValidFileList != null && invoiceBatch.ValidFileList.Count > 0 && masterclass.CSRInvoice.InvoiceNumber != null)
                    {
                        context.Logger.Log($"Inside listing of the fileName");
                        try
                        {
                            foreach (var fileName in invoiceBatch.ValidFileList)
                            {
                                context.Logger.Log($"Data {fileName}   {masterclass.CSRInvoice.InvoiceNumber}");
                                context.Logger.Log($"Data {fileName}   {invoiceBatch.ValidFileList}");
                                if (fileName.ToLowerInvariant().Contains("_inv_"))
                                {
                                    context.Logger.Log($"Data {fileName} {masterclass.CSRInvoice.InvoiceNumber}");
                                    if (fileName.ToLowerInvariant().Contains(masterclass.CSRInvoice.InvoiceNumber.ToLowerInvariant()))
                                    {
                                        attachedInvoiceFileName = fileName;
                                        renamedInvoiceFileName = RenameFile(attachedInvoiceFileName);
                                        context.Logger.Log($"Data :found file{attachedInvoiceFileName} ranamed file {renamedInvoiceFileName}");
                                    }
                                }
                                if (fileName.ToLowerInvariant().Contains("_tr_"))
                                {
                                    if (fileName.ToLowerInvariant().Contains(masterclass.CSRInvoice.InvoiceNumber.ToLowerInvariant()))
                                    {
                                        attchedTRtFileName = fileName;
                                        renamedTRFileName = RenameFile(attchedTRtFileName);
                                        context.Logger.Log($"Data :found file{attchedTRtFileName} ranamed file {renamedTRFileName}");
                                    }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            context.Logger.Log($"{e}{e.InnerException}{e.StackTrace}");
                        }
                    }
                    if (invoiceBatch.ValidFileList.Contains(attachedInvoiceFileName) && invoiceBatch.ValidFileList.Contains(attchedTRtFileName))
                    {
                        csrInvoice.InvoiceStatus = "Pending";
                        context.Logger.Log($" CSR status :  {csrInvoice.InvoiceStatus}");

                    }
                    else
                    {
                        csrInvoice.InvoiceStatus = "Rejected";
                        context.Logger.Log($" CSR Status :  {csrInvoice.InvoiceStatus}");

                    }
                    if (!string.IsNullOrEmpty(attchedTRtFileName) && !string.IsNullOrEmpty(attachedInvoiceFileName) && !string.IsNullOrEmpty(renamedInvoiceFileName) && !string.IsNullOrEmpty(renamedTRFileName))
                    {
                        context.Logger.Log($" Digitally sign check Started for Invoice :  {csrInvoice.InvoiceNumber}");
                        GetObjectResponse getObjectResponseInv = await s3.GetFileFromS3(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attachedInvoiceFileName, context);
                        PdfReader readPDFInv = new PdfReader(getObjectResponseInv.ResponseStream);
                        context.Logger.Log($" Digitally sign check :  {csrInvoice.InvoiceNumber}");
                        AcroFields fieldsInv = readPDFInv.AcroFields;
                        ArrayList namesInv = fieldsInv.GetSignatureNames(); //.GetSignatureNames();
                        context.Logger.Log($"Digitally sign check for INV : {namesInv.Count}");
                        context.Logger.Log($"Digitally sign check for TR and Inv : {JsonConvert.SerializeObject(namesInv)}");
                        if (namesInv.Count > 0)
                        {
                            csrInvoice.InvoiceFileNm = renamedInvoiceFileName;
                            csrInvoice.TRFileNm = renamedTRFileName;

                            await db.InsertAsync<CSRInvoice>(csrInvoice, csrTable, context);

                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName, CSRDestinationBucket,
                                    CommonConstants.CSRVendor_PublicPath,
                                    CommonConstants.Private_Folder + "/" + CommonConstants.CSRvendor_FilePath + "/" + CommonConstants.CSRInvoiceFilePath,
                                    attachedInvoiceFileName, renamedInvoiceFileName, context);

                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attachedInvoiceFileName, context);

                            await s3.CopyFileFromOneFolderToOther(masterclass.BucketName, CSRDestinationBucket,
                                    CommonConstants.CSRVendor_PublicPath,
                                    CommonConstants.Private_Folder + "/" + CommonConstants.CSRvendor_FilePath + "/" + CommonConstants.CSRTRFilePath,
                                    attchedTRtFileName, renamedTRFileName, context);

                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attchedTRtFileName, context);
                        }
                        else
                        {
                            csrInvoice.InvoiceFileNm = renamedInvoiceFileName;
                            csrInvoice.TRFileNm = renamedTRFileName;
                            csrInvoice.RejectedRemarks = "Invoice is not digitally signed.";
                            csrInvoice.InvoiceStatus = "Rejected";
                            await db.InsertAsync<CSRInvoice>(csrInvoice, csrTable, context);
                            if (!string.IsNullOrEmpty(attachedInvoiceFileName))
                            {
                                await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attachedInvoiceFileName, context);
                            }
                            if (!string.IsNullOrEmpty(attchedTRtFileName))
                            {
                                await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attchedTRtFileName, context);
                            }
                        }
                    }
                    else
                    {
                        csrInvoice.RejectedRemarks = "Either Inv or TR file is missing / Not digitally signed.";
                        csrInvoice.InvoiceStatus = "Rejected";
                        if (masterclass.IsDublicate == "N")
                        {
                            await db.InsertAsync<CSRInvoice>(csrInvoice, csrTable, context);
                        }
                        if (!string.IsNullOrEmpty(attachedInvoiceFileName))
                        {
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attachedInvoiceFileName, context);
                        }
                        if (!string.IsNullOrEmpty(attchedTRtFileName))
                        {
                            await s3.DeleteFile(masterclass.BucketName, CommonConstants.CSRVendor_PublicPath, attchedTRtFileName, context);
                        }
                    }
                }
                catch (Exception e)
                {
                    context.Logger.Log($"{e.Message}");
                    context.Logger.Log($"{e.InnerException}");
                    context.Logger.Log($"{e.StackTrace}");
                }
            }
        }
        private string RenameFile(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName))
            {
                var splitedFileName = fileName.Split('.');
                string renamedAttcahedFile = splitedFileName[0] + "_" + TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyyMMddHHmm") + "." + splitedFileName[1];
                return renamedAttcahedFile;
            }
            else
            {
                return null;
            }
        }
    }
}
