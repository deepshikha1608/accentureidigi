﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSRDataValidationAndInsertion.Models
{
    public class CSRInvoice
    {
        public string VendorCd { get; set; }
        public string InvoiceNumber { get; set; }
        public string InvoiceDt { get; set; }
        public string InvoiceStatus { get; set; }
        public string TRNumber { get; set; }
        public string BookingID { get; set; }
        public string BookingDt { get; set; }
        public string EmpNm { get; set; }
        public string EmpNumber { get; set; }
        public string EmpPhone { get; set; }
        public string EmpEmail { get; set; }
        public string WBSECd { get; set; }
        public string DestFacility { get; set; }
        public string DestState { get; set; }
        public string CheckInDt { get; set; }
        public string CheckOutDt { get; set; }
        public float TotalAmt { get; set; }
        public string PropertyNm { get; set; }
        public string PropertyEmail { get; set; }
        public string PropertyPhone { get; set; }
        public string CorporateGST { get; set; }
        public string PropertyGST { get; set; }
        public string CompanyNm { get; set; }
        public string BillingAddressAcc { get; set; }
        public string BankRefNumber { get; set; }
        public string HSNSSE { get; set; }
        public float SingleSGSTTax { get; set; }
        public float SingleSGSTAmt { get; set; }
        public float SingleCGSTTax { get; set; }
        public float SingleCGSTAmt { get; set; }
        public float SingleIGSTTax { get; set; }
        public float SingleIGSTAmt { get; set; }
        public float TotalGSTAmt { get; set; }
        public string InvoiceFileNm { get; set; }
        public string TRFileNm { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }
        public string DocNumber { get; set; }
        public string DocDate { get; set; }
        public string BillingAddressCSR { get; set; }
        public float TaxableAmt { get; set; }
        public string TravelCity { get; set; }
        public string creditTakenOn { get; set; }
        public int IdigiKey { get; set; }
        public string RejectedRemarks { get; set; }
        public string StateCd { get; set; }
        public string GSTR2AStatus { get; set; }
    }
}
