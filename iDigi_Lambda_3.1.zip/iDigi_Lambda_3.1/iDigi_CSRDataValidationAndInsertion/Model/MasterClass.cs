﻿using iDigi_CSRDataValidationAndInsertion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CSRDataValidationAndInsertion.Model
{
    public class MasterClass
    {
        public MasterClass()
        {
            // UdaanInvoice = new UdaanInvoice();
            //UdaanInvoiceDump = new UdaanInvoiceDump();
            CSRInvoice = new CSRInvoice();
        }
        public string Vendor { get; set; }
        public string BucketName { get; set; }
        public string UdaanLgiCSVName { get; set; }
        public string InvoiceBatchDttm { get; set; }
        //public UdaanInvoice UdaanInvoice { get; set; }

       // public UdaanInvoiceDump UdaanInvoiceDump { get; set; }
        public bool IsLastUdaanChildLambdaInvoking { get; set; }
        public CSRInvoice CSRInvoice { get; set; }
        public string CsrCSVFileName { get; set; }
        public string IsDublicate { get; set; }
    }
}
