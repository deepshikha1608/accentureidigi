﻿using iDigi_CWTBulkApproveAndReject.Model;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;

namespace iDigi_CWTBulkApproveAndReject
{
    class IDigiS3
    {
        IAmazonS3 S3Client { get; set; }
        public IDigiS3()
        {
            S3Client = new AmazonS3Client();
        }
        public async Task<GetObjectResponse> GetFileFromS3(string bucketName, string folderPath, string fileName, ILambdaContext context)
        {
            try
            {
                GetObjectResponse getObjectResponse = null;
                if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderPath) && !string.IsNullOrEmpty(fileName))
                {
                    var getObjectRequest = new GetObjectRequest
                    {
                        BucketName = bucketName + "/" + folderPath,
                        Key = fileName
                    };

                    getObjectResponse = await
                        S3Client.GetObjectAsync(getObjectRequest);
                }
                else
                {
                    if (string.IsNullOrEmpty(bucketName))
                    { context.Logger.Log($"ERROR: The passed bucket name is null or empty {bucketName}"); }
                    if (string.IsNullOrEmpty(folderPath))
                    { context.Logger.Log($"ERROR: The passed folder path is null or empty {folderPath}"); }
                    if (string.IsNullOrEmpty(fileName))
                    { context.Logger.Log($"ERROR: The passed file name is null or empty {fileName}"); }
                }

                return getObjectResponse;
            }
            catch (Exception e)
            {

                context.Logger.Log($"Error:Exception occured while trying to get the file, error message -{e.Message}");
                context.Logger.Log($"Error: Inner exception message -{e.InnerException}");
                context.Logger.Log($"Error: Stack trace -{e.StackTrace}"); return null;
            }

        }

        public async Task DeleteFile(string bucketName, string folderPath, string fileName, ILambdaContext context)
        {
            context.Logger.Log($"Process: Now process started to delete the file :{fileName} from path :{folderPath} in bucket :{bucketName}");

            if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderPath) && !string.IsNullOrEmpty(fileName))
            {
                var deleteObjectRequest = new DeleteObjectRequest()
                {
                    BucketName = bucketName + "/" + folderPath,
                    Key = fileName

                };
                context.Logger.Log($"Process: Now deleting the file, name :{fileName} from folder {bucketName}/{folderPath}");
                var deleteObjectResponse = await S3Client.DeleteObjectAsync(deleteObjectRequest);
                //return deleteObjectResponse;
            }
            else
            {
                if (string.IsNullOrEmpty(bucketName))
                { context.Logger.Log($"ERROR: The passed bucket name is null or empty {bucketName}"); }
                if (string.IsNullOrEmpty(folderPath))
                { context.Logger.Log($"ERROR: The passed folder path is null or empty {folderPath}"); }
                if (string.IsNullOrEmpty(fileName))
                { context.Logger.Log($"ERROR: The passed file name is null or empty {fileName}"); }
            }
        }



        public async Task PutFileToS3(string bucketName, string folderPath, MemoryStream stream, string fileName, ILambdaContext context)
        {
            try
            {

                if (!string.IsNullOrEmpty(bucketName) && !string.IsNullOrEmpty(folderPath) && !string.IsNullOrEmpty(fileName))
                {

                    var PutObjectRequest = new PutObjectRequest
                    {
                        BucketName = bucketName + "/" + folderPath,
                        Key = fileName,
                        InputStream = stream,
                    };

                    await S3Client.PutObjectAsync(PutObjectRequest);
                    Console.WriteLine("Placed file" + fileName + " at FullBucketName" + PutObjectRequest.BucketName);
                }
                else
                {
                    if (string.IsNullOrEmpty(bucketName))
                    { context.Logger.Log($"ERROR: The passed bucket name is null or empty {bucketName}"); }
                    if (string.IsNullOrEmpty(folderPath))
                    { context.Logger.Log($"ERROR: The passed folder path is null or empty {folderPath}"); }
                    if (string.IsNullOrEmpty(fileName))
                    { context.Logger.Log($"ERROR: The passed file name is null or empty {fileName}"); }
                }


            }
            catch (Exception e)
            {

                context.Logger.Log($"Error:Exception occured while trying to get the file, error message -{e.Message}");
                context.Logger.Log($"Error: Inner exception message -{e.InnerException}");
                context.Logger.Log($"Error: Stack trace -{e.StackTrace}");
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceBucket"></param>
        /// <param name="destinationBucket"></param>
        /// <param name="sourceFolder"></param>
        /// <param name="destinationFolder"></param>
        /// <param name="fileName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task CopyFileFromOneFolderToOther(string sourceBucket, string destinationBucket, string sourceFolder, string destinationFolder, string srcFileName, string destFileName, ILambdaContext context)
        {
            if (!string.IsNullOrEmpty(srcFileName))
            {
                var copyObjectRequest = new CopyObjectRequest()
                {
                    SourceBucket = sourceBucket + "/" + sourceFolder,
                    DestinationBucket = destinationBucket + "/" + destinationFolder,
                    SourceKey = srcFileName,
                    DestinationKey = destFileName
                };
                context.Logger.Log($"Process :Before copying the file : {srcFileName} from :{sourceBucket + "/" + sourceFolder} to {destinationBucket + "/" + destinationFolder}");
                await S3Client.CopyObjectAsync(copyObjectRequest);
                context.Logger.Log($"Copied successfully");
            }
        }



    
}
}
