﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CWTBulkApproveAndReject.Model
{
    class CwtPostApprovalRejectionEntities
    {
        public CwtPostApprovalRejectionEntities()
        {

        }

        public CwtPostApprovalRejectionEntities(int id)
        {
            Id = id;
        }
        public int Id { get; set; }
        public string ModuleNm { get; set; }
        public string UploadDttm { get; set; }
        public string UploadedBy { get; set; }
        public string FileNm { get; set; }
        public string FilePath { get; set; }
        public string ErrorFileNm { get; set; }
        public string ErrorFilePath { get; set; }
        public string TotalRecCnt { get; set; }
        public string ErrorRecCnt { get; set; }
        public string FileExpiryDttm { get; set; }
        public int IsActive { get; set; }

    }
}