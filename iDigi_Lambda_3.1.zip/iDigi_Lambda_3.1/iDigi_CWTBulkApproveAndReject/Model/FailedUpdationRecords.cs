﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CWTBulkApproveAndReject.Model
{
    class FailedUpdationRecords
    {
        public FailedUpdationRecords()
        {

        }

       
        public string UploadedDt { get; set; }
        public string UploadedDttm { get; set; }
        public string UploadedBy { get; set; }
        public List<CwtCsvRecords> FailedRecords { get; set; }
        public CwtCsvRecords FailedRecord { get; set; }
    }
}

