﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CWTBulkApproveAndReject.Model
{
    class CwtInvoiceDetails
    {
        public CwtInvoiceDetails()
        {

        }

        public CwtInvoiceDetails(int id)
        {
            Id = id;
        }

        public int Id { get; set; }
        public string AccentureGSTNo { get; set; }

        public int CWTInvoiceId { get; set; }
        public float TotalGSTonTicketValueCompTax { get; set; }
        public int InvoiceBatchId { get; set; }
        public string InternalInvoiceRefNo { get; set; }
        public string StatusCd { get; set; }
        public string TAWBSeNo { get; set; }

        public string TaxRate { get; set; }
        public float CCGST { get; set; }

        public string TaxType { get; set; }

        public float TCGST { get; set; }
        public string EmployeeNo { get; set; }
        public string DivisionNm { get; set; }
        public string InvoiceDt { get; set; }

        public string regionPOS { get; set; }

        public string VendorInvoiceCRNo { get; set; }
        public string PaxNm { get; set; }
        public string AirLineNm { get; set; }
        public string FlightNo { get; set; }
        public string AirLineCd { get; set; }
        public string TicketNo { get; set; }

        public float TIGST { get; set; }

        public float TotalGSTonMerchantFee { get; set; }

        public float TotalGSTonTransacFee { get; set; }
        public string Sector { get; set; }

        public int SerialNo { get; set; }
        public string IssuanceDt { get; set; }

        public float K3IGSTTicketValue { get; set; }
        public string TravelDt { get; set; }
        public string ReturnDt { get; set; }
        public float BasicAmt { get; set; }
        public string BIZPlace { get; set; }
        public float YQTaxAmt { get; set; }
        public float DomesticTaxAmt { get; set; }
        public float InternationalTaxAmt { get; set; }
        public float ServiceTaxAmt { get; set; }

        public int StatusId { get; set; }
        public float InvoiceAmt { get; set; }
        public float CommAmt { get; set; }
        public float CSGSTOrCUGST { get; set; }
        public float ALIncvORAmt { get; set; }
        public float NetDiscountAmt { get; set; }
        public string InvoiceNo { get; set; }
        public float CRNInvoiceAmt { get; set; }
        public float XxlnAmt { get; set; }
        public float MgmtFeesAmt { get; set; }

        public float MIGST { get; set; }
        public float BankChargesAmt { get; set; }
        public float NetHCAmt { get; set; }
        public float NetPayAmt { get; set; }
        public string TRFNo { get; set; }

        public float TSGSTOrTUGST { get; set; }
        public string DestinationCd { get; set; }
        public string BusinessUnitCd { get; set; }
        public string IntnlDomInd { get; set; }
        public string BookingCancelInd { get; set; }
        public int NoOfTrips { get; set; }
        public string LocationCd { get; set; }
        public string UATPOrNonUATPInd { get; set; }

        public string VendorGSTNumber { get; set; }
        public string SuperSaverOrNormalInd { get; set; }
        public string ClassOfTravelInd { get; set; }
        public string ReIssuanceNo { get; set; }
        public string CNNo { get; set; }
        public float JnTaxBaseAmt { get; set; }
        public float ServiceTaxOnJnBaseAmt { get; set; }
        public float SBCOnJnBaseAmt { get; set; }
        public float KKCOnJnBastAmt { get; set; }
        public float BankChargeServiceTaxAmt { get; set; }
        public float MgmtFeesServiceTaxAmt { get; set; }
        public string MainInvoiceNo { get; set; }

        public string EmpStatus { get; set; }

        public float CIGST { get; set; }

        public float MCGST { get; set; }
        public string PNRDetails { get; set; }
        public string GSAPNR { get; set; }

        public string HSNSAC { get; set; }
        public string Remarks { get; set; }
        public string RTPRemarks { get; set; }
        public string CN { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDttm { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDttm { get; set; }

        public float MSGSTOrMUGST { get; set; }
        public string AEEAction { get; set; }
        public string RTPAction { get; set; }
        public string LGIGenerated { get; set; }

        public string LocationAddress { get; set; }
        //public string InvoiceErrorDetails { get; set; }
        public string AEEApproved { get; set; }
        public string RTPApproved { get; set; }
        public string DFMURN { get; set; }
        public string EmpCompanyCd { get; set; }
        public string WBSECompanyCd { get; set; }
        public string EntrypageValue { get; set; }
        public string ActionMethodStatus { get; set; }
        public string InvoicePDF { get; set; }
        public string TicketPDF { get; set; }
        public string SupportPDFs { get; set; }

        public List<String> SupportPDFFiles { get; set; }
        public string Location { get; set; }
        public string IsGSTError { get; set; }
        public int GSTID { get; set; }
        public int BusinessPlaceId { get; set; }
        public string TRCopyPDF { get; set; }
        public string OriginalInvoicePDF { get; set; }
        public string CreditNotePDF { get; set; }
        public string InvoiceStatusCd { get; set; }
        public string AirlineInvoice { get; set; }
        public string IsTrValidated { get; set; }
        public string AirLineInvoiceFileName { get; set; }
        public float NetPayDifference { get; set; }
        public string IsBatchValidated { get; set; }
        public double ADF { get; set; }
        public double USF { get; set; }
        public double CuteFee { get; set; }
        public double SeatFees { get; set; }
        public double SSR { get; set; }
        public double OtherChgs { get; set; }
        public double TaxableValue { get; set; }
        public double AirTravellnRelatedChg { get; set; }
        public double AirportChgs { get; set; }
        public double AAT { get; set; }
        public string OrgInvNo { get; set; }
        public string OrgInvDt { get; set; }
        public string NDCInvoiceStatus { get; set; }
        public string WireId { get; set; }
        public string VendorCd { get; set; }
        public string SearchInvoiceDt { get; set; }

        public string SearchIssuanceDt { get; set; }

        public string SearchModifiedDttm { get; set; }

        public string SearchReturnDt { get; set; }

        public string SearchTravelDt { get; set; }

        public string SearchInvoiceSubmittedDt { get; set; }

        public string aeeActionDate { get; set; }

        public string SearchCreatedDttm { get; set; }

        public string SearchResubmissionDttm { get; set; }
    }
}
