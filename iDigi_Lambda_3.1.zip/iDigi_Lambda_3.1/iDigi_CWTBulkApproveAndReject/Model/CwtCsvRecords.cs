﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iDigi_CWTBulkApproveAndReject.Model
{
    public class CwtCsvRecords
    {
        public CwtCsvRecords()
        {

        }

        public string VendorInvoiceCRNo { get; set; }
        public string RTPAction { get; set; }
        public string RTPRemarks { get; set; }
        public string Error { get; set; }
       
       
    }
}
