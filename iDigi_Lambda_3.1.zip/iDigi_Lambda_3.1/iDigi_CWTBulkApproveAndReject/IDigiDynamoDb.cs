﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using iDigi_CWTBulkApproveAndReject.Model;
using Amazon.DynamoDBv2.DataModel;

namespace iDigi_CWTBulkApproveAndReject
{
    public class IDigiDynamoDb
    {
        static IAmazonDynamoDB dbClient { get; set; }
        public static Amazon.DynamoDBv2.DataModel.DynamoDBContext db { get; set; }

        public IDigiDynamoDb()
        {
            dbClient = new AmazonDynamoDBClient();
            db = new Amazon.DynamoDBv2.DataModel.DynamoDBContext(dbClient);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InsertAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            var document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.PutItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tObject"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task UpdateItemAsync<T>(T tObject, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Document document = IDigiDynamoDocumentConverter.ToDocument(tObject);
            await table.UpdateItemAsync(document);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="scanFilterCondition"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<List<T>> ScanAsync<T>(ScanFilter scanFilterCondition, string tableName, ILambdaContext context)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            List<Document> documentList = new List<Document>();
            do
            {
                documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="tableName"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InsertLambdaLogDetails(object obj, string tableName, ILambdaContext context)
        {
            LambdaLogDetails log = new LambdaLogDetails();
            log.LambdaRequestId = context.AwsRequestId;
            log.LambdaName = context.FunctionName;
            log.LambdaLogGroupName = context.LogGroupName;
            log.LambdaLogStreamName = context.LogStreamName;
            log.LambdaExeStartDttm = DateTime.UtcNow.ToString("yyyy - MM - dd HH: mm:ss.fff");
            TimeZoneInfo IndianTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
            log.LambdaExeStartDttmIst = TimeZoneInfo.ConvertTime(DateTime.UtcNow, IndianTimeZone).ToString("mm/dd/yyyy hh:mm:ss.fff");
            log.ModifiedDttm = DateTime.UtcNow.ToString("mm/dd/yyyy HH:mm");
            await InsertAsync<LambdaLogDetails>(log, tableName, context);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj">Object with only attributes need update has to be intialised otherwise all other atribute
        /// values will be over written, primary keys are mondatary 
        /// </param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public async Task UpdateLambdaLogDetailsWithException(Exception e, string tableName, ILambdaContext context)
        {
            LambdaLogDetails log = new LambdaLogDetails();
            log.LambdaRequestId = context.AwsRequestId;
            log.LambdaName = context.FunctionName;
            log.InnerExceptionMsg = e.InnerException.Message;
            log.ExceptionMsg = e.Message;
            log.StackTaceStr = e.StackTrace;
            log.ModifiedDttm = DateTime.UtcNow.ToString("mm/dd/yyyy hh:mm:ss.fff");
            await UpdateItemAsync<LambdaLogDetails>(log, tableName, context);
        }

        public async Task UpdateLambdaLogDetailsWithEndTimeDetails(string tableName, ILambdaContext context)
        {
            LambdaLogDetails log = new LambdaLogDetails();
            log.LambdaRequestId = context.AwsRequestId;
            log.LambdaName = context.FunctionName;
            log.LambdaExeEndDttm = DateTime.UtcNow.ToString("mm/dd/yyyy hh:mm:ss.fff");
            TimeZoneInfo IndianTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
            log.LambdaExeEndDttmIst = TimeZoneInfo.ConvertTime(DateTime.UtcNow, IndianTimeZone).ToString("mm/dd/yyyy hh:mm:ss.fff");
            log.ModifiedDttm = DateTime.UtcNow.ToString("mm/dd/yyyy HH:mm");
            await UpdateItemAsync<LambdaLogDetails>(log, tableName, context);
        }

        public async Task<List<T>> FilterScanSpecificAttribute<T>(ScanOperationConfig scanFilterCondition, string tableName)
        {
            Table table = Table.LoadTable(dbClient, tableName);
            Search search = table.Scan(scanFilterCondition);

            List<T> resultList = new List<T>();
            List<Document> documentList = new List<Document>();
            do
            {
                documentList = await search.GetNextSetAsync();
                foreach (var document in documentList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            } while (!search.IsDone);

            return resultList;
        }

    }
}

