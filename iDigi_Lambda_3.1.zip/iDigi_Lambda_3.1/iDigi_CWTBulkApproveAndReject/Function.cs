using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.Lambda.Model;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using CsvHelper;
using iDigi_CWTBulkApproveAndReject.Model;
using MoreLinq;
using Newtonsoft.Json;
using OfficeOpenXml;




// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace iDigi_CWTBulkApproveAndReject
{
    public class Function
    {
        IAmazonS3 S3Client { get; set; }
        IAmazonLambda LambdaClient { get; set; }
        IAmazonDynamoDB DbClient { get; set; }

        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {

            S3Client = new AmazonS3Client();
            LambdaClient = new AmazonLambdaClient();
            DbClient = new AmazonDynamoDBClient();
        }

        /// <summary>
        /// Constructs an instance with a preconfigured S3 client. This can be used for testing the outside of the Lambda environment.
        /// </summary>
        /// <param name="s3Client"></param>
        public Function(IAmazonS3 s3Client)
        {
            this.S3Client = s3Client;
        }

        public static string CloudEnvironment
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("Environment");
            }
        }
        public static TimeZoneInfo INDIAN_ZONE
        {

            get
            {
                if (System.Environment.GetEnvironmentVariable("DebugEnvironMent") == "true")
                { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
                else
                {
                    return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
                }
                //return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            }
        }
        public static string DebugEnvironMent
        {
            get
            {
                return System.Environment.GetEnvironmentVariable("DebugEnvironMent");
            }

        }
        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an S3 event object and can be used 
        /// to respond to S3 notifications.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(S3Event evnt, ILambdaContext context)
        {
            context.Logger.Log($"Lambda invoked");
            var s3Event = evnt.Records?[0].S3;
            string bucketName = evnt.Records[0].S3.Bucket.Name;
            try
            {
                string objectKeyForFetchingVendorName =
                System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' '));
                //string fileColsDbColsMappingTable = string.Empty;
                //string poTransactionTable = string.Empty;

                string dataInserterLambda = string.Empty;
                //string approvedExceptionTable = string.Empty;
                string cwtInvoiceTableName = string.Empty;

                //string cwtHistoryLogTableName = string.Empty;



                string PARFileUploadTableName = string.Empty;

                //string amountCategoryMasterTable = string.Empty;
                //string EYPrivateBucket = string.Empty;

                if (CloudEnvironment.ToLowerInvariant() == "prod")
                {
                    //fileColsDbColsMappingTable =
                    //    CommonConstants.AirId + "_" + CommonConstants.FileColsDbColsMappingTable;
                    //poTransactionTable = CommonConstants.AirId + "_" + CommonConstants.PoTransactionTable;

                    //dataInserterLambda = CommonConstants.POtransactionMasterDataInserterLambda;
                    //approvedExceptionTable =
                    //    CommonConstants.AirId + "_" + CommonConstants.ApprovedExceptionInvoicesTable;
                    //cwtEtravelDataTable = CommonConstants.AirId + "_" + CommonConstants.CWTEtravelTable;
                    //airlineInvoiceDataTable = CommonConstants.AirId + "_" +
                    //                          CommonConstants.AirlineInvoiceTable;

                    //vendorMasterTableName = CommonConstants.AirId + "_" + CommonConstants.VendorMasterTable;

                    //PARFileUploadTableName = CommonConstants.AirId + "_" + CommonConstants.PARFileUploadTableName;
                    //amountCategoryMasterTable = CommonConstants.AirId + "_" + CommonConstants.AmountCategoryMasterTable;

                    //EYPrivateBucket = CommonConstants.EYPrivateBucketforProd;
                    cwtInvoiceTableName = CommonConstants.AirId + "_" + CommonConstants.CWTInvoicesTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_"  + CommonConstants.PARFileUploadTableName;


                }
                else
                {
                    //fileColsDbColsMappingTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                    //                             CommonConstants.FileColsDbColsMappingTable;
                    //poTransactionTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                    //                     CommonConstants.PoTransactionTable;
                    //vendorMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                    //                    CommonConstants.VendorMasterTable;
                    //dataInserterLambda = CommonConstants.POtransactionMasterDataInserterLambdaForStageAndDev;

                    cwtInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTInvoicesTable;
                    //cwtEtravelDataTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.CWTEtravelTable;
                    //airlineInvoiceDataTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.AirlineInvoiceTable;
                    //GenericTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.NewGenericInvoicetable;
                    //IQNTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.IQNInvoiceTable;
                    //VisaTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.UdaanInvoiceTable;
                    //vendorMasterTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VendorMasterTable;
                    //RealEstateTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.RealEstateInvoicesNewTable;
                    PARFileUploadTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PARFileUploadTableName;
                    //gstr2aTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" +
                    //             CommonConstants.GSTR2aInvoiceTable;
                    //APInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.APInvoicesTable;
                    //ForexInvoiceTableName = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.ForexInvoicesTable;
                    //amountCategoryMasterTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.AmountCategoryMasterTable;

                    //EYPrivateBucket = CommonConstants.EYPrivateBucketforStage;
                }
                context.Logger.Log($"{CloudEnvironment}");
                string[] objectKeySplited = objectKeyForFetchingVendorName.Split('/');

                #region CWT BULK Approval Rejection
                // path : /public/PostApprovalRejection 

                //doubt
                if (objectKeySplited[1].ToLowerInvariant() == CommonConstants.S3_Post_ApprovalRejection_Path.ToLowerInvariant())
                {
                    Console.WriteLine("invoked CWT bulk approval rejection part of lambda");
                    IDigiS3 S3 = new IDigiS3();
                    string FileName = (System.Net.WebUtility.UrlDecode(evnt.Records[0].S3.Object.Key.Replace('+', ' ')).Replace(CommonConstants.PARFolder_FilePath + "/", ""));
                    context.Logger.LogLine($"Start :{context.FunctionName} has invoked in {CloudEnvironment} environment by {FileName}");
                    Console.WriteLine("bucketName - " + bucketName + " , PARcsvdumpFolder - " + CommonConstants.PARFolder_FilePath + " , FileName - " + FileName);
                    var csvFileData = await S3.GetFileFromS3(bucketName, CommonConstants.PARFolder_FilePath, FileName, context);
                    Console.WriteLine("PAR- got file from s3");
                    //Fetch all AEE Approved data from CWT Table
                    var allcwtInvoiceData = new List<CwtInvoiceDetails>();

                    var scanFilterCwtTable = new ScanFilter();
                    scanFilterCwtTable.AddCondition("AEEAction", ScanOperator.Equal, "Approved");
                    //doubt
                    ScanOperationConfig scanOperationConfigGenericTable = new ScanOperationConfig()
                    {
                        Filter = scanFilterCwtTable,
                        //Select = SelectValues.SpecificAttributes,
                        //AttributesToGet = new List<string> { "VendorRegisteredCd", "VendorInvoiceNumber", "DFMURN", "InvoiceHistoryLogs", "RTPRemarks", "InvoiceStatusCd", "AttachedFile" }
                    };
                    allcwtInvoiceData = await ScanAndFindTheInvoice<CwtInvoiceDetails>(new CwtInvoiceDetails(), cwtInvoiceTableName, scanOperationConfigGenericTable);
                    Console.WriteLine("Fetched cwt data Aee approved");


                    int TotalCount = 0;
                    int SuccessfullyChangedCount = 0;
                    CwtCsvRecords SuccessfulRecord = null;
                    List<CwtCsvRecords> SuccessfulRecordList = new List<CwtCsvRecords>();
                    CwtCsvRecords FailedRecord = null;
                    List<CwtCsvRecords> FailedRecordList = new List<CwtCsvRecords>();

                    if (csvFileData != null)
                    {
                        using (var csvReadData = new System.IO.StreamReader(csvFileData.ResponseStream))
                        {
                            Console.WriteLine($"Process: Now StreamReader is reading the data from the file {FileName}");
                            var csv = new CsvHelper.CsvReader(csvReadData);

                            csv.Configuration.HasHeaderRecord = false;//CSV file from the DFM does not have Header 

                            string VendorInvoiceCRNo = string.Empty;
                            string RTPAction = string.Empty;
                            string RTPRemarks = string.Empty;
                            //string fileName1 = string.Empty;
                            string fileName2 = string.Empty;
                            //var filePath1 = string.Empty;
                            var filePath2 = string.Empty;
                            var Email = string.Empty;
                            int count = 0;
                            while (csv.Read())
                            {
                                if (count > 0)

                                {

                                    int ChangeFlag = 0;
                                    SuccessfulRecord = new CwtCsvRecords();
                                    FailedRecord = new CwtCsvRecords();
                                    VendorInvoiceCRNo = csv.GetField<string>(0).Trim();
                                    RTPAction = csv.GetField<string>(1).Trim();
                                    //string tempVendorCd = csv.GetField<string>(1);
                                    RTPRemarks = csv.GetField<string>(2).Trim();
                                    Console.WriteLine(" VendorInvoiceCRNo" + VendorInvoiceCRNo + ",RTPAction " + RTPAction + ",RTPRemarks " + RTPRemarks + ", FileName " + FileName);
                                    RTPAction = RTPAction.ToLower().Trim();
                                    var Error = string.Empty;
                                    if (RTPAction == "approve")
                                    {
                                        RTPAction = "Approved";
                                    }
                                    else if (RTPAction == "reject")
                                    {
                                        RTPAction = "Rejected";
                                    }
                                    if (!string.IsNullOrWhiteSpace(VendorInvoiceCRNo) && !string.IsNullOrWhiteSpace(RTPAction))
                                    {
                                        if ((RTPAction == "Approved") || (RTPAction == "Rejected"))
                                        {
                                            TotalCount = TotalCount + 1;
                                            CwtInvoiceDetails updatedInvoiceData = new CwtInvoiceDetails();
                                            updatedInvoiceData = allcwtInvoiceData.FirstOrDefault(invoice => invoice.VendorInvoiceCRNo == VendorInvoiceCRNo);
                                            if (updatedInvoiceData != null)
                                            {
                                                if ((updatedInvoiceData.RTPAction == "Pending") || (updatedInvoiceData.RTPAction == ""))
                                                {
                                                    await CwtInvoiceUpdateStatus(VendorInvoiceCRNo, RTPAction, RTPRemarks, FileName, cwtInvoiceTableName, updatedInvoiceData, context, bucketName);
                                                    ChangeFlag = 1;
                                                    Console.WriteLine("CWT- updated one invoice from cwt table");
                                                }
                                                else
                                                {
                                                    Error = "RTP action cannot be taken on invoices that are already Approved or Rejected";
                                                }
                                            }
                                            else
                                            {
                                                Error = "Invoice is not AEE Approved";
                                            }
                                        }
                                        else 
                                        {
                                            Error = "RTP Action should be either Approve or Reject";
                                        }
                                        
                                    }
                                    else
                                    {
                                        context.Logger.Log($"Log : One of the following parameter is null or empty VendorInvoiceCRNo : {VendorInvoiceCRNo}, RTPAction :{RTPAction}");
                                        context.Logger.Log($"contd..  FileName :{FileName}");
                                        Error = "One of the following parameter is null or empty VendorInvoiceCRNo or RTP Action";
                                    }

                                    if (ChangeFlag == 0)
                                    {
                                        FailedRecord.VendorInvoiceCRNo = VendorInvoiceCRNo;
                                        FailedRecord.RTPAction = RTPAction;
                                        FailedRecord.RTPRemarks = RTPRemarks;
                                        FailedRecord.Error = Error;
                                        FailedRecordList.Add(FailedRecord);
                                    }
                                }
                                count++;
                            }



                            if (FailedRecordList.Count > 0)
                            {
                                fileName2 = "Fail_" + FileName;
                                if (fileName2.Contains("Fail"))
                                {

                                    filePath2 = "private/postapprovalrejection/cwt/RejectedDump";

                                }
                                var splittedname1 = FileName.Split('_');
                                string ToId = splittedname1[1];
                                //var scanFilterVendorTable = new ScanFilter();
                                //List<VendorMaster> UserData = new List<VendorMaster>();
                                //scanFilterVendorTable.AddCondition("VendorUserId", ScanOperator.Equal, ToId);
                                //ScanOperationConfig scanOperationConfigVendorTable = new ScanOperationConfig()
                                //{
                                //    Filter = scanFilterVendorTable
                                //};
                                //    UserData = await ScanAndFindTheInvoice<VendorMaster>(new VendorMaster(), vendorMasterTable, scanOperationConfigVendorTable);
                                //    foreach (var item in UserData)
                                //    {
                                //        Console.WriteLine("Fetched user's email" + item.Email);
                                //        Email = item.Email;
                                //    }
                                //}
                                //Console.WriteLine("Fetched user's email" + Email);
                                var splittedname = FileName.Split('_');
                                CwtPostApprovalRejectionEntities NewPARRecord = new CwtPostApprovalRejectionEntities();
                                NewPARRecord.ModuleNm = splittedname[0];
                                NewPARRecord.UploadDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                                NewPARRecord.UploadedBy = splittedname[1];
                                NewPARRecord.FileNm = FileName;
                                NewPARRecord.FilePath = CommonConstants.PARFolder_FilePath;
                                if (FailedRecordList.Count > 0)
                                {
                                    NewPARRecord.ErrorFileNm = fileName2;
                                    NewPARRecord.ErrorFilePath = filePath2;
                                    MemoryStream stream2 = new MemoryStream();
                                    using (var package = new ExcelPackage(new MemoryStream()))
                                    {
                                        Console.WriteLine("inside 1st excel generation");
                                        var workbook = package.Workbook;
                                        Console.WriteLine("work book");
                                        var worksheet = workbook.Worksheets.Add("Failed Invoices");
                                        Console.WriteLine("work Sheet");
                                        Console.WriteLine(FailedRecordList.Count);
                                        worksheet.Cells.LoadFromCollection(FailedRecordList, true, OfficeOpenXml.Table.TableStyles.None);
                                        Console.WriteLine("before saving");
                                        package.SaveAs(stream2);
                                        Console.WriteLine("after saving");
                                    }
                                    await S3.PutFileToS3(bucketName, filePath2, stream2, fileName2, context);
                                    Console.WriteLine("putting file" + fileName2 + "at path :" + filePath2);
                                }
                                NewPARRecord.TotalRecCnt = TotalCount.ToString();
                                NewPARRecord.ErrorRecCnt = (TotalCount - SuccessfullyChangedCount).ToString();
                                NewPARRecord.IsActive = 1;
                                IDigiDynamoDb db = new IDigiDynamoDb();
                                await db.InsertAsync<CwtPostApprovalRejectionEntities>(NewPARRecord, PARFileUploadTableName, context);
                                context.Logger.Log($"File Upload Data saved successfully for {FileName}");
                                Console.Write($"File Upload Data saved successfully for {FileName}");
                                //if (FailedRecordList.Count > 0)
                                //{
                                //    Console.WriteLine("entering failedrecord addition function");
                                //    await FailedRecordAddition(FailedRecordList, NewPARRecord.UploadedBy, Email, context);
                                //}

                            }
                        }
                        return;
                    }

                    #endregion
                    //return input?.ToUpper();

                }
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }

        private async Task CwtInvoiceUpdateStatus(string VendorInvoiceCRNo, string RTPAction, string RTPRemarks, string FileName, string tableName, CwtInvoiceDetails updatedInvoiceData, ILambdaContext context, string BucketName)
        {
            try
            {
                //string VisaHistoryLogTable = string.Empty;
                DateTime datetime = new DateTime();
                //if (CloudEnvironment.ToLowerInvariant() == "prod")
                //{
                //    VisaHistoryLogTable = CommonConstants.AirId + "_" + CommonConstants.VisaHistoryLogTable;
                //}
                //else
                //{
                //    VisaHistoryLogTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.VisaHistoryLogTable;
                //}


                Console.WriteLine($"Updating for {updatedInvoiceData.VendorInvoiceCRNo} - {updatedInvoiceData.VendorCd}");
                var splittedname = FileName.Split('_');
                CwtInvoiceDetails updateInvoiceData = new CwtInvoiceDetails();
                updateInvoiceData = updatedInvoiceData;
                updateInvoiceData.RTPRemarks = RTPRemarks;
                updateInvoiceData.ModifiedBy = splittedname[1];
                updateInvoiceData.RTPAction = RTPAction;
                //updateInvoiceData.RTPTeam = splittedname[1];
                updateInvoiceData.AccentureGSTNo = updateInvoiceData.AccentureGSTNo;
                updateInvoiceData.BIZPlace = updateInvoiceData.BIZPlace;
                updateInvoiceData.SearchModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("yyyy/MM/dd HH:mm");
                updateInvoiceData.ModifiedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
                Table table = Table.LoadTable(DbClient, tableName);
                var doc = IDigiDynamoDocumentConverter.ToDocument(updateInvoiceData);
                await table.PutItemAsync(doc);
                Console.WriteLine($"Updated for {updatedInvoiceData.VendorInvoiceCRNo} - {updatedInvoiceData.VendorCd}");

                //Console.WriteLine($"Updating History for {updatedInvoiceData.VendorInvoiceCRNo} - {updatedInvoiceData.VendorCd}");
                //InvoiceHistoryLogs Newlog = new InvoiceHistoryLogs();
                //{
                //    Newlog.SourceId = updatedInvoiceData.VendorRegisteredCd + "-" + updatedInvoiceData.VendorInvoiceNumber;
                //    Newlog.ModifiedBy = updatedInvoiceData.RTPTeam;
                //    Newlog.StatusCd = updatedInvoiceData.InvoiceStatusCd;
                //    Newlog.StatusDt = updatedInvoiceData.ModifiedDttm;
                //    Newlog.VendorCd = updatedInvoiceData.VendorCd;
                //    if (!string.IsNullOrEmpty(Newlog.StatusDt))
                //    {
                //        if (DateTime.TryParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out datetime))
                //        {
                //            Newlog.SearchStatusDt = DateTime.ParseExact(Newlog.StatusDt, "MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd HH:mm");
                //        }
                //    }
                //}
                //IDigiDynamoDb db = new IDigiDynamoDb();
                //await db.InsertAsync<InvoiceHistoryLogs>(Newlog, VisaHistoryLogTable, context);
                //if (!string.IsNullOrEmpty(updatedInvoiceData.AttachedFile))
                //{
                //    var sourcepath = CommonConstants.VisaInvoicePath;
                //    var destinationpath = CommonConstants.VisaRejectedInvoicePath;
                //    var respose = await CopyFileFromOneFolderToOther(BucketName, sourcepath, BucketName, destinationpath, updatedInvoiceData.AttachedFile);
                //    if (respose.HttpStatusCode == HttpStatusCode.OK)
                //    {
                //        Console.WriteLine("eNTERED STATTUS CODE DELTEE BLOCK " + " " + " -" + HttpStatusCode.OK);
                //        await DeleteFile(BucketName, sourcepath, updatedInvoiceData.AttachedFile);
                //    }
                //    context.Logger.Log($"Now the file { updatedInvoiceData.AttachedFile} associated with the invoice number { updatedInvoiceData.VendorInvoiceNumber} is moved to private {BucketName + destinationpath}");
                //}
                Console.WriteLine($"Updated for {updatedInvoiceData.VendorInvoiceCRNo} - {updatedInvoiceData.VendorCd}");
            }
            catch (Exception e)
            {
                context.Logger.LogLine($"{e.Message}");
                context.Logger.LogLine($"{e.InnerException}");
                context.Logger.LogLine($"{e.StackTrace}");
                throw;
            }
        }
        public async Task FailedRecordAddition(List<CwtCsvRecords> FailedRecordList, string UploadedBy, string Email, ILambdaContext context)
        {
            string PARFailedRecordsTable = string.Empty;
            if (CloudEnvironment.ToLowerInvariant() == "prod")
            {
                PARFailedRecordsTable = CommonConstants.AirId + "_" + CommonConstants.PARFailedRecordsTableName;
            }
            else
            {
                PARFailedRecordsTable = CommonConstants.AirId + "_" + CloudEnvironment + "_" + CommonConstants.PARFailedRecordsTableName;
            }
            FailedUpdationRecords obj = new FailedUpdationRecords();
            obj.UploadedBy = UploadedBy;
            //obj.Email = Email;
            obj.UploadedDt = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy");
            obj.UploadedDttm = TimeZoneInfo.ConvertTime(DateTime.UtcNow, INDIAN_ZONE).ToString("MM/dd/yyyy HH:mm");
            obj.FailedRecords = new List<CwtCsvRecords>();
            obj.FailedRecord = new CwtCsvRecords();
            foreach (var item in FailedRecordList)
            {
                obj.FailedRecord.VendorInvoiceCRNo = item.VendorInvoiceCRNo;
                obj.FailedRecord.RTPAction = item.RTPAction;
                obj.FailedRecord.RTPRemarks = item.RTPRemarks;
                obj.FailedRecords.Add(obj.FailedRecord);
            }
            IDigiDynamoDb db = new IDigiDynamoDb();
            await db.InsertAsync<FailedUpdationRecords>(obj, PARFailedRecordsTable, context);
        }
        private async Task<List<T>> ScanAndFindTheInvoice<T>(T obj, string tableName, ScanOperationConfig scanOperationConfig)
        {
            Table table = Table.LoadTable(DbClient, tableName);
            Search search = table.Scan(scanOperationConfig);
            List<T> resultList = new List<T>();
            int count = 0;
            do
            {
                count = count + 1;
                List<Document> docList = await search.GetNextSetAsync();
                foreach (var document in docList)
                {
                    resultList.Add(IDigiDynamoDocumentConverter.ToObject<T>(document));
                }
            }
            while (!search.IsDone);
            Console.WriteLine($"Data :Total number of iteration  :{count}");
            Console.WriteLine($"Data :Total no of items(rows) returned for {obj.GetType().Name} :{resultList.Count}");
            return resultList;
        }
    }
}