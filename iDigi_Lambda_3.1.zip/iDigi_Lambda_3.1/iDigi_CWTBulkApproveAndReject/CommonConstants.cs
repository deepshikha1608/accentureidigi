﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iDigi_CWTBulkApproveAndReject
{
    public static class CommonConstants
    {
        public const string AirId = "7433";

        public const string LambdaLogDetailsTable = "LambdaLogDetails";
        public const string FileColsDbColsMappingTable = "FileColsDBColsMapping";
        public const string PoTransactionTable = "POTransactions";
        public const string VendorMasterTable = "VendorMaster";
        public const string ApprovedExceptionInvoicesTable = "ApprovedExceptionInvoices";
        //public const string CWTEtravelTable = "CwtEtravelData";
        //public const string RealEstateApprovedExceptionTable = "RealEstateApprovedExceptionInvoices";
        //public const string AirlineInvoiceTable = "AirlineInvoice";
        //public const string GSTR2aInvoiceTable = "GSTR2AInvoices";
        public const string AmountCategoryMasterTable = "AmountCategoryMaster";


        public const string PO_FileFolder = "PO";
        //public const string VendorMaster_FileFolder = "Vendor";
        public const string ApprovedException_FileFolder = "approvedexception";

        //public const string AirlineCreditTakenUpdateCsvFoplder = "airlinebulkapprovecsv";
        //public const string GSTR2ACsvfolderPath = "gstr2acsv";
        // public const string CWTEtravelData_FilePath = "cwtetraveldata";
        //public const string CWTEtravelData_FilePath = "etravel";
        //public const string Procurement_POTrasaction_FilePath = "private/procurement/PO";
        public const string Procurement_VendorMaster_FilePath = "private/procurement/Vendor";
        //public const string AirlineCreditTaken_FilePath = "private/cwt/airlinebulkapprovecsv";
        //public const string Procurement_ApprovedException_FilePath = "private/procurement/approvedexception";
        //public const string Procurement_CWTEtravelData_FilePath = "private/cwt/etravel";
        //public const string GSTR2A_FilePath = "private/gstr2acsv";

        //public const string RealEstateApprovedException_FileFolder = "realestateapprovedexception";
        //public const string Procurement_RealEstateApprovedException_FilePath = "private/procurement/realestateapprovedexception";

        //public const string POTrans_FileModuleCd = "POTRANS";
        //public const string GSTR2A_FileModuleCd = "GSTR2A";
        //public const string POTrans_CSVFile_HeaderColType = "HR";





        public const string VendorMaster_FileModuleCd = "VNDRMAS";
        public const string VendorMaster_CSVFile_HeaderColType = "HR";

        public const string ApprovedException_FileModuleCd = "APVDEXPN";
        public const string ApprovedException_CSVFile_HeaderColType = "HR";

        //public const string CWTEtravelData_FileModuleCd = "CWTETRAVEL";
        //public const string CWTEtravelData_CSVFile_HeaderColType = "HR";


        public const string POtransactionMasterDataInserterLambdaForStageAndDev = "7433_iDIgi_RTPValidator";
        public const string POtransactionMasterDataInserterLambda = "7433_iDIgi_CSVDataInserter";

        public const string ProcurementTeam = "Procurement";

        public const string IsActiveTRUE = "TRUE";
        public const string EtravelJob = "EtravelEbiJOb";
        public const string S3_Post_ApprovalRejection_Path = "bulkapprovereject";
        public const string S3_NDC_PaymentStatusUpdate_Path = "ndc/ndcpaymentstatuscsv";
        public const string NewGenericInvoicetable = "GenericInvoices";
        public const string IQNInvoiceTable = "IQNInvoices";
        public const string UdaanInvoiceTable = "VisaInvoiceDetails";
        public const string RealEstateInvoicesNewTable = "RealEstateInvoices";
        public const string APInvoicesTable = "APInvoices";
        public const string CWTInvoicesTable = "CWTInvoice";
        public const string GenericHistoryLogTable = "GenericInvoiceHistoryLogs";
        public const string VisaHistoryLogTable = "VisaInvoiceHistoryLogs";
        public const string IQNHistoryLogTable = "IqnInvoiceHistoryLogs";
        public const string RealEstateHistoryLogTable = "RealEstateInvoiceHistoryLogs";
        public const string APHistoryLogTable = "APInvoiceHistoryLogs";
        public const string ForexHistoryLogTable = "ForexHistoryLogs";
        public const string IQN_NonCompliant_STATUS = "Non Compliant";
        public const string PARFileUploadTableName = "PARFileUploadDetails";
        public const string PARFailedRecordsTableName = "PARFailedRecords";
        public const string Approved_PAR_Path = "/ApprovedDump";
        public const string Rejected_PAR_Path = "/RejectedDump";
        public const string PARFolder_FilePath = "public/bulkapprovereject";

        public const string RealEstateInvoicePath = "private/realestate/invoice";
        public const string GenericInvoicePath = "private/generic/invoice";
        public const string VisaInvoicePath = "private/udaan/invoice";
        public const string IQNInvoicePath = "private/iqn/invoice";
        public const string ForexInvoicePath = "private/forex/invoice";

        //public const string RealEstateRejectedInvoicePath = "private/realestate/rejectedinvoices";
        //public const string GenericRejectedInvoicePath = "private/generic/rejectedinvoices";
        //public const string VisaRejectedInvoicePath = "private/udaan/rejectedinvoices";
        //public const string IQNRejectedInvoicePath = "private/iqn/rejectedinvoices";
        //public const string ForexRejectedInvoicePath = "private/forex/rejectedinvoices";

        public const string EYcsvFile_FolderPath = "EY";
        public const string EYPrivatePath = "private/EY";
        public const string EYPrivateBucketforProd = "7433-idigi-prod";
        public const string EYPrivateBucketforStage = "7433";


        public const string NDCPaymentStatusUpdate_FilePath = "MySupplierPortal";
        public const string ndc_FileFolder = "private/MySupplierPortal";

        //public const string Module_ReasEstate = "realestate";
        //public const string Module_RE = "re";//this is also for RealEstate
        //public const string Module_IQN = "iqn";
        //public const string Module_Generic = "generic";
        //public const string Module_Udaan = "visa";
        //public const string Module_Forex = "forex";


        //public const string GSTR2A_Matched_STATUS = "GSTR2AMatched";
        //public const string GSTR2A_Mismatched_STATUS = "GSTR2AMismatched";
        //public const string GSTR2A_Missing_STATUS = "GSTR2AMissing";

        //public const string UdaanVendorCode = "100252385";
        //public const string FCMVendorCode = "100407668";
    }
}
